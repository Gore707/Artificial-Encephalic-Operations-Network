from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.cognitive_state_comparator import CognitiveStateComparator
from aeon.cognitive_divergence import CognitiveDivergenceService
from aeon.cognitive_guardian import CognitiveGuardian
class Stub:
 def __init__(self):self.metadata=self
 def verify(self,x):return {"all_ok":True}
 def assess(self,x):return "assessment"
class Empty:pass
def state(c,name,x):
 return c.create_state(name,{"x":x},{"x":"Hz"},{"x":"DERIVED"},{"x":1.0},{"x":"test"})
def test_guardian_integrates_comparison_divergence_and_authority_boundary():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);cmp=CognitiveStateComparator(db,a);div=CognitiveDivergenceService(db,a,cmp);stub=Stub()
  g=CognitiveGuardian(db,a,Empty(),cmp,stub,Empty(),div);ref=state(cmp,"ref",1);obs=state(cmp,"obs",3)
  case=g.create_case("case",ref.state_id,"meta","series");assert g.assess_reconstruction(case.case_id)=="assessment"
  q=g.compare_to_reference(case.case_id,obs.state_id);assert q.metrics["mae"]==2
  d=g.record_divergence(case.case_id,obs.state_id,1,"ms");assert d.rmse==2
  r=g.status_report(case.case_id);assert r["safety_authority"]=="AEON SAFETY KERNEL / DETERMINISTIC" and r["identity_status"]=="UNDETERMINED"
