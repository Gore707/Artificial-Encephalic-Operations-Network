from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.safety_kernel import SafetyKernel
from aeon.neural_safety import NeuralSafetyPolicies,GenesisValidator,NeuralSafetyError

def setup(t):
 db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);k=SafetyKernel(db,a);return db,a,k,NeuralSafetyPolicies(db,a,k),GenesisValidator(db,a)

def test_model_specific_policy_creates_deterministic_bounds():
 with tempfile.TemporaryDirectory() as t:
  db,a,k,p,g=setup(t);p.register_policy("model.x.rate",0,100,"HOLD_NEW_WORK","declared by model")
  assert len(p.list())==1
  assert not k.evaluate("model.x.rate",50)
  d=k.evaluate("model.x.rate",101);assert d and k.hold_new_work

def test_genesis_passes_valid_recurrent_state():
 with tempfile.TemporaryDirectory() as t:
  db,a,k,p,g=setup(t)
  state={"nodes":[{"id":"a"},{"id":"b"}],"edges":[{"source":"a","target":"a"},{"source":"a","target":"b"}],
         "parameters":{"dt":0.001},"provenance":{"topology":"MEASURED","dt":"DERIVED"},
         "model_checks":[{"name":"declared-domain","passed":True}]}
  r=g.validate("model-1",state);assert r.passed and g.require_pass(r)
  ok,msg=a.verify();assert ok,msg

def test_genesis_blocks_invalid_or_unprovenanced_state():
 with tempfile.TemporaryDirectory() as t:
  db,a,k,p,g=setup(t)
  state={"nodes":[{"id":"a"},{"id":"a"}],"edges":[{"source":"a","target":"missing"}],
         "parameters":{"x":float("inf")},"provenance":{"x":"MADE_UP"},"model_checks":[]}
  r=g.validate("bad",state);assert not r.passed
  try:g.require_pass(r)
  except NeuralSafetyError:pass
  else:raise AssertionError("invalid genesis state allowed to execute")
