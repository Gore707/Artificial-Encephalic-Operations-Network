from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_cache_virtual_device import NeuralCacheVirtualDevice
from aeon.neural_cache_block import NeuralCacheBlockStore
from aeon.neural_cache_migration import NeuralCacheMigration
def test_verified_cross_device_copy_and_source_preservation():
 with tempfile.TemporaryDirectory() as x:
  root=Path(x);db=StateDatabase(root/"s.db");a=AuditTrail(db);ds=NeuralCacheVirtualDevice(db,a,root/"cache")
  d1=ds.create("source",3*1024*1024);d2=ds.create("target",3*1024*1024);bs=NeuralCacheBlockStore(db,a,ds)
  payload=b"state-vector"*5000;src=bs.write(d1.device_id,payload);m=NeuralCacheMigration(db,a,ds,bs)
  q=m.transfer(src.block_id,d2.device_id,"MIGRATE");assert m.verify(q.migration_id)["all_ok"]
  assert bs.read(q.target_block_id)==payload and bs.read(src.block_id)==payload
