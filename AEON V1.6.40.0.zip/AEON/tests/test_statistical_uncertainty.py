from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.statistical_uncertainty import StatisticalUncertaintyAnalysis,UncertaintyAnalysisError
def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);d=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"));return d,StatisticalUncertaintyAnalysis(d,a)
def test_stats_and_epistemics():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);d,u=setup(root);p=root/"m.csv";p.write_text("x\n1\n2\n3\n4\n");ds=d.register_file(p,"m","HARDWARE","MEASURED");s=u.summarize(ds.dataset_id,"x");assert s.n==4 and s.mean==2.5 and s.evidence_class=="HARDWARE" and s.provenance=="MEASURED" and s.standard_error is not None
def test_rss():
 with tempfile.TemporaryDirectory() as t:
  d,u=setup(Path(t));q=u.propagate_independent(10,{"a":3,"b":4},2);assert q.standard_uncertainty==5 and q.lower==0 and q.upper==20 and "independent" in q.method
def test_negative_rejected():
 with tempfile.TemporaryDirectory() as t:
  d,u=setup(Path(t))
  try:u.propagate_independent(1,{"bad":-1})
  except UncertaintyAnalysisError:pass
  else:raise AssertionError("negative uncertainty accepted")
