from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_cache_virtual_device import NeuralCacheVirtualDevice
from aeon.neural_cache_block import NeuralCacheBlockStore
from aeon.neural_cache_redundancy import NeuralCacheRedundantStorage
def test_replica_recovery_after_source_corruption():
 with tempfile.TemporaryDirectory() as x:
  root=Path(x);db=StateDatabase(root/"s.db");a=AuditTrail(db);ds=NeuralCacheVirtualDevice(db,a,root/"cache")
  d1=ds.create("a",2*1024*1024);d2=ds.create("b",2*1024*1024);bs=NeuralCacheBlockStore(db,a,ds)
  payload=b"critical-neural-state"*1000;src=bs.write(d1.device_id,payload)
  rs=NeuralCacheRedundantStorage(db,a,ds,bs);r=rs.create(src.block_id,(d2.device_id,));assert rs.verify(r.replica_set_id)["all_ok"]
  p=Path(src.path);raw=bytearray(p.read_bytes());raw[-1]^=1;p.write_bytes(raw)
  v=rs.verify(r.replica_set_id);assert v["status"]=="DEGRADED" and v["recoverable"] and rs.recover(r.replica_set_id)==payload
