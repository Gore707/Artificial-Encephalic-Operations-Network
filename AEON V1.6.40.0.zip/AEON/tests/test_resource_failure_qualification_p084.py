from pathlib import Path
import tempfile,json
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.resource_failure_qualification import ResourceFailureQualification
def test_resource_fault_decisions():
 with tempfile.TemporaryDirectory() as x:
  q=ResourceFailureQualification(StateDatabase(Path(x)/"s.db"),AuditTrail(StateDatabase(Path(x)/"s.db")))
  assert q.disk_capacity(100,90,20).passed
  assert q.interrupted_write(b"known-good",b"partial-new",False).passed
  t=q.thermal_limit(95,75,90);assert t.passed and json.loads(t.observed_json)["action"]=="HOLD"
  m=q.memory_pressure(98,100,.95);assert m.passed and json.loads(m.observed_json)["action"]=="HOLD_NEW_WORK"
