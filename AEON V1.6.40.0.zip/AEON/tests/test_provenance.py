from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.workspaces import WorkspaceStore
from aeon.provenance import ImmutableSourceStore, ProvenanceStore
from aeon.data_objects import DataObjectStore, DataObjectError

def test_immutable_source_and_provenance():
    with tempfile.TemporaryDirectory() as tmp:
        p=Path(tmp); state=p/"state"; src=p/"capture.bin"
        src.write_bytes(b"measured-neural-source")
        db=StateDatabase(state/"aeon_state.sqlite3")
        ws_store=WorkspaceStore(state,db); ws=ws_store.create("Acquisition")
        imm=ImmutableSourceStore(p/"immutable")
        prov=ProvenanceStore(db)
        objects=DataObjectStore(db,ws_store,imm,prov)
        obj=objects.create(
            ws.workspace_id,"dataset","Raw Capture",
            source_path=str(src), preserve_source=True,
            provenance_class="MEASURED", operation="acquire",
            agent="test-instrument", confidence=1.0,
            evidence={"modality":"synthetic-test"},
        )
        assert obj.immutable_source
        assert objects.verify_source(obj.object_id)[0] is True
        history=prov.history(obj.object_id)
        assert history[0].classification=="MEASURED"
        try:
            objects.delete(obj.object_id)
        except DataObjectError:
            pass
        else:
            raise AssertionError("immutable source object was deletable")
