from aeon.accelerators import AcceleratorDiscovery, AcceleratorDevice

def test_discovery_never_fabricates_required_fields():
    inv=AcceleratorDiscovery().discover()
    assert inv.timestamp_unix > 0
    assert isinstance(inv.probes, tuple)
    for d in inv.devices:
        assert d.name
        assert d.vendor
        assert d.backend
        assert d.source
        if d.memory_total_bytes is not None:
            assert d.memory_total_bytes > 0
        if d.memory_free_bytes is not None:
            assert d.memory_free_bytes >= 0
        if d.utilization_percent is not None:
            assert 0 <= d.utilization_percent <= 100

def test_dedupe_prefers_first_provider_record():
    a=AcceleratorDevice("ROCm","amd:0","Radeon Test","AMD",1,None,None,None,None,"rocm-smi")
    b=AcceleratorDevice("OS_VISIBLE","display:0","Radeon Test","AMD",None,None,None,None,None,"EnumDisplayDevicesW")
    out=AcceleratorDiscovery._dedupe([a,b])
    assert len(out)==1
    assert out[0].backend=="ROCm"
