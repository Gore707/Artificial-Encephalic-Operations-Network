from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.scientific_visualization_studio import ScientificVisualizationStudio,VisualizationStudioError
def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);lab=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"))
 return a,lab,ScientificVisualizationStudio(lab,a)
def test_numeric_columns_and_plot_preserve_epistemics():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,lab,v=setup(root);p=root/"trace.csv";p.write_text("time,signal,label\n0,1,a\n1,2,b\n2,4,c\n")
  d=lab.register_file(p,"trace","IMPORTED","MEASURED")
  cols=v.numeric_columns(d.dataset_id);assert [c.name for c in cols]==["time","signal"]
  plot=v.make_plot(d.dataset_id,"time","signal","s","mV")
  assert plot.x==(0.0,1.0,2.0) and plot.y==(1.0,2.0,4.0)
  assert plot.evidence_class=="IMPORTED" and plot.provenance=="MEASURED"
  ok,msg=a.verify();assert ok,msg
def test_non_numeric_pair_rejected():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,lab,v=setup(root);p=root/"x.csv";p.write_text("a,b\nx,y\n")
  d=lab.register_file(p,"x","SIMULATION","DERIVED")
  try:v.make_plot(d.dataset_id,"a","b")
  except VisualizationStudioError:pass
  else:raise AssertionError("non-numeric data plotted as numeric")
