from pathlib import Path
import json,tempfile,time
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.node_protocol import NodeRegistry,PROTOCOL_VERSION
from aeon.cluster import ClusterManager,DISCOVERY_MAGIC,ClusterError
def setup(t,stale=15):
 db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);n=NodeRegistry(db,a);c=ClusterManager(db,a,n,port=49231,stale_seconds=stale);return db,a,n,c
def test_discovery_packet_ingest():
 with tempfile.TemporaryDirectory() as t:
  db,a,n,c=setup(t)
  data=json.dumps({"magic":DISCOVERY_MAGIC,"node_id":"peer-x","hostname":"peer",
                   "protocol_version":PROTOCOL_VERSION,"service_port":50000}).encode()
  p=c.ingest(data,("10.1.2.3",49231))
  assert p.node_id=="peer-x" and p.address=="10.1.2.3:50000" and p.status=="ONLINE"
def test_self_and_incompatible_ignored_rejected():
 with tempfile.TemporaryDirectory() as t:
  db,a,n,c=setup(t)
  selfmsg=json.dumps({"magic":DISCOVERY_MAGIC,"node_id":c.local.node_id,"hostname":"self",
                      "protocol_version":PROTOCOL_VERSION,"service_port":49231}).encode()
  assert c.ingest(selfmsg,("127.0.0.1",49231)) is None
  bad=json.dumps({"magic":DISCOVERY_MAGIC,"node_id":"x","protocol_version":999}).encode()
  try:c.ingest(bad,("127.0.0.1",1))
  except ClusterError:pass
  else:raise AssertionError("incompatible peer accepted")
def test_liveness_stales_peer():
 with tempfile.TemporaryDirectory() as t:
  db,a,n,c=setup(t,stale=.01);p=n.observe("peer","1.2.3.4:9")
  c.refresh_liveness(now=p.last_seen_unix+1)
  assert n.get("peer").status=="STALE"
