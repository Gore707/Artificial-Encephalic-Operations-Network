from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab,DataLabError

def test_register_preserves_immutable_source_and_epistemics():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);db=StateDatabase(root/"s.db");a=AuditTrail(db);imm=ImmutableSourceStore(root/"immutable")
  lab=ApotheosisDataLab(db,a,imm);src=root/"neurons.csv";src.write_text("id,value\nn1,1\nn2,2\n")
  d=lab.register_file(src,"test neurons","IMPORTED","MEASURED",{"modality":"synthetic-test"})
  assert d.evidence_class=="IMPORTED" and d.provenance=="MEASURED"
  assert Path(d.metadata["immutable_path"]).read_bytes()==src.read_bytes()
  ok,_=lab.verify_source(d.dataset_id);assert ok
  view=lab.inspect_tabular(d.dataset_id);assert view["column_count"]==2 and len(view["rows"])==3
  ok,msg=a.verify();assert ok,msg

def test_invalid_epistemic_class_rejected():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);db=StateDatabase(root/"s.db");a=AuditTrail(db);lab=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"i"))
  p=root/"x.bin";p.write_bytes(b"x")
  try:lab.register_file(p,"x","REALISH","MEASURED")
  except DataLabError:pass
  else:raise AssertionError("invalid evidence class accepted")
