import ast
from pathlib import Path
def test_desktop_aeonservices_wiring_covers_every_field_by_keyword():
 root=Path(__file__).resolve().parents[1]
 api=ast.parse((root/"aeon"/"app_api.py").read_text(encoding="utf-8"))
 desk=ast.parse((root/"aeon"/"desktop.py").read_text(encoding="utf-8"))
 cls=next(n for n in api.body if isinstance(n,ast.ClassDef) and n.name=="AeonServices")
 fields=[n.target.id for n in cls.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name)]
 calls=[n for n in ast.walk(desk) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="AeonServices"]
 assert len(calls)==1
 call=calls[0]
 assert not call.args, "AeonServices must use keyword wiring to prevent positional drift"
 assert {k.arg for k in call.keywords}==set(fields)
