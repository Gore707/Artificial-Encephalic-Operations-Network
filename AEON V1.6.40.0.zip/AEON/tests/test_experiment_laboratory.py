from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.experiment_laboratory import ExperimentLaboratory,ExperimentLabError
def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);d=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"));return a,d,ExperimentLaboratory(db,a,d)
def test_definition_binds_dataset_and_hash():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,d,l=setup(root);p=root/"x.csv";p.write_text("t,v\n0,1\n");ds=d.register_file(p,"x","SIMULATION","DERIVED")
  e=l.define("baseline","SIMULATION",[ds.dataset_id],{"dt":0.001},"test hypothesis")
  assert e.status=="DEFINED" and e.dataset_ids==(ds.dataset_id,)
  ok,actual=l.verify_definition(e.experiment_id);assert ok and actual==e.definition_sha256
  assert l.get(e.experiment_id).parameters["dt"]==0.001
def test_unknown_dataset_rejected():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,d,l=setup(root)
  try:l.define("bad","IMPORTED",["missing"])
  except Exception:pass
  else:raise AssertionError("unknown input accepted")
  assert l.list()==()
