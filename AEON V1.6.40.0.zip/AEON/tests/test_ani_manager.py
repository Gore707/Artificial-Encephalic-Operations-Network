from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.ani_manager import ANIManager
class O:
 def __init__(self,**kw):self.__dict__.update(kw)
class S:
 def __init__(self,o,complete=None):self.o=o;self.complete=complete
 def get(self,x):return self.o
 def verify(self,x):return {"all_ok":True}
 def completeness(self,x):return self.complete or {"required_unknown_fields":()}
def test_ani_manager_assembles_but_never_auto_authorizes_execution():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db)
  sp=S(O(definition_sha256="a"*64),{"required_unknown_fields":("vm",)})
  tp=S(O(definition_sha256="b"*64,ani_spec_id="spec"))
  sy=S(O(definition_sha256="c"*64,topology_id="top"))
  dy=S(O(definition_sha256="d"*64,topology_id="top",synaptic_state_id="syn"))
  md=S(O(definition_sha256="e"*64,ani_spec_id="spec",topology_id="top"))
  m=ANIManager(db,a,sp,tp,sy,dy,md);q=m.create("candidate","spec","top","syn","dyn","meta")
  assert m.verify(q.ani_id)["all_ok"];r=m.readiness(q.ani_id)
  assert r["information_sufficiency"]=="UNDETERMINED" and r["genesis_status"]=="NOT_VALIDATED" and r["executable"] is False and r["required_unknown_fields"]==("vm",)
