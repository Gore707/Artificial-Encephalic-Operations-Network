from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.neuroimaging_ingestion import NeuroimagingIngestion
from aeon.volume_reconstruction import VolumeReconstructionService
from aeon.neuron_segmentation import NeuronSegmentationService,NeuronSegmentationError
def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);d=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"));n=NeuroimagingIngestion(db,a,d);v=VolumeReconstructionService(db,a,d,n);return d,n,v,NeuronSegmentationService(db,a,v)
def volume(root,d,n,v):
 p=root/"v.dat";p.write_bytes(b"volume");ds=d.register_file(p,"v","IMPORTED","MEASURED");img=n.register(ds.dataset_id,"EM","fixed",{"x_nm":4,"y_nm":4,"z_nm":30},["electron"],{"frame":"static"});return v.define(img.imaging_id,(10,10,10),{"x_nm":4,"y_nm":4,"z_nm":30},"SOURCE")
def test_segments_are_source_bound_and_provenance_explicit():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);d,n,v,s=setup(root);vol=volume(root,d,n,v);q=s.create(vol.volume_id,"manual-reviewed","1",[{"segment_id":"a","label":"candidate-cell","voxel_count":20,"centroid":[1,2,3],"confidence":0.9,"provenance":"MEASURED"},{"segment_id":"b","voxel_count":10,"provenance":"AI-RECONSTRUCTED"}])
  assert len(q.segments)==2 and s.verify(q.segmentation_id)["all_ok"];summary=s.summary(q.segmentation_id);assert summary["segments"]==2 and "not a neuron count" in summary["note"]
def test_bad_confidence_rejected():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);d,n,v,s=setup(root);vol=volume(root,d,n,v)
  try:s.create(vol.volume_id,"test","1",[{"voxel_count":1,"confidence":1.5}])
  except NeuronSegmentationError:pass
  else:raise AssertionError("invalid confidence accepted")
