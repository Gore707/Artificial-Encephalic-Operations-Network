from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_partition import NeuralPartitionService,NeuralPartitionError
class N:
 network_id="net";neuron_states=(("a","sa"),("b","sb"),("c","sc"),("d","sd"))
 synapses=({"edge_id":"ab","source_node_id":"a","target_node_id":"b"},{"edge_id":"bc","source_node_id":"b","target_node_id":"c"},{"edge_id":"cd","source_node_id":"c","target_node_id":"d"})
class S:
 def get(self,x):return N()
def test_balanced_partition_and_cut_edges():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);p=NeuralPartitionService(db,a,S());q=p.create("net",2)
  d=p.describe(q.plan_id);assert d["partition_sizes"]=={0:2,1:2} and d["cut_edges"]==1 and p.verify(q.plan_id)["all_ok"]
def test_too_many_partitions_rejected():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);p=NeuralPartitionService(db,a,S())
  try:p.create("net",5)
  except NeuralPartitionError:pass
  else:raise AssertionError("invalid partition count accepted")
