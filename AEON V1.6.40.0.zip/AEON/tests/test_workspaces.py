from pathlib import Path
import tempfile

from aeon.workspaces import WorkspaceStore, WorkspaceError


def test_workspace_lifecycle():
    with tempfile.TemporaryDirectory() as tmp:
        store = WorkspaceStore(Path(tmp))
        a = store.create("Alpha")
        b = store.create("Beta")
        assert store.active_id() == a.workspace_id
        assert store.path_for(a.workspace_id).is_dir()

        store.activate(b.workspace_id)
        assert store.active().name == "Beta"

        renamed = store.rename(b.workspace_id, "Beta Prime")
        assert renamed.name == "Beta Prime"

        store.delete(a.workspace_id)
        assert [w.name for w in store.list()] == ["Beta Prime"]


def test_empty_name_rejected():
    with tempfile.TemporaryDirectory() as tmp:
        store = WorkspaceStore(Path(tmp))
        try:
            store.create("   ")
        except WorkspaceError:
            pass
        else:
            raise AssertionError("empty workspace name accepted")
