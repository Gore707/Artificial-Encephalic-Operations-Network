from pathlib import Path
from aeon.config import load_config
from aeon.preflight import run_preflight

def test_preflight_passes_in_project_tree():
    root = Path(__file__).resolve().parents[1]
    cfg = load_config(root)
    ok, checks = run_preflight(root, cfg)
    assert ok, [(c.name, c.detail) for c in checks if not c.ok]
