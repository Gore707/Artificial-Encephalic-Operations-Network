from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.ani_reconstruction_metadata import ANIReconstructionMetadataService,ANIReconstructionMetadataError
class O:
 def __init__(self,**kw):self.__dict__.update(kw)
class Svc:
 def __init__(self,o):self.o=o
 def get(self,x):return self.o
 def verify(self,x):return {"all_ok":True}
def test_uncertainty_metadata_preserves_epistemic_class():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db)
  spec=Svc(O(definition_sha256="a"*64));top=Svc(O(definition_sha256="b"*64,ani_spec_id="spec"));syn=Svc(O(definition_sha256="c"*64,topology_id="top"));dyn=Svc(O(definition_sha256="d"*64,topology_id="top",synaptic_state_id="syn"))
  m=ANIReconstructionMetadataService(db,a,spec,top,syn,dyn)
  q=m.create("spec",[{"target_ref":"node:n1","property_name":"ion-channel-state","provenance":"AI-RECONSTRUCTED","confidence":.31,"method":"model-x","method_version":"1","source_refs":["morphology:n1"],"uncertainty":{"kind":"epistemic"}}],topology_id="top",synaptic_state_id="syn",dynamic_state_id="dyn",unknowns=["true channel distribution never measured"])
  assert m.verify(q.metadata_id)["all_ok"];z=m.summary(q.metadata_id);assert z["information_sufficiency"]=="UNDETERMINED" and z["provenance_counts"]["AI-RECONSTRUCTED"]==1 and "does not convert" in z["note"]
def test_inference_requires_method_version():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);svc=Svc(O(definition_sha256="a"*64));m=ANIReconstructionMetadataService(db,a,svc,svc,svc,svc)
  try:m.create("spec",[{"target_ref":"x","property_name":"y","provenance":"INFERRED"}])
  except ANIReconstructionMetadataError:pass
  else:raise AssertionError("unattributed inference accepted")
