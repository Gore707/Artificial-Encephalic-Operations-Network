from pathlib import Path
import tempfile,math
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.cognitive_state_comparator import CognitiveStateComparator
def mk(c,name,vals,units=None):
 units=units or {k:"Hz" for k in vals};return c.create_state(name,vals,units,{k:"DERIVED" for k in vals},{k:1.0 for k in vals},{k:"test" for k in vals})
def test_comparison_metrics_missing_and_identity_boundary():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);c=CognitiveStateComparator(db,a)
  l=mk(c,"left",{"a":1,"b":2});r=mk(c,"right",{"a":2,"b":4,"c":9});q=c.compare(l.state_id,r.state_id)
  assert q.metrics["comparable_count"]==2 and abs(q.metrics["mae"]-1.5)<1e-12 and q.missing_left==("c",)
  assert "does not establish personal identity" in q.details["interpretation"]
def test_unit_mismatch_excluded():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);c=CognitiveStateComparator(db,a)
  l=mk(c,"l",{"x":1},{"x":"Hz"});r=mk(c,"r",{"x":1},{"x":"mV"});q=c.compare(l.state_id,r.state_id)
  assert q.metrics["comparable_count"]==0 and q.details["variables"]["x"]["reason"]=="UNIT_MISMATCH"
