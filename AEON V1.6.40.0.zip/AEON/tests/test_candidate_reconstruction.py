from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.candidate_reconstruction import CandidateReconstructionService,CandidateReconstructionError
class M:
 def get(self,x):return object()
 def verify(self,x):return {"all_ok":True}
def test_candidate_provenance_and_comparison():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=CandidateReconstructionService(db,a,M())
  one=s.create("meta","A",[{"target_ref":"n1","property_name":"v","value":-65,"unit":"mV","provenance":"AI-RECONSTRUCTED","confidence":.9,"method":"model","method_version":"1","source_refs":["raw:1"]}])
  two=s.create("meta","B",[{"target_ref":"n1","property_name":"v","value":-60,"unit":"mV","provenance":"INFERRED","confidence":.7,"method":"constraint","method_version":"2"}])
  assert one.status=="HYPOTHESIS" and s.verify(one.candidate_id)["all_ok"]
  q=s.compare(one.candidate_id,two.candidate_id);assert q["variables"][0]["numeric_delta"]==5.0
def test_measured_candidate_rejected():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=CandidateReconstructionService(db,a,M())
  try:s.create("m","bad",[{"target_ref":"n","property_name":"x","value":1,"unit":"u","provenance":"MEASURED","confidence":1,"method":"x","method_version":"1"}])
  except CandidateReconstructionError:pass
  else:raise AssertionError("candidate was allowed to claim MEASURED provenance")
