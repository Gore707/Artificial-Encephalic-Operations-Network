from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.ani_specification import ANISpecificationService
from aeon.ani_topology import ANITopologyService
class Obj:
 def __init__(self,**kw):self.__dict__.update(kw)
class Conns:
 def __init__(self):
  self.c=Obj(definition_sha256="c"*64,nodes=(Obj(node_id="A",classification_id=None,provenance="DERIVED"),Obj(node_id="B",classification_id=None,provenance="DERIVED")),
   edges=(Obj(edge_id="e1",source_node_id="A",target_node_id="A",synapse_id="s1",kind="ELECTRICAL",direction="BIDIRECTIONAL",provenance="DERIVED",confidence=.8),
          Obj(edge_id="e2",source_node_id="A",target_node_id=None,synapse_id="s2",kind="UNKNOWN",direction="UNKNOWN",provenance="UNKNOWN",confidence=None)))
 def get(self,x):return self.c
 def verify(self,x):return {"all_ok":True}
def test_topology_preserves_recurrence_and_partial_endpoints():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);c=Conns();s=ANISpecificationService(db,a,c)
  spec=s.create("s",[{"domain":"TOPOLOGY","name":"graph","value_type":"graph","required":True,"provenance":"DERIVED"}],source_connectome_id="c1")
  t=ANITopologyService(db,a,s,c);q=t.create_from_connectome(spec.ani_spec_id,"c1","conductance-snn")
  assert t.verify(q.topology_id)["all_ok"];z=t.summary(q.topology_id);assert z["self_edges"]==1 and z["partial_edges"]==1 and "model-aware" in z["note"]
