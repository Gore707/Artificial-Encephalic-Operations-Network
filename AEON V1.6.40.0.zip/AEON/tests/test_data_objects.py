from pathlib import Path
import tempfile

from aeon.state_db import StateDatabase
from aeon.workspaces import WorkspaceStore
from aeon.data_objects import DataObjectStore, DataObjectError


def test_data_object_lifecycle_and_source_verification():
    with tempfile.TemporaryDirectory() as tmp:
        state = Path(tmp) / "state"
        source = Path(tmp) / "sample.bin"
        source.write_bytes(b"AEON-scientific-data")

        db = StateDatabase(state / "aeon_state.sqlite3")
        workspaces = WorkspaceStore(state, db)
        ws = workspaces.create("Research")
        objects = DataObjectStore(db, workspaces)

        obj = objects.create(
            ws.workspace_id, "dataset", "Sample",
            media_type="application/octet-stream",
            source_path=str(source),
            metadata={"instrument": "synthetic-test"},
        )
        assert obj.sha256
        assert obj.size_bytes == len(b"AEON-scientific-data")
        assert objects.verify_source(obj.object_id)[0] is True

        source.write_bytes(b"changed")
        assert objects.verify_source(obj.object_id)[0] is False


def test_invalid_kind_is_rejected():
    with tempfile.TemporaryDirectory() as tmp:
        state = Path(tmp)
        db = StateDatabase(state / "aeon_state.sqlite3")
        workspaces = WorkspaceStore(state, db)
        ws = workspaces.create("Research")
        objects = DataObjectStore(db, workspaces)
        try:
            objects.create(ws.workspace_id, "nonsense", "Bad")
        except DataObjectError:
            pass
        else:
            raise AssertionError("unsupported data kind accepted")
