from pathlib import Path
import sys,tempfile,time
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.process_supervisor import ProcessSupervisor

def terminal(s,p,timeout=5):
    end=time.time()+timeout
    while time.time()<end:
        x=s.snapshot(p)
        if x.state in ("EXITED","CRASHED"): return x
        time.sleep(.05)
    raise AssertionError("not terminal")

def test_crash_containment():
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"s.db"); a=AuditTrail(db); s=ProcessSupervisor(Path(t),a,.05)
        try:
            p=s.launch("crash",[sys.executable,"-S","-c","raise RuntimeError('boom')"])
            x=terminal(s,p); assert x.state=="CRASHED" and x.return_code!=0
        finally: s.shutdown()

def test_restart_and_stop():
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"s.db"); a=AuditTrail(db); s=ProcessSupervisor(Path(t),a,.05)
        try:
            p=s.launch("restart",[sys.executable,"-S","-c","raise SystemExit(2)"],restart_limit=1)
            x=terminal(s,p); assert x.restart_count==1 and x.state=="CRASHED"
            q=s.launch("sleep",[sys.executable,"-S","-c","import time;time.sleep(30)"])
            time.sleep(.1); y=s.stop(q,2); assert y.state=="EXITED"
        finally: s.shutdown()
