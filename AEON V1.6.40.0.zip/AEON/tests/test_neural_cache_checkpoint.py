from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_cache_virtual_device import NeuralCacheVirtualDevice
from aeon.neural_cache_block import NeuralCacheBlockStore
from aeon.neural_cache_checkpoint import NeuralCacheStateCheckpointService,NeuralCacheCheckpointError
def test_checkpoint_restore_and_corruption_refusal():
 with tempfile.TemporaryDirectory() as x:
  root=Path(x);db=StateDatabase(root/"s.db");a=AuditTrail(db);ds=NeuralCacheVirtualDevice(db,a,root/"cache");d=ds.create("d",4*1024*1024);bs=NeuralCacheBlockStore(db,a,ds)
  b1=bs.write(d.device_id,b"neurons"*1000);b2=bs.write(d.device_id,b"synapses"*1000);s=NeuralCacheStateCheckpointService(db,a,bs)
  q=s.create("run-1",42,4.2,"ms",(b1.block_id,b2.block_id));assert s.verify(q.checkpoint_id)["all_ok"]
  r=s.restore(q.checkpoint_id);assert r["logical_step"]==42 and r["payloads"]==(b"neurons"*1000,b"synapses"*1000)
  p=Path(b2.path);raw=bytearray(p.read_bytes());raw[-1]^=1;p.write_bytes(raw)
  assert not s.verify(q.checkpoint_id)["all_ok"]
  try:s.restore(q.checkpoint_id)
  except NeuralCacheCheckpointError:pass
  else:raise AssertionError("corrupt checkpoint restored")
