from pathlib import Path
import tempfile,pytest
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.persistent_safety_gate import PersistentSafetyGate
from aeon.genesis_execution_gate import GenesisExecutionGate,GenesisExecutionGateError
def test_certificate_binds_exact_subject_and_failure_holds_persistently():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);sg=PersistentSafetyGate(db,a);g=GenesisExecutionGate(db,a,sg)
  good={"model_version":"m1","topology":{"nodes":[{"id":"a"},{"id":"b"}],"edges":[["a","b"]]},"provenance":["MEASURED","INFERRED"]}
  c=g.validate("ani-1",b"exact-state",good);assert c.status=="PASS" and g.require_pass(c.certificate_id,b"exact-state")
  with pytest.raises(GenesisExecutionGateError):g.require_pass(c.certificate_id,b"changed-state")
  bad={"model_version":"m1","topology":{"nodes":[{"id":"a"}],"edges":[["a","missing"]]},"provenance":["MEASURED"]}
  f=g.validate("ani-bad",b"bad",bad);assert f.status=="FAIL" and sg.get("GENESIS_EXECUTION").held
