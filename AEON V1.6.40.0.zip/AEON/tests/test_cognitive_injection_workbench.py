from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.neuroimaging_ingestion import NeuroimagingIngestion
from aeon.volume_reconstruction import VolumeReconstructionService
from aeon.neuron_segmentation import NeuronSegmentationService
from aeon.neurite_tracing import NeuriteTracingService
from aeon.synapse_detection import SynapseDetectionService
from aeon.cell_classification import CellClassificationService
from aeon.connectome_reconstruction import ConnectomeReconstructionService
from aeon.cognitive_injection_workbench import CognitiveInjectionWorkbench, CognitiveInjectionWorkbenchError

def make(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);d=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"))
 n=NeuroimagingIngestion(db,a,d);v=VolumeReconstructionService(db,a,d,n);s=NeuronSegmentationService(db,a,v)
 t=NeuriteTracingService(db,a,s);y=SynapseDetectionService(db,a,t);cl=CellClassificationService(db,a,s)
 c=ConnectomeReconstructionService(db,a,s,y,cl)
 w=CognitiveInjectionWorkbench(db,a,n,v,s,t,y,cl,c)
 p=root/"source.dat";p.write_bytes(b"real-source")
 ds=d.register_file(p,"source","IMPORTED","MEASURED")
 im=n.register(ds.dataset_id,"EM","fixed",{"x_nm":4,"y_nm":4,"z_nm":30},["electron"],{"static":True})
 vol=v.define(im.imaging_id,(10,10,10),{"x_nm":4,"y_nm":4,"z_nm":30},"SOURCE")
 sg=s.create(vol.volume_id,"manual","1",[{"segment_id":"a","voxel_count":8},{"segment_id":"b","voxel_count":9}])
 ta=t.create(sg.segmentation_id,"a","trace","1",[{"node_id":"a1","xyz":[0,0,0],"kind":"AXON"}],[])
 tb=t.create(sg.segmentation_id,"b","trace","1",[{"node_id":"b1","xyz":[1,0,0],"kind":"DENDRITE"}],[])
 sy=y.create("manual","1",[{"pre_trace_id":ta.trace_id,"pre_node_id":"a1","post_trace_id":tb.trace_id,"post_node_id":"b1","kind":"CHEMICAL","direction":"DIRECTED","provenance":"DERIVED"}])
 cc=cl.classify(sg.segmentation_id,"a","custom","NEURON",confidence=.8,provenance="INFERRED",evidence=[{"basis":"morphology"}])
 co=c.reconstruct("c",[{"node_id":"A","segmentation_id":sg.segmentation_id,"segment_id":"a","classification_id":cc.classification_id},{"node_id":"B","segmentation_id":sg.segmentation_id,"segment_id":"b"}],[sy.detection_id])
 return w,im,vol,sg,ta,tb,sy,cc,co

def test_full_case_integrity_and_epistemic_gate():
 with tempfile.TemporaryDirectory() as x:
  w,im,vol,sg,ta,tb,sy,cc,co=make(Path(x))
  q=w.create_case("case",im.imaging_id,vol.volume_id,sg.segmentation_id,[ta.trace_id,tb.trace_id],[sy.detection_id],[cc.classification_id],co.connectome_id)
  st=w.status(q.case_id)
  assert st["completed_stages"]==7 and st["integrity"]["all_ok"]
  assert st["information_sufficiency"]=="UNDETERMINED"
  assert "not proof" in st["note"]

def test_cross_chain_mismatch_rejected():
 with tempfile.TemporaryDirectory() as x:
  root=Path(x);w,im,vol,sg,ta,tb,sy,cc,co=make(root)
  # A case may be partial, but records supplied together must form the same chain.
  try:w.create_case("bad", imaging_id=im.imaging_id, segmentation_id="missing")
  except Exception:pass
  else:raise AssertionError("invalid cross-chain case accepted")
