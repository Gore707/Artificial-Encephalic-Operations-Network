from aeon.bootstrap import main

def test_version(capsys):
    assert main(["--version"]) == 0
    assert "AEON" in capsys.readouterr().out

def test_preflight():
    assert main(["--preflight"]) == 0
