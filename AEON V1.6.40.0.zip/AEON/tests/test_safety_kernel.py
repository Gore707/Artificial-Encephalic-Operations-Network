from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.guardian import GuardianService
from aeon.safety_kernel import SafetyKernel,SafetyGovernor,SafetyError

def setup(t):
 db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);g=GuardianService(db,a);k=SafetyKernel(db,a);v=SafetyGovernor(k,g,a);return db,a,g,k,v

def test_explicit_rule_causes_deterministic_hold():
 with tempfile.TemporaryDirectory() as t:
  db,a,g,k,v=setup(t);k.add_rule("cpu.temp.c",">=",90,"HOLD_NEW_WORK")
  assert not k.hold_new_work
  assert not v.submit_measurement("cpu.temp.c",70,"HOST")
  d=v.submit_measurement("cpu.temp.c",95,"HOST")
  assert d[0].executed and k.hold_new_work and g.status=="INTERVENTION"
  ok,msg=a.verify();assert ok,msg

def test_ai_or_inferred_provenance_cannot_actuate_interlock():
 with tempfile.TemporaryDirectory() as t:
  db,a,g,k,v=setup(t);k.add_rule("gpu.temp.c",">=",90,"HOLD_NEW_WORK")
  for provenance in ("INFERRED","AI-RECONSTRUCTED","DERIVED"):
   try:v.submit_measurement("gpu.temp.c",100,provenance)
   except SafetyError:pass
   else:raise AssertionError("non-measured inference actuated Safety Kernel")
  assert not k.hold_new_work

def test_missing_measurement_fails_closed_not_fabricated():
 with tempfile.TemporaryDirectory() as t:
  db,a,g,k,v=setup(t);k.add_rule("ram.ecc.errors",">",0,"HOLD_NEW_WORK")
  try:v.submit_measurement("ram.ecc.errors",None,"HARDWARE")
  except SafetyError:pass
  else:raise AssertionError("missing measurement treated as safe")
  assert not k.decisions()
