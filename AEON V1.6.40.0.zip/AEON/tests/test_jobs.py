from dataclasses import dataclass
from pathlib import Path
import sys,tempfile,time
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.resources import ResourceManager,ResourceRequest
from aeon.process_supervisor import ProcessSupervisor
from aeon.jobs import JobScheduler
@dataclass(frozen=True)
class CPU:logical_processors:int=8
@dataclass(frozen=True)
class Mem:total_bytes:int=16*1024**3;available_bytes:int=12*1024**3
@dataclass(frozen=True)
class Vol:free_bytes:int=100*1024**3
@dataclass(frozen=True)
class Host:cpu:CPU=CPU();memory:Mem=Mem();storage:tuple=(Vol(),)
class HW:
 def discover(self):return Host()
@dataclass(frozen=True)
class AI:devices:tuple=()
class GPU:
 def discover(self):return AI()
def wait(s,jid,want,timeout=5):
 end=time.time()+timeout
 while time.time()<end:
  j=s.get(jid)
  if j.state in want:return j
  time.sleep(.05)
 raise AssertionError(s.get(jid))
def test_jobs():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);p=ProcessSupervisor(Path(t),a,.05)
  r=ResourceManager(HW(),GPU(),db,a);s=JobScheduler(db,a,r,p,.05)
  try:
   j=s.submit("ok","test",[sys.executable,"-S","-c","raise SystemExit(0)"],ResourceRequest())
   assert wait(s,j.job_id,{"SUCCEEDED"}).return_code==0
   j=s.submit("bad","test",[sys.executable,"-S","-c","raise SystemExit(3)"],ResourceRequest())
   assert wait(s,j.job_id,{"FAILED"}).return_code==3
   assert not r.leases()
  finally:s.shutdown();p.shutdown()
