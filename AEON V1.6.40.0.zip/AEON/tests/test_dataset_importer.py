from pathlib import Path
import tempfile,json
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.dataset_importer import DatasetImporter,DatasetImportError

def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);lab=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"immutable"))
 return a,lab,DatasetImporter(lab,a)

def test_csv_preview_and_import():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,lab,imp=setup(root);p=root/"cells.csv";p.write_text("id,value\nn1,1\nn2,2\n")
  v=imp.preview(p);assert v.format=="csv" and v.column_count==2 and v.headers==("id","value")
  d=imp.import_file(p,"cells","IMPORTED","MEASURED",{"modality":"test"})
  assert lab.get(d.dataset_id).metadata["import_format"]=="csv"
  assert Path(d.metadata["immutable_path"]).exists()
  ok,msg=a.verify();assert ok,msg

def test_invalid_json_rejected_before_catalog():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,lab,imp=setup(root);p=root/"bad.json";p.write_text("{bad")
  try:imp.import_file(p,"bad","IMPORTED","MEASURED")
  except DatasetImportError:pass
  else:raise AssertionError("invalid JSON imported")
  assert lab.list()==()
