from pathlib import Path
import tempfile,json
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.failure_qualification import FailureCorruptionQualification
from aeon.process_failure_qualification import ProcessFailureQualification
from aeon.distributed_failure_qualification import DistributedFailureQualification
from aeon.resource_failure_qualification import ResourceFailureQualification
from aeon.neural_data_failure_qualification import NeuralDataFailureQualification
from aeon.failure_validation_campaign import FailureValidationCampaign
class Dummy: pass
def test_phase_campaign_and_residual_risk_are_explicit():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db)
  # P081 is not invoked by the non-destructive campaign because it requires real disposable cache artifacts.
  p081=Dummy();p082=ProcessFailureQualification(db,a);p083=DistributedFailureQualification(db,a);p084=ResourceFailureQualification(db,a);p085=NeuralDataFailureQualification(db,a)
  q=FailureValidationCampaign(db,a,p081,p082,p083,p084,p085);r=q.run_non_destructive_suite()
  checks=json.loads(r.checks_json);assert r.status=="PASS" and len(checks)>=10 and all(c["pass"] for c in checks)
  ready=q.readiness();assert "production independent watchdog" in ready["not_qualified"] and "full GSVL execution gate" in ready["not_qualified"]
