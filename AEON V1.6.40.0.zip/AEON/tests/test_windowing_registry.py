from aeon.apps import AppRegistry, AppSpec

def test_registry_rejects_duplicate_app_ids():
    registry = AppRegistry()
    registry.register(AppSpec("x", "X", lambda parent: parent))
    try:
        registry.register(AppSpec("x", "X2", lambda parent: parent))
    except ValueError:
        pass
    else:
        raise AssertionError("duplicate app id accepted")

def test_registry_returns_registered_apps():
    registry = AppRegistry()
    spec = AppSpec("system", "System", lambda parent: parent)
    registry.register(spec)
    assert registry.get("system") is spec
    assert registry.all() == (spec,)
