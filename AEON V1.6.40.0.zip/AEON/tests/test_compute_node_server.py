import json,socket,time
from aeon.compute_node_server import ComputeNodeServer
def wire(req):return json.dumps(req.__dict__,sort_keys=True,separators=(",",":")).encode()+b"\n"
def test_bounded_authenticated_server_and_replay():
 s=ComputeNodeServer("n1",b"0123456789abcdef0123456789abcdef",lambda:{"load":.2})
 req=s.make_request("STATUS");one=s.handle(req.__dict__);assert one.ok and one.payload["status"]["load"]==.2
 two=s.handle(req.__dict__);assert not two.ok and "replayed" in two.payload["error"]
 bad=s.make_request("PING").__dict__.copy();bad["signature"]="0"*64;assert not s.handle(bad).ok
def test_tcp_round_trip_and_no_arbitrary_execution():
 s=ComputeNodeServer("n1",b"0123456789abcdef0123456789abcdef");host,port=s.start()
 try:
  req=s.make_request("CAPABILITIES")
  with socket.create_connection((host,port),2) as c:
   c.sendall(wire(req));data=b""
   while b"\n" not in data:data+=c.recv(65536)
  r=json.loads(data.decode());assert r["ok"] and r["payload"]["arbitrary_execution"] is False
  evil=s.make_request("EXEC",{"argv":["cmd.exe"]});assert not s.handle(evil.__dict__).ok
 finally:s.stop()
