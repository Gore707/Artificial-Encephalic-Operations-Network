from pathlib import Path
import tempfile,json
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.distributed_failure_qualification import DistributedFailureQualification
def test_distributed_fault_detection():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);q=DistributedFailureQualification(db,a)
  assert q.node_stale(10,30,5).passed
  assert q.packet_loss((1,2,3,4),(1,2,4)).passed
  assert q.desync({"n1":100,"n2":103},0).passed
  assert q.replay(("a","b","a")).passed
  assert q.summary()["passed"]==4
