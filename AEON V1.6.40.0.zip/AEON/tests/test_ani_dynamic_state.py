from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.ani_dynamic_state import ANIDynamicStateService,ANIDynamicStateError
class O:
 def __init__(self,**kw):self.__dict__.update(kw)
class T:
 def __init__(self):self.o=O(definition_sha256="t"*64,nodes=(O(node_id="n1"),),edges=(O(edge_id="e1"),))
 def get(self,x):return self.o
 def verify(self,x):return {"all_ok":True}
class S:
 def __init__(self):self.o=O(definition_sha256="s"*64,topology_id="t1")
 def get(self,x):return self.o
 def verify(self,x):return {"all_ok":True}
def test_dynamic_state_separates_measured_from_initialized():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);d=ANIDynamicStateService(db,a,T(),S())
  q=d.create("t1",[{"target_type":"NODE","target_id":"n1","name":"Vm","value":-65.0,"unit":"mV","provenance":"MEASURED"},{"target_type":"NODE","target_id":"n1","name":"gating_state","value":0.2,"provenance":"INFERRED","confidence":.4}],synaptic_state_id="s1",biological_time_ref="acquisition-frame-17",explicitly_unmeasured=[("NODE","n1","intracellular_calcium")])
  assert d.verify(q.dynamic_state_id)["all_ok"];z=d.summary(q.dynamic_state_id);assert z["measured"]==1 and z["initialized_or_inferred"]==1 and "not biological measurement" in z["note"]
def test_missing_node_rejected():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);d=ANIDynamicStateService(db,a,T(),S())
  try:d.create("t1",[{"target_type":"NODE","target_id":"missing","name":"Vm","value":0}])
  except ANIDynamicStateError:pass
  else:raise AssertionError("missing target accepted")
