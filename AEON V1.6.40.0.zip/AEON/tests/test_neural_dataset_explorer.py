from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.neural_dataset_explorer import NeuralDatasetExplorer
def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);lab=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"));return a,lab,NeuralDatasetExplorer(lab,a)
def test_profile():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,lab,e=setup(root);p=root/"n.csv";p.write_text("id,x,y,type\nn1,1,2,A\nn2,3,,B\n");d=lab.register_file(p,"n","IMPORTED","MEASURED")
  q=e.profile(d.dataset_id,"NEURON");assert q.numeric_fields==("x","y") and dict(q.missing_counts)["y"]==1 and q.provenance=="MEASURED"
def test_edges_allow_self_recurrence():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,lab,e=setup(root);p=root/"e.csv";p.write_text("source,target\nn1,n1\nn1,n2\nn2,n1\n");d=lab.register_file(p,"e","SIMULATION","DERIVED")
  s=e.edge_summary(d.dataset_id);assert s["nodes_observed"]==2 and s["edges_observed"]==3 and s["self_edges"]==1
