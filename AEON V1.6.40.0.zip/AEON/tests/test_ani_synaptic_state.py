from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.ani_synaptic_state import ANISynapticStateService,ANISynapticStateError
class Obj:
 def __init__(self,**kw):self.__dict__.update(kw)
class T:
 def __init__(self):self.o=Obj(definition_sha256="a"*64,model_family="snn",edges=(Obj(edge_id="e1"),))
 def get(self,x):return self.o
 def verify(self,x):return {"all_ok":True}
def test_synaptic_state_tracks_measured_and_unmeasured_separately():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=ANISynapticStateService(db,a,T())
  q=s.create("t",[{"edge_id":"e1","property_name":"WEIGHT","value":.4,"unit":"relative","provenance":"INFERRED","confidence":.6}],explicitly_unmeasured=[("e1","RECEPTOR_STATE"),("e1","PLASTICITY")])
  assert s.verify(q.synaptic_state_id)["all_ok"];z=s.summary(q.synaptic_state_id);assert z["parameters"]==1 and z["explicitly_unmeasured"]==2 and "does not supply" in z["note"]
def test_cannot_supply_and_mark_unmeasured_same_property():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=ANISynapticStateService(db,a,T())
  try:s.create("t",[{"edge_id":"e1","property_name":"WEIGHT","value":1}],explicitly_unmeasured=[("e1","WEIGHT")])
  except ANISynapticStateError:pass
  else:raise AssertionError("contradictory state accepted")
