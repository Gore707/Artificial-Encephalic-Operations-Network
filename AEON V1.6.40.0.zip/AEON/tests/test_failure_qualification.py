from pathlib import Path
import tempfile
from types import SimpleNamespace
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.integrity import IntegrityService
from aeon.transactional_files import TransactionalFileStore
from aeon.recovery import RecoveryManager
from aeon.neural_safety import GenesisValidator,NeuralSafetyPolicies
from aeon.safety_kernel import SafetyKernel
from aeon.failure_qualification import FailureQualification

def test_disposable_failure_qualification():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);db=StateDatabase(root/"s.db");a=AuditTrail(db)
  integ=IntegrityService(db,a);tx=TransactionalFileStore(db,a,root/"state");rec=RecoveryManager(db,a,tx);ns=NeuralSafetyPolicies(db,a,SafetyKernel(db,a));gen=GenesisValidator(db,a)
  s=SimpleNamespace(integrity=integ,transactional_files=tx,recovery=rec,genesis=gen)
  r=FailureQualification(s,a).run()
  assert r.passed,[(c.name,c.detail) for c in r.cases if not c.passed]
  assert len(r.cases)==5
  ok,msg=a.verify();assert ok,msg

def test_qualification_never_requires_user_source_path():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);db=StateDatabase(root/"s.db");a=AuditTrail(db)
  s=SimpleNamespace(integrity=IntegrityService(db,a),
    transactional_files=TransactionalFileStore(db,a,root/"state"),
    genesis=(NeuralSafetyPolicies(db,a,SafetyKernel(db,a)) and GenesisValidator(db,a)))
  s.recovery=RecoveryManager(db,a,s.transactional_files)
  r=FailureQualification(s,a).run()
  assert all("disposable" in c.detail.lower() or c.passed for c in r.cases)
