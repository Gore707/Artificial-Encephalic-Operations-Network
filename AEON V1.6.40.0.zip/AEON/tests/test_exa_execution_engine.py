from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.exa_execution_engine import ExaExecutionEngine,ExaExecutionError
class Plan:
 network_id="net";assignments={"a":"n1"};definition_sha256="a"*64
class Part:
 def verify(self,x):return {"all_ok":True}
 def get(self,x):return Plan()
class Node:
 def __init__(self,status):self.node_id="n1";self.status=status
class Cluster:
 def __init__(self):self.status="REGISTERED"
 def list_nodes(self):return (Node(self.status),)
class Ck:pass
class Cks:
 def get(self,x):return Ck()
 def verify(self,x):return {"all_ok":False}
def test_run_requires_online_to_start_and_monotonic_commits():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);cl=Cluster();e=ExaExecutionEngine(db,a,None,None,Part(),Cks(),cl)
  q=e.create_run("net","plan","ms");assert q.status=="READY"
  try:e.start(q.run_id)
  except ExaExecutionError:pass
  else:raise AssertionError("started without ONLINE node")
  cl.status="ONLINE";q=e.start(q.run_id);assert q.status=="RUNNING"
  q=e.commit(q.run_id,1,.1);assert q.logical_step==1
  try:e.commit(q.run_id,3,.2)
  except ExaExecutionError:pass
  else:raise AssertionError("skipped logical step")
  r=e.readiness(q.run_id);assert r["arbitrary_remote_execution"] is False and r["production_security_qualified"] is False
