from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.performance_benchmark import PerformanceBenchmark
from aeon.workload_optimizer import WorkloadOptimizer
from aeon.cluster_performance_optimizer import ClusterPerformanceOptimizer
from aeon.performance_optimization_qualification import PerformanceOptimizationQualification
def test_cross_layer_performance_qualification_is_evidence_bound():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db)
  b=PerformanceBenchmark(db,a);w=WorkloadOptimizer(db,a);c=ClusterPerformanceOptimizer(db,a)
  br=b.run("tiny",lambda:sum(range(20)),20,2)
  wr=w.plan("local",1000,8,1024*1024,32,.75,.5)
  caps={"n1":1,"n2":2};cr=c.plan("cluster",120,caps)
  q=PerformanceOptimizationQualification(db,a,b,w,c);r=q.qualify(br.benchmark_id,wr.plan_id,cr.plan_id,caps)
  assert r.status=="PASS" and q.verify(r.qualification_id)["all_ok"]
  with db.transaction() as con:con.execute("UPDATE p090_performance_qualifications SET checks_json=checks_json||'x' WHERE qualification_id=?",(r.qualification_id,))
  assert not q.verify(r.qualification_id)["all_ok"]
