from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.workload_optimizer import WorkloadOptimizer
def test_bounded_resource_plan_and_integrity():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");q=WorkloadOptimizer(db,AuditTrail(db))
  r=q.plan("neural-batch",10000,16,1024*1024,bytes_per_item=100,max_cpu_fraction=.5,max_memory_fraction=.25)
  assert r.workers==8 and r.memory_budget_bytes==262144 and 1<=r.chunk_size<=2621 and r.estimated_chunks>=1
  assert q.verify(r.plan_id)["all_ok"]
  with db.transaction() as c:c.execute("UPDATE p088_workload_plans SET workers=99 WHERE plan_id=?",(r.plan_id,))
  assert not q.verify(r.plan_id)["all_ok"]
