from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_cache_virtual_device import NeuralCacheVirtualDevice
from aeon.neural_cache_block import NeuralCacheBlockStore
from aeon.neural_cache_redundancy import NeuralCacheRedundantStorage
from aeon.failure_qualification import FailureCorruptionQualification
def test_p081_gating_detection_and_replica_recovery():
 with tempfile.TemporaryDirectory() as x:
  root=Path(x);db=StateDatabase(root/"s.db");a=AuditTrail(db);ds=NeuralCacheVirtualDevice(db,a,root/"cache");d1=ds.create("a",3*1024*1024);d2=ds.create("b",3*1024*1024);bs=NeuralCacheBlockStore(db,a,ds);rs=NeuralCacheRedundantStorage(db,a,ds,bs);q=FailureCorruptionQualification(db,a,bs,rs)
  protected=bs.write(d1.device_id,b"protected")
  try:q.bit_flip(protected.block_id)
  except RuntimeError:pass
  else:raise AssertionError("non-disposable block mutated")
  b=bs.write(d1.device_id,b"recover"*1000,metadata={"disposable_failure_test":True});r=rs.create(b.block_id,(d2.device_id,))
  out=q.replica_recovery(r.replica_set_id);assert out.passed and rs.verify(r.replica_set_id)["recoverable"]
