from pathlib import Path
import tempfile,json
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.cluster_performance_optimizer import ClusterPerformanceOptimizer
def test_capacity_weighted_cluster_plan_is_complete_and_bound():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");q=ClusterPerformanceOptimizer(db,AuditTrail(db))
  r=q.plan("distributed-neural",100,{"n1":1,"n2":2,"n3":1})
  a=json.loads(r.assignments_json);assert sum(a.values())==100 and a["n2"]==50 and a["n1"]==25 and a["n3"]==25
  assert q.verify(r.plan_id,{"n1":1,"n2":2,"n3":1})["all_ok"]
  assert not q.verify(r.plan_id,{"n1":1,"n2":1,"n3":1})["all_ok"]
