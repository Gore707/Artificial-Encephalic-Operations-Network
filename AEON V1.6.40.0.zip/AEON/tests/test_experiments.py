from dataclasses import dataclass
from pathlib import Path
import sys,tempfile,time
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.resources import ResourceManager,ResourceRequest
from aeon.process_supervisor import ProcessSupervisor
from aeon.jobs import JobScheduler
from aeon.experiments import ExperimentManager,ExperimentError
@dataclass(frozen=True)
class CPU:logical_processors:int=8
@dataclass(frozen=True)
class Mem:total_bytes:int=16*1024**3;available_bytes:int=12*1024**3
@dataclass(frozen=True)
class Vol:free_bytes:int=100*1024**3
@dataclass(frozen=True)
class Host:cpu:CPU=CPU();memory:Mem=Mem();storage:tuple=(Vol(),)
class HW:
 def discover(self):return Host()
@dataclass(frozen=True)
class AI:devices:tuple=()
class GPU:
 def discover(self):return AI()
def wait(e,rid,timeout=5):
 end=time.time()+timeout
 while time.time()<end:
  r=e.get_run(rid)
  if r.state in {"SUCCEEDED","FAILED","CANCELLED"}:return r
  time.sleep(.05)
 raise AssertionError(e.get_run(rid))
def test_simulation_definition_and_run():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);p=ProcessSupervisor(Path(t),a,.05)
  rm=ResourceManager(HW(),GPU(),db,a);js=JobScheduler(db,a,rm,p,.05);e=ExperimentManager(db,a,js)
  try:
   d=e.create("tiny sim","SIMULATION",[sys.executable,"-S","-c","pass"],
              {"model":"test","seed":42},ResourceRequest(cpu_logical=1))
   assert len(d.definition_hash)==64 and d.mode=="SIMULATION"
   run=e.run(d.experiment_id,"tester");done=wait(e,run.run_id)
   assert done.state=="SUCCEEDED" and done.definition_hash==d.definition_hash
   assert js.get(done.job_id).state=="SUCCEEDED"
  finally:js.shutdown();p.shutdown()
def test_invalid_mode_rejected():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db)
  class J:pass
  e=ExperimentManager(db,a,J())
  try:e.create("x","REALISH",["x"])
  except ExperimentError:pass
  else:raise AssertionError("invalid evidence mode accepted")
