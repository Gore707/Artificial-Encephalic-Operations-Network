from dataclasses import dataclass
from pathlib import Path
import tempfile

from aeon.audit import AuditTrail
from aeon.resources import ResourceManager, ResourceRequest, ResourcePolicyError
from aeon.state_db import StateDatabase

@dataclass(frozen=True)
class CPU: logical_processors:int=16
@dataclass(frozen=True)
class Mem: total_bytes:int=32*1024**3; available_bytes:int=20*1024**3
@dataclass(frozen=True)
class Vol: free_bytes:int=200*1024**3
@dataclass(frozen=True)
class Host: cpu:CPU=CPU(); memory:Mem=Mem(); storage:tuple=(Vol(),)
class HW:
    def discover(self): return Host()
@dataclass(frozen=True)
class Dev:
    backend:str="ROCm"; memory_total_bytes:int=12*1024**3
@dataclass(frozen=True)
class Accel: devices:tuple=(Dev(),)
class GPU:
    def discover(self): return Accel()

def manager(tmp):
    db=StateDatabase(Path(tmp)/"s.db")
    audit=AuditTrail(db)
    return ResourceManager(HW(),GPU(),db,audit),audit

def test_conservative_envelope_and_lease():
    with tempfile.TemporaryDirectory() as t:
        r,a=manager(t)
        e=r.envelope()
        assert e.cpu_logical_limit==12
        assert e.memory_limit_bytes==24*1024**3
        assert e.gpu_memory_limit_bytes==int(12*1024**3*.8)
        lease=r.admit("test",ResourceRequest(cpu_logical=2,memory_bytes=1024**3,gpu_memory_bytes=1024**3))
        assert len(r.leases())==1
        assert r.release(lease.lease_id)
        ok,msg=a.verify(); assert ok,msg

def test_oversubscription_denied():
    with tempfile.TemporaryDirectory() as t:
        r,_=manager(t)
        try:
            r.admit("too-big",ResourceRequest(cpu_logical=16))
        except ResourcePolicyError:
            pass
        else:
            raise AssertionError("CPU oversubscription allowed")

def test_unknown_vram_denies_vram_reservation():
    class UnknownGPU:
        def discover(self):
            @dataclass(frozen=True)
            class UDev:
                backend:str="OS_VISIBLE"; memory_total_bytes:object=None
            @dataclass(frozen=True)
            class UInv:
                devices:tuple=(UDev(),)
            return UInv()
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"s.db"); a=AuditTrail(db)
        r=ResourceManager(HW(),UnknownGPU(),db,a)
        assert r.envelope().conservative_due_to_unknown_gpu_vram
        try:
            r.admit("gpu",ResourceRequest(gpu_memory_bytes=1))
        except ResourcePolicyError:
            pass
        else:
            raise AssertionError("Unknown VRAM was allowed")
