from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.persistent_safety_gate import PersistentSafetyGate
from aeon.genesis_execution_gate import GenesisExecutionGate
from aeon.independent_watchdog import IndependentWatchdog
from aeon.execution_admission import ExecutionAdmission
from aeon.integrated_execution_controller import IntegratedExecutionController
from aeon.release_candidate_qualifier import ReleaseCandidateQualifier
def test_rc_qualification_exercises_guarded_chain_and_detects_tamper():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);sg=PersistentSafetyGate(db,a);gg=GenesisExecutionGate(db,a,sg);wd=IndependentWatchdog(db,a,sg);ea=ExecutionAdmission(db,a,sg,gg,wd);ic=IntegratedExecutionController(db,a,ea,sg);q=ReleaseCandidateQualifier(db,a,sg,gg,wd,ea,ic)
  r=q.run();assert r.status=="PASS" and q.verify(r.qualification_id)["all_ok"]
  with db.transaction() as c:c.execute("UPDATE p095_rc_qualifications SET checks_json=checks_json||'x' WHERE qualification_id=?",(r.qualification_id,))
  assert not q.verify(r.qualification_id)["all_ok"]
