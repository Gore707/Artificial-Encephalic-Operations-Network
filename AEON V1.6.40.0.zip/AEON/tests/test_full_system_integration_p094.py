from pathlib import Path
import tempfile,pytest
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.persistent_safety_gate import PersistentSafetyGate
from aeon.genesis_execution_gate import GenesisExecutionGate
from aeon.independent_watchdog import IndependentWatchdog
from aeon.execution_admission import ExecutionAdmission
from aeon.integrated_execution_controller import IntegratedExecutionController
def test_guarded_integrated_execution_rechecks_safety_before_running():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);sg=PersistentSafetyGate(db,a);gg=GenesisExecutionGate(db,a,sg);wd=IndependentWatchdog(db,a,sg);ea=ExecutionAdmission(db,a,sg,gg,wd);ic=IntegratedExecutionController(db,a,ea,sg)
  desc={"model_version":"m1","topology":{"nodes":[{"id":"a"}],"edges":[]},"provenance":["MEASURED"]}
  cert=gg.validate("ani",b"state",desc);run=ic.admit("ani",b"state",cert.certificate_id);assert ic.require_runnable(run.run_id)
  sg.hold("NEW_WORK","operator hold","HUMAN_OPERATOR")
  with pytest.raises(Exception):ic.transition(run.run_id,"RUNNING")
  sg.release("NEW_WORK","reviewed","HUMAN_OPERATOR")
  assert ic.transition(run.run_id,"RUNNING").status=="RUNNING"
