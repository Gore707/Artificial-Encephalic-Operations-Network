from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.reconstruction_confidence import ReconstructionConfidenceService
class Claim:
 def __init__(self,p,c,t="n1",prop="v"):self.provenance=p;self.confidence=c;self.target_ref=t;self.property_name=prop
class Meta:
 claims=(Claim("MEASURED",.95),Claim("AI-RECONSTRUCTED",.99,"n2"),Claim("INFERRED",.6,"n3"))
 unknowns=("membrane_channel_state:n4",)
class M:
 def get(self,x):return Meta()
 def verify(self,x):return {"all_ok":True,"definition_ok":True}
def test_confidence_preserves_epistemic_classes():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=ReconstructionConfidenceService(db,a,M());q=s.assess("m")
  assert q.provenance_counts["MEASURED"]==1 and q.provenance_counts["AI-RECONSTRUCTED"]==1
  assert q.information_sufficiency=="UNDETERMINED" and q.unknown_count==1
  assert "does not promote" in q.details["interpretation"]
