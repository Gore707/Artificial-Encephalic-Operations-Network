from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_clock import NeuralClockService,NeuralClockError
def test_fixed_clock_and_sync():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);c=NeuralClockService(db,a);q=c.create("run","ms",0.25,"FIXED_STEP")
  q=c.advance(q.clock_id);q=c.advance(q.clock_id);assert q.current_time==0.5 and q.tick_index==2
  s=c.synchronize(q.clock_id,{"snn":0.5,"partition-b":0.5004},.001);assert s["synchronized"]
  s=c.synchronize(q.clock_id,{"snn":0.51},.001);assert not s["synchronized"]
def test_manual_requires_delta_and_hold_blocks_advance():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);c=NeuralClockService(db,a);q=c.create("manual")
  try:c.advance(q.clock_id)
  except NeuralClockError:pass
  else:raise AssertionError("manual clock advanced without delta")
  c.set_status(q.clock_id,"HELD")
  try:c.advance(q.clock_id,1)
  except NeuralClockError:pass
  else:raise AssertionError("held clock advanced")
