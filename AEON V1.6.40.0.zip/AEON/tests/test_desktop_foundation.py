from pathlib import Path
from aeon.config import load_config
from aeon.telemetry import HostTelemetry

def test_host_telemetry_returns_real_disk_measurement():
    root = Path(__file__).resolve().parents[1]
    snap = HostTelemetry(root).snapshot()
    assert snap.disk_total_bytes > 0
    assert 0 <= snap.disk_used_bytes <= snap.disk_total_bytes

def test_ui_configuration_is_valid():
    root = Path(__file__).resolve().parents[1]
    cfg = load_config(root)
    assert int(cfg.get("ui.telemetry_interval_ms")) >= 250
    assert "x" in str(cfg.get("ui.geometry"))
