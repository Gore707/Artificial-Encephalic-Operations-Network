from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.guardian import GuardianService,GuardianError

def setup(t):
    db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);g=GuardianService(db,a)
    return db,a,g

def test_guardian_records_provenanced_evidence():
    with tempfile.TemporaryDirectory() as t:
        db,a,g=setup(t)
        o=g.observe("host.telemetry","CPU sample accepted",["cpu.utilization=22%"],
                    status="OBSERVING",confidence_kind="DETERMINISTIC",provenance="MEASURED")
        assert o.provenance=="MEASURED" and o.evidence and g.status=="OBSERVING"
        ok,msg=a.verify();assert ok,msg

def test_hypothesis_requires_explicit_non_deterministic_class():
    with tempfile.TemporaryDirectory() as t:
        db,a,g=setup(t)
        o=g.observe("guardian.analysis","Possible workload contention",["latency trend"],
                    status="ADVISORY",confidence_kind="HYPOTHESIS",confidence=.61,provenance="DERIVED")
        assert o.confidence_kind=="HYPOTHESIS" and o.confidence==.61
        try:g.observe("x","bad",confidence_kind="DETERMINISTIC",confidence=.9)
        except GuardianError:pass
        else:raise AssertionError("deterministic fact accepted probabilistic confidence")

def test_guardian_has_no_safety_bypass_surface():
    with tempfile.TemporaryDirectory() as t:
        db,a,g=setup(t)
        forbidden=("kill_process","restore","rollback","execute","write_hardware","override_safety")
        assert all(not hasattr(g,name) for name in forbidden)
        try:g.set_status("INVALID","test")
        except GuardianError:pass
        else:raise AssertionError("invalid status accepted")
