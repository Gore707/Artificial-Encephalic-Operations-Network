from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.neuroimaging_ingestion import NeuroimagingIngestion
def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);d=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"));return d,NeuroimagingIngestion(db,a,d)
def test_registration_binds_source_and_metadata():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);d,n=setup(root);p=root/"volume.dat";p.write_bytes(b"imaging-test");ds=d.register_file(p,"vol","IMPORTED","MEASURED")
  q=n.register(ds.dataset_id,"EM","fixed",{"x_nm":4,"y_nm":4,"z_nm":30},["electron"],{"frame":"static"},["sectioned"],["dynamic_state"],{"resolution_nm":1})
  assert q.source_sha256==ds.sha256 and n.verify(q.imaging_id)["all_ok"] and n.completeness(q.imaging_id)["complete_for_declared_fields"]
def test_missing_fields_are_reported_not_inferred():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);d,n=setup(root);p=root/"x.dat";p.write_bytes(b"x");ds=d.register_file(p,"x","IMPORTED","UNKNOWN");q=n.register(ds.dataset_id,"OTHER")
  c=n.completeness(q.imaging_id);assert "resolution" in c["missing"] and "uncertainty" in c["missing"] and "Information Sufficiency" in c["note"]
