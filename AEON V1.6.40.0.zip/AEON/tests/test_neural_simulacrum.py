from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neuron_simulation import NeuronSimulationEngine
from aeon.synapse_engine import SynapseEngine
from aeon.snn_engine import SNNEngine
from aeon.neural_clock import NeuralClockService
from aeon.neural_partition import NeuralPartitionService
from aeon.gpu_execution import GPUExecutionEngine
from aeon.distributed_neural import DistributedNeuralExecution
from aeon.neural_simulacrum import NeuralSimulacrum,NeuralSimulacrumError
def stack(path):
 db=StateDatabase(path);a=AuditTrail(db);ne=NeuronSimulationEngine(db,a);sy=SynapseEngine(db,a);sn=SNNEngine(db,a,ne,sy);cl=NeuralClockService(db,a);pa=NeuralPartitionService(db,a,sn);gp=GPUExecutionEngine(db,a);di=DistributedNeuralExecution(db,a,pa,cl,sn);si=NeuralSimulacrum(db,a,sn,cl,pa,gp,di);return ne,sy,sn,cl,pa,gp,di,si
def test_integrated_local_runtime():
 with tempfile.TemporaryDirectory() as x:
  ne,sy,sn,cl,pa,gp,di,si=stack(Path(x)/"s.db");m=ne.create_lif_model();st=ne.initialize(m.model_id)
  net=sn.create("one",[{"node_id":"n","state_id":st.state_id}]);clock=cl.create("clock")
  r=si.create("sim",net.network_id,clock.clock_id);assert si.readiness(r.runtime_id)["mathematical_runtime_ready"]
  out=si.step_local(r.runtime_id,1.0,{"n":0.0});assert out["clock_time"]==1.0 and out["network"]["simulation_time_ms"]==1.0
  rd=si.readiness(r.runtime_id);assert not rd["ani_execution_authorized"] and rd["information_sufficiency"]=="UNDETERMINED"
def test_unsynchronized_start_rejected():
 with tempfile.TemporaryDirectory() as x:
  ne,sy,sn,cl,pa,gp,di,si=stack(Path(x)/"s.db");st=ne.initialize(ne.create_lif_model().model_id);net=sn.create("one",[{"node_id":"n","state_id":st.state_id}]);clock=cl.create("clock");cl.advance(clock.clock_id,1)
  try:si.create("bad",net.network_id,clock.clock_id)
  except NeuralSimulacrumError:pass
  else:raise AssertionError("unsynchronized runtime accepted")
