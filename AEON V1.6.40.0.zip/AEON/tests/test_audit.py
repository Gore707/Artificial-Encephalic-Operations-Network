from pathlib import Path
import sqlite3, tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail

def test_audit_chain_and_append_only():
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"state.sqlite3")
        audit=AuditTrail(db)
        a=audit.append("INFO","test","start",details={"value":1})
        b=audit.append("WARNING","test","warning",subject="unit")
        ok,detail=audit.verify()
        assert ok,detail
        assert b.previous_hash==a.event_hash
        try:
            with db.transaction() as conn:
                conn.execute("DELETE FROM audit_events WHERE event_id=?",(a.event_id,))
        except sqlite3.DatabaseError:
            pass
        else:
            raise AssertionError("append-only audit delete was allowed")
