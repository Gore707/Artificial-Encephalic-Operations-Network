from pathlib import Path
import tempfile,csv,json
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.visualization import VisualizationStore,Series,VisualizationError
def test_figure_persistence_and_exports():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);v=VisualizationStore(db,a,Path(t))
  f=v.create("Measured trace","time (s)","signal (mV)",
             [Series("trace",(0,1,2),(1,3,2),"s","mV","MEASURED","source-1")])
  assert v.get(f.figure_id).series[0].provenance=="MEASURED"
  p=v.export_csv(f.figure_id);rows=list(csv.reader(p.open()))
  assert rows[0][0:3]==["series","x","y"] and len(rows)==4
  q=v.export_spec(f.figure_id);assert json.loads(q.read_text())["figure_id"]==f.figure_id
  ok,msg=a.verify();assert ok,msg
def test_rejects_invalid_quantitative_data():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);v=VisualizationStore(db,a,Path(t))
  try:v.create("bad","x","y",[Series("x",(1,),(float("nan"),))])
  except VisualizationError:pass
  else:raise AssertionError("NaN accepted")
