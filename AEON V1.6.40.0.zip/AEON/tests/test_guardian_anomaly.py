from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.guardian import GuardianService
from aeon.guardian_anomaly import GuardianAnomalyDetector,AnomalyError

class Sample:
    def __init__(self,v,unit="%",provenance="MEASURED"):self.value=v;self.unit=unit;self.provenance=provenance
class Stream:
    def __init__(self,values):self.values=values
    def read(self,channel,limit):return tuple(Sample(v) for v in self.values[-limit:])

def test_nominal_window_does_not_create_alert():
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);g=GuardianService(db,a)
        d=GuardianAnomalyDetector(g,Stream([10,11,9,10,10,11,9,10]),a,min_samples=8)
        r=d.assess_channel("cpu");assert not r.anomalous and r.severity=="NOMINAL" and not g.list()

def test_outlier_is_statistical_guardian_evidence():
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);g=GuardianService(db,a)
        d=GuardianAnomalyDetector(g,Stream([10,10.2,9.8,10.1,9.9,10.0,10.1,30]),a,min_samples=8)
        r=d.assess_channel("cpu")
        assert r.anomalous and r.severity=="WARNING"
        o=g.list()[0];assert o.confidence_kind=="STATISTICAL" and "not by itself" in o.summary
        ok,msg=a.verify();assert ok,msg

def test_mixed_units_and_short_windows_rejected():
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);g=GuardianService(db,a)
        class Mixed:
            def read(self,channel,limit):return tuple([Sample(1,"%")]*7+[Sample(2,"C")])
        d=GuardianAnomalyDetector(g,Mixed(),a,min_samples=8)
        try:d.assess_channel("bad")
        except AnomalyError:pass
        else:raise AssertionError("mixed-unit baseline accepted")
        try:d.assess_values("short",[1,2,3])
        except AnomalyError:pass
        else:raise AssertionError("short baseline accepted")
