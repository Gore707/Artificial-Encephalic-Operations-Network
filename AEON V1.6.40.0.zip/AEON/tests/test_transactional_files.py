from pathlib import Path
import hashlib,tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.transactional_files import TransactionalFileStore,TransactionalWriteError
def test_replace_preserves_verified_backup():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);s=TransactionalFileStore(db,a,Path(t))
  p=Path(t)/"state.json";p.write_bytes(b"old")
  b=s.write_bytes(p,b"new")
  assert p.read_bytes()==b"new" and b is not None
  assert Path(b.backup_path).read_bytes()==b"old"
  assert s.verify_backup(b.backup_id)==(True,"ok")
  ok,msg=a.verify();assert ok,msg
def test_optimistic_digest_guard():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);s=TransactionalFileStore(db,a,Path(t))
  p=Path(t)/"x";p.write_bytes(b"a");expected=hashlib.sha256(b"a").hexdigest()
  p.write_bytes(b"changed")
  try:s.write_bytes(p,b"next",expected)
  except TransactionalWriteError:pass
  else:raise AssertionError("stale expected digest accepted")
  assert p.read_bytes()==b"changed"
def test_new_file_has_no_backup():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);s=TransactionalFileStore(db,a,Path(t))
  p=Path(t)/"new.bin";b=s.write_bytes(p,b"first")
  assert b is None and p.read_bytes()==b"first" and not s.backups(p)
