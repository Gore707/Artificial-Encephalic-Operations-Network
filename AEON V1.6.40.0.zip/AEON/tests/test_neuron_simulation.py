from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neuron_simulation import NeuronSimulationEngine,NeuronSimulationError
def test_lif_rest_and_spike_are_deterministic():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);e=NeuronSimulationEngine(db,a);m=e.create_lif_model()
  s=e.initialize(m.model_id);s=e.step(s.state_id,1.0,0.0);assert abs(s.values["v_mv"]+65)<1e-12 and not s.values["spike"]
  fired=False
  for _ in range(50):
   s=e.step(s.state_id,1.0,1.0);fired |= s.values["spike"]
  assert fired and s.simulation_time==51.0
def test_invalid_dt_rejected():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);e=NeuronSimulationEngine(db,a);s=e.initialize(e.create_lif_model().model_id)
  try:e.step(s.state_id,0)
  except NeuronSimulationError:pass
  else:raise AssertionError("zero timestep accepted")
