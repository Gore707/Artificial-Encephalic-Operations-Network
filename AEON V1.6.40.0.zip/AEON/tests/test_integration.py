from pathlib import Path
import tempfile
from types import SimpleNamespace
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.integration import IntegrationDiagnostics
class Good:
 def integrity_check(self):return "ok"
class HW:
 def snapshot(self):return SimpleNamespace(logical_cpu_count=16)
class Acc:
 def discover(self):return ()
class Stream:
 def channels(self):return ()
class Lister:
 def list(self):return ()
class Backups:
 def list_backups(self):return ()
class Recovery:
 def list_events(self):return ()
def test_cross_service_report_is_real_and_audited():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db)
  s=SimpleNamespace(state_db=Good(),audit=a,hardware=HW(),accelerators=Acc(),telemetry_stream=Stream(),
    jobs=Lister(),checkpoints=Lister(),integrity=Lister(),transactional_files=Backups(),recovery=Recovery(),
    nodes=Lister(),cluster=SimpleNamespace(local=SimpleNamespace(node_id="node-test")),
    guardian=SimpleNamespace(status="NOMINAL"),safety_kernel=SimpleNamespace(list_rules=lambda:()),
    genesis=object())
  r=IntegrationDiagnostics(s,a).run();assert r.passed and len(r.checks)>=15
  ok,msg=a.verify();assert ok,msg
def test_failed_service_produces_failed_report_not_fake_pass():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db)
  class Bad:
   def integrity_check(self):raise RuntimeError("deliberate failure")
  s=SimpleNamespace(state_db=Bad(),audit=a,hardware=HW(),accelerators=Acc(),telemetry_stream=Stream(),
    jobs=Lister(),checkpoints=Lister(),integrity=Lister(),transactional_files=Backups(),recovery=Recovery(),
    nodes=Lister(),cluster=SimpleNamespace(local=SimpleNamespace(node_id="node-test")),
    guardian=SimpleNamespace(status="NOMINAL"),safety_kernel=SimpleNamespace(list_rules=lambda:()),
    genesis=object())
  r=IntegrationDiagnostics(s,a).run();assert not r.passed
  assert any(not c.passed and c.name=="database.integrity" for c in r.checks)
