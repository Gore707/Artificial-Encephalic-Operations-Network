from pathlib import Path
import tempfile,json
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.process_failure_qualification import ProcessFailureQualification
def test_exception_hard_exit_and_hang_are_contained():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);q=ProcessFailureQualification(db,a)
  for scenario in ("EXCEPTION","HARD_EXIT","HANG"):
   r=q.run(scenario,.15);obs=json.loads(r.observed_json)
   assert r.contained and not obs["worker_alive"] and obs["passed"]
  s=q.summary();assert s["executed"]==3 and s["contained"]==3
