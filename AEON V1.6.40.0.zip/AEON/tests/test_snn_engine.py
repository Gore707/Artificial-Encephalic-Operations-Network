from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neuron_simulation import NeuronSimulationEngine
from aeon.synapse_engine import SynapseEngine
from aeon.snn_engine import SNNEngine,SNNEngineError
def test_two_neuron_network_propagates_spike_deterministically():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);ne=NeuronSimulationEngine(db,a);se=SynapseEngine(db,a);sn=SNNEngine(db,a,ne,se)
  m=ne.create_lif_model();n1=ne.initialize(m.model_id);n2=ne.initialize(m.model_id);sm=se.create_current_exponential(5.0,tau_ms=5,delay_ms=0);ss=se.initialize(sm.model_id)
  net=sn.create("pair",[{"node_id":"a","state_id":n1.state_id},{"node_id":"b","state_id":n2.state_id}],[{"edge_id":"e","source_node_id":"a","target_node_id":"b","state_id":ss.state_id}])
  first=sn.step(net.network_id,1,{"a":4.0});assert "a" in first["spikes"]
  second=sn.step(net.network_id,1);assert second["incoming_current_na"]["b"]>0 and second["step_index"]==2
def test_missing_endpoint_rejected():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);ne=NeuronSimulationEngine(db,a);se=SynapseEngine(db,a);sn=SNNEngine(db,a,ne,se)
  st=ne.initialize(ne.create_lif_model().model_id);ss=se.initialize(se.create_current_exponential(1).model_id)
  try:sn.create("bad",[{"node_id":"a","state_id":st.state_id}],[{"edge_id":"e","source_node_id":"a","target_node_id":"b","state_id":ss.state_id}])
  except SNNEngineError:pass
  else:raise AssertionError("missing endpoint accepted")
