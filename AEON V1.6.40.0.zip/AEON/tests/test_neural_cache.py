from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_cache_virtual_device import NeuralCacheVirtualDevice
from aeon.neural_cache_block import NeuralCacheBlockStore
from aeon.neural_cache_redundancy import NeuralCacheRedundantStorage
from aeon.neural_cache_checkpoint import NeuralCacheStateCheckpointService
from aeon.neural_cache_migration import NeuralCacheMigration
from aeon.neural_cache import NeuralCache
def test_neural_cache_1_0_end_to_end_recovery_checkpoint_migration():
 with tempfile.TemporaryDirectory() as x:
  root=Path(x);db=StateDatabase(root/"s.db");a=AuditTrail(db);ds=NeuralCacheVirtualDevice(db,a,root/"cache")
  d1=ds.create("a",4*1024*1024);d2=ds.create("b",4*1024*1024);d3=ds.create("c",4*1024*1024)
  bs=NeuralCacheBlockStore(db,a,ds);rs=NeuralCacheRedundantStorage(db,a,ds,bs);cs=NeuralCacheStateCheckpointService(db,a,bs);ms=NeuralCacheMigration(db,a,ds,bs)
  nc=NeuralCache(db,a,ds,bs,rs,cs,ms);v=nc.create_volume("brain-state",(d1.device_id,d2.device_id,d3.device_id))
  payload=b"validated-neural-state"*4000;w=nc.write_state(v.volume_id,payload,replicas=2);assert nc.verify_state(w["block_id"],w["replica_set_id"])["recoverable"]
  b=bs.get(w["block_id"]);p=Path(b.path);raw=bytearray(p.read_bytes());raw[-1]^=1;p.write_bytes(raw)
  assert nc.recover_state(w["block_id"],w["replica_set_id"])==payload
  # Use the valid replica for checkpoint/migration because corrupt source must never be silently accepted.
  valid_replica=rs.get(w["replica_set_id"]).replica_block_ids[0]
  ck=nc.checkpoint_state("run",7,.7,"ms",(valid_replica,));assert cs.verify(ck.checkpoint_id)["all_ok"]
  mig=nc.migrate_state(valid_replica,d3.device_id);assert ms.verify(mig.migration_id)["all_ok"]
  h=nc.health();assert h["physical_hardware"].startswith("NOT IMPLEMENTED") and h["corrective_ecc"] is False
