from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_cache_virtual_device import NeuralCacheVirtualDevice
from aeon.neural_cache_block import NeuralCacheBlockStore,NeuralCacheBlockError
def test_block_roundtrip_and_corruption_detection():
 with tempfile.TemporaryDirectory() as x:
  root=Path(x);db=StateDatabase(root/"s.db");a=AuditTrail(db);devs=NeuralCacheVirtualDevice(db,a,root/"cache");d=devs.create("d",2*1024*1024)
  s=NeuralCacheBlockStore(db,a,devs);payload=b"neural-state"*1000;b=s.write(d.device_id,payload,metadata={"source":"test"})
  assert s.verify(b.block_id)["all_ok"] and s.read(b.block_id)==payload
  p=Path(b.path);raw=bytearray(p.read_bytes());raw[-1]^=1;p.write_bytes(raw)
  v=s.verify(b.block_id);assert not v["all_ok"] and (not v["sha256_ok"] or not v["crc32_ok"])
  try:s.read(b.block_id)
  except NeuralCacheBlockError:pass
  else:raise AssertionError("corrupt block read as valid")
