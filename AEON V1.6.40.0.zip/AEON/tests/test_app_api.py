from pathlib import Path
from aeon.app_api import AppRegistry, AppDescriptor, AppAPIError

def test_registry_is_read_only_by_snapshot():
    registry = AppRegistry()
    descriptor = AppDescriptor("x", "X", "1.0", lambda ctx: None)
    registry.register(descriptor)
    snap = registry.snapshot()
    assert snap["x"] is descriptor
    try:
        snap["y"] = descriptor
    except TypeError:
        pass
    else:
        raise AssertionError("registry snapshot was mutable")

def test_unknown_app_is_explicit_error():
    registry = AppRegistry()
    try:
        registry.get("missing")
    except AppAPIError:
        pass
    else:
        raise AssertionError("unknown app did not raise AppAPIError")
