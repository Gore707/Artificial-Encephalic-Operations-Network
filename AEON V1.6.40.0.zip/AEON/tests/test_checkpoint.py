from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.checkpoint import CheckpointStore,CheckpointError
def test_checkpoint_roundtrip_and_restore():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);s=CheckpointStore(db,a,Path(t))
  cp=s.create_bytes("experiment","run-1","tick-100",b"state-data",{"tick":100})
  assert cp.size_bytes==10 and cp.consistency=="BYTE_ATOMIC"
  assert s.verify(cp.checkpoint_id)==(True,"ok")
  out=s.restore_copy(cp.checkpoint_id,Path(t)/"restored.bin")
  assert out.read_bytes()==b"state-data"
  ok,msg=a.verify();assert ok,msg
def test_tamper_detected():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);s=CheckpointStore(db,a,Path(t))
  cp=s.create_bytes("simulation","sim-1","state",b"abc")
  p=Path(cp.payload_path);p.chmod(0o644);p.write_bytes(b"abd")
  ok,msg=s.verify(cp.checkpoint_id);assert not ok and msg=="sha256 mismatch"
  try:s.restore_copy(cp.checkpoint_id,Path(t)/"bad.bin")
  except CheckpointError:pass
  else:raise AssertionError("corrupt checkpoint restored")
def test_file_capture():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);s=CheckpointStore(db,a,Path(t))
  src=Path(t)/"source.bin";src.write_bytes(b"x"*4096)
  cp=s.create_file("job","j1","closed-file",src)
  assert s.verify(cp.checkpoint_id)[0]
