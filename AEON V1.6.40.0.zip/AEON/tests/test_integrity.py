from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.integrity import IntegrityService
def test_register_and_verify():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);svc=IntegrityService(db,a)
  p=Path(t)/"x.bin";p.write_bytes(b"A"*9000)
  rec=svc.register_file("dataset","d1",p,4096)
  result=svc.verify(rec.record_id)
  assert result.ok and result.bad_chunks==()
  ok,msg=a.verify();assert ok,msg
def test_chunk_corruption_localized():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);svc=IntegrityService(db,a)
  p=Path(t)/"x.bin";p.write_bytes(b"A"*4096+b"B"*4096+b"C"*4096)
  rec=svc.register_file("checkpoint","c1",p,4096)
  data=bytearray(p.read_bytes());data[5000]^=0xff;p.write_bytes(data)
  result=svc.verify(rec.record_id)
  assert not result.ok and result.bad_chunks==(1,) and "SHA-256 mismatch" in result.reason
def test_truncation_detected():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);svc=IntegrityService(db,a)
  p=Path(t)/"x.bin";p.write_bytes(b"x"*10000)
  rec=svc.register_file("source","s1",p,4096);p.write_bytes(b"x"*2000)
  result=svc.verify(rec.record_id)
  assert not result.ok and result.actual_size==2000 and "size mismatch" in result.reason
