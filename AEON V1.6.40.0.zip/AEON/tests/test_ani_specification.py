from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.ani_specification import ANISpecificationService,ANISpecificationError
class C:
 def get(self,x):raise KeyError
 def verify(self,x):return {"all_ok":False}
def test_ani_schema_tracks_unknowns_without_sufficiency_claim():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=ANISpecificationService(db,a,C())
  q=s.create("research-state",[{"field_id":"topology","domain":"TOPOLOGY","name":"graph","value_type":"graph","required":True,"provenance":"DERIVED"},{"field_id":"vm","domain":"DYNAMIC","name":"membrane potential","unit":"mV","value_type":"float","required":True,"provenance":"UNKNOWN"}],unmeasured_domains=["MOLECULAR","GLIAL"],assumptions=["dynamic state unavailable"])
  assert s.verify(q.ani_spec_id)["all_ok"]
  c=s.completeness(q.ani_spec_id);assert c["information_sufficiency"]=="UNDETERMINED" and c["required_unknown_fields"]==("vm",)
def test_bad_provenance_rejected():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=ANISpecificationService(db,a,C())
  try:s.create("bad",[{"domain":"TOPOLOGY","name":"x","value_type":"graph","provenance":"MAGIC"}])
  except ANISpecificationError:pass
  else:raise AssertionError("invalid provenance accepted")
