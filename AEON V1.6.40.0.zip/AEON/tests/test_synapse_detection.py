from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.neuroimaging_ingestion import NeuroimagingIngestion
from aeon.volume_reconstruction import VolumeReconstructionService
from aeon.neuron_segmentation import NeuronSegmentationService
from aeon.neurite_tracing import NeuriteTracingService
from aeon.synapse_detection import SynapseDetectionService,SynapseDetectionError
def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);d=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"));n=NeuroimagingIngestion(db,a,d);v=VolumeReconstructionService(db,a,d,n);s=NeuronSegmentationService(db,a,v);t=NeuriteTracingService(db,a,s);y=SynapseDetectionService(db,a,t)
 p=root/"v.dat";p.write_bytes(b"v");ds=d.register_file(p,"v","IMPORTED","MEASURED");im=n.register(ds.dataset_id,"EM","fixed",{"nm":4},["electron"],{"static":True});vol=v.define(im.imaging_id,(4,4,4),{"nm":4},"SOURCE");sg=s.create(vol.volume_id,"manual","1",[{"segment_id":"a","voxel_count":4},{"segment_id":"b","voxel_count":4}])
 ta=t.create(sg.segmentation_id,"a","trace","1",[{"node_id":"a1","xyz":[0,0,0],"kind":"AXON"}],[]);tb=t.create(sg.segmentation_id,"b","trace","1",[{"node_id":"b1","xyz":[1,0,0],"kind":"DENDRITE"}],[]);return y,ta,tb
def test_candidate_contact_is_bound_and_not_functional_claim():
 with tempfile.TemporaryDirectory() as x:
  y,a,b=setup(Path(x));q=y.create("manual-reviewed","1",[{"pre_trace_id":a.trace_id,"pre_node_id":"a1","post_trace_id":b.trace_id,"post_node_id":"b1","xyz":[.5,0,0],"kind":"CHEMICAL","direction":"DIRECTED","confidence":.91,"provenance":"MEASURED"}])
  assert y.verify(q.detection_id)["all_ok"];s=y.summary(q.detection_id);assert s["chemical"]==1 and "does not establish" in s["note"]
def test_missing_trace_rejected():
 with tempfile.TemporaryDirectory() as x:
  y,a,b=setup(Path(x))
  try:y.create("x","1",[{"pre_trace_id":"missing"}])
  except Exception:pass
  else:raise AssertionError("missing trace accepted")
