from pathlib import Path
import tempfile,json
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.persistent_safety_gate import PersistentSafetyGate
from aeon.genesis_execution_gate import GenesisExecutionGate
from aeon.independent_watchdog import IndependentWatchdog
from aeon.execution_admission import ExecutionAdmission
from aeon.integrated_execution_controller import IntegratedExecutionController
from aeon.release_candidate_qualifier import ReleaseCandidateQualifier
from aeon.apotheosis_research_stack import ApotheosisResearchStack
def test_final_release_is_integrity_bound_and_scientifically_bounded():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);sg=PersistentSafetyGate(db,a);gg=GenesisExecutionGate(db,a,sg);wd=IndependentWatchdog(db,a,sg);ea=ExecutionAdmission(db,a,sg,gg,wd);ic=IntegratedExecutionController(db,a,ea,sg);rc=ReleaseCandidateQualifier(db,a,sg,gg,wd,ea,ic);rs=ApotheosisResearchStack(db,a,rc,sg,gg,wd,ic)
  r=rs.qualify_release();m=json.loads(r.manifest_json)
  assert r.status=="PASS_WITH_RESIDUAL_DEBT" and rs.verify(r.release_id)["all_ok"]
  assert m["scientific_status"]["information_sufficiency"]=="UNDETERMINED"
  assert m["scientific_status"]["brain_uploading_currently_demonstrated"] is False
  assert len(m["residual_engineering_debt"])>=1
  with db.transaction() as c:c.execute("UPDATE p096_research_stack_releases SET manifest_json=manifest_json||'x' WHERE release_id=?",(r.release_id,))
  assert not rs.verify(r.release_id)["all_ok"]
