from pathlib import Path
import tempfile
import pytest
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.persistent_safety_gate import PersistentSafetyGate,PersistentSafetyGateError
def test_gate_persists_and_guardian_cannot_mutate():
 with tempfile.TemporaryDirectory() as x:
  p=Path(x)/"s.db";db=StateDatabase(p);g=PersistentSafetyGate(db,AuditTrail(db))
  g.hold("NEW_WORK","qualification fault","SAFETY_KERNEL")
  with pytest.raises(PersistentSafetyGateError):g.require_clear("NEW_WORK")
  with pytest.raises(PersistentSafetyGateError):g.release("NEW_WORK","ai wants release","GUARDIAN")
  # New service instance against same DB proves restart persistence.
  db2=StateDatabase(p);g2=PersistentSafetyGate(db2,AuditTrail(db2))
  assert g2.get("NEW_WORK").held
  g2.release("NEW_WORK","operator reviewed","HUMAN_OPERATOR")
  assert g2.require_clear("NEW_WORK")
