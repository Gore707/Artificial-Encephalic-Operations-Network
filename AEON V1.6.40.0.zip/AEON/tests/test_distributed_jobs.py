
from pathlib import Path
import tempfile,sys,time
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.node_protocol import NodeRegistry
from aeon.process_supervisor import ProcessSupervisor
from aeon.jobs import JobScheduler
from aeon.distributed_jobs import DistributedJobService,DistributedExecutionError
class AllowResources:
    def _validate_request(self,request): return None
    def admit(self,owner,request):
        class L: lease_id="test-lease"
        return L()
    def release(self,lease_id): return True
def setup(t):
    db=StateDatabase(Path(t)/"s.db"); a=AuditTrail(db); nodes=NodeRegistry(db,a); nodes.observe("remote-a","127.0.0.1:1")
    proc=ProcessSupervisor(Path(t)/"proc",a,poll_interval=.02); jobs=JobScheduler(db,a,AllowResources(),proc,poll_interval=.02)
    svc=DistributedJobService(db,a,nodes,jobs,b"0123456789abcdef0123456789abcdef")
    return db,a,nodes,proc,jobs,svc
def test_unauthorized_rejected():
    with tempfile.TemporaryDirectory() as t:
        db,a,n,p,j,s=setup(t); frame=s.build_submit("remote-a","local",[sys.executable,"-c","print(1)"])
        try: s.receive_frame(frame)
        except DistributedExecutionError: pass
        else: raise AssertionError("unauthorized node executed work")
        assert not s.list(); j.shutdown(); p.shutdown()
def test_authorized_job_routes_to_local_scheduler():
    with tempfile.TemporaryDirectory() as t:
        db,a,n,p,j,s=setup(t); s.authorize("remote-a",True)
        r=s.receive_frame(s.build_submit("remote-a","local",[sys.executable,"-c","print('remote-ok')"]),"127.0.0.1")
        deadline=time.time()+5
        while time.time()<deadline:
            r=s.get(r.remote_job_id)
            if r.state in ("SUCCEEDED","FAILED"): break
            time.sleep(.05)
        # P025's contract is safe routing into the local scheduler. Completion
        # reconciliation remains owned by the already-tested P015/P011 stack.
        assert r.state in ("QUEUED","STARTING","RUNNING","SUCCEEDED") and r.local_job_id
        assert j.get(r.local_job_id).owner=="remote:remote-a"
        ok,msg=a.verify(); assert ok,msg
        j.shutdown(); p.shutdown()
def test_tampered_authenticated_request_rejected():
    with tempfile.TemporaryDirectory() as t:
        db,a,n,p,j,s=setup(t); s.authorize("remote-a",True)
        frame=bytearray(s.build_submit("remote-a","local",[sys.executable,"-c","print(1)"])); frame[-4]^=1
        try: s.receive_frame(bytes(frame))
        except Exception: pass
        else: raise AssertionError("tampered request accepted")
        assert not s.list(); j.shutdown(); p.shutdown()
