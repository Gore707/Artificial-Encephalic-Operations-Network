from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.cognitive_anomaly import CognitiveAnomalyDetector,CognitiveAnomalyError
def test_robust_anomaly_detection_and_dedupe():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);d=CognitiveAnomalyDetector(db,a)
  for v in (10,10.1,9.9,10.05,9.95,10.02):d.observe("population-a","firing_rate",v,"Hz","DERIVED",1.0,"telemetry:test")
  o=d.observe("population-a","firing_rate",50,"Hz","DERIVED",.9,"telemetry:test")
  z=d.detect_robust_z(o.observation_id,window=16,minimum_history=5);assert z is not None and z.severity=="CRITICAL" and z.details["provenance"]=="DERIVED"
  assert d.detect_robust_z(o.observation_id,window=16,minimum_history=5).anomaly_id==z.anomaly_id
def test_insufficient_history_returns_no_finding():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);d=CognitiveAnomalyDetector(db,a);o=d.observe("s","m",1,"u","MEASURED",1,"src")
  assert d.detect_robust_z(o.observation_id) is None
