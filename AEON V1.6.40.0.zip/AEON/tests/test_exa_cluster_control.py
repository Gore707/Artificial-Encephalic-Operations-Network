from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.exa_cluster_control import ExaClusterControl
def test_cluster_lifecycle_and_stale_does_not_refresh_seen():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=ExaClusterControl(db,a)
  n=s.register("n1","127.0.0.1",9001,9002,{"gpu":"AMD"});seen=n.last_seen_unix
  n=s.heartbeat("n1","ONLINE");assert n.status=="ONLINE"
  h=s.hold("n1","maintenance");assert h.status=="HELD";assert s.mark_stale(.001,now=h.last_seen_unix+10)==()
  r=s.release("n1");old=r.last_seen_unix;st=s.mark_stale(.001,now=old+10);assert st==("n1",)
  off=s.get("n1");assert off.status=="OFFLINE" and off.last_seen_unix==old
def test_dashboard_has_no_arbitrary_execution():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=ExaClusterControl(db,a);s.register("n","localhost",1,2)
  assert s.dashboard()["arbitrary_remote_execution"] is False
