from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.security import IdentityAccessManager, AuthorizationError, IdentityError
from aeon.session import SessionManager

def test_bootstrap_authentication_and_permissions():
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"state.sqlite3")
        audit=AuditTrail(db)
        iam=IdentityAccessManager(db,audit)
        admin=iam.bootstrap_administrator("admin","Administrator","correct-horse-1")
        assert "security.manage" in iam.permissions_for(admin.user_id)
        assert iam.authenticate("admin","wrong-password") is None
        logged=iam.authenticate("admin","correct-horse-1")
        assert logged and logged.user_id==admin.user_id
        iam.require(admin.user_id,"system.protected",action="unit_test")

def test_fail_closed_and_repeated_bootstrap_blocked():
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"state.sqlite3")
        audit=AuditTrail(db)
        iam=IdentityAccessManager(db,audit)
        admin=iam.bootstrap_administrator("admin","Administrator","correct-horse-1")
        try:
            iam.require(None,"system.protected",action="dangerous")
        except AuthorizationError:
            pass
        else:
            raise AssertionError("anonymous protected action was allowed")
        try:
            iam.bootstrap_administrator("other","Other","another-pass-1")
        except IdentityError:
            pass
        else:
            raise AssertionError("second bootstrap administrator was allowed")

def test_session():
    with tempfile.TemporaryDirectory() as t:
        db=StateDatabase(Path(t)/"state.sqlite3")
        audit=AuditTrail(db)
        iam=IdentityAccessManager(db,audit)
        admin=iam.bootstrap_administrator("admin","Administrator","correct-horse-1")
        session=SessionManager()
        assert session.user_id is None
        session.login(admin)
        assert session.user_id==admin.user_id
        session.logout()
        assert session.user_id is None
