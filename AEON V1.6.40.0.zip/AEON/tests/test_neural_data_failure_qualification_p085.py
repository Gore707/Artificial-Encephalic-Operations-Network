from pathlib import Path
import tempfile,json,math
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_data_failure_qualification import NeuralDataFailureQualification
def test_neural_data_faults_are_detected_without_relabeling_ai_as_measured():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");q=NeuralDataFailureQualification(db,AuditTrail(db))
  assert q.nonfinite_state((0.0,float("nan"),1.0)).passed
  assert q.invalid_topology_reference(("n1","n2"),(("n1","n2"),("n2","missing"))).passed
  assert q.unlabeled_reconstruction(({"value":1,"provenance":"MEASURED"},{"value":2})).passed
  r=q.low_confidence_ai_reconstruction(.2,.8);o=json.loads(r.observed_json);assert r.passed and o["treated_as_measured"] is False
  assert q.summary()["passed"]==4
