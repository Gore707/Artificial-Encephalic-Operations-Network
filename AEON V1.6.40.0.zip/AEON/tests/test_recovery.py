from pathlib import Path
import hashlib,tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.transactional_files import TransactionalFileStore
from aeon.recovery import RecoveryManager,RecoveryError
def sha(b):return hashlib.sha256(b).hexdigest()
def test_verified_rollback_and_reverse_material():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);fs=TransactionalFileStore(db,a,Path(t));r=RecoveryManager(db,a,fs)
  p=Path(t)/"state";p.write_bytes(b"v1")
  b1=fs.write_bytes(p,b"v2")
  ev=r.rollback(b1.backup_id,expected_current_sha256=sha(b"v2"))
  assert p.read_bytes()==b"v1" and ev.status=="SUCCEEDED"
  assert ev.pre_recovery_backup_id is not None
  assert Path(fs.get(ev.pre_recovery_backup_id).backup_path).read_bytes()==b"v2"
  ok,msg=a.verify();assert ok,msg
def test_corrupt_backup_rejected_without_touching_target():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);fs=TransactionalFileStore(db,a,Path(t));r=RecoveryManager(db,a,fs)
  p=Path(t)/"state";p.write_bytes(b"old");b=fs.write_bytes(p,b"current")
  bp=Path(b.backup_path);bp.chmod(0o644);bp.write_bytes(b"corrupt")
  try:r.rollback(b.backup_id)
  except RecoveryError:pass
  else:raise AssertionError("corrupt backup accepted")
  assert p.read_bytes()==b"current"
def test_stale_current_guard():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db);fs=TransactionalFileStore(db,a,Path(t));r=RecoveryManager(db,a,fs)
  p=Path(t)/"state";p.write_bytes(b"a");b=fs.write_bytes(p,b"b");p.write_bytes(b"c")
  try:r.rollback(b.backup_id,expected_current_sha256=sha(b"b"))
  except Exception:pass
  else:raise AssertionError("stale current state overwritten")
  assert p.read_bytes()==b"c"
