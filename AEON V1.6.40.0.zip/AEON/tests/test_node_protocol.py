from pathlib import Path
import socket,tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.node_protocol import NodeCodec,NodeRegistry,NodeProtocolError,message
SECRET=b"test-secret-not-production"
def test_codec_roundtrip_and_authentication():
 m=message("HEARTBEAT","node-a",{"load":0.25},"node-b")
 frame=NodeCodec.encode(m,SECRET);got=NodeCodec.decode(frame,SECRET)
 assert got.message_id==m.message_id and got.payload["load"]==0.25
 bad=bytearray(frame);bad[-5]^=1
 try:NodeCodec.decode(bytes(bad),SECRET)
 except NodeProtocolError:pass
 else:raise AssertionError("tampered frame accepted")
def test_socket_framing():
 a,b=socket.socketpair()
 try:
  m=message("HELLO","a",{"protocol":1});a.sendall(NodeCodec.encode(m,SECRET))
  got=NodeCodec.recv(b,SECRET);assert got.message_type=="HELLO"
 finally:a.close();b.close()
def test_peer_registry():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");audit=AuditTrail(db);r=NodeRegistry(db,audit)
  r.observe("node-a","10.0.0.2:48230");p=r.get("node-a")
  assert p.status=="ONLINE" and p.protocol_version==1 and len(r.list())==1
