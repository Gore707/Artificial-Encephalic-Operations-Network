from pathlib import Path
import tempfile,math
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.synapse_engine import SynapseEngine,SynapseEngineError
def test_exponential_synapse_delay_and_decay():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);e=SynapseEngine(db,a);m=e.create_current_exponential(2.0,tau_ms=10,delay_ms=2);s=e.initialize(m.model_id)
  e.emit_presynaptic_spike(s.state_id);s=e.step(s.state_id,1);assert s.values["current_na"]==0
  s=e.step(s.state_id,1);assert abs(s.values["current_na"]-2)<1e-12
  s=e.step(s.state_id,10);assert abs(s.values["current_na"]-2*math.exp(-1))<1e-12
def test_bad_model_domain_rejected():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);e=SynapseEngine(db,a)
  try:e.create_current_exponential(1,tau_ms=0)
  except SynapseEngineError:pass
  else:raise AssertionError("invalid tau accepted")
