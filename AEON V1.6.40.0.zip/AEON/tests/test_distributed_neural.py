from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.distributed_neural import DistributedNeuralExecution,DistributedNeuralError
class O:
 def __init__(self,**kw):self.__dict__.update(kw)
class P:
 def get(self,x):return O(partition_count=2)
 def verify(self,x):return {"all_ok":True}
class C:
 def __init__(self):self.q=O(status="READY",current_time=1.0,time_unit="ms")
 def get(self,x):return self.q
 def synchronize(self,cid,parts,tol):
  rows=tuple({"participant":k,"time":v,"drift":v-self.q.current_time,"within_tolerance":abs(v-self.q.current_time)<=tol} for k,v in parts.items())
  return {"synchronized":all(x["within_tolerance"] for x in rows),"participants":rows}
def test_distributed_commit_and_desync_hold():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);e=DistributedNeuralExecution(db,a,P(),C(),None);r=e.create("p","c",{0:"node-a",1:"node-b"})
  ok=e.commit_step(r.run_id,{0:1.0,1:1.0001},.001);assert ok["committed"]
  bad=e.commit_step(r.run_id,{0:1.0,1:1.1},.001);assert not bad["committed"] and e.get(r.run_id).status=="DESYNCHRONIZED"
def test_all_partitions_must_be_assigned():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);e=DistributedNeuralExecution(db,a,P(),C(),None)
  try:e.create("p","c",{0:"node-a"})
  except DistributedNeuralError:pass
  else:raise AssertionError("incomplete partition mapping accepted")
