import threading,time
from aeon.telemetry_stream import TelemetryRingBuffer,TelemetryStreamError

def test_bounded_ring_and_aggregation():
 b=TelemetryRingBuffer(128)
 for i in range(200):
  b.publish("neural.population.rate",i,"Hz","DERIVED","sim-1",timestamp_unix=float(i))
 s=b.stats()
 assert s["retained"]==128
 assert s["oldest_sequence"]==73
 rows=b.read(channel="neural.population.rate",after_sequence=190)
 assert len(rows)==10 and rows[0].sequence==191
 w=b.aggregate("neural.population.rate",seconds=9,now_unix=199)
 assert w.count==10 and w.minimum==190 and w.maximum==199
 assert w.latest==199 and w.provenance=="DERIVED"

def test_provenance_and_finite_enforcement():
 b=TelemetryRingBuffer(128)
 try:b.publish("x",float("nan"))
 except TelemetryStreamError:pass
 else:raise AssertionError("NaN accepted")
 try:b.publish("x",1,provenance="FAKE")
 except TelemetryStreamError:pass
 else:raise AssertionError("invalid provenance accepted")

def test_wait_and_concurrent_publish():
 b=TelemetryRingBuffer(128)
 def worker():
  time.sleep(.05);b.publish("host.cpu",12.5,"%","MEASURED","host")
 t=threading.Thread(target=worker);t.start()
 seq=b.wait_for_sequence(0,.5);t.join()
 assert seq>=1 and b.latest("host.cpu").value==12.5
