from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.gpu_execution import GPUExecutionEngine,GPUExecutionError
def test_execution_always_has_truthful_available_backend():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);e=GPUExecutionEngine(db,a);r=e.vector_affine([1,2,3],2,-1)
  assert r.values==(1.0,3.0,5.0) and r.backend in ("CPU","CUDA","ROCM/HIP")
  assert e.summary()["preferred_backend"]==r.backend
def test_unavailable_backend_rejected():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);e=GPUExecutionEngine(db,a)
  try:e.vector_affine([1],backend="definitely-not-a-backend")
  except GPUExecutionError:pass
  else:raise AssertionError("unavailable backend accepted")
