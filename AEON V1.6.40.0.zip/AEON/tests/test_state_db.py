from pathlib import Path
import tempfile

from aeon.state_db import StateDatabase
from aeon.workspaces import WorkspaceStore


def test_state_database_roundtrip_and_integrity():
    with tempfile.TemporaryDirectory() as tmp:
        db = StateDatabase(Path(tmp) / "state.sqlite3")
        db.set("ui", "layout", {"name": "primary", "scale": 1.0})
        assert db.get("ui", "layout") == {"name": "primary", "scale": 1.0}
        assert db.namespace("ui")["layout"]["name"] == "primary"
        ok, detail = db.integrity_check()
        assert ok, detail


def test_workspace_store_uses_database():
    with tempfile.TemporaryDirectory() as tmp:
        state = Path(tmp)
        db = StateDatabase(state / "aeon_state.sqlite3")
        store = WorkspaceStore(state, db)
        ws = store.create("Persistent")
        assert store.active_id() == ws.workspace_id
        reopened = WorkspaceStore(state, StateDatabase(state / "aeon_state.sqlite3"))
        assert reopened.get(ws.workspace_id).name == "Persistent"
