from pathlib import Path
from aeon.config import load_config

def test_default_config_loads():
    root = Path(__file__).resolve().parents[1]
    cfg = load_config(root)
    assert cfg.get("aeon.name") == "AEON"
    assert cfg.get("aeon.project") == "GNS-2025-INITIATIVE-APOTHEOSIS"
    assert cfg.get("safety.fail_closed") is True
