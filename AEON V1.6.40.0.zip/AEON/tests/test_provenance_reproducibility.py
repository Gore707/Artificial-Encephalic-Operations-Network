from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.experiment_laboratory import ExperimentLaboratory
from aeon.provenance_reproducibility import ProvenanceReproducibilityStudio
def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);d=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"));e=ExperimentLaboratory(db,a,d);return a,d,e,ProvenanceReproducibilityStudio(db,a,d,e)
def test_manifest_binds_definition_and_dataset_hashes():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,d,e,r=setup(root);p=root/"x.csv";p.write_text("x\n1\n");ds=d.register_file(p,"x","SIMULATION","DERIVED");ex=e.define("test","SIMULATION",[ds.dataset_id],{"dt":0.1})
  q=r.capture(ex.experiment_id,"NUMERICALLY-REPRODUCIBLE",{"aeon":"test"},{"seed":42},{"python":"test"});v=r.verify(q.record_id)
  assert v["all_ok"] and q.dataset_bindings==((ds.dataset_id,ds.sha256),) and q.seeds["seed"]==42
def test_capture_does_not_prove_replay():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);a,d,e,r=setup(root);ex=e.define("nondet","SIMULATION");q=r.capture(ex.experiment_id,"NON-DETERMINISTIC")
  assert q.level=="NON-DETERMINISTIC" and r.verify(q.record_id)["record_ok"]
