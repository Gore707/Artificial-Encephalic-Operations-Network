from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.neural_cache_virtual_device import NeuralCacheVirtualDevice,NeuralCacheError
def test_virtual_device_capacity_integrity_and_lifecycle():
 with tempfile.TemporaryDirectory() as x:
  root=Path(x);db=StateDatabase(root/"s.db");a=AuditTrail(db);s=NeuralCacheVirtualDevice(db,a,root/"cache")
  q=s.create("test",1024*1024,4096);assert s.verify(q.device_id)["all_ok"]
  q=s.reserve(q.device_id,4096);assert q.used_bytes==4096
  q=s.release(q.device_id,2048);assert q.used_bytes==2048
  q=s.set_status(q.device_id,"READ_ONLY")
  try:s.reserve(q.device_id,1)
  except NeuralCacheError:pass
  else:raise AssertionError("write reservation accepted on read-only device")
