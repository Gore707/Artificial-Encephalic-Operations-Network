from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.cognitive_state_comparator import CognitiveStateComparator
from aeon.cognitive_divergence import CognitiveDivergenceService
def state(c,name,x):
 return c.create_state(name,{"x":x},{"x":"mV"},{"x":"DERIVED"},{"x":1.0},{"x":"test"})
def test_divergence_series_and_trend():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);c=CognitiveStateComparator(db,a);d=CognitiveDivergenceService(db,a,c)
  ref=state(c,"ref",0);s1=state(c,"s1",1);s2=state(c,"s2",3)
  a1=d.record("run",ref.state_id,s1.state_id,1,"ms");a2=d.record("run",ref.state_id,s2.state_id,2,"ms")
  assert a1.rmse==1 and a2.rmse==3
  tr=d.trend("run");assert tr["classification"]=="DESCRIPTIVE_ONLY" and abs(tr["rmse_slope_per_time_unit"]-2)<1e-12
  assert "does not establish loss of identity" in a2.details["interpretation"]
def test_record_is_idempotent_for_same_state_time():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);c=CognitiveStateComparator(db,a);d=CognitiveDivergenceService(db,a,c)
  r=state(c,"r",0);o=state(c,"o",1);one=d.record("s",r.state_id,o.state_id,1,"ms");two=d.record("s",r.state_id,o.state_id,1,"ms")
  assert one.sample_id==two.sample_id
