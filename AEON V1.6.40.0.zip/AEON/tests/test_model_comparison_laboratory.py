from pathlib import Path
import tempfile,math
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.provenance import ImmutableSourceStore
from aeon.apotheosis_data_lab import ApotheosisDataLab
from aeon.model_comparison_laboratory import ModelComparisonLaboratory
def setup(root):
 db=StateDatabase(root/"s.db");a=AuditTrail(db);d=ApotheosisDataLab(db,a,ImmutableSourceStore(root/"imm"));return d,ModelComparisonLaboratory(d,a)
def test_metrics_and_epistemics():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);d,m=setup(root);p=root/"m.csv";p.write_text("observed,predicted\n1,1\n2,3\n3,2\n");ds=d.register_file(p,"m","SIMULATION","DERIVED");q=m.evaluate(ds.dataset_id,"observed","predicted")
  assert q.n==3 and math.isclose(q.mae,2/3) and math.isclose(q.rmse,math.sqrt(2/3)) and q.evidence_class=="SIMULATION"
def test_compare_has_no_winner():
 with tempfile.TemporaryDirectory() as t:
  root=Path(t);d,m=setup(root);p=root/"m.csv";p.write_text("o,a,b\n1,1,2\n2,2,3\n");ds=d.register_file(p,"m","IMPORTED","MEASURED");r=m.compare([(ds.dataset_id,"o","a"),(ds.dataset_id,"o","b")])
  assert len(r.reports)==2 and "does not declare" in r.notes and not hasattr(r,"winner")
