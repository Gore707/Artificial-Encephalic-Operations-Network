from pathlib import Path
import tempfile
from types import SimpleNamespace
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.os_release import OSReleaseQualifier

class DB:
 def integrity_check(self):return "ok"
class HW:
 def snapshot(self):return SimpleNamespace(logical_cpu_count=16)
class Acc:
 def discover(self):return ()
class Guardian:status="NOMINAL"
class Safety:
 def list_rules(self):return ()

def test_release_gate_fails_if_integration_cannot_run():
 with tempfile.TemporaryDirectory() as t:
  db=StateDatabase(Path(t)/"s.db");a=AuditTrail(db)
  # Deliberately incomplete services: integration must fail, so release cannot lie.
  s=SimpleNamespace(state_db=DB(),audit=a,guardian=Guardian(),safety_kernel=Safety(),
                    genesis=object(),hardware=HW(),accelerators=Acc())
  r=OSReleaseQualifier(s,a).run(False)
  assert not r.passed
  assert any(g.name=="integration.foundation" and not g.passed for g in r.gates)
  ok,msg=a.verify();assert ok,msg

def test_version_is_os_1_0():
 assert OSReleaseQualifier.VERSION=="1.0.0"
