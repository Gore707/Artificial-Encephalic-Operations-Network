from pathlib import Path
import tempfile

from aeon.hardware import HardwareDiscovery


def test_hardware_discovery_reports_real_host_basics():
    with tempfile.TemporaryDirectory() as t:
        inv=HardwareDiscovery(Path(t)).discover()
        assert inv.cpu.logical_processors >= 1
        assert inv.cpu.architecture
        assert inv.operating_system
        assert inv.machine is not None
        if inv.memory.total_bytes is not None:
            assert inv.memory.total_bytes > 0
            assert inv.memory.available_bytes is None or 0 <= inv.memory.available_bytes <= inv.memory.total_bytes
        assert len(inv.storage) >= 1
        for volume in inv.storage:
            assert volume.total_bytes > 0
            assert volume.used_bytes >= 0
            assert volume.free_bytes >= 0
            assert volume.used_bytes + volume.free_bytes <= volume.total_bytes + 1024*1024
