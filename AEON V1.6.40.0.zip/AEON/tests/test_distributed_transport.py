import socket
from aeon.distributed_transport import DistributedTransportServer,DistributedTransportClient,DistributedTransportError
def test_binary_transport_round_trip_integrity_and_chunks():
 got={}
 s=DistributedTransportServer("n1",b"0123456789abcdef0123456789abcdef",lambda i,p,m:got.update(id=i,payload=p,meta=m),max_bytes=2_000_000)
 addr=s.start()
 try:
  data=(b"neural-state-"*100000);c=DistributedTransportClient(b"0123456789abcdef0123456789abcdef",65536);r=c.send(addr,data,{"kind":"test"})
  assert r.verified and r.byte_count==len(data) and r.chunk_count>1 and got["payload"]==data and got["meta"]["kind"]=="test"
 finally:s.stop()
def test_wrong_key_rejected():
 s=DistributedTransportServer("n1",b"0123456789abcdef0123456789abcdef",lambda *x:None);addr=s.start()
 try:
  try:DistributedTransportClient(b"fedcba9876543210fedcba9876543210").send(addr,b"x")
  except DistributedTransportError as e:assert "authentication" in str(e)
  else:raise AssertionError("wrong key accepted")
 finally:s.stop()
