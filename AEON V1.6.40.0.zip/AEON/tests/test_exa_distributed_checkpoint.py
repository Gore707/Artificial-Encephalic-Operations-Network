from pathlib import Path
import tempfile,hashlib
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.exa_distributed_checkpoint import DistributedCheckpointService,PartitionCheckpoint,DistributedCheckpointError
class Plan:
 definition_sha256="a"*64;assignments={"n1":"node-a","n2":"node-b"}
class P:
 def verify(self,x):return {"all_ok":True}
 def get(self,x):return Plan()
def part(pid,node,step=4,t=2.0):
 return PartitionCheckpoint(pid,node,"ckpt:"+pid,hashlib.sha256(pid.encode()).hexdigest(),100,step,t,"ms")
def test_consistent_checkpoint_and_verify():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=DistributedCheckpointService(db,a,P())
  q=s.create("run","plan",(part("p0","node-a"),part("p1","node-b")))
  assert q.status=="CONSISTENT" and q.logical_step==4 and s.verify(q.checkpoint_id)["all_ok"]
def test_mixed_simulation_instants_rejected():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);s=DistributedCheckpointService(db,a,P())
  try:s.create("run","plan",(part("p0","node-a",4,2.0),part("p1","node-b",5,2.5)))
  except DistributedCheckpointError:pass
  else:raise AssertionError("inconsistent distributed checkpoint accepted")
