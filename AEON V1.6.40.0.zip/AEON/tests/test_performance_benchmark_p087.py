from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.performance_benchmark import PerformanceBenchmark
def test_measured_benchmark_is_persisted_and_integrity_bound():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");q=PerformanceBenchmark(db,AuditTrail(db));state={"n":0}
  def work():state["n"]+=1
  r=q.run("counter",work,iterations=20,warmup=3)
  assert state["n"]==23 and r.iterations==20 and r.median_ns>0 and r.p95_ns>=r.minimum_ns and r.throughput_per_s>0
  assert q.verify(r.benchmark_id)["all_ok"]
  with db.transaction() as c:c.execute("UPDATE p087_benchmarks SET median_ns=median_ns+1 WHERE benchmark_id=?",(r.benchmark_id,))
  assert not q.verify(r.benchmark_id)["all_ok"]
