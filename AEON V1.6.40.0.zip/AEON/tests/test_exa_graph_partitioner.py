from pathlib import Path
import tempfile
from aeon.state_db import StateDatabase
from aeon.audit import AuditTrail
from aeon.exa_graph_partitioner import ExaNeuralGraphPartitioner,ComputeNodeCapacity
class Syn:
 def __init__(self,a,b):self.pre_neuron_id=a;self.post_neuron_id=b
class Syns:
 def get_state(self,x):return {"s1":Syn("a","b"),"s2":Syn("b","c")}[x]
class Net:
 neuron_state_ids=("a","b","c");synapse_state_ids=("s1","s2")
class SNN:
 synapses=Syns()
 def get_network(self,x):return Net()
class G:
 snn=SNN()
 def network_signature(self,x):return "sig"
def test_resource_weighted_plan_and_verify():
 with tempfile.TemporaryDirectory() as x:
  db=StateDatabase(Path(x)/"s.db");a=AuditTrail(db);p=ExaNeuralGraphPartitioner(db,a,G())
  q=p.create("net",(ComputeNodeCapacity("small",4,8*1024**3,0,0),ComputeNodeCapacity("large",16,32*1024**3,1,8*1024**3)))
  assert len(q.assignments)==3 and set(q.assignments.values())<= {"small","large"} and p.verify(q.plan_id)["all_ok"]
  assert q.node_loads["large"]["capacity_score"]>q.node_loads["small"]["capacity_score"]
