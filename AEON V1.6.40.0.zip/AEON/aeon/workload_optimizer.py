from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class WorkloadOptimizationError(RuntimeError):pass

@dataclass(frozen=True)
class WorkloadPlan:
 plan_id:str;created_unix:float;workload:str;items:int;workers:int;chunk_size:int;estimated_chunks:int;host_logical_cpus:int;memory_budget_bytes:int;plan_sha256:str

class WorkloadOptimizer:
 """P088 conservative local workload planning.
 Produces bounded plans from detected/declared resources; it does not impose hard OS quotas.
 """
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p088_workload_plans(
   plan_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,workload TEXT NOT NULL,items INTEGER NOT NULL,workers INTEGER NOT NULL,
   chunk_size INTEGER NOT NULL,estimated_chunks INTEGER NOT NULL,host_logical_cpus INTEGER NOT NULL,memory_budget_bytes INTEGER NOT NULL,plan_sha256 TEXT NOT NULL)""")
 def plan(self,workload,items,host_logical_cpus,available_memory_bytes,bytes_per_item=1,max_cpu_fraction=.75,max_memory_fraction=.50):
  name=str(workload).strip();items=int(items);cpus=int(host_logical_cpus);mem=int(available_memory_bytes);bpi=int(bytes_per_item)
  cf=float(max_cpu_fraction);mf=float(max_memory_fraction)
  if not name or items<1 or cpus<1 or mem<1 or bpi<1 or not 0<cf<=1 or not 0<mf<=1:raise WorkloadOptimizationError("invalid workload/resource inputs")
  workers=max(1,min(cpus,int(cpus*cf)))
  budget=max(1,int(mem*mf));max_items=max(1,budget//bpi)
  chunk=max(1,min(items,max_items,max(1,(items+workers-1)//workers)))
  chunks=(items+chunk-1)//chunk
  payload={"workload":name,"items":items,"workers":workers,"chunk_size":chunk,"estimated_chunks":chunks,"host_logical_cpus":cpus,"memory_budget_bytes":budget}
  sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest();pid="p088-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p088_workload_plans VALUES(?,?,?,?,?,?,?,?,?,?)",(pid,time.time(),name,items,workers,chunk,chunks,cpus,budget,sha))
  self.audit.append("INFO","performance.p088","workload_plan",subject=pid,details=payload);return self.get(pid)
 def get(self,pid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p088_workload_plans WHERE plan_id=?",(pid,)).fetchone()
  if r is None:raise WorkloadOptimizationError("unknown workload plan")
  return WorkloadPlan(r["plan_id"],r["created_unix"],r["workload"],r["items"],r["workers"],r["chunk_size"],r["estimated_chunks"],r["host_logical_cpus"],r["memory_budget_bytes"],r["plan_sha256"])
 def verify(self,pid):
  r=self.get(pid);payload={"workload":r.workload,"items":r.items,"workers":r.workers,"chunk_size":r.chunk_size,"estimated_chunks":r.estimated_chunks,"host_logical_cpus":r.host_logical_cpus,"memory_budget_bytes":r.memory_budget_bytes}
  sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
  return {"plan_id":pid,"all_ok":sha==r.plan_sha256,"computed_sha256":sha,"stored_sha256":r.plan_sha256}
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM p088_workload_plans").fetchone()["n"]
  return {"phase":"PERFORMANCE & CLUSTER OPTIMIZATION II","plans":n,"scope":"Conservative resource-aware local planning. Advisory/cooperative only; hard OS quotas and thermal enforcement remain unqualified."}
