from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid,math

class ANIDynamicStateError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")

@dataclass(frozen=True)
class DynamicVariable:
 variable_id:str;target_type:str;target_id:str;name:str;value:object;unit:str
 provenance:str;confidence:float|None;source_ref:str|None;uncertainty:dict

@dataclass(frozen=True)
class ANIDynamicState:
 dynamic_state_id:str;topology_id:str;synaptic_state_id:str|None;created_unix:float
 biological_time_ref:str|None;simulation_time:float|None;simulation_time_unit:str
 variables:tuple[DynamicVariable,...];explicitly_unmeasured:tuple[tuple[str,str,str],...]
 initialization_policy:str;assumptions:tuple[str,...];source_hashes:tuple[tuple[str,str],...];definition_sha256:str

class ANIDynamicStateService:
 """Time-dependent ANI state with explicit measured-vs-initialized provenance."""
 def __init__(self,db,audit,topologies,synaptic_states):
  self.db=db;self.audit=audit;self.topologies=topologies;self.synaptic_states=synaptic_states;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS ani_dynamic_states(
   dynamic_state_id TEXT PRIMARY KEY,topology_id TEXT NOT NULL,synaptic_state_id TEXT,created_unix REAL NOT NULL,
   biological_time_ref TEXT,simulation_time REAL,simulation_time_unit TEXT NOT NULL,variables_json TEXT NOT NULL,
   unmeasured_json TEXT NOT NULL,initialization_policy TEXT NOT NULL,assumptions_json TEXT NOT NULL,
   source_hashes_json TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def create(self,topology_id,variables=(),synaptic_state_id=None,biological_time_ref=None,
            simulation_time=None,simulation_time_unit="",explicitly_unmeasured=(),
            initialization_policy="PRESERVE_PROVENANCE",assumptions=()):
  topo=self.topologies.get(topology_id)
  if not self.topologies.verify(topology_id)["all_ok"]:raise ANIDynamicStateError("ANI topology integrity failed")
  bindings={"TOPOLOGY:"+topology_id:topo.definition_sha256}
  if synaptic_state_id is not None:
   syn=self.synaptic_states.get(str(synaptic_state_id))
   if syn.topology_id!=topology_id:raise ANIDynamicStateError("synaptic state belongs to different topology")
   if not self.synaptic_states.verify(str(synaptic_state_id))["all_ok"]:raise ANIDynamicStateError("synaptic state integrity failed")
   bindings["SYNAPTIC:"+str(synaptic_state_id)]=syn.definition_sha256
  if simulation_time is not None:
   simulation_time=float(simulation_time)
   if not math.isfinite(simulation_time):raise ANIDynamicStateError("simulation time must be finite")
  policy=str(initialization_policy).strip()
  if not policy:raise ANIDynamicStateError("initialization policy required")
  nodeids={n.node_id for n in topo.nodes};edgeids={e.edge_id for e in topo.edges};out=[];seen=set()
  for raw in variables:
   x=dict(raw);tt=str(x.get("target_type","")).upper();tid=str(x.get("target_id",""));name=str(x.get("name","")).strip()
   if tt not in ("NODE","EDGE","GLOBAL"):raise ANIDynamicStateError("target_type must be NODE, EDGE, or GLOBAL")
   if tt=="NODE" and tid not in nodeids:raise ANIDynamicStateError("dynamic variable references absent node")
   if tt=="EDGE" and tid not in edgeids:raise ANIDynamicStateError("dynamic variable references absent edge")
   if tt=="GLOBAL" and not tid:tid="GLOBAL"
   if not name:raise ANIDynamicStateError("dynamic variable name required")
   key=(tt,tid,name)
   if key in seen:raise ANIDynamicStateError("duplicate dynamic variable")
   seen.add(key);prov=str(x.get("provenance","UNKNOWN"))
   if prov not in PROVENANCE:raise ANIDynamicStateError("invalid provenance")
   conf=x.get("confidence")
   if conf is not None:
    conf=float(conf)
    if not math.isfinite(conf) or not 0<=conf<=1:raise ANIDynamicStateError("confidence must be within [0,1]")
   val=x.get("value")
   if isinstance(val,float) and not math.isfinite(val):raise ANIDynamicStateError("numeric dynamic value must be finite")
   out.append(DynamicVariable(str(x.get("variable_id") or ("dynvar-"+uuid.uuid4().hex)),tt,tid,name,val,str(x.get("unit","")),prov,conf,
    str(x["source_ref"]) if x.get("source_ref") is not None else None,dict(x.get("uncertainty") or {})))
  missing=[]
  for raw in explicitly_unmeasured:
   if len(raw)!=3:raise ANIDynamicStateError("unmeasured entry must be target_type,target_id,name")
   tt,tid,name=str(raw[0]).upper(),str(raw[1]),str(raw[2])
   if (tt,tid,name) in seen:raise ANIDynamicStateError("variable cannot be supplied and explicitly unmeasured")
   missing.append((tt,tid,name))
  payload={"topology_id":topology_id,"synaptic_state_id":str(synaptic_state_id) if synaptic_state_id is not None else None,
   "biological_time_ref":str(biological_time_ref) if biological_time_ref is not None else None,
   "simulation_time":simulation_time,"simulation_time_unit":str(simulation_time_unit),"variables":[v.__dict__ for v in out],
   "explicitly_unmeasured":tuple(sorted(set(missing))),"initialization_policy":policy,
   "assumptions":tuple(str(x) for x in assumptions),"source_hashes":tuple(sorted(bindings.items()))}
  try:raw=self._canon(payload)
  except (TypeError,ValueError) as exc:raise ANIDynamicStateError("dynamic state must be JSON-serializable") from exc
  sha=hashlib.sha256(raw.encode()).hexdigest();sid="ani-dyn-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO ani_dynamic_states VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
   (sid,topology_id,payload["synaptic_state_id"],now,payload["biological_time_ref"],simulation_time,payload["simulation_time_unit"],
    json.dumps(payload["variables"],sort_keys=True),json.dumps(payload["explicitly_unmeasured"]),policy,json.dumps(payload["assumptions"]),
    json.dumps(payload["source_hashes"]),sha))
  self.audit.append("INFO","ani.dynamic_state","created",subject=sid,details={"variables":len(out),"unmeasured":len(missing),"definition_sha256":sha})
  return self.get(sid)
 def get(self,sid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM ani_dynamic_states WHERE dynamic_state_id=?",(sid,)).fetchone()
  if r is None:raise ANIDynamicStateError("unknown ANI dynamic state")
  return ANIDynamicState(r["dynamic_state_id"],r["topology_id"],r["synaptic_state_id"],r["created_unix"],r["biological_time_ref"],
   r["simulation_time"],r["simulation_time_unit"],tuple(DynamicVariable(**x) for x in json.loads(r["variables_json"])),
   tuple(tuple(x) for x in json.loads(r["unmeasured_json"])),r["initialization_policy"],tuple(json.loads(r["assumptions_json"])),
   tuple(tuple(x) for x in json.loads(r["source_hashes_json"])),r["definition_sha256"])
 def verify(self,sid):
  q=self.get(sid);source_ok=True
  for key,sha in q.source_hashes:
   try:
    typ,rid=key.split(":",1);svc=self.topologies if typ=="TOPOLOGY" else self.synaptic_states
    obj=svc.get(rid);source_ok &= obj.definition_sha256==sha and svc.verify(rid)["all_ok"]
   except Exception:source_ok=False
  payload={"topology_id":q.topology_id,"synaptic_state_id":q.synaptic_state_id,"biological_time_ref":q.biological_time_ref,
   "simulation_time":q.simulation_time,"simulation_time_unit":q.simulation_time_unit,"variables":[v.__dict__ for v in q.variables],
   "explicitly_unmeasured":q.explicitly_unmeasured,"initialization_policy":q.initialization_policy,
   "assumptions":q.assumptions,"source_hashes":q.source_hashes}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  return {"definition_ok":definition_ok,"source_ok":bool(source_ok),"all_ok":definition_ok and bool(source_ok)}
 def summary(self,sid):
  q=self.get(sid);return {"variables":len(q.variables),"explicitly_unmeasured":len(q.explicitly_unmeasured),
   "measured":sum(v.provenance=="MEASURED" for v in q.variables),"initialized_or_inferred":sum(v.provenance in ("INFERRED","AI-RECONSTRUCTED") for v in q.variables),
   "note":"Simulation initialization is not biological measurement. Electrical/dynamic state remains provenance-bound and model-aware."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["dynamic_state_id"] for r in c.execute("SELECT dynamic_state_id FROM ani_dynamic_states ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
