from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class GenesisExecutionGateError(RuntimeError):pass

@dataclass(frozen=True)
class GenesisCertificate:
 certificate_id:str;created_unix:float;subject_id:str;subject_sha256:str;validator_version:str;model_version:str;status:str;checks_json:str;certificate_sha256:str

class GenesisExecutionGate:
 """P092 evidence-bound pre-execution Genesis gate.
 A PASS certificate is bound to the exact subject hash and validation metadata.
 Failure places a persistent P091 GENESIS_EXECUTION hold.
 """
 VALID_PROVENANCE={"MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN"}
 VALIDATOR_VERSION="GSVL-P092-1"
 def __init__(self,db,audit,safety_gate):
  self.db=db;self.audit=audit;self.safety_gate=safety_gate;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p092_genesis_certificates(
   certificate_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,subject_id TEXT NOT NULL,subject_sha256 TEXT NOT NULL,
   validator_version TEXT NOT NULL,model_version TEXT NOT NULL,status TEXT NOT NULL,checks_json TEXT NOT NULL,certificate_sha256 TEXT NOT NULL)""")
 def validate(self,subject_id,subject_bytes,descriptor):
  sid=str(subject_id).strip();mv=str(dict(descriptor).get("model_version","")).strip()
  if not sid or not isinstance(subject_bytes,(bytes,bytearray)) or not mv:raise GenesisExecutionGateError("subject id, bytes, and model_version required")
  d=dict(descriptor);top=d.get("topology",{});nodes=list(top.get("nodes",[]));edges=list(top.get("edges",[]));prov=list(d.get("provenance",[]))
  node_ids=[str(n.get("id","")) if isinstance(n,dict) else str(n) for n in nodes];node_set=set(node_ids)
  bad_edges=[i for i,e in enumerate(edges) if not isinstance(e,(list,tuple)) or len(e)!=2 or str(e[0]) not in node_set or str(e[1]) not in node_set]
  bad_prov=[i for i,p in enumerate(prov) if str(p).upper() not in self.VALID_PROVENANCE]
  checks=[
   {"check":"nonempty_subject","pass":len(subject_bytes)>0},
   {"check":"unique_nonempty_nodes","pass":bool(node_ids) and all(node_ids) and len(node_ids)==len(node_set)},
   {"check":"topology_references","pass":not bad_edges,"invalid_edge_indices":bad_edges},
   {"check":"provenance_labels","pass":bool(prov) and not bad_prov,"invalid_provenance_indices":bad_prov},
   {"check":"model_version_bound","pass":bool(mv)}
  ]
  status="PASS" if all(x["pass"] for x in checks) else "FAIL";sh=hashlib.sha256(bytes(subject_bytes)).hexdigest()
  canonical=json.dumps({"subject_id":sid,"subject_sha256":sh,"validator_version":self.VALIDATOR_VERSION,"model_version":mv,"status":status,"checks":checks},sort_keys=True,separators=(",",":"))
  certsha=hashlib.sha256(canonical.encode()).hexdigest();cid="p092-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p092_genesis_certificates VALUES(?,?,?,?,?,?,?,?,?)",(cid,time.time(),sid,sh,self.VALIDATOR_VERSION,mv,status,json.dumps(checks,sort_keys=True,separators=(",",":")),certsha))
  if status!="PASS":self.safety_gate.hold("GENESIS_EXECUTION","GSVL certificate failed for "+sid,"SAFETY_KERNEL")
  self.audit.append("INFO" if status=="PASS" else "CRITICAL","safety.p092","genesis_validation",subject=cid,details={"subject_id":sid,"status":status,"subject_sha256":sh})
  return self.get(cid)
 def get(self,cid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p092_genesis_certificates WHERE certificate_id=?",(cid,)).fetchone()
  if r is None:raise GenesisExecutionGateError("unknown Genesis certificate")
  return GenesisCertificate(r["certificate_id"],r["created_unix"],r["subject_id"],r["subject_sha256"],r["validator_version"],r["model_version"],r["status"],r["checks_json"],r["certificate_sha256"])
 def require_pass(self,cid,subject_bytes):
  r=self.get(cid)
  if r.status!="PASS":raise GenesisExecutionGateError("Genesis certificate is not PASS")
  if hashlib.sha256(bytes(subject_bytes)).hexdigest()!=r.subject_sha256:raise GenesisExecutionGateError("subject does not match Genesis certificate")
  canonical=json.dumps({"subject_id":r.subject_id,"subject_sha256":r.subject_sha256,"validator_version":r.validator_version,"model_version":r.model_version,"status":r.status,"checks":json.loads(r.checks_json)},sort_keys=True,separators=(",",":"))
  if hashlib.sha256(canonical.encode()).hexdigest()!=r.certificate_sha256:raise GenesisExecutionGateError("Genesis certificate integrity failure")
  self.safety_gate.require_clear("GENESIS_EXECUTION")
  return True
 def status(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM p092_genesis_certificates").fetchone()["n"]
  return {"phase":"SECURITY & SAFETY QUALIFICATION II","certificates":n,"validator_version":self.VALIDATOR_VERSION,
   "scope":"Persistent subject-hash/model-version/validator-version-bound pre-execution certificates. Model-specific biological plausibility and bounded dynamic preflight remain future validation work."}
