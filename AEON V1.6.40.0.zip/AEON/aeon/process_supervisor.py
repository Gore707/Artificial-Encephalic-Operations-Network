from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence
import os, signal, subprocess, threading, time, uuid

class ProcessSupervisorError(RuntimeError): pass

@dataclass(frozen=True)
class ProcessSnapshot:
    process_id: str
    name: str
    pid: int
    state: str
    started_unix: float
    ended_unix: float | None
    return_code: int | None
    restart_count: int
    stdout_path: str
    stderr_path: str

class _Managed:
    def __init__(self,pid,name,command,cwd,env,restart_limit,out,err):
        self.process_id=pid; self.name=name; self.command=tuple(command)
        self.cwd=cwd; self.env=env; self.restart_limit=restart_limit
        self.stdout_path=out; self.stderr_path=err
        self.proc=None; self.started_unix=0.0; self.ended_unix=None
        self.return_code=None; self.restart_count=0; self.stop_requested=False
        self.state="CREATED"; self.stdout_handle=None; self.stderr_handle=None

class ProcessSupervisor:
    """OS-process containment for AEON child workloads.

    Child failure is detected independently of application code, output is
    isolated to per-process files, restart is bounded, and shutdown is explicit.
    This is crash containment, not a hardened privilege/security sandbox.
    """
    def __init__(self,runtime_dir:Path,audit,poll_interval:float=0.20):
        self.runtime_dir=Path(runtime_dir)
        self.log_dir=self.runtime_dir/"processes"; self.log_dir.mkdir(parents=True,exist_ok=True)
        self.audit=audit; self.poll_interval=max(0.05,float(poll_interval))
        self._lock=threading.RLock(); self._items={}
        self._shutdown=threading.Event()
        self._monitor=threading.Thread(target=self._monitor_loop,name="aeon-process-supervisor",daemon=True)
        self._monitor.start()

    def launch(self,name:str,command:Sequence[str],*,cwd:Path|None=None,
               env:dict[str,str]|None=None,restart_limit:int=0)->str:
        name=name.strip()
        if not name: raise ProcessSupervisorError("Process name is required")
        if not command: raise ProcessSupervisorError("Process command is required")
        if not 0 <= restart_limit <= 10:
            raise ProcessSupervisorError("restart_limit must be between 0 and 10")
        ident="proc-"+uuid.uuid4().hex
        item=_Managed(ident,name,command,str(Path(cwd).resolve()) if cwd else None,
                      dict(env) if env else None,int(restart_limit),
                      self.log_dir/f"{ident}.stdout.log",self.log_dir/f"{ident}.stderr.log")
        with self._lock:
            self._items[ident]=item
            try: self._spawn(item)
            except Exception:
                self._items.pop(ident,None); raise
        return ident

    def _spawn(self,item):
        item.state="STARTING"; item.stop_requested=False
        item.stdout_handle=item.stdout_path.open("ab",buffering=0)
        item.stderr_handle=item.stderr_path.open("ab",buffering=0)
        env=os.environ.copy()
        if item.env: env.update(item.env)
        kwargs={"cwd":item.cwd,"env":env,"stdin":subprocess.DEVNULL,
                "stdout":item.stdout_handle,"stderr":item.stderr_handle,"close_fds":True}
        if os.name=="nt": kwargs["creationflags"]=subprocess.CREATE_NEW_PROCESS_GROUP
        else: kwargs["start_new_session"]=True
        try: item.proc=subprocess.Popen(item.command,**kwargs)
        except Exception as exc:
            self._close(item); item.state="CRASHED"; item.ended_unix=time.time()
            self.audit.append("CRITICAL","process","launch_failed",subject=item.process_id,
                              details={"name":item.name,"error":repr(exc)})
            raise ProcessSupervisorError(f"Failed to launch {item.name}: {exc}") from exc
        item.started_unix=time.time(); item.ended_unix=None; item.return_code=None; item.state="RUNNING"
        self.audit.append("INFO","process","launched",subject=item.process_id,
                          details={"name":item.name,"pid":item.proc.pid,
                                   "restart_count":item.restart_count})

    def _refresh(self,item):
        if item.proc is None or item.state not in ("RUNNING","STOPPING"): return
        rc=item.proc.poll()
        if rc is None: return
        item.return_code=rc; item.ended_unix=time.time(); self._close(item)
        if item.stop_requested:
            item.state="EXITED"; return
        if rc==0:
            item.state="EXITED"
            self.audit.append("INFO","process","exited",subject=item.process_id,
                              details={"name":item.name,"return_code":rc})
            return
        item.state="CRASHED"
        self.audit.append("WARNING","process","crashed",subject=item.process_id,
                          details={"name":item.name,"return_code":rc,
                                   "restart_count":item.restart_count})
        if item.restart_count < item.restart_limit:
            item.restart_count += 1
            try: self._spawn(item)
            except ProcessSupervisorError: pass

    def _monitor_loop(self):
        while not self._shutdown.wait(self.poll_interval):
            try:
                with self._lock:
                    for item in tuple(self._items.values()): self._refresh(item)
            except Exception as exc:
                try:
                    self.audit.append("CRITICAL","process","supervisor_monitor_error",
                                      details={"error":repr(exc)})
                except Exception: pass

    def snapshot(self,process_id):
        with self._lock:
            item=self._get(process_id); self._refresh(item); return self._snap(item)

    def list(self):
        with self._lock:
            for item in tuple(self._items.values()): self._refresh(item)
            return tuple(self._snap(i) for i in self._items.values())

    def stop(self,process_id,timeout:float=5.0):
        with self._lock:
            item=self._get(process_id); self._refresh(item)
            if item.state not in ("RUNNING","STARTING"): return self._snap(item)
            item.stop_requested=True; item.state="STOPPING"; proc=item.proc
            self.audit.append("INFO","process","stop_requested",subject=process_id,
                              details={"name":item.name})
        if proc and proc.poll() is None:
            self._terminate(proc)
            try: proc.wait(timeout=max(0.1,timeout))
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait(timeout=2)
        with self._lock:
            item.return_code=proc.poll() if proc else None
            item.ended_unix=time.time(); item.state="EXITED"; self._close(item)
            self.audit.append("INFO","process","stopped",subject=process_id,
                              details={"name":item.name,"return_code":item.return_code})
            return self._snap(item)

    def _terminate(self,proc):
        try:
            if os.name=="nt": proc.terminate()
            else: os.killpg(os.getpgid(proc.pid),signal.SIGTERM)
        except (ProcessLookupError,PermissionError,OSError):
            try: proc.terminate()
            except OSError: pass

    def shutdown(self):
        for snap in self.list():
            if snap.state in ("RUNNING","STARTING","STOPPING"):
                try: self.stop(snap.process_id)
                except Exception: pass
        self._shutdown.set()
        if self._monitor.is_alive(): self._monitor.join(timeout=2)

    def _get(self,pid):
        try: return self._items[pid]
        except KeyError as exc: raise ProcessSupervisorError(f"Unknown managed process: {pid}") from exc

    @staticmethod
    def _snap(i):
        return ProcessSnapshot(i.process_id,i.name,i.proc.pid if i.proc else -1,i.state,
                               i.started_unix,i.ended_unix,i.return_code,i.restart_count,
                               str(i.stdout_path),str(i.stderr_path))
    @staticmethod
    def _close(i):
        for attr in ("stdout_handle","stderr_handle"):
            h=getattr(i,attr,None)
            if h:
                try: h.close()
                except OSError: pass
                setattr(i,attr,None)
