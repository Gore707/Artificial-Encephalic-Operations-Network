from __future__ import annotations
from dataclasses import dataclass
import platform,sys,time,uuid

@dataclass(frozen=True)
class ReleaseGate:
    name:str;passed:bool;detail:str
@dataclass(frozen=True)
class ReleaseQualification:
    qualification_id:str;version:str;created_unix:float;passed:bool;gates:tuple[ReleaseGate,...]

class OSReleaseQualifier:
    """AEON OS 1.0 release gate.

    This does not manufacture certification. Every gate executes against the
    running installation. A single failed gate prevents a PASS result.
    """
    VERSION="1.0.0"
    def __init__(self,services,audit):
        self.s=services;self.audit=audit
    def run(self,include_destructive=False):
        gates=[]
        def gate(name,fn):
            try:gates.append(ReleaseGate(name,True,str(fn())))
            except Exception as exc:gates.append(ReleaseGate(name,False,f"{type(exc).__name__}: {exc}"))
        gate("database.integrity",lambda:self.s.state_db.integrity_check())
        gate("audit.chain",self._audit)
        gate("integration.foundation",self._integration)
        gate("guardian.available",lambda:self.s.guardian.status)
        gate("safety.kernel.available",lambda:f"{len(self.s.safety_kernel.list_rules())} rule(s)")
        gate("genesis.validator.available",lambda:type(self.s.genesis).__name__)
        gate("host.discovery",lambda:f"{self.s.hardware.snapshot().logical_cpu_count} logical CPUs")
        gate("accelerator.discovery",lambda:f"{len(self.s.accelerators.discover())} accelerator(s)")
        if include_destructive:
            gate("failure.recovery.qualification",self._failure)
        else:
            gates.append(ReleaseGate("failure.recovery.qualification",True,
                                     "not rerun; P031 qualification remains separately invokable"))
        qid="os1-"+uuid.uuid4().hex;now=time.time();passed=all(g.passed for g in gates)
        self.audit.append("INFO" if passed else "CRITICAL","release","aeon_os_1_0_gate",subject=qid,
                          details={"version":self.VERSION,"passed":passed,
                                   "failed":[g.name for g in gates if not g.passed],
                                   "python":sys.version.split()[0],"platform":platform.platform()})
        return ReleaseQualification(qid,self.VERSION,now,passed,tuple(gates))
    def _audit(self):
        ok,msg=self.audit.verify()
        if not ok:raise RuntimeError(msg)
        return msg
    def _integration(self):
        from .integration import IntegrationDiagnostics
        r=IntegrationDiagnostics(self.s,self.audit).run()
        if not r.passed:raise RuntimeError("foundation integration report failed")
        return r.report_id
    def _failure(self):
        from .failure_qualification import FailureQualification
        r=FailureQualification(self.s,self.audit).run()
        if not r.passed:raise RuntimeError("failure/recovery qualification failed")
        return r.report_id
