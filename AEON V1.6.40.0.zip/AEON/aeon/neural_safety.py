from __future__ import annotations
from dataclasses import dataclass
import json,math,time,uuid

class NeuralSafetyError(RuntimeError):pass

@dataclass(frozen=True)
class NeuralPolicy:
    policy_id:str;metric:str;minimum:float|None;maximum:float|None;action:str;enabled:bool;description:str

@dataclass(frozen=True)
class GenesisResult:
    certificate_id:str;model_id:str;passed:bool;created_unix:float;checks:tuple[dict,...];provenance_summary:dict

class NeuralSafetyPolicies:
    """Deterministic neural-runtime policy layer plus Genesis preflight gate.

    Bounds are model-specific and are never invented as universal neuroscience.
    A model must explicitly register its allowed domains before those metrics
    can be used as hard interlocks.
    """
    def __init__(self,db,audit,kernel):
        self.db=db;self.audit=audit;self.kernel=kernel;self._ensure_schema()
    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS neural_safety_policies(
              policy_id TEXT PRIMARY KEY,metric TEXT NOT NULL,minimum REAL,maximum REAL,
              action TEXT NOT NULL,enabled INTEGER NOT NULL,description TEXT NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS genesis_certificates(
              certificate_id TEXT PRIMARY KEY,model_id TEXT NOT NULL,passed INTEGER NOT NULL,
              created_unix REAL NOT NULL,checks_json TEXT NOT NULL,provenance_json TEXT NOT NULL)""")
    def register_policy(self,metric,minimum=None,maximum=None,action="HOLD_NEW_WORK",description=""):
        if minimum is None and maximum is None:raise NeuralSafetyError("policy requires at least one bound")
        if minimum is not None and maximum is not None and float(minimum)>float(maximum):raise NeuralSafetyError("minimum exceeds maximum")
        pid="npol-"+uuid.uuid4().hex
        with self.db.transaction() as c:c.execute("INSERT INTO neural_safety_policies VALUES(?,?,?,?,?,1,?)",
            (pid,str(metric),None if minimum is None else float(minimum),None if maximum is None else float(maximum),action,str(description)))
        if minimum is not None:self.kernel.add_rule(metric,"<",float(minimum),action,rule_id=pid+"-min")
        if maximum is not None:self.kernel.add_rule(metric,">",float(maximum),action,rule_id=pid+"-max")
        self.audit.append("WARNING","neural.safety","policy_registered",subject=pid,
                          details={"metric":metric,"minimum":minimum,"maximum":maximum,"action":action})
        return pid
    def list(self):
        with self.db._connect() as c:return tuple(dict(r) for r in c.execute("SELECT * FROM neural_safety_policies ORDER BY metric").fetchall())

class GenesisValidator:
    """Pre-tick deterministic validation for executable neural state."""
    REQUIRED_PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")
    def __init__(self,db,audit):
        self.db=db;self.audit=audit
    def validate(self,model_id,state):
        if not isinstance(state,dict):raise NeuralSafetyError("state must be a mapping")
        checks=[]
        def add(name,passed,detail):checks.append({"name":name,"passed":bool(passed),"detail":str(detail)})
        nodes=state.get("nodes");edges=state.get("edges");params=state.get("parameters",{})
        add("schema.nodes",isinstance(nodes,list),"nodes must be a list")
        add("schema.edges",isinstance(edges,list),"edges must be a list")
        add("schema.parameters",isinstance(params,dict),"parameters must be a mapping")
        ids=[]
        if isinstance(nodes,list):
            ids=[n.get("id") for n in nodes if isinstance(n,dict)]
            add("topology.unique_node_ids",len(ids)==len(set(ids)) and None not in ids,"node IDs must be unique and present")
        else:add("topology.unique_node_ids",False,"nodes unavailable")
        known=set(ids)
        if isinstance(edges,list):
            valid=all(isinstance(e,dict) and e.get("source") in known and e.get("target") in known for e in edges)
            add("topology.edge_references",valid,"edge endpoints must reference known nodes; recurrent/self edges are permitted")
        else:add("topology.edge_references",False,"edges unavailable")
        finite=True
        if isinstance(params,dict):
            for v in params.values():
                if isinstance(v,(int,float)) and not math.isfinite(float(v)):finite=False
        add("numerical.finite_parameters",finite,"numeric parameters must be finite")
        prov=state.get("provenance",{})
        prov_ok=isinstance(prov,dict) and all(v in self.REQUIRED_PROVENANCE for v in prov.values())
        add("provenance.labels",prov_ok,"provenance values must use AEON epistemic classes")
        model_checks=state.get("model_checks",[])
        model_ok=isinstance(model_checks,list) and len(model_checks)>0 and all(isinstance(x,dict) and x.get("passed") is True for x in model_checks)
        add("model_specific.invariants",model_ok,"model must supply at least one passed model-specific invariant")
        passed=all(c["passed"] for c in checks);cid="gen-"+uuid.uuid4().hex;now=time.time()
        summary={}
        if isinstance(prov,dict):
            for v in prov.values():summary[v]=summary.get(v,0)+1
        with self.db.transaction() as c:c.execute("INSERT INTO genesis_certificates VALUES(?,?,?,?,?,?)",
            (cid,str(model_id),1 if passed else 0,now,json.dumps(checks,separators=(",",":")),json.dumps(summary,separators=(",",":"))))
        self.audit.append("INFO" if passed else "CRITICAL","neural.genesis","validation",subject=cid,
                          details={"model_id":model_id,"passed":passed,"failed_checks":[x["name"] for x in checks if not x["passed"]]})
        return GenesisResult(cid,str(model_id),passed,now,tuple(checks),summary)
    def require_pass(self,result):
        if not isinstance(result,GenesisResult) or not result.passed:
            raise NeuralSafetyError("execution locked: Genesis validation has not passed")
        return True
