from __future__ import annotations
from dataclasses import dataclass
import json,multiprocessing as mp,time,uuid

class ProcessFailureQualificationError(RuntimeError):pass

def _crash_worker(mode):
 if mode=="EXCEPTION":raise RuntimeError("intentional disposable worker failure")
 if mode=="HARD_EXIT":
  import os;os._exit(73)
 if mode=="HANG":
  while True:time.sleep(1)

@dataclass(frozen=True)
class ProcessFailureResult:
 qualification_id:str;created_unix:float;scenario:str;timeout_seconds:float;exit_code:int|None;contained:bool;observed_json:str

class ProcessFailureQualification:
 """P082 disposable subprocess crash/hang containment qualification.
 Never kills arbitrary external processes: it creates and controls only its own test worker.
 """
 SCENARIOS=("EXCEPTION","HARD_EXIT","HANG")
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p082_process_failure_qualifications(
   qualification_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,scenario TEXT NOT NULL,timeout_seconds REAL NOT NULL,
   exit_code INTEGER,contained INTEGER NOT NULL,observed_json TEXT NOT NULL)""")
 def run(self,scenario,timeout_seconds=1.0):
  scenario=str(scenario).upper();timeout=float(timeout_seconds)
  if scenario not in self.SCENARIOS or timeout<=0 or timeout>10:raise ProcessFailureQualificationError("invalid disposable process scenario/timeout")
  p=mp.Process(target=_crash_worker,args=(scenario,),daemon=True);p.start();timed_out=False
  p.join(timeout)
  if p.is_alive():
   timed_out=True;p.terminate();p.join(2.0)
   if p.is_alive():
    p.kill();p.join(2.0)
  contained=not p.is_alive()
  expected_timeout=scenario=="HANG"
  passed=contained and (timed_out==expected_timeout)
  observed={"pid":p.pid,"timed_out":timed_out,"exit_code":p.exitcode,"worker_alive":p.is_alive(),"expected_timeout":expected_timeout,"passed":passed}
  qid="p082-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p082_process_failure_qualifications VALUES(?,?,?,?,?,?,?)",
   (qid,time.time(),scenario,timeout,p.exitcode,1 if contained else 0,json.dumps(observed,sort_keys=True)))
  self.audit.append("INFO" if passed else "CRITICAL","failure_qualification.p082","process_failure_containment",subject=qid,details=observed)
  return self.get(qid)
 def get(self,qid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p082_process_failure_qualifications WHERE qualification_id=?",(qid,)).fetchone()
  if r is None:raise ProcessFailureQualificationError("unknown P082 qualification")
  return ProcessFailureResult(r["qualification_id"],r["created_unix"],r["scenario"],r["timeout_seconds"],r["exit_code"],bool(r["contained"]),r["observed_json"])
 def summary(self):
  with self.db._connect() as c:
   total=c.execute("SELECT COUNT(*) n FROM p082_process_failure_qualifications").fetchone()["n"]
   contained=c.execute("SELECT COUNT(*) n FROM p082_process_failure_qualifications WHERE contained=1").fetchone()["n"]
  return {"phase":"FAILURE & CORRUPTION VALIDATION II","executed":total,"contained":contained,
   "scope":"Disposable AEON-created subprocesses only. This qualifies crash/hang containment behavior, not arbitrary OS process control or the still-missing independent production watchdog."}
