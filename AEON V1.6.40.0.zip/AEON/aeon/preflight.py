from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json, os, platform, shutil, sys, tempfile, time

@dataclass
class Check:
    name: str
    ok: bool
    detail: str

def _writable(path: Path) -> Check:
    try:
        path.mkdir(parents=True, exist_ok=True)
        fd, probe = tempfile.mkstemp(prefix=".aeon_write_", dir=path)
        os.close(fd)
        Path(probe).unlink(missing_ok=True)
        return Check(f"writable:{path.name}", True, str(path))
    except OSError as exc:
        return Check(f"writable:{path.name}", False, str(exc))

def run_preflight(root: Path, cfg) -> tuple[bool, list[Check]]:
    checks = [
        Check("python", sys.version_info >= (3, 11), platform.python_version()),
        Check("platform", platform.system() == "Windows" or platform.system() in {"Linux", "Darwin"},
              platform.platform()),
        Check("config", True, "configuration parsed"),
    ]
    for key in ("paths.runtime", "paths.logs", "paths.state", "paths.data"):
        checks.append(_writable(cfg.path(key)))
    free = shutil.disk_usage(root).free
    checks.append(Check("disk_free", free >= 100 * 1024 * 1024,
                        f"{free / (1024**3):.2f} GiB available"))
    return all(c.ok for c in checks), checks

def write_report(state_dir: Path, checks: list[Check]) -> Path:
    state_dir.mkdir(parents=True, exist_ok=True)
    out = state_dir / "last_preflight.json"
    payload = {
        "timestamp_unix": time.time(),
        "checks": [asdict(c) for c in checks],
        "passed": all(c.ok for c in checks),
    }
    tmp = out.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp, out)
    return out
