from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class NeuralCacheRedundancyError(RuntimeError):pass

@dataclass(frozen=True)
class ReplicaSet:
 replica_set_id:str;created_unix:float;source_block_id:str;payload_sha256:str;replica_block_ids:tuple;device_ids:tuple;status:str;manifest_sha256:str

class NeuralCacheRedundantStorage:
 """Independent block replicas across distinct virtual devices.
 Recovery returns bytes only from a replica that passes the P076 integrity gate.
 """
 def __init__(self,db,audit,devices,blocks):
  self.db=db;self.audit=audit;self.devices=devices;self.blocks=blocks;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS neural_cache_replica_sets(
   replica_set_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,source_block_id TEXT NOT NULL,payload_sha256 TEXT NOT NULL,
   replica_block_ids_json TEXT NOT NULL,device_ids_json TEXT NOT NULL,status TEXT NOT NULL,manifest_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 def create(self,source_block_id,target_device_ids):
  src=self.blocks.get(source_block_id)
  if not self.blocks.verify(source_block_id)["all_ok"]:raise NeuralCacheRedundancyError("source block failed integrity verification")
  targets=tuple(str(x) for x in target_device_ids)
  if not targets:raise NeuralCacheRedundancyError("at least one target device required")
  if len(set(targets))!=len(targets):raise NeuralCacheRedundancyError("replicas require distinct target devices")
  if src.device_id in targets:raise NeuralCacheRedundancyError("source device cannot also be a replica target")
  payload=self.blocks.read(source_block_id);made=[]
  try:
   for did in targets:
    self.devices.get(did)
    b=self.blocks.write(did,payload,kind=src.kind,metadata={**src.metadata,"replica_of":source_block_id})
    if b.sha256!=src.sha256:raise NeuralCacheRedundancyError("replica digest mismatch")
    made.append(b.block_id)
  except Exception:
   # P076 has no delete API yet; do not pretend rollback deleted successfully written replicas.
   self.audit.append("WARNING","neural_cache.redundancy","replica_set_incomplete",subject=source_block_id,details={"created_blocks":made})
   raise
  payload_def={"source_block_id":source_block_id,"payload_sha256":src.sha256,"replica_block_ids":made,"device_ids":list(targets)}
  rid="ncrepl-"+uuid.uuid4().hex;mh=self._sha(payload_def)
  with self.db.transaction() as c:c.execute("INSERT INTO neural_cache_replica_sets VALUES(?,?,?,?,?,?,?,?)",(rid,time.time(),source_block_id,src.sha256,json.dumps(made),json.dumps(targets),"HEALTHY",mh))
  self.audit.append("INFO","neural_cache.redundancy","replica_set_created",subject=rid,details={"copies":1+len(made),"devices":1+len(targets)})
  return self.get(rid)
 def get(self,rid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM neural_cache_replica_sets WHERE replica_set_id=?",(rid,)).fetchone()
  if r is None:raise NeuralCacheRedundancyError("unknown replica set")
  return ReplicaSet(r["replica_set_id"],r["created_unix"],r["source_block_id"],r["payload_sha256"],tuple(json.loads(r["replica_block_ids_json"])),tuple(json.loads(r["device_ids_json"])),r["status"],r["manifest_sha256"])
 def verify(self,rid):
  q=self.get(rid);definition={"source_block_id":q.source_block_id,"payload_sha256":q.payload_sha256,"replica_block_ids":list(q.replica_block_ids),"device_ids":list(q.device_ids)}
  manifest=self._sha(definition)==q.manifest_sha256;copies=[]
  for bid in (q.source_block_id,)+q.replica_block_ids:
   try:
    v=self.blocks.verify(bid);b=self.blocks.get(bid);ok=v["all_ok"] and b.sha256==q.payload_sha256
   except Exception:ok=False
   copies.append({"block_id":bid,"valid":ok})
  valid=sum(1 for x in copies if x["valid"]);status="HEALTHY" if valid==len(copies) else ("DEGRADED" if valid else "LOST")
  return {"manifest_ok":manifest,"copies":copies,"valid_copies":valid,"status":status,"recoverable":manifest and valid>0,"all_ok":manifest and valid==len(copies)}
 def recover(self,rid):
  q=self.get(rid);v=self.verify(rid)
  if not v["manifest_ok"]:raise NeuralCacheRedundancyError("replica manifest integrity failed")
  for c in v["copies"]:
   if c["valid"]:
    data=self.blocks.read(c["block_id"])
    if hashlib.sha256(data).hexdigest()==q.payload_sha256:
     self.audit.append("INFO","neural_cache.redundancy","recovery_read",subject=rid,details={"block_id":c["block_id"]})
     return data
  raise NeuralCacheRedundancyError("no valid replica remains")
 def list_sets(self):
  with self.db._connect() as c:ids=[r["replica_set_id"] for r in c.execute("SELECT replica_set_id FROM neural_cache_replica_sets ORDER BY created_unix").fetchall()]
  return tuple(self.get(x) for x in ids)
 def summary(self):
  sets=self.list_sets();return {"replica_sets":len(sets),"note":"Redundancy improves availability against independent copy corruption; it is not corrective ECC and does not guarantee survival of correlated device/filesystem failure."}
