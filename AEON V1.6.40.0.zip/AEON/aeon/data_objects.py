from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import hashlib
import json
import re
import time
import uuid

_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$")
KINDS = {
    "dataset", "volume", "table", "timeseries", "image",
    "graph", "model", "result", "artifact",
}


class DataObjectError(RuntimeError):
    pass


@dataclass(frozen=True)
class DataObject:
    object_id: str
    workspace_id: str
    kind: str
    name: str
    created_unix: float
    updated_unix: float
    media_type: str | None = None
    units: str | None = None
    source_path: str | None = None
    sha256: str | None = None
    size_bytes: int | None = None
    immutable_source: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


class DataObjectStore:
    def __init__(self, state_db, workspaces, immutable_store=None, provenance=None):
        self.db = state_db
        self.workspaces = workspaces
        self.immutable_store = immutable_store
        self.provenance = provenance
        self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS data_objects (
                    object_id TEXT PRIMARY KEY,
                    workspace_id TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    name TEXT NOT NULL,
                    created_unix REAL NOT NULL,
                    updated_unix REAL NOT NULL,
                    media_type TEXT,
                    units TEXT,
                    source_path TEXT,
                    sha256 TEXT,
                    size_bytes INTEGER,
                    immutable_source INTEGER NOT NULL DEFAULT 0,
                    metadata_json TEXT NOT NULL,
                    FOREIGN KEY(workspace_id) REFERENCES workspaces(workspace_id)
                        ON DELETE CASCADE
                )
            """)
            cols = {row["name"] for row in conn.execute("PRAGMA table_info(data_objects)").fetchall()}
            if "immutable_source" not in cols:
                conn.execute(
                    "ALTER TABLE data_objects ADD COLUMN immutable_source INTEGER NOT NULL DEFAULT 0"
                )
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_data_objects_workspace
                ON data_objects(workspace_id, created_unix)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_data_objects_kind
                ON data_objects(kind)
            """)

    @staticmethod
    def hash_file(path: Path, chunk_size: int = 1024 * 1024) -> tuple[str, int]:
        h = hashlib.sha256()
        size = 0
        with Path(path).open("rb") as stream:
            while True:
                chunk = stream.read(chunk_size)
                if not chunk:
                    break
                h.update(chunk)
                size += len(chunk)
        return h.hexdigest(), size

    def create(
        self, workspace_id: str, kind: str, name: str, *,
        media_type: str | None = None, units: str | None = None,
        source_path: str | None = None, metadata: dict[str, Any] | None = None,
        fingerprint_source: bool = True, preserve_source: bool = False,
        provenance_class: str | None = None, operation: str = "register",
        agent: str = "AEON", confidence: float | None = None,
        parent_object_id: str | None = None, evidence: dict[str, Any] | None = None,
    ) -> DataObject:
        self.workspaces.get(workspace_id)
        kind = kind.strip().lower()
        name = name.strip()
        if kind not in KINDS:
            raise DataObjectError(f"Unsupported data-object kind: {kind}")
        if not name:
            raise DataObjectError("Data-object name cannot be empty")
        if len(name) > 160:
            raise DataObjectError("Data-object name is too long")
        meta = dict(metadata or {})
        try:
            meta_json = json.dumps(meta, separators=(",", ":"), ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            raise DataObjectError(f"Metadata is not JSON serializable: {exc}") from exc

        digest = None
        size = None
        normalized_path = None
        immutable = False
        if source_path:
            source = Path(source_path).expanduser().resolve()
            if not source.is_file():
                raise DataObjectError(f"Source file does not exist: {source}")
            if preserve_source:
                if self.immutable_store is None:
                    raise DataObjectError("Immutable source store is unavailable")
                stored, digest, size = self.immutable_store.ingest(source)
                normalized_path = str(stored)
                immutable = True
            else:
                normalized_path = str(source)
                if fingerprint_source:
                    digest, size = self.hash_file(source)
                else:
                    size = source.stat().st_size

        now = time.time()
        object_id = "obj-" + uuid.uuid4().hex
        if not _ID.match(object_id):
            raise DataObjectError("Generated object id failed validation")
        with self.db.transaction() as conn:
            conn.execute("""
                INSERT INTO data_objects(
                    object_id, workspace_id, kind, name, created_unix, updated_unix,
                    media_type, units, source_path, sha256, size_bytes,
                    immutable_source, metadata_json
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                object_id, workspace_id, kind, name, now, now,
                media_type, units, normalized_path, digest, size,
                1 if immutable else 0, meta_json
            ))
        obj = self.get(object_id)
        if provenance_class:
            if self.provenance is None:
                self.delete(object_id)
                raise DataObjectError("Provenance store is unavailable")
            try:
                self.provenance.record(
                    object_id, provenance_class, operation=operation, agent=agent,
                    parent_object_id=parent_object_id, confidence=confidence,
                    evidence=evidence,
                )
            except Exception:
                self.delete(object_id)
                raise
        return obj

    def _row_to_object(self, row) -> DataObject:
        return DataObject(
            object_id=row["object_id"], workspace_id=row["workspace_id"],
            kind=row["kind"], name=row["name"],
            created_unix=float(row["created_unix"]),
            updated_unix=float(row["updated_unix"]),
            media_type=row["media_type"], units=row["units"],
            source_path=row["source_path"], sha256=row["sha256"],
            size_bytes=row["size_bytes"],
            immutable_source=bool(row["immutable_source"]),
            metadata=json.loads(row["metadata_json"]),
        )

    def get(self, object_id: str) -> DataObject:
        with self.db._connect() as conn:
            row = conn.execute("SELECT * FROM data_objects WHERE object_id=?", (object_id,)).fetchone()
        if row is None:
            raise DataObjectError(f"Unknown data object: {object_id}")
        return self._row_to_object(row)

    def list(self, workspace_id: str, *, kind: str | None = None) -> tuple[DataObject, ...]:
        self.workspaces.get(workspace_id)
        with self.db._connect() as conn:
            if kind is None:
                rows = conn.execute(
                    "SELECT * FROM data_objects WHERE workspace_id=? ORDER BY created_unix, object_id",
                    (workspace_id,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM data_objects WHERE workspace_id=? AND kind=? "
                    "ORDER BY created_unix, object_id",
                    (workspace_id, kind.lower()),
                ).fetchall()
        return tuple(self._row_to_object(row) for row in rows)

    def update_metadata(self, object_id: str, metadata: dict[str, Any]) -> DataObject:
        obj = self.get(object_id)
        if obj.immutable_source:
            raise DataObjectError("Immutable source objects cannot have metadata rewritten")
        encoded = json.dumps(dict(metadata), separators=(",", ":"), ensure_ascii=False)
        with self.db.transaction() as conn:
            cursor = conn.execute(
                "UPDATE data_objects SET metadata_json=?, updated_unix=? WHERE object_id=?",
                (encoded, time.time(), object_id),
            )
            if cursor.rowcount != 1:
                raise DataObjectError(f"Unknown data object: {object_id}")
        return self.get(object_id)

    def verify_source(self, object_id: str) -> tuple[bool | None, str]:
        obj = self.get(object_id)
        if not obj.source_path:
            return None, "No source file is associated with this object"
        if obj.immutable_source and self.immutable_store is not None and obj.sha256:
            return self.immutable_store.verify(obj.sha256)
        source = Path(obj.source_path)
        if not source.is_file():
            return False, "Source file is missing"
        if not obj.sha256:
            return None, "Source was registered without a SHA-256 fingerprint"
        digest, size = self.hash_file(source)
        if digest != obj.sha256 or size != obj.size_bytes:
            return False, "Source file no longer matches its registered fingerprint"
        return True, "Source file matches registered SHA-256 and size"

    def delete(self, object_id: str) -> None:
        obj = self.get(object_id)
        if obj.immutable_source:
            raise DataObjectError("Immutable source objects cannot be deleted through the data-object API")
        with self.db.transaction() as conn:
            cursor = conn.execute("DELETE FROM data_objects WHERE object_id=?", (object_id,))
            if cursor.rowcount != 1:
                raise DataObjectError(f"Unknown data object: {object_id}")
