from __future__ import annotations
from dataclasses import dataclass
import json,math,time,uuid

class NeuralClockError(RuntimeError):pass

@dataclass(frozen=True)
class NeuralClock:
 clock_id:str;name:str;created_unix:float;time_unit:str;current_time:float;tick_index:int
 default_step:float|None;mode:str;status:str

class NeuralClockService:
 """Explicit simulation clock. It does not impose a universal neural timestep."""
 MODES=("MANUAL","FIXED_STEP")
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS neural_clocks(
   clock_id TEXT PRIMARY KEY,name TEXT NOT NULL,created_unix REAL NOT NULL,time_unit TEXT NOT NULL,current_time REAL NOT NULL,
   tick_index INTEGER NOT NULL,default_step REAL,mode TEXT NOT NULL,status TEXT NOT NULL)""")
 @staticmethod
 def _positive(x,name):
  v=float(x)
  if not math.isfinite(v) or v<=0:raise NeuralClockError(name+" must be finite and > 0")
  return v
 def create(self,name,time_unit="ms",default_step=None,mode="MANUAL"):
  name=str(name).strip();unit=str(time_unit).strip();mode=str(mode).upper()
  if not name or not unit:raise NeuralClockError("name and time unit required")
  if mode not in self.MODES:raise NeuralClockError("invalid clock mode")
  step=None if default_step is None else self._positive(default_step,"default_step")
  if mode=="FIXED_STEP" and step is None:raise NeuralClockError("fixed-step clock requires default_step")
  cid="nclock-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO neural_clocks VALUES(?,?,?,?,?,?,?,?,?)",(cid,name,now,unit,0.0,0,step,mode,"READY"))
  self.audit.append("INFO","neural_simulacrum.clock","created",subject=cid,details={"mode":mode,"time_unit":unit,"default_step":step})
  return self.get(cid)
 def get(self,cid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM neural_clocks WHERE clock_id=?",(cid,)).fetchone()
  if r is None:raise NeuralClockError("unknown neural clock")
  return NeuralClock(r["clock_id"],r["name"],r["created_unix"],r["time_unit"],r["current_time"],r["tick_index"],r["default_step"],r["mode"],r["status"])
 def advance(self,cid,delta=None):
  q=self.get(cid)
  if q.status!="READY":raise NeuralClockError("clock is not ready")
  if delta is None:
   if q.default_step is None:raise NeuralClockError("explicit delta required for this clock")
   d=q.default_step
  else:d=self._positive(delta,"delta")
  nt=q.current_time+d;idx=q.tick_index+1
  with self.db.transaction() as c:c.execute("UPDATE neural_clocks SET current_time=?,tick_index=? WHERE clock_id=?",(nt,idx,cid))
  return self.get(cid)
 def set_status(self,cid,status):
  status=str(status).upper()
  if status not in ("READY","HELD","STOPPED"):raise NeuralClockError("invalid clock status")
  self.get(cid)
  with self.db.transaction() as c:c.execute("UPDATE neural_clocks SET status=? WHERE clock_id=?",(status,cid))
  self.audit.append("INFO","neural_simulacrum.clock","status_changed",subject=cid,details={"status":status})
  return self.get(cid)
 def synchronize(self,cid,participants,tolerance):
  """Compare participant simulation times to the clock without mutating them."""
  q=self.get(cid);tol=float(tolerance)
  if not math.isfinite(tol) or tol<0:raise NeuralClockError("tolerance must be finite and >= 0")
  rows=[];ok=True
  for name,value in dict(participants).items():
   v=float(value)
   if not math.isfinite(v):raise NeuralClockError("participant time must be finite")
   drift=v-q.current_time;inside=abs(drift)<=tol;ok &= inside
   rows.append({"participant":str(name),"time":v,"drift":drift,"within_tolerance":inside})
  return {"clock_id":cid,"clock_time":q.current_time,"time_unit":q.time_unit,"tolerance":tol,"participants":tuple(rows),"synchronized":bool(ok)}
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM neural_clocks").fetchone()["n"]
  return {"clocks":n,"modes":self.MODES,"note":"Clock cadence is model/run specific. AEON does not assume one universal biological or simulation timestep."}
