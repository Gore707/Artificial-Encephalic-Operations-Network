from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,math,time,uuid

class ExaGraphPartitionError(RuntimeError): pass

@dataclass(frozen=True)
class ComputeNodeCapacity:
    node_id:str; cpu_threads:int; ram_bytes:int; accelerator_units:int; accelerator_memory_bytes:int; weight:float=1.0

@dataclass(frozen=True)
class ExaPartitionPlan:
    plan_id:str; created_unix:float; network_id:str; network_signature:str; strategy:str
    assignments:dict; node_loads:dict; cut_edges:int; definition_sha256:str

class ExaNeuralGraphPartitioner:
    """Deterministic resource-aware placement over the P059 neural graph."""
    STRATEGY="RESOURCE_WEIGHTED_GREEDY"
    def __init__(self,db,audit,graph_partitioner):
        self.db=db; self.audit=audit; self.graph=graph_partitioner; self._schema()
    def _schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS exa_partition_plans(
            plan_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,network_id TEXT NOT NULL,network_signature TEXT NOT NULL,
            strategy TEXT NOT NULL,assignments_json TEXT NOT NULL,node_loads_json TEXT NOT NULL,cut_edges INTEGER NOT NULL,
            definition_sha256 TEXT NOT NULL)""")
    @staticmethod
    def _sha(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    @staticmethod
    def _capacity_score(n):
        if not n.node_id or n.cpu_threads<1 or n.ram_bytes<1 or n.accelerator_units<0 or n.accelerator_memory_bytes<0 or not math.isfinite(n.weight) or n.weight<=0:
            raise ExaGraphPartitionError("invalid compute node capacity")
        accel_mem=n.accelerator_memory_bytes if n.accelerator_units else 0
        return n.weight*(n.cpu_threads+n.ram_bytes/(8*1024**3)+4*n.accelerator_units+accel_mem/(4*1024**3))
    def create(self,network_id,nodes):
        caps=tuple(nodes)
        if not caps: raise ExaGraphPartitionError("at least one compute node required")
        if len({n.node_id for n in caps})!=len(caps): raise ExaGraphPartitionError("duplicate node_id")
        scores={n.node_id:self._capacity_score(n) for n in caps}
        network=self.graph.snn.get_network(network_id); signature=self.graph.network_signature(network_id)
        neuron_ids=sorted(network.neuron_state_ids)
        if not neuron_ids: raise ExaGraphPartitionError("network has no neurons")
        assigned={}; loads={k:0 for k in scores}; normalized={k:0.0 for k in scores}
        for neuron in neuron_ids:
            target=min(scores,key=lambda k:(normalized[k],k))
            assigned[neuron]=target; loads[target]+=1; normalized[target]=loads[target]/scores[target]
        cut=0
        for sid in network.synapse_state_ids:
            syn=self.graph.snn.synapses.get_state(sid)
            if syn.pre_neuron_id in assigned and syn.post_neuron_id in assigned and assigned[syn.pre_neuron_id]!=assigned[syn.post_neuron_id]:
                cut+=1
        node_loads={k:{"neurons":loads[k],"capacity_score":scores[k],"normalized_load":loads[k]/scores[k]} for k in sorted(scores)}
        payload={"network_id":network_id,"network_signature":signature,"strategy":self.STRATEGY,"assignments":assigned,"node_loads":node_loads,"cut_edges":cut}
        pid="exapart-"+uuid.uuid4().hex; sha=self._sha(payload)
        with self.db.transaction() as c:
            c.execute("INSERT INTO exa_partition_plans VALUES(?,?,?,?,?,?,?,?,?)",(pid,time.time(),network_id,signature,self.STRATEGY,json.dumps(assigned,sort_keys=True),json.dumps(node_loads,sort_keys=True),cut,sha))
        self.audit.append("INFO","exa_execution.graph_partitioner","plan_created",subject=pid,details={"network_id":network_id,"nodes":len(caps),"neurons":len(neuron_ids),"cut_edges":cut})
        return self.get(pid)
    def get(self,pid):
        with self.db._connect() as c: r=c.execute("SELECT * FROM exa_partition_plans WHERE plan_id=?",(pid,)).fetchone()
        if r is None: raise ExaGraphPartitionError("unknown Exa partition plan")
        return ExaPartitionPlan(r["plan_id"],r["created_unix"],r["network_id"],r["network_signature"],r["strategy"],json.loads(r["assignments_json"]),json.loads(r["node_loads_json"]),r["cut_edges"],r["definition_sha256"])
    def verify(self,pid):
        p=self.get(pid); current=self.graph.network_signature(p.network_id)
        payload={"network_id":p.network_id,"network_signature":p.network_signature,"strategy":p.strategy,"assignments":p.assignments,"node_loads":p.node_loads,"cut_edges":p.cut_edges}
        own=self._sha(payload)==p.definition_sha256
        return {"definition_ok":own,"network_signature_ok":current==p.network_signature,"all_ok":own and current==p.network_signature}
    def list(self,limit=250):
        with self.db._connect() as c: ids=[r["plan_id"] for r in c.execute("SELECT plan_id FROM exa_partition_plans ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get(x) for x in ids)
    def summary(self):
        with self.db._connect() as c: n=c.execute("SELECT COUNT(*) n FROM exa_partition_plans").fetchone()["n"]
        return {"plans":n,"strategy":self.STRATEGY,"note":"Placement is deterministic and resource-weighted; it is not a claim of globally optimal graph partitioning."}
