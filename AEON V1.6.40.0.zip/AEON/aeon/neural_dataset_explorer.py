from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import csv,json,math
class NeuralDatasetError(RuntimeError):pass
NEURAL_ROLES=("NEURON","EDGE","SYNAPSE","TRACE","VOLUME","CELL","MOLECULAR","GLIAL","DYNAMIC","OTHER")
@dataclass(frozen=True)
class NeuralDatasetProfile:
    dataset_id:str;role:str;evidence_class:str;provenance:str;format:str
    records_examined:int;fields:tuple[str,...];numeric_fields:tuple[str,...]
    missing_counts:tuple[tuple[str,int],...];metadata:dict
class NeuralDatasetExplorer:
    """Neural-aware inspection without inventing biological semantics."""
    def __init__(self,data_lab,audit):self.data_lab=data_lab;self.audit=audit
    def profile(self,dataset_id,role="OTHER",max_rows=100000):
        if role not in NEURAL_ROLES:raise NeuralDatasetError("invalid neural dataset role")
        d=self.data_lab.get(dataset_id);p=Path(d.source_path)
        if not p.is_file():raise NeuralDatasetError("original dataset locator unavailable")
        fields=[];numeric=set();missing={};n=0
        if d.format in ("csv","tsv"):
            delim="\t" if d.format=="tsv" else ","
            with p.open("r",encoding="utf-8-sig",newline="") as f:
                r=csv.DictReader(f,delimiter=delim);fields=list(r.fieldnames or ())
                missing={x:0 for x in fields};candidates={x:True for x in fields}
                for row in r:
                    if n>=max_rows:break
                    n+=1
                    for x in fields:
                        v=row.get(x)
                        if v is None or not str(v).strip():missing[x]+=1;continue
                        try:v=float(v)
                        except (TypeError,ValueError):candidates[x]=False
                        else:
                            if not math.isfinite(v):candidates[x]=False
                numeric={x for x in fields if candidates[x]}
        elif d.format=="json":
            obj=json.loads(p.read_text(encoding="utf-8"));rows=(obj if isinstance(obj,list) else [obj])[:max_rows];n=len(rows)
            if rows and all(isinstance(x,dict) for x in rows):
                fields=list(dict.fromkeys(k for row in rows for k in row));missing={x:sum(1 for row in rows if row.get(x) in (None,"")) for x in fields}
                for x in fields:
                    vals=[row.get(x) for row in rows if row.get(x) not in (None,"")]
                    if vals and all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(float(v)) for v in vals):numeric.add(x)
        else:raise NeuralDatasetError("structured profiling supports CSV, TSV, and JSON")
        q=NeuralDatasetProfile(d.dataset_id,role,d.evidence_class,d.provenance,d.format,n,tuple(fields),tuple(x for x in fields if x in numeric),tuple((x,missing.get(x,0)) for x in fields),dict(d.metadata))
        self.audit.append("INFO","apotheosis.neural_dataset","profiled",subject=d.dataset_id,details={"role":role,"records_examined":n,"evidence":d.evidence_class,"provenance":d.provenance})
        return q
    def edge_summary(self,dataset_id,source_field="source",target_field="target",max_rows=200000):
        d=self.data_lab.get(dataset_id)
        if d.format not in ("csv","tsv"):raise NeuralDatasetError("edge summary requires CSV/TSV")
        p=Path(d.source_path);delim="\t" if d.format=="tsv" else ",";nodes=set();edges=self_edges=0
        with p.open("r",encoding="utf-8-sig",newline="") as f:
            r=csv.DictReader(f,delimiter=delim)
            if source_field not in (r.fieldnames or ()) or target_field not in (r.fieldnames or ()):raise NeuralDatasetError("edge fields absent")
            for row in r:
                if edges>=max_rows:break
                s=str(row[source_field]).strip();t=str(row[target_field]).strip()
                if not s or not t:continue
                nodes.update((s,t));edges+=1;self_edges+=int(s==t)
        return {"dataset_id":dataset_id,"nodes_observed":len(nodes),"edges_observed":edges,"self_edges":self_edges,"truncated":edges>=max_rows,"evidence_class":d.evidence_class,"provenance":d.provenance}
