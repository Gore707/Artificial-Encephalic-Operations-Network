from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid,math

class ANIReconstructionMetadataError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")

@dataclass(frozen=True)
class ReconstructionClaim:
 claim_id:str;target_ref:str;property_name:str;provenance:str;confidence:float|None
 uncertainty:dict;method:str;method_version:str;source_refs:tuple[str,...];assumptions:tuple[str,...];notes:str

@dataclass(frozen=True)
class ANIReconstructionMetadata:
 metadata_id:str;ani_spec_id:str;topology_id:str|None;synaptic_state_id:str|None;dynamic_state_id:str|None
 created_unix:float;claims:tuple[ReconstructionClaim,...];unknowns:tuple[str,...];source_hashes:tuple[tuple[str,str],...];definition_sha256:str

class ANIReconstructionMetadataService:
 """Binds uncertainty/provenance claims to ANI components without upgrading inference into measurement."""
 def __init__(self,db,audit,specs,topologies,synaptic,dynamic):
  self.db=db;self.audit=audit;self.specs=specs;self.topologies=topologies;self.synaptic=synaptic;self.dynamic=dynamic;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS ani_reconstruction_metadata(
   metadata_id TEXT PRIMARY KEY,ani_spec_id TEXT NOT NULL,topology_id TEXT,synaptic_state_id TEXT,dynamic_state_id TEXT,
   created_unix REAL NOT NULL,claims_json TEXT NOT NULL,unknowns_json TEXT NOT NULL,source_hashes_json TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def create(self,ani_spec_id,claims=(),topology_id=None,synaptic_state_id=None,dynamic_state_id=None,unknowns=()):
  spec=self.specs.get(ani_spec_id)
  if not self.specs.verify(ani_spec_id)["all_ok"]:raise ANIReconstructionMetadataError("ANI specification integrity failed")
  bindings={"ANI_SPEC:"+ani_spec_id:spec.definition_sha256}
  if topology_id is not None:
   t=self.topologies.get(str(topology_id))
   if t.ani_spec_id!=ani_spec_id:raise ANIReconstructionMetadataError("topology belongs to another ANI specification")
   if not self.topologies.verify(str(topology_id))["all_ok"]:raise ANIReconstructionMetadataError("topology integrity failed")
   bindings["TOPOLOGY:"+str(topology_id)]=t.definition_sha256
  if synaptic_state_id is not None:
   s=self.synaptic.get(str(synaptic_state_id))
   if topology_id is not None and s.topology_id!=str(topology_id):raise ANIReconstructionMetadataError("synaptic state belongs to another topology")
   if not self.synaptic.verify(str(synaptic_state_id))["all_ok"]:raise ANIReconstructionMetadataError("synaptic integrity failed")
   bindings["SYNAPTIC:"+str(synaptic_state_id)]=s.definition_sha256
  if dynamic_state_id is not None:
   d=self.dynamic.get(str(dynamic_state_id))
   if topology_id is not None and d.topology_id!=str(topology_id):raise ANIReconstructionMetadataError("dynamic state belongs to another topology")
   if synaptic_state_id is not None and d.synaptic_state_id not in (None,str(synaptic_state_id)):raise ANIReconstructionMetadataError("dynamic state belongs to another synaptic state")
   if not self.dynamic.verify(str(dynamic_state_id))["all_ok"]:raise ANIReconstructionMetadataError("dynamic integrity failed")
   bindings["DYNAMIC:"+str(dynamic_state_id)]=d.definition_sha256
  out=[];seen=set()
  for raw in claims:
   x=dict(raw);target=str(x.get("target_ref","")).strip();prop=str(x.get("property_name","")).strip()
   if not target or not prop:raise ANIReconstructionMetadataError("claim target and property required")
   key=(target,prop)
   if key in seen:raise ANIReconstructionMetadataError("duplicate reconstruction claim")
   seen.add(key);prov=str(x.get("provenance","UNKNOWN"))
   if prov not in PROVENANCE:raise ANIReconstructionMetadataError("invalid provenance")
   conf=x.get("confidence")
   if conf is not None:
    conf=float(conf)
    if not math.isfinite(conf) or not 0<=conf<=1:raise ANIReconstructionMetadataError("confidence must be within [0,1]")
   method=str(x.get("method","")).strip();version=str(x.get("method_version","")).strip()
   if prov in ("DERIVED","INFERRED","AI-RECONSTRUCTED") and (not method or not version):
    raise ANIReconstructionMetadataError("derived/inferred reconstruction claims require method and version")
   out.append(ReconstructionClaim(str(x.get("claim_id") or ("claim-"+uuid.uuid4().hex)),target,prop,prov,conf,
    dict(x.get("uncertainty") or {}),method,version,tuple(str(v) for v in x.get("source_refs",())),
    tuple(str(v) for v in x.get("assumptions",())),str(x.get("notes",""))))
  payload={"ani_spec_id":ani_spec_id,"topology_id":str(topology_id) if topology_id is not None else None,
   "synaptic_state_id":str(synaptic_state_id) if synaptic_state_id is not None else None,
   "dynamic_state_id":str(dynamic_state_id) if dynamic_state_id is not None else None,
   "claims":[c.__dict__ for c in out],"unknowns":tuple(str(x) for x in unknowns),"source_hashes":tuple(sorted(bindings.items()))}
  try:raw=self._canon(payload)
  except (TypeError,ValueError) as exc:raise ANIReconstructionMetadataError("metadata must be JSON-serializable") from exc
  sha=hashlib.sha256(raw.encode()).hexdigest();mid="ani-meta-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO ani_reconstruction_metadata VALUES(?,?,?,?,?,?,?,?,?,?)",
   (mid,ani_spec_id,payload["topology_id"],payload["synaptic_state_id"],payload["dynamic_state_id"],now,
    json.dumps(payload["claims"],sort_keys=True),json.dumps(payload["unknowns"]),json.dumps(payload["source_hashes"]),sha))
  self.audit.append("INFO","ani.reconstruction_metadata","created",subject=mid,details={"claims":len(out),"unknowns":len(payload["unknowns"]),"definition_sha256":sha})
  return self.get(mid)
 def get(self,mid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM ani_reconstruction_metadata WHERE metadata_id=?",(mid,)).fetchone()
  if r is None:raise ANIReconstructionMetadataError("unknown ANI reconstruction metadata")
  return ANIReconstructionMetadata(r["metadata_id"],r["ani_spec_id"],r["topology_id"],r["synaptic_state_id"],r["dynamic_state_id"],r["created_unix"],
   tuple(ReconstructionClaim(**x) for x in json.loads(r["claims_json"])),tuple(json.loads(r["unknowns_json"])),
   tuple(tuple(x) for x in json.loads(r["source_hashes_json"])),r["definition_sha256"])
 def verify(self,mid):
  q=self.get(mid);source_ok=True
  services={"ANI_SPEC":self.specs,"TOPOLOGY":self.topologies,"SYNAPTIC":self.synaptic,"DYNAMIC":self.dynamic}
  for key,sha in q.source_hashes:
   try:
    typ,rid=key.split(":",1);svc=services[typ];obj=svc.get(rid);source_ok &= obj.definition_sha256==sha and svc.verify(rid)["all_ok"]
   except Exception:source_ok=False
  payload={"ani_spec_id":q.ani_spec_id,"topology_id":q.topology_id,"synaptic_state_id":q.synaptic_state_id,"dynamic_state_id":q.dynamic_state_id,
   "claims":[c.__dict__ for c in q.claims],"unknowns":q.unknowns,"source_hashes":q.source_hashes}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  return {"definition_ok":definition_ok,"source_ok":bool(source_ok),"all_ok":definition_ok and bool(source_ok)}
 def summary(self,mid):
  q=self.get(mid);return {"claims":len(q.claims),"unknowns":len(q.unknowns),
   "provenance_counts":{p:sum(c.provenance==p for c in q.claims) for p in PROVENANCE},
   "information_sufficiency":"UNDETERMINED",
   "note":"Confidence quantifies a reconstruction claim; it does not convert inferred or AI-reconstructed information into measured source information."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["metadata_id"] for r in c.execute("SELECT metadata_id FROM ani_reconstruction_metadata ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
