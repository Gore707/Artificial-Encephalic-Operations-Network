from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import re
import shutil
import time
import uuid

from .state_db import StateDatabase

_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


class WorkspaceError(RuntimeError):
    pass


@dataclass(frozen=True)
class Workspace:
    workspace_id: str
    name: str
    created_unix: float
    updated_unix: float


class WorkspaceStore:
    """P006 workspace persistence backed by AEON's transactional state database."""
    MIGRATION_ID = "p006-workspaces-json-to-sqlite"

    def __init__(self, state_dir: Path, db: StateDatabase | None = None):
        self.state_dir = Path(state_dir)
        self.db = db if db is not None else StateDatabase(Path(state_dir) / "state.db")
        self.workspace_root = self.state_dir / "workspaces"
        self.legacy_catalog = self.state_dir / "workspaces.json"
        self.workspace_root.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()
        self._migrate_legacy_catalog()

    def _ensure_schema(self):
        with self.db.transaction() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS workspaces (
                    workspace_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    created_unix REAL NOT NULL,
                    updated_unix REAL NOT NULL
                )
            """)

    def _migrate_legacy_catalog(self):
        if self.db.migration_applied(self.MIGRATION_ID):
            return
        import json
        with self.db.transaction() as conn:
            if self.legacy_catalog.exists():
                try:
                    data = json.loads(self.legacy_catalog.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError) as exc:
                    raise WorkspaceError(f"Legacy workspace catalog unreadable: {exc}") from exc
                for item in data.get("workspaces", []):
                    conn.execute("""
                        INSERT OR IGNORE INTO workspaces
                        (workspace_id, name, created_unix, updated_unix)
                        VALUES(?, ?, ?, ?)
                    """, (
                        item["workspace_id"], item["name"],
                        float(item["created_unix"]), float(item["updated_unix"]),
                    ))
                if data.get("active"):
                    encoded = __import__("json").dumps(data["active"])
                    conn.execute("""
                        INSERT INTO settings(namespace, key, value_json, updated_unix)
                        VALUES('workspaces', 'active_id', ?, ?)
                        ON CONFLICT(namespace, key) DO UPDATE SET
                            value_json=excluded.value_json,
                            updated_unix=excluded.updated_unix
                    """, (encoded, time.time()))
            self.db.mark_migration(self.MIGRATION_ID, conn)

        if self.legacy_catalog.exists():
            migrated = self.legacy_catalog.with_suffix(".json.migrated")
            try:
                os.replace(self.legacy_catalog, migrated)
            except OSError:
                pass

    def list(self) -> tuple[Workspace, ...]:
        with self.db._connect() as conn:
            rows = conn.execute("""
                SELECT workspace_id, name, created_unix, updated_unix
                FROM workspaces ORDER BY created_unix, workspace_id
            """).fetchall()
        return tuple(Workspace(**dict(row)) for row in rows)

    def active_id(self) -> str | None:
        return self.db.get("workspaces", "active_id")

    def active(self) -> Workspace | None:
        active = self.active_id()
        if active is None:
            return None
        try:
            return self.get(active)
        except WorkspaceError:
            return None

    def get(self, workspace_id: str) -> Workspace:
        with self.db._connect() as conn:
            row = conn.execute("""
                SELECT workspace_id, name, created_unix, updated_unix
                FROM workspaces WHERE workspace_id=?
            """, (workspace_id,)).fetchone()
        if row is None:
            raise WorkspaceError(f"Unknown workspace: {workspace_id}")
        return Workspace(**dict(row))

    def path_for(self, workspace_id: str) -> Path:
        self.get(workspace_id)
        return self.workspace_root / workspace_id

    def create(self, name: str) -> Workspace:
        name = name.strip()
        if not name:
            raise WorkspaceError("Workspace name cannot be empty")
        if len(name) > 96:
            raise WorkspaceError("Workspace name is too long")
        now = time.time()
        workspace_id = "ws-" + uuid.uuid4().hex[:12]
        if not _ID_RE.match(workspace_id):
            raise WorkspaceError("Generated workspace id failed validation")
        path = self.workspace_root / workspace_id

        try:
            path.mkdir(parents=True, exist_ok=False)
            with self.db.transaction() as conn:
                conn.execute("""
                    INSERT INTO workspaces(workspace_id, name, created_unix, updated_unix)
                    VALUES(?, ?, ?, ?)
                """, (workspace_id, name, now, now))
                active = conn.execute("""
                    SELECT value_json FROM settings
                    WHERE namespace='workspaces' AND key='active_id'
                """).fetchone()
                if active is None:
                    import json
                    conn.execute("""
                        INSERT INTO settings(namespace, key, value_json, updated_unix)
                        VALUES('workspaces', 'active_id', ?, ?)
                    """, (json.dumps(workspace_id), now))
        except Exception:
            if path.exists():
                shutil.rmtree(path, ignore_errors=True)
            raise
        return Workspace(workspace_id, name, now, now)

    def activate(self, workspace_id: str) -> Workspace:
        ws = self.get(workspace_id)
        self.db.set("workspaces", "active_id", workspace_id)
        return ws

    def rename(self, workspace_id: str, new_name: str) -> Workspace:
        new_name = new_name.strip()
        if not new_name:
            raise WorkspaceError("Workspace name cannot be empty")
        if len(new_name) > 96:
            raise WorkspaceError("Workspace name is too long")
        now = time.time()
        with self.db.transaction() as conn:
            cursor = conn.execute("""
                UPDATE workspaces SET name=?, updated_unix=? WHERE workspace_id=?
            """, (new_name, now, workspace_id))
            if cursor.rowcount != 1:
                raise WorkspaceError(f"Unknown workspace: {workspace_id}")
        return self.get(workspace_id)

    def delete(self, workspace_id: str) -> None:
        ws = self.get(workspace_id)
        path = self.workspace_root / workspace_id
        resolved = path.resolve()
        if resolved.parent != self.workspace_root.resolve():
            raise WorkspaceError("Refusing unsafe workspace deletion")

        with self.db.transaction() as conn:
            cursor = conn.execute(
                "DELETE FROM workspaces WHERE workspace_id=?", (workspace_id,)
            )
            if cursor.rowcount != 1:
                raise WorkspaceError(f"Unknown workspace: {workspace_id}")

            import json
            active = self.active_id()
            if active == workspace_id:
                next_row = conn.execute(
                    "SELECT workspace_id FROM workspaces ORDER BY created_unix LIMIT 1"
                ).fetchone()
                next_id = next_row["workspace_id"] if next_row else None
                conn.execute("""
                    INSERT INTO settings(namespace, key, value_json, updated_unix)
                    VALUES('workspaces', 'active_id', ?, ?)
                    ON CONFLICT(namespace, key) DO UPDATE SET
                        value_json=excluded.value_json,
                        updated_unix=excluded.updated_unix
                """, (json.dumps(next_id), time.time()))

        if path.exists():
            shutil.rmtree(path)
