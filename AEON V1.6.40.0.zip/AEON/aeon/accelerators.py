from __future__ import annotations

from dataclasses import dataclass
import ctypes
import ctypes.util
import json
import os
import platform
import re
import shutil
import subprocess
import time


@dataclass(frozen=True)
class AcceleratorDevice:
    backend: str
    device_id: str
    name: str
    vendor: str
    memory_total_bytes: int | None
    memory_free_bytes: int | None
    driver_version: str | None
    temperature_c: float | None
    utilization_percent: float | None
    source: str


@dataclass(frozen=True)
class AcceleratorInventory:
    timestamp_unix: float
    devices: tuple[AcceleratorDevice, ...]
    probes: tuple[str, ...]


class AcceleratorDiscovery:
    """Discover NVIDIA, AMD, and OS-visible display accelerators.

    Values are emitted only when returned by a real provider/API. Generic
    OS display enumeration may identify a GPU without VRAM/telemetry; those
    fields remain None rather than being estimated.
    """

    def discover(self) -> AcceleratorInventory:
        devices: list[AcceleratorDevice] = []
        probes: list[str] = []

        nvidia = self._nvidia_smi()
        probes.append("nvidia-smi:" + ("available" if nvidia is not None else "unavailable"))
        if nvidia:
            devices.extend(nvidia)

        amd = self._amd_rocm()
        probes.append("rocm-smi:" + ("available" if amd is not None else "unavailable"))
        if amd:
            devices.extend(amd)

        # Windows fallback is important for consumer AMD systems that do not
        # have ROCm tools installed.
        if platform.system() == "Windows":
            generic = self._windows_display_devices()
            probes.append("windows-display:" + ("available" if generic is not None else "unavailable"))
            if generic:
                devices.extend(generic)

        return AcceleratorInventory(
            timestamp_unix=time.time(),
            devices=tuple(self._dedupe(devices)),
            probes=tuple(probes),
        )

    @staticmethod
    def _run(command: list[str], timeout: float = 4.0) -> subprocess.CompletedProcess | None:
        exe = shutil.which(command[0])
        if exe is None:
            return None
        try:
            return subprocess.run(
                [exe, *command[1:]],
                capture_output=True, text=True, timeout=timeout,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
        except (OSError, subprocess.SubprocessError):
            return None

    def _nvidia_smi(self) -> list[AcceleratorDevice] | None:
        fields = [
            "index","name","memory.total","memory.free","driver_version",
            "temperature.gpu","utilization.gpu"
        ]
        result = self._run([
            "nvidia-smi",
            f"--query-gpu={','.join(fields)}",
            "--format=csv,noheader,nounits",
        ])
        if result is None:
            return None
        if result.returncode != 0:
            return []
        devices = []
        for line in result.stdout.splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) != len(fields):
                continue
            def number(text, cast=float):
                try:
                    return cast(text) if text not in ("N/A","[N/A]","") else None
                except ValueError:
                    return None
            total_mib = number(parts[2], int)
            free_mib = number(parts[3], int)
            devices.append(AcceleratorDevice(
                backend="CUDA",
                device_id=f"nvidia:{parts[0]}",
                name=parts[1] or "NVIDIA GPU",
                vendor="NVIDIA",
                memory_total_bytes=total_mib * 1024 * 1024 if total_mib is not None else None,
                memory_free_bytes=free_mib * 1024 * 1024 if free_mib is not None else None,
                driver_version=parts[4] or None,
                temperature_c=number(parts[5], float),
                utilization_percent=number(parts[6], float),
                source="nvidia-smi",
            ))
        return devices

    def _amd_rocm(self) -> list[AcceleratorDevice] | None:
        result = self._run(["rocm-smi", "--showproductname", "--showmeminfo", "vram",
                            "--showtemp", "--showuse", "--json"])
        if result is None:
            return None
        if result.returncode != 0:
            return []
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError:
            return []
        devices = []
        for card, values in payload.items():
            if not isinstance(values, dict):
                continue
            name = (values.get("Card series") or values.get("Card model") or
                    values.get("Card SKU") or card)
            total = self._first_int(values, ("VRAM Total Memory (B)", "VRAM Total Used Memory (B)"))
            used = self._first_int(values, ("VRAM Total Used Memory (B)",))
            free = total - used if total is not None and used is not None and total >= used else None
            temp = self._first_float_matching(values, "Temperature")
            util = self._first_float_matching(values, "GPU use")
            devices.append(AcceleratorDevice(
                backend="ROCm",
                device_id=f"amd:{card}",
                name=str(name),
                vendor="AMD",
                memory_total_bytes=total,
                memory_free_bytes=free,
                driver_version=None,
                temperature_c=temp,
                utilization_percent=util,
                source="rocm-smi",
            ))
        return devices

    @staticmethod
    def _first_int(values, keys):
        for key in keys:
            if key in values:
                match = re.search(r"-?\d+", str(values[key]))
                if match:
                    try: return int(match.group())
                    except ValueError: pass
        return None

    @staticmethod
    def _first_float_matching(values, needle):
        for key, value in values.items():
            if needle.lower() in key.lower():
                match = re.search(r"-?\d+(?:\.\d+)?", str(value))
                if match:
                    try: return float(match.group())
                    except ValueError: pass
        return None

    def _windows_display_devices(self) -> list[AcceleratorDevice] | None:
        # EnumDisplayDevicesW is available without PowerShell/WMI dependencies.
        try:
            user32 = ctypes.windll.user32
        except AttributeError:
            return None

        class DISPLAY_DEVICEW(ctypes.Structure):
            _fields_ = [
                ("cb", ctypes.c_ulong),
                ("DeviceName", ctypes.c_wchar * 32),
                ("DeviceString", ctypes.c_wchar * 128),
                ("StateFlags", ctypes.c_ulong),
                ("DeviceID", ctypes.c_wchar * 128),
                ("DeviceKey", ctypes.c_wchar * 128),
            ]

        DISPLAY_DEVICE_MIRRORING_DRIVER = 0x00000008
        devices = []
        index = 0
        while True:
            dd = DISPLAY_DEVICEW()
            dd.cb = ctypes.sizeof(dd)
            if not user32.EnumDisplayDevicesW(None, index, ctypes.byref(dd), 0):
                break
            index += 1
            if dd.StateFlags & DISPLAY_DEVICE_MIRRORING_DRIVER:
                continue
            name = dd.DeviceString.strip()
            if not name:
                continue
            upper = (name + " " + dd.DeviceID).upper()
            if "NVIDIA" in upper:
                vendor, backend = "NVIDIA", "OS_VISIBLE"
            elif "AMD" in upper or "RADEON" in upper or "ATI" in upper:
                vendor, backend = "AMD", "OS_VISIBLE"
            elif "INTEL" in upper:
                vendor, backend = "Intel", "OS_VISIBLE"
            else:
                vendor, backend = "Unknown", "OS_VISIBLE"
            devices.append(AcceleratorDevice(
                backend=backend,
                device_id=f"display:{index-1}",
                name=name,
                vendor=vendor,
                memory_total_bytes=None,
                memory_free_bytes=None,
                driver_version=None,
                temperature_c=None,
                utilization_percent=None,
                source="EnumDisplayDevicesW",
            ))
        return devices

    @staticmethod
    def _dedupe(devices):
        result = []
        for device in devices:
            duplicate = False
            for existing in result:
                same_vendor = existing.vendor.lower() == device.vendor.lower()
                same_name = existing.name.strip().lower() == device.name.strip().lower()
                # Prefer provider-specific CUDA/ROCm records over generic OS enumeration.
                if same_vendor and same_name:
                    duplicate = True
                    break
            if not duplicate:
                result.append(device)
        return result
