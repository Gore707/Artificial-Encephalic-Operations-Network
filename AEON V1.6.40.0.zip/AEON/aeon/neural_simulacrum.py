from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class NeuralSimulacrumError(RuntimeError):pass

@dataclass(frozen=True)
class SimulacrumRuntime:
 runtime_id:str;name:str;created_unix:float;network_id:str;clock_id:str
 partition_plan_id:str|None;distributed_run_id:str|None;backend_preference:str
 status:str;definition_sha256:str

class NeuralSimulacrum:
 """P062 integration boundary for explicit mathematical neural simulations.
 ANI images are not executable through this service; Genesis authorization remains a separate unresolved integration gate.
 """
 def __init__(self,db,audit,snn,clock,partitions,gpu,distributed):
  self.db=db;self.audit=audit;self.snn=snn;self.clock=clock;self.partitions=partitions;self.gpu=gpu;self.distributed=distributed;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS neural_simulacrum_runtimes(
   runtime_id TEXT PRIMARY KEY,name TEXT NOT NULL,created_unix REAL NOT NULL,network_id TEXT NOT NULL,clock_id TEXT NOT NULL,
   partition_plan_id TEXT,distributed_run_id TEXT,backend_preference TEXT NOT NULL,status TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _sha(payload):return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 def create(self,name,network_id,clock_id,partition_plan_id=None,distributed_run_id=None,backend_preference="AUTO"):
  name=str(name).strip()
  if not name:raise NeuralSimulacrumError("runtime name required")
  n=self.snn.get(network_id);clk=self.clock.get(clock_id)
  if clk.status!="READY":raise NeuralSimulacrumError("clock must be READY")
  if abs(float(n.simulation_time_ms)-float(clk.current_time))>1e-12:raise NeuralSimulacrumError("network and clock must begin synchronized")
  if partition_plan_id:
   p=self.partitions.get(partition_plan_id)
   if p.network_id!=network_id or not self.partitions.verify(partition_plan_id)["all_ok"]:raise NeuralSimulacrumError("partition plan does not verify for network")
  if distributed_run_id:
   d=self.distributed.get(distributed_run_id)
   if d.plan_id!=partition_plan_id or d.clock_id!=clock_id:raise NeuralSimulacrumError("distributed run binding mismatch")
  bp=str(backend_preference).upper()
  if bp!="AUTO" and not any(b.backend_id==backend_preference and b.available for b in self.gpu.discover()):raise NeuralSimulacrumError("requested backend unavailable")
  payload={"name":name,"network_id":network_id,"clock_id":clock_id,"partition_plan_id":partition_plan_id,
   "distributed_run_id":distributed_run_id,"backend_preference":backend_preference}
  rid="simulacrum-"+uuid.uuid4().hex;sha=self._sha(payload);now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO neural_simulacrum_runtimes VALUES(?,?,?,?,?,?,?,?,?,?)",
   (rid,name,now,network_id,clock_id,partition_plan_id,distributed_run_id,backend_preference,"READY",sha))
  self.audit.append("INFO","neural_simulacrum","runtime_created",subject=rid,details={"network_id":network_id,"distributed":bool(distributed_run_id)})
  return self.get(rid)
 def get(self,rid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM neural_simulacrum_runtimes WHERE runtime_id=?",(rid,)).fetchone()
  if r is None:raise NeuralSimulacrumError("unknown Neural Simulacrum runtime")
  return SimulacrumRuntime(r["runtime_id"],r["name"],r["created_unix"],r["network_id"],r["clock_id"],r["partition_plan_id"],r["distributed_run_id"],r["backend_preference"],r["status"],r["definition_sha256"])
 def verify(self,rid):
  q=self.get(rid);payload={"name":q.name,"network_id":q.network_id,"clock_id":q.clock_id,"partition_plan_id":q.partition_plan_id,
   "distributed_run_id":q.distributed_run_id,"backend_preference":q.backend_preference}
  definition_ok=self._sha(payload)==q.definition_sha256
  try:
   n=self.snn.get(q.network_id);clk=self.clock.get(q.clock_id);sources_ok=True
   if q.partition_plan_id:sources_ok &= self.partitions.verify(q.partition_plan_id)["all_ok"]
   if q.distributed_run_id:self.distributed.get(q.distributed_run_id)
  except Exception:sources_ok=False
  return {"definition_ok":definition_ok,"sources_ok":bool(sources_ok),"all_ok":definition_ok and bool(sources_ok)}
 def step_local(self,rid,dt_ms,external_currents=None):
  q=self.get(rid)
  if q.status!="READY":raise NeuralSimulacrumError("runtime is not READY")
  if q.distributed_run_id:raise NeuralSimulacrumError("distributed runtime requires distributed coordination")
  clk=self.clock.get(q.clock_id);net=self.snn.get(q.network_id)
  if abs(float(clk.current_time)-float(net.simulation_time_ms))>1e-12:
   self.hold(rid,"clock/network desynchronization");raise NeuralSimulacrumError("clock/network desynchronized")
  result=self.snn.step(q.network_id,dt_ms,external_currents)
  advanced=self.clock.advance(q.clock_id,dt_ms)
  if abs(float(advanced.current_time)-float(result["simulation_time_ms"]))>1e-12:
   self.hold(rid,"post-step clock/network desynchronization");raise NeuralSimulacrumError("post-step desynchronization")
  return {"runtime_id":rid,"clock_time":advanced.current_time,"network":result,"backend":"CPU"}
 def hold(self,rid,reason):
  self.get(rid)
  with self.db.transaction() as c:c.execute("UPDATE neural_simulacrum_runtimes SET status='HELD' WHERE runtime_id=?",(rid,))
  self.audit.append("WARNING","neural_simulacrum","held",subject=rid,details={"reason":str(reason)})
  return self.get(rid)
 def readiness(self,rid):
  q=self.get(rid);v=self.verify(rid)
  return {"integrity":v,"status":q.status,"mathematical_runtime_ready":v["all_ok"] and q.status=="READY",
   "ani_execution_authorized":False,"genesis_status":"NOT_INTEGRATED",
   "information_sufficiency":"UNDETERMINED",
   "note":"Neural Simulacrum 1.0 executes explicit mathematical SNN models. It does not establish ANI executability, biological equivalence, personal identity, continuity, or consciousness."}
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM neural_simulacrum_runtimes").fetchone()["n"]
  return {"runtimes":n,"release":"NEURAL SIMULACRUM 1.0","note":"Integrated P055-P061 mathematical simulation stack; ANI/Genesis execution authorization remains intentionally closed."}
