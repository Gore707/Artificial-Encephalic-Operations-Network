from __future__ import annotations
from dataclasses import dataclass
import importlib.util,math,time,uuid

class GPUExecutionError(RuntimeError):pass

@dataclass(frozen=True)
class GPUBackend:
 backend_id:str;kind:str;device:str;available:bool;reason:str

@dataclass(frozen=True)
class GPUExecutionResult:
 execution_id:str;backend:str;device:str;operation:str;count:int;elapsed_s:float;values:tuple[float,...]

class GPUExecutionEngine:
 """Numerical accelerator backend with explicit CPU fallback and no fabricated GPU availability."""
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS gpu_executions(
   execution_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,backend TEXT NOT NULL,device TEXT NOT NULL,
   operation TEXT NOT NULL,count INTEGER NOT NULL,elapsed_s REAL NOT NULL)""")
 def discover(self):
  out=[]
  if importlib.util.find_spec("torch") is not None:
   try:
    import torch
    if torch.cuda.is_available():
     out.append(GPUBackend("torch-cuda","CUDA",torch.cuda.get_device_name(0),True,""))
    hip=getattr(torch.version,"hip",None)
    if hip and torch.cuda.is_available():
     out.append(GPUBackend("torch-rocm","ROCM/HIP",torch.cuda.get_device_name(0),True,""))
   except Exception as exc:out.append(GPUBackend("torch","TORCH","",False,type(exc).__name__))
  if importlib.util.find_spec("cupy") is not None:
   try:
    import cupy as cp
    n=cp.cuda.runtime.getDeviceCount()
    if n:out.append(GPUBackend("cupy","CUDA",str(cp.cuda.runtime.getDeviceProperties(0).get("name","GPU")),True,""))
   except Exception as exc:out.append(GPUBackend("cupy","CUDA","",False,type(exc).__name__))
  out.append(GPUBackend("cpu","CPU","host",True,"deterministic fallback"))
  # Deduplicate actual GPU routes while retaining explicit CPU fallback.
  seen=set();uniq=[]
  for x in out:
   k=(x.kind,x.device,x.available)
   if k not in seen:seen.add(k);uniq.append(x)
  return tuple(uniq)
 def preferred(self):
  for b in self.discover():
   if b.available and b.kind!="CPU":return b
  return GPUBackend("cpu","CPU","host",True,"no supported accelerator runtime detected")
 @staticmethod
 def _validate(values):
  vals=tuple(float(x) for x in values)
  if any(not math.isfinite(x) for x in vals):raise GPUExecutionError("all values must be finite")
  return vals
 def vector_affine(self,values,scale=1.0,bias=0.0,backend="AUTO"):
  vals=self._validate(values);scale=float(scale);bias=float(bias)
  if not math.isfinite(scale) or not math.isfinite(bias):raise GPUExecutionError("scale/bias must be finite")
  selected=self.preferred() if str(backend).upper()=="AUTO" else next((x for x in self.discover() if x.backend_id==backend and x.available),None)
  if selected is None:raise GPUExecutionError("requested accelerator backend unavailable")
  t=time.perf_counter()
  if selected.kind in ("CUDA","ROCM/HIP") and selected.backend_id.startswith("torch"):
   import torch
   dev="cuda";x=torch.tensor(vals,dtype=torch.float64,device=dev);result=tuple(float(v) for v in (x*scale+bias).cpu().tolist())
  elif selected.backend_id=="cupy":
   import cupy as cp
   x=cp.asarray(vals,dtype=cp.float64);result=tuple(float(v) for v in cp.asnumpy(x*scale+bias).tolist())
  else:result=tuple(x*scale+bias for x in vals)
  elapsed=time.perf_counter()-t;eid="gpu-exec-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO gpu_executions VALUES(?,?,?,?,?,?,?)",(eid,time.time(),selected.kind,selected.device,"VECTOR_AFFINE",len(vals),elapsed))
  self.audit.append("INFO","neural_simulacrum.gpu","execution",subject=eid,details={"backend":selected.kind,"device":selected.device,"count":len(vals)})
  return GPUExecutionResult(eid,selected.kind,selected.device,"VECTOR_AFFINE",len(vals),elapsed,result)
 def summary(self):
  back=self.discover();pref=self.preferred()
  return {"preferred_backend":pref.kind,"preferred_device":pref.device,"backends":tuple((b.kind,b.device,b.available,b.reason) for b in back),
   "note":"P060 provides a real accelerator execution path when a supported runtime is present and reports CPU fallback explicitly. It does not claim GPU execution when unavailable."}
