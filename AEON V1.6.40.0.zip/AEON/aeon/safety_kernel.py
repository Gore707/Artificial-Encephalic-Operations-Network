from __future__ import annotations
from dataclasses import dataclass
import threading,time,uuid

class SafetyError(RuntimeError):pass

ACTIONS=("ALLOW","HOLD_NEW_WORK","CANCEL_JOB","ISOLATE_PROCESS")
LEVELS=("INFO","ADVISORY","WARNING","CRITICAL","SAFETY_INTERVENTION")

@dataclass(frozen=True)
class SafetyRule:
    rule_id:str;metric:str;operator:str;threshold:float;action:str;level:str;enabled:bool=True

@dataclass(frozen=True)
class SafetyDecision:
    decision_id:str;rule_id:str;metric:str;value:float;action:str;level:str
    created_unix:float;executed:bool;target_id:str|None;reason:str

class SafetyKernel:
    """Deterministic AEON safety authority foundation.

    Guardian may supply observations but cannot approve/override decisions.
    Only explicit rules can cause interventions. Unknown/missing measurements
    never become invented safe values.
    """
    def __init__(self,db,audit,jobs=None,processes=None):
        self.db=db;self.audit=audit;self.jobs=jobs;self.processes=processes
        self._hold=False;self._lock=threading.RLock();self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS safety_rules(
              rule_id TEXT PRIMARY KEY,metric TEXT NOT NULL,operator TEXT NOT NULL,
              threshold REAL NOT NULL,action TEXT NOT NULL,level TEXT NOT NULL,enabled INTEGER NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS safety_decisions(
              decision_id TEXT PRIMARY KEY,rule_id TEXT NOT NULL,metric TEXT NOT NULL,value REAL NOT NULL,
              action TEXT NOT NULL,level TEXT NOT NULL,created_unix REAL NOT NULL,executed INTEGER NOT NULL,
              target_id TEXT,reason TEXT NOT NULL)""")

    @property
    def hold_new_work(self):return self._hold

    def add_rule(self,metric,operator,threshold,action,level="SAFETY_INTERVENTION",rule_id=None):
        if operator not in (">",">=","<","<=","=="):raise SafetyError("unsupported operator")
        if action not in ACTIONS:raise SafetyError("unsupported action")
        if level not in LEVELS:raise SafetyError("unsupported level")
        rid=rule_id or "srule-"+uuid.uuid4().hex
        with self.db.transaction() as c:
            c.execute("INSERT INTO safety_rules VALUES(?,?,?,?,?,?,1)",
                      (rid,str(metric),operator,float(threshold),action,level))
        self.audit.append("WARNING","safety","rule_added",subject=rid,
                          details={"metric":metric,"operator":operator,"threshold":float(threshold),
                                   "action":action,"level":level})
        return self.get_rule(rid)

    def get_rule(self,rid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM safety_rules WHERE rule_id=?",(rid,)).fetchone()
        if r is None:raise SafetyError("unknown rule")
        return SafetyRule(r["rule_id"],r["metric"],r["operator"],r["threshold"],r["action"],r["level"],bool(r["enabled"]))

    def list_rules(self):
        with self.db._connect() as c:ids=[r["rule_id"] for r in c.execute("SELECT rule_id FROM safety_rules ORDER BY rule_id").fetchall()]
        return tuple(self.get_rule(i) for i in ids)

    @staticmethod
    def _match(op,a,b):
        return {">":a>b,">=":a>=b,"<":a<b,"<=":a<=b,"==":a==b}[op]

    def evaluate(self,metric,value,target_id=None):
        if value is None:raise SafetyError("missing measurement cannot be evaluated as safe")
        v=float(value);decisions=[]
        for rule in self.list_rules():
            if not rule.enabled or rule.metric!=metric or not self._match(rule.operator,v,rule.threshold):continue
            executed=False;reason=f"{metric} {rule.operator} {rule.threshold}"
            if rule.action=="HOLD_NEW_WORK":
                with self._lock:self._hold=True
                executed=True
            elif rule.action=="CANCEL_JOB":
                if not target_id or self.jobs is None:raise SafetyError("CANCEL_JOB requires job target")
                self.jobs.cancel(target_id);executed=True
            elif rule.action=="ISOLATE_PROCESS":
                if not target_id or self.processes is None:raise SafetyError("ISOLATE_PROCESS requires process target")
                self.processes.stop(target_id);executed=True
            elif rule.action=="ALLOW":executed=True
            did="sdec-"+uuid.uuid4().hex;now=time.time()
            with self.db.transaction() as c:
                c.execute("INSERT INTO safety_decisions VALUES(?,?,?,?,?,?,?,?,?,?)",
                          (did,rule.rule_id,metric,v,rule.action,rule.level,now,1 if executed else 0,target_id,reason))
            self.audit.append("CRITICAL" if rule.level in ("CRITICAL","SAFETY_INTERVENTION") else "WARNING",
                              "safety","decision",subject=did,
                              details={"rule_id":rule.rule_id,"metric":metric,"value":v,
                                       "action":rule.action,"executed":executed,"target_id":target_id})
            decisions.append(SafetyDecision(did,rule.rule_id,metric,v,rule.action,rule.level,now,executed,target_id,reason))
        return tuple(decisions)

    def release_hold(self,reason):
        if not str(reason).strip():raise SafetyError("release requires explicit reason")
        with self._lock:self._hold=False
        self.audit.append("WARNING","safety","hold_released",subject="kernel",details={"reason":str(reason)})

    def decisions(self,limit=200):
        with self.db._connect() as c:rows=c.execute(
            "SELECT * FROM safety_decisions ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()
        return tuple(SafetyDecision(r["decision_id"],r["rule_id"],r["metric"],r["value"],r["action"],r["level"],
                                    r["created_unix"],bool(r["executed"]),r["target_id"],r["reason"]) for r in rows)

class SafetyGovernor:
    """Bridge from measured telemetry to deterministic SafetyKernel rules."""
    def __init__(self,kernel,guardian,audit):
        self.kernel=kernel;self.guardian=guardian;self.audit=audit
    def submit_measurement(self,metric,value,provenance="MEASURED",target_id=None):
        if provenance not in ("MEASURED","HOST","HARDWARE"):
            raise SafetyError("interlocks require measured/host/hardware provenance")
        decisions=self.kernel.evaluate(str(metric),value,target_id)
        if decisions:
            self.guardian.set_status("INTERVENTION","Deterministic Safety Kernel rule triggered")
        return decisions
