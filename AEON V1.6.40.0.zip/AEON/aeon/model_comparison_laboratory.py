from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import csv,math,statistics
class ModelComparisonError(RuntimeError):pass
@dataclass(frozen=True)
class ModelMetrics:
 dataset_id:str;observed_field:str;predicted_field:str;n:int;mae:float;rmse:float;mean_error:float;correlation:float|None;evidence_class:str;provenance:str
@dataclass(frozen=True)
class ComparisonReport:
 reports:tuple[ModelMetrics,...];metric:str;notes:str
class ModelComparisonLaboratory:
 """Quantitative comparison without declaring scientific truth or a winner."""
 def __init__(self,data_lab,audit):self.data_lab=data_lab;self.audit=audit
 def evaluate(self,dataset_id,observed_field,predicted_field,max_rows=500000):
  d=self.data_lab.get(dataset_id)
  if d.format not in ("csv","tsv"):raise ModelComparisonError("model comparison requires CSV/TSV")
  p=Path(d.source_path)
  if not p.is_file():raise ModelComparisonError("original dataset locator unavailable")
  obs=[];pred=[];delim="\t" if d.format=="tsv" else ","
  with p.open("r",encoding="utf-8-sig",newline="") as f:
   r=csv.DictReader(f,delimiter=delim)
   if observed_field not in (r.fieldnames or ()) or predicted_field not in (r.fieldnames or ()):raise ModelComparisonError("comparison field absent")
   for row in r:
    if len(obs)>=max_rows:break
    try:a=float(row[observed_field]);b=float(row[predicted_field])
    except (TypeError,ValueError):continue
    if math.isfinite(a) and math.isfinite(b):obs.append(a);pred.append(b)
  if not obs:raise ModelComparisonError("no paired finite observations")
  err=[b-a for a,b in zip(obs,pred)];mae=statistics.fmean(abs(x) for x in err);rmse=math.sqrt(statistics.fmean(x*x for x in err));bias=statistics.fmean(err)
  corr=None
  if len(obs)>=2:
   ma=statistics.fmean(obs);mb=statistics.fmean(pred);da=sum((x-ma)**2 for x in obs);db=sum((x-mb)**2 for x in pred)
   if da>0 and db>0:corr=sum((a-ma)*(b-mb) for a,b in zip(obs,pred))/math.sqrt(da*db)
  q=ModelMetrics(dataset_id,observed_field,predicted_field,len(obs),mae,rmse,bias,corr,d.evidence_class,d.provenance)
  self.audit.append("INFO","apotheosis.model_comparison","model_evaluated",subject=dataset_id,details={"observed":observed_field,"predicted":predicted_field,"n":len(obs),"mae":mae,"rmse":rmse})
  return q
 def compare(self,specs,metric="rmse"):
  if metric not in ("mae","rmse","mean_error","correlation"):raise ModelComparisonError("unsupported comparison metric")
  reports=tuple(self.evaluate(*s) for s in specs)
  if not reports:raise ModelComparisonError("at least one model comparison required")
  return ComparisonReport(reports,metric,"Metrics are descriptive. AEON does not declare a scientifically correct model or winner.")
