from __future__ import annotations

import os
import tkinter as tk
from tkinter import messagebox, simpledialog

from . import __version__
from .app_api import AeonApplication
from .preflight import run_preflight, write_report
from .workspaces import WorkspaceError

BG = "#070707"
PANEL = "#101010"
RED = "#d21f2b"
TEXT = "#e7e7e7"
MUTED = "#999999"
GREEN = "#35c46a"


def _bytes(value):
    if value is None:
        return "N/A"
    value = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if value < 1024 or unit == "TiB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return "N/A"


def _title(parent, title, subtitle=""):
    tk.Label(parent, text=title, bg=PANEL, fg=RED,
             font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=18, pady=(18, 2))
    if subtitle:
        tk.Label(parent, text=subtitle, bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 9)).pack(anchor="w", padx=18, pady=(0, 12))


class SystemDiagnosticsApp(AeonApplication):
    app_id = "system"
    title = "System Diagnostics"

    def build(self, parent):
        services = self.context.services
        _title(parent, "SYSTEM DIAGNOSTICS",
               "Measured host data only. Unsupported sensors remain N/A.")
        snap = services.host_snapshot()
        cfg = services.config
        active = services.workspaces.active()
        items = [
            ("AEON VERSION", __version__),
            ("PROJECT", cfg.get("aeon.project")),
            ("ACTIVE WORKSPACE", active.name if active else "NONE"),
            ("CPU LOGICAL PROCESSORS", str(os.cpu_count() or "N/A")),
            ("CPU UTILIZATION", "N/A" if snap.cpu_percent is None else f"{snap.cpu_percent:.1f}%"),
            ("RAM", f"{_bytes(snap.ram_used_bytes)} / {_bytes(snap.ram_total_bytes)}"),
            ("PROJECT DISK", f"{_bytes(snap.disk_used_bytes)} / {_bytes(snap.disk_total_bytes)}"),
            ("SAFETY MODE", "FAIL-CLOSED" if cfg.get("safety.fail_closed", True) else "CONFIGURED OFF"),
        ]
        grid = tk.Frame(parent, bg=PANEL)
        grid.pack(fill="x", padx=18, pady=8)
        for row, (name, value) in enumerate(items):
            tk.Label(grid, text=name, width=28, anchor="w", bg=PANEL, fg=MUTED,
                     font=("Consolas", 9)).grid(row=row, column=0, sticky="w", pady=5)
            tk.Label(grid, text=value, anchor="w", bg=PANEL, fg=TEXT,
                     font=("Consolas", 10, "bold")).grid(row=row, column=1, sticky="w", pady=5)


class WorkspaceManagerApp(AeonApplication):
    app_id = "workspaces"
    title = "Workspaces"

    def build(self, parent):
        self.parent = parent
        _title(parent, "PROJECT / WORKSPACE MANAGER",
               "Persistent AEON research workspaces. Deletion requires explicit confirmation.")
        toolbar = tk.Frame(parent, bg=PANEL)
        toolbar.pack(fill="x", padx=18, pady=(0, 8))
        for text, command in (
            ("NEW", self.create),
            ("ACTIVATE", self.activate),
            ("RENAME", self.rename),
            ("DELETE", self.delete),
            ("REFRESH", self.refresh),
        ):
            tk.Button(toolbar, text=text, command=command, bg=BG, fg=RED,
                      activebackground=RED, activeforeground=TEXT, relief="flat",
                      padx=10, pady=6, font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 5))

        self.listbox = tk.Listbox(parent, bg=BG, fg=TEXT, selectbackground=RED,
                                  selectforeground=TEXT, relief="flat",
                                  font=("Consolas", 10), activestyle="none")
        self.listbox.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        self.refresh()

    def _selected(self):
        selection = self.listbox.curselection()
        if not selection:
            raise WorkspaceError("Select a workspace first")
        return self._rows[selection[0]]

    def refresh(self):
        store = self.context.services.workspaces
        active = store.active_id()
        self._rows = list(store.list())
        self.listbox.delete(0, "end")
        for ws in self._rows:
            marker = "●" if ws.workspace_id == active else " "
            self.listbox.insert("end", f"{marker}  {ws.name:<42}  {ws.workspace_id}")

    def create(self):
        name = simpledialog.askstring("New AEON Workspace", "Workspace name:", parent=self.parent)
        if name is None:
            return
        try:
            ws = self.context.services.workspaces.create(name)
            self.context.services.logger.info("Workspace created | id=%s | name=%s", ws.workspace_id, ws.name)
            self.refresh()
        except WorkspaceError as exc:
            messagebox.showerror("Workspace Error", str(exc), parent=self.parent)

    def activate(self):
        try:
            ws = self._selected()
            self.context.services.workspaces.activate(ws.workspace_id)
            self.context.services.logger.info("Workspace activated | id=%s", ws.workspace_id)
            self.refresh()
        except WorkspaceError as exc:
            messagebox.showerror("Workspace Error", str(exc), parent=self.parent)

    def rename(self):
        try:
            ws = self._selected()
            name = simpledialog.askstring("Rename Workspace", "New name:",
                                          initialvalue=ws.name, parent=self.parent)
            if name is None:
                return
            updated = self.context.services.workspaces.rename(ws.workspace_id, name)
            self.context.services.logger.info("Workspace renamed | id=%s | name=%s",
                                              updated.workspace_id, updated.name)
            self.refresh()
        except WorkspaceError as exc:
            messagebox.showerror("Workspace Error", str(exc), parent=self.parent)

    def delete(self):
        try:
            ws = self._selected()
            if not messagebox.askyesno(
                "Delete Workspace",
                f"Delete workspace '{ws.name}' and its AEON workspace directory?\n\nThis cannot be undone.",
                parent=self.parent,
            ):
                return
            self.context.services.workspaces.delete(ws.workspace_id)
            self.context.services.logger.warning("Workspace deleted | id=%s | name=%s",
                                                 ws.workspace_id, ws.name)
            self.refresh()
        except WorkspaceError as exc:
            messagebox.showerror("Workspace Error", str(exc), parent=self.parent)


class EventLogApp(AeonApplication):
    app_id = "event_log"
    title = "Event Log"

    def build(self, parent):
        services = self.context.services
        _title(parent, "AEON EVENT LOG", "Current rotating runtime log; read-only.")
        path = services.path("paths.logs") / "aeon.log"
        box = tk.Text(parent, bg=BG, fg=TEXT, insertbackground=RED,
                      relief="flat", font=("Consolas", 9), wrap="none")
        box.pack(fill="both", expand=True, padx=18, pady=(4, 18))
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()[-500:]
            box.insert("1.0", "\n".join(lines))
        except OSError as exc:
            box.insert("1.0", f"Unable to read log: {exc}")
        box.configure(state="disabled")


class PreflightApp(AeonApplication):
    app_id = "preflight"
    title = "Preflight Qualification"

    def build(self, parent):
        services = self.context.services
        ok, checks = run_preflight(services.root, services.config)
        report = write_report(services.path("paths.state"), checks)
        services.logger.info("Interactive preflight | passed=%s | report=%s", ok, report)
        _title(parent, "PREFLIGHT QUALIFICATION",
               f"Result: {'PASS' if ok else 'FAIL'} • {report}")
        frame = tk.Frame(parent, bg=PANEL)
        frame.pack(fill="x", padx=18, pady=8)
        for i, check in enumerate(checks):
            fg = GREEN if check.ok else RED
            tk.Label(frame, text="PASS" if check.ok else "FAIL", width=8, anchor="w",
                     bg=PANEL, fg=fg, font=("Consolas", 9, "bold")).grid(row=i, column=0, sticky="w", pady=4)
            tk.Label(frame, text=check.name, width=24, anchor="w",
                     bg=PANEL, fg=TEXT, font=("Consolas", 9)).grid(row=i, column=1, sticky="w")
            tk.Label(frame, text=check.detail, anchor="w",
                     bg=PANEL, fg=MUTED, font=("Consolas", 9)).grid(row=i, column=2, sticky="w")


class AuditDiagnosticsApp(AeonApplication):
    app_id = "audit"
    title = "Audit & Diagnostics"

    def build(self, parent):
        services = self.context.services
        ok, detail = services.audit.verify()
        _title(parent, "AUDIT & DIAGNOSTICS",
               f"Audit integrity: {'VERIFIED' if ok else 'FAILED'} — {detail}")
        toolbar = tk.Frame(parent, bg=PANEL)
        toolbar.pack(fill="x", padx=18, pady=(0, 8))
        self.status = tk.Label(toolbar, text="", bg=PANEL, fg=MUTED, font=("Consolas", 9))
        self.status.pack(side="right")
        tk.Button(toolbar, text="WRITE DIAGNOSTIC SNAPSHOT", command=self.write_snapshot,
                  bg=BG, fg=RED, activebackground=RED, activeforeground=TEXT,
                  relief="flat", padx=10, pady=6,
                  font=("Segoe UI", 9, "bold")).pack(side="left")
        box = tk.Text(parent, bg=BG, fg=TEXT, insertbackground=RED,
                      relief="flat", font=("Consolas", 9), wrap="none")
        box.pack(fill="both", expand=True, padx=18, pady=(0, 18))
        for event in services.audit.recent(500):
            subject = f" [{event.subject}]" if event.subject else ""
            box.insert("end", f"{event.sequence:06d}  {event.severity:<19} "
                              f"{event.category}/{event.action}{subject}  actor={event.actor}\n")
        box.configure(state="disabled")

    def write_snapshot(self):
        path = self.context.services.diagnostics.write_snapshot()
        self.context.services.audit.append("INFO", "diagnostics", "snapshot_written",
                                           actor="AEON", subject=str(path))
        self.status.config(text=f"WROTE {path}")


class SecurityApp(AeonApplication):
    app_id = "security"
    title = "Identity & Access"

    def build(self, parent):
        self.parent = parent
        self._render()

    def _clear(self):
        for child in self.parent.winfo_children():
            child.destroy()

    def _render(self):
        self._clear()
        s=self.context.services
        _title(self.parent, "IDENTITY & ACCESS",
               "Local users, authenticated session, deterministic role permissions.")
        body=tk.Frame(self.parent,bg=PANEL)
        body.pack(fill="both",expand=True,padx=18,pady=(0,18))

        if s.identity.user_count()==0:
            tk.Label(body,text="FIRST-RUN ADMINISTRATOR BOOTSTRAP",bg=PANEL,fg=RED,
                     font=("Segoe UI",11,"bold")).pack(anchor="w",pady=(4,8))
            self.user_entry=tk.Entry(body,bg=BG,fg=TEXT,insertbackground=RED,relief="flat")
            self.name_entry=tk.Entry(body,bg=BG,fg=TEXT,insertbackground=RED,relief="flat")
            self.pass_entry=tk.Entry(body,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",show="*")
            for label,widget in (("Username",self.user_entry),("Display name",self.name_entry),
                                 ("Password (10+ characters)",self.pass_entry)):
                tk.Label(body,text=label,bg=PANEL,fg=MUTED,font=("Consolas",9)).pack(anchor="w")
                widget.pack(fill="x",pady=(2,8))
            tk.Button(body,text="CREATE INITIAL ADMINISTRATOR",command=self._bootstrap,
                      bg=BG,fg=RED,activebackground=RED,activeforeground=TEXT,
                      relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(anchor="w")
            self.status=tk.Label(body,text="",bg=PANEL,fg=MUTED,font=("Consolas",9))
            self.status.pack(anchor="w",pady=8)
            return

        if s.session.user is None:
            tk.Label(body,text="AUTHENTICATION REQUIRED",bg=PANEL,fg=RED,
                     font=("Segoe UI",11,"bold")).pack(anchor="w",pady=(4,8))
            self.user_entry=tk.Entry(body,bg=BG,fg=TEXT,insertbackground=RED,relief="flat")
            self.pass_entry=tk.Entry(body,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",show="*")
            for label,widget in (("Username",self.user_entry),("Password",self.pass_entry)):
                tk.Label(body,text=label,bg=PANEL,fg=MUTED,font=("Consolas",9)).pack(anchor="w")
                widget.pack(fill="x",pady=(2,8))
            tk.Button(body,text="SIGN IN",command=self._login,bg=BG,fg=RED,
                      activebackground=RED,activeforeground=TEXT,relief="flat",
                      padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(anchor="w")
            self.status=tk.Label(body,text="",bg=PANEL,fg=MUTED,font=("Consolas",9))
            self.status.pack(anchor="w",pady=8)
            return

        user=s.session.user
        roles=", ".join(s.identity.roles_for(user.user_id)) or "none"
        perms=sorted(s.identity.permissions_for(user.user_id))
        tk.Label(body,text=f"SIGNED IN: {user.display_name} ({user.username})",
                 bg=PANEL,fg=TEXT,font=("Segoe UI",11,"bold")).pack(anchor="w",pady=(4,4))
        tk.Label(body,text=f"ROLES: {roles}",bg=PANEL,fg=MUTED,
                 font=("Consolas",9)).pack(anchor="w")
        tk.Label(body,text="PERMISSIONS:",bg=PANEL,fg=RED,
                 font=("Consolas",9,"bold")).pack(anchor="w",pady=(12,3))
        tk.Label(body,text="\n".join(perms),justify="left",bg=PANEL,fg=TEXT,
                 font=("Consolas",9)).pack(anchor="w")
        tk.Button(body,text="SIGN OUT",command=self._logout,bg=BG,fg=RED,
                  activebackground=RED,activeforeground=TEXT,relief="flat",
                  padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(anchor="w",pady=(16,0))

    def _bootstrap(self):
        try:
            user=self.context.services.identity.bootstrap_administrator(
                self.user_entry.get(),self.name_entry.get(),self.pass_entry.get())
            self.context.services.session.login(user)
            self._render()
        except Exception as exc:
            self.status.config(text=str(exc),fg=RED)

    def _login(self):
        user=self.context.services.identity.authenticate(
            self.user_entry.get(),self.pass_entry.get())
        if user is None:
            self.status.config(text="AUTHENTICATION FAILED",fg=RED)
            return
        self.context.services.session.login(user)
        self._render()

    def _logout(self):
        user_id=self.context.services.session.user_id
        if user_id:
            self.context.services.audit.append("INFO","security","session_logout",
                                               actor=user_id,subject=user_id)
        self.context.services.session.logout()
        self._render()

class ProcessMonitorApp(AeonApplication):
    app_id="processes"
    title="Process Supervisor"
    def build(self,parent):
        self.parent=parent
        _title(parent,"PROCESS SUPERVISOR",
               "Real OS child-process containment, lifecycle state, output logs, and bounded restart.")
        bar=tk.Frame(parent,bg=PANEL); bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,
                  activebackground=RED,activeforeground=TEXT,relief="flat",
                  padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        tk.Button(bar,text="STOP SELECTED",command=self.stop_selected,bg=BG,fg=RED,
                  activebackground=RED,activeforeground=TEXT,relief="flat",
                  padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left",padx=5)
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9))
        self.status.pack(side="right")
        self.listbox=tk.Listbox(parent,bg=BG,fg=TEXT,selectbackground=RED,
                                selectforeground=TEXT,relief="flat",font=("Consolas",9))
        self.listbox.pack(fill="both",expand=True,padx=18,pady=(0,18)); self.refresh()
    def refresh(self):
        self.rows=list(self.context.services.processes.list()); self.listbox.delete(0,"end")
        for p in self.rows:
            self.listbox.insert("end",f"{p.state:<9} PID {p.pid:<7} R{p.restart_count:<2} "
                                      f"{p.name:<28} {p.process_id}")
        self.status.config(text=f"{len(self.rows)} MANAGED")
    def stop_selected(self):
        s=self.listbox.curselection()
        if not s: self.status.config(text="SELECT A PROCESS",fg=RED); return
        p=self.rows[s[0]]
        try:
            self.context.services.require_permission("system.protected",
                action="stop_managed_process",subject=p.process_id)
            self.context.services.processes.stop(p.process_id); self.refresh()
        except Exception as exc: self.status.config(text=str(exc),fg=RED)


class HardwareInventoryApp(AeonApplication):
    app_id = "hardware"
    title = "Hardware Inventory"

    @staticmethod
    def _fmt_bytes(value):
        if value is None:
            return "UNAVAILABLE"
        n=float(value)
        for unit in ("B","KiB","MiB","GiB","TiB","PiB"):
            if n < 1024 or unit == "PiB":
                return f"{n:.2f} {unit}"
            n /= 1024
        return "UNAVAILABLE"

    def build(self, parent):
        _title(parent, "HOST HARDWARE INVENTORY",
               "Measured CPU, physical memory, and mounted storage. Unknown values remain unavailable.")
        toolbar=tk.Frame(parent,bg=PANEL)
        toolbar.pack(fill="x",padx=18,pady=(0,8))
        self.status=tk.Label(toolbar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9))
        self.status.pack(side="right")
        tk.Button(toolbar,text="REFRESH INVENTORY",command=self.refresh,
                  bg=BG,fg=RED,activebackground=RED,activeforeground=TEXT,
                  relief="flat",padx=10,pady=6,
                  font=("Segoe UI",9,"bold")).pack(side="left")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none")
        self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()

    def refresh(self):
        inv=self.context.services.hardware.discover()
        c=inv.cpu; m=inv.memory
        lines=[
            f"OS           {inv.operating_system}",
            f"MACHINE      {inv.machine}",
            "",
            "CPU",
            f"  Model      {c.model or 'UNAVAILABLE'}",
            f"  Vendor     {c.vendor or 'UNAVAILABLE'}",
            f"  Arch       {c.architecture}",
            f"  Logical    {c.logical_processors}",
            "",
            "PHYSICAL MEMORY",
            f"  Total      {self._fmt_bytes(m.total_bytes)}",
            f"  Available  {self._fmt_bytes(m.available_bytes)}",
            "",
            "STORAGE VOLUMES",
        ]
        for v in inv.storage:
            lines.extend([
                f"  {v.path}",
                f"    Total    {self._fmt_bytes(v.total_bytes)}",
                f"    Used     {self._fmt_bytes(v.used_bytes)}",
                f"    Free     {self._fmt_bytes(v.free_bytes)}",
            ])
        if not inv.storage:
            lines.append("  NO QUERYABLE STORAGE VOLUMES")
        self.box.configure(state="normal")
        self.box.delete("1.0","end")
        self.box.insert("1.0","\n".join(lines))
        self.box.configure(state="disabled")
        self.status.config(text=f"{len(inv.storage)} VOLUME(S)")


class AcceleratorInventoryApp(AeonApplication):
    app_id = "accelerators"
    title = "GPU & Accelerators"

    @staticmethod
    def _bytes(value):
        if value is None:
            return "UNAVAILABLE"
        n=float(value)
        for unit in ("B","KiB","MiB","GiB","TiB"):
            if n < 1024 or unit == "TiB":
                return f"{n:.2f} {unit}"
            n /= 1024
        return "UNAVAILABLE"

    def build(self, parent):
        _title(parent, "GPU / ACCELERATOR INVENTORY",
               "Provider-backed discovery. Missing VRAM, temperature, or utilization is never estimated.")
        bar=tk.Frame(parent,bg=PANEL)
        bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,
                  activebackground=RED,activeforeground=TEXT,relief="flat",
                  padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9))
        self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none")
        self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()

    def refresh(self):
        inv=self.context.services.accelerators.discover()
        lines=["PROBES"]+[f"  {p}" for p in inv.probes]+["","DEVICES"]
        if not inv.devices:
            lines.append("  NO ACCELERATOR DETECTED BY AVAILABLE PROVIDERS")
        for d in inv.devices:
            lines += [
                f"  {d.name}",
                f"    Vendor       {d.vendor}",
                f"    Backend      {d.backend}",
                f"    Device ID    {d.device_id}",
                f"    VRAM total   {self._bytes(d.memory_total_bytes)}",
                f"    VRAM free    {self._bytes(d.memory_free_bytes)}",
                f"    Driver       {d.driver_version or 'UNAVAILABLE'}",
                f"    Temperature  {str(d.temperature_c)+' C' if d.temperature_c is not None else 'UNAVAILABLE'}",
                f"    Utilization  {str(d.utilization_percent)+' %' if d.utilization_percent is not None else 'UNAVAILABLE'}",
                f"    Source       {d.source}",
                ""
            ]
        self.box.configure(state="normal"); self.box.delete("1.0","end")
        self.box.insert("1.0","\n".join(lines)); self.box.configure(state="disabled")
        self.status.config(text=f"{len(inv.devices)} DEVICE(S)")


class ResourceManagerApp(AeonApplication):
    app_id = "resources"
    title = "Resource Manager"

    @staticmethod
    def _bytes(value):
        if value is None:
            return "UNAVAILABLE"
        n=float(value)
        for unit in ("B","KiB","MiB","GiB","TiB"):
            if n < 1024 or unit=="TiB":
                return f"{n:.2f} {unit}"
            n/=1024
        return "UNAVAILABLE"

    def build(self,parent):
        _title(parent,"RESOURCE MANAGER",
               "Conservative AEON admission envelope. Headroom is reserved for the host OS, UI, and safety services.")
        bar=tk.Frame(parent,bg=PANEL); bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,
                  activebackground=RED,activeforeground=TEXT,relief="flat",
                  padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9))
        self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none")
        self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()

    def refresh(self):
        r=self.context.services.resources
        e=r.envelope(); a=r.available()
        lines=[
            f"POLICY                 {e.policy}",
            "",
            "CPU",
            f"  Host logical         {e.cpu_logical_total}",
            f"  AEON ceiling         {e.cpu_logical_limit}",
            f"  Currently available  {a.cpu_logical_limit}",
            "",
            "PHYSICAL MEMORY",
            f"  Host total           {self._bytes(e.memory_total_bytes)}",
            f"  AEON ceiling         {self._bytes(e.memory_limit_bytes)}",
            f"  Currently available  {self._bytes(a.memory_limit_bytes)}",
            "",
            "STORAGE",
            f"  Current free pool    {self._bytes(e.storage_free_bytes)}",
            f"  Required reserve     {self._bytes(e.storage_reserve_bytes)}",
            "",
            "GPU / ACCELERATOR",
            f"  Devices detected     {e.accelerators_detected}",
            f"  Provider VRAM total  {self._bytes(e.gpu_memory_total_bytes)}",
            f"  AEON VRAM ceiling    {self._bytes(e.gpu_memory_limit_bytes)}",
            f"  Available VRAM       {self._bytes(a.gpu_memory_limit_bytes)}",
            f"  Unknown-VRAM guard   {'ACTIVE' if e.conservative_due_to_unknown_gpu_vram else 'NOT REQUIRED'}",
            "",
            f"ACTIVE LEASES          {len(r.leases())}",
            "",
            "P014 ENFORCEMENT",
            "  AEON jobs must acquire a lease before consuming declared resources.",
            "  Requests exceeding the envelope are denied.",
            "  Unknown provider VRAM blocks nonzero VRAM reservations.",
            "  This patch does not overclock or alter firmware/power limits.",
            "  Thermal intervention is intentionally deferred to telemetry/safety layers."
        ]
        self.box.configure(state="normal"); self.box.delete("1.0","end")
        self.box.insert("1.0","\n".join(lines)); self.box.configure(state="disabled")
        self.status.config(text=f"{len(r.leases())} ACTIVE LEASE(S)")

class JobSchedulerApp(AeonApplication):
    app_id="jobs";title="Job Scheduler"
    def build(self,parent):
        self.parent=parent;_title(parent,"JOB SCHEDULER","Persistent, resource-gated background execution.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        tk.Button(bar,text="CANCEL SELECTED",command=self.cancel,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left",padx=5)
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.listbox=tk.Listbox(parent,bg=BG,fg=TEXT,selectbackground=RED,selectforeground=TEXT,
                                relief="flat",font=("Consolas",9));self.listbox.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def refresh(self):
        self.rows=list(self.context.services.jobs.list());self.listbox.delete(0,"end")
        for j in self.rows:self.listbox.insert("end",f"{j.state:<10} CPU {j.request.cpu_logical:<3} {j.name:<28} {j.job_id}")
        self.status.config(text=f"{len(self.rows)} JOB(S)")
    def cancel(self):
        s=self.listbox.curselection()
        if not s:self.status.config(text="SELECT A JOB",fg=RED);return
        j=self.rows[s[0]]
        try:
            self.context.services.require_permission("system.protected",action="cancel_job",subject=j.job_id)
            self.context.services.jobs.cancel(j.job_id);self.refresh()
        except Exception as exc:self.status.config(text=str(exc),fg=RED)

class VisualizationStudioApp(AeonApplication):
    app_id="visualizations";title="Visualization Studio"
    def build(self,parent):
        self.parent=parent
        _title(parent,"SCIENTIFIC VISUALIZATION","Quantitative figure specifications with units, provenance, and reproducible export.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        tk.Button(bar,text="EXPORT CSV",command=self.export,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left",padx=5)
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.canvas=tk.Canvas(parent,bg=BG,highlightthickness=0)
        self.canvas.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.canvas.bind("<Configure>",lambda e:self.draw());self.refresh()
    def refresh(self):
        self.figures=list(self.context.services.visualizations.list())
        self.current=self.figures[0] if self.figures else None;self.draw()
        self.status.config(text=f"{len(self.figures)} FIGURE(S)")
    def draw(self):
        if not hasattr(self,"canvas"):return
        c=self.canvas;c.delete("all");w=max(100,c.winfo_width());h=max(100,c.winfo_height())
        if not getattr(self,"current",None):
            c.create_text(w/2,h/2,text="NO QUANTITATIVE FIGURES YET",fill=MUTED,font=("Consolas",11));return
        f=self.current;pad=55
        c.create_text(pad,20,anchor="w",text=f.title,fill=TEXT,font=("Segoe UI",12,"bold"))
        xs=[v for s in f.series for v in s.x];ys=[v for s in f.series for v in s.y]
        xmin,xmax=min(xs),max(xs);ymin,ymax=min(ys),max(ys)
        if xmax==xmin:xmax=xmin+1
        if ymax==ymin:ymax=ymin+1
        c.create_line(pad,h-pad,w-pad,h-pad,fill=MUTED);c.create_line(pad,pad,pad,h-pad,fill=MUTED)
        for idx,s in enumerate(f.series):
            pts=[]
            for x,y in zip(s.x,s.y):
                px=pad+(x-xmin)/(xmax-xmin)*(w-2*pad);py=h-pad-(y-ymin)/(ymax-ymin)*(h-2*pad);pts.extend((px,py))
            if len(pts)>=4:c.create_line(*pts,fill=RED,width=2)
            elif pts:c.create_oval(pts[0]-2,pts[1]-2,pts[0]+2,pts[1]+2,fill=RED,outline="")
            c.create_text(w-pad,pad+idx*18,anchor="ne",text=f"{s.name} [{s.provenance}]",fill=TEXT,font=("Consolas",8))
        c.create_text(w/2,h-15,text=f.x_label,fill=MUTED,font=("Consolas",8))
        c.create_text(8,h/2,anchor="w",text=f.y_label,fill=MUTED,font=("Consolas",8))
    def export(self):
        if not self.current:self.status.config(text="NO FIGURE",fg=RED);return
        try:p=self.context.services.visualizations.export_csv(self.current.figure_id);self.status.config(text=f"EXPORTED {p.name}")
        except Exception as exc:self.status.config(text=str(exc),fg=RED)


class TelemetryStreamApp(AeonApplication):
    app_id="telemetry_stream";title="Telemetry Stream"
    def build(self,parent):
        self.parent=parent
        _title(parent,"REAL-TIME TELEMETRY BUS",
               "Bounded raw telemetry with provenance-aware aggregate windows.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,
                  activebackground=RED,activeforeground=TEXT,relief="flat",
                  padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9))
        self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none")
        self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def refresh(self):
        bus=self.context.services.telemetry_stream
        st=bus.stats()
        lines=[
            f"RING CAPACITY      {st['capacity']}",
            f"RETAINED SAMPLES   {st['retained']}",
            f"CURRENT SEQUENCE   {st['current_sequence']}",
            f"ACTIVE CHANNELS    {st['channels']}",
            "",
            "CHANNEL WINDOWS (last 5 seconds)"
        ]
        for ch in bus.channels():
            w=bus.aggregate(ch,seconds=5.0)
            lines.append(
                f"{ch:<34} n={w.count:<6} latest={str(w.latest):<14} "
                f"mean={str(w.mean):<14} {w.unit:<8} [{w.provenance}]"
            )
        if not bus.channels():
            lines.append("NO HIGH-RATE CHANNELS PUBLISHED YET")
        lines += [
            "",
            "P017 CONTRACT",
            "Raw events are retained only within bounded ring capacity.",
            "Guardian/UI consumers can use aggregate windows instead of every raw event.",
            "Every sample carries provenance and source identity.",
            "No universal neural timestep is imposed by the telemetry transport."
        ]
        self.box.configure(state="normal");self.box.delete("1.0","end")
        self.box.insert("1.0","\n".join(lines));self.box.configure(state="disabled")
        self.status.config(text=f"{st['retained']} / {st['capacity']} SAMPLES")

class ExperimentManagerApp(AeonApplication):
    app_id="experiments";title="Experiments"
    def build(self,parent):
        _title(parent,"EXPERIMENT MANAGER",
               "Versioned definitions and runs with explicit evidence mode and resource-gated execution.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def refresh(self):
        ex=self.context.services.experiments
        defs=ex.list();runs=ex.runs()
        lines=["DEFINITIONS"]
        for e in defs:lines.append(f"{e.mode:<11} {e.name:<30} {e.experiment_id}  {e.definition_hash[:12]}")
        if not defs:lines.append("NO EXPERIMENT DEFINITIONS")
        lines+=["","RUNS"]
        for r in runs:lines.append(f"{r.state:<11} {r.mode:<11} {r.run_id} -> {r.job_id}")
        if not runs:lines.append("NO EXPERIMENT RUNS")
        lines+=["","EVIDENCE MODES: SIMULATION / IMPORTED / HOST / HARDWARE",
                "Definitions are hash-identified; execution passes through the resource-gated Job Scheduler."]
        self.box.configure(state="normal");self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))
        self.box.configure(state="disabled");self.status.config(text=f"{len(defs)} DEF / {len(runs)} RUN")

class CheckpointManagerApp(AeonApplication):
    app_id="checkpoints";title="Checkpoints"
    def build(self,parent):
        _title(parent,"CHECKPOINT MANAGER",
               "Immutable, hash-verified state snapshots with explicit consistency classification.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        tk.Button(bar,text="VERIFY ALL",command=self.verify,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left",padx=5)
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def refresh(self):
        rows=self.context.services.checkpoints.list();lines=[]
        for c in rows:lines.append(f"{c.consistency:<18} {c.size_bytes:>12} B  {c.state_label:<20} {c.checkpoint_id} {c.sha256[:12]}")
        if not rows:lines=["NO CHECKPOINTS"]
        lines+=["","BYTE_ATOMIC = payload was captured and committed atomically by AEON.",
                "BACKEND_CONSISTENT may only be asserted by a backend that supplied a valid consistency barrier."]
        self.box.configure(state="normal");self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))
        self.box.configure(state="disabled");self.status.config(text=f"{len(rows)} CHECKPOINT(S)")
    def verify(self):
        rows=self.context.services.checkpoints.list();bad=[]
        for c in rows:
            ok,msg=self.context.services.checkpoints.verify(c.checkpoint_id)
            if not ok:bad.append(f"{c.checkpoint_id}: {msg}")
        self.status.config(text="ALL VERIFIED" if not bad else f"{len(bad)} FAILED",fg=TEXT if not bad else RED)

class IntegrityManagerApp(AeonApplication):
    app_id="integrity";title="Integrity"
    def build(self,parent):
        _title(parent,"DATA INTEGRITY",
               "SHA-256 verification with chunk-level CRC32 damage localization.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        tk.Button(bar,text="VERIFY ALL",command=self.verify,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left",padx=5)
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def refresh(self):
        rows=self.context.services.integrity.list();lines=[]
        for r in rows:lines.append(f"{r.object_type:<16} {r.size_bytes:>12} B  {r.object_id:<28} {r.digest[:16]}  {r.record_id}")
        if not rows:lines=["NO REGISTERED INTEGRITY RECORDS"]
        lines+=["","SHA-256 = authoritative content digest.","CRC32 = fast chunk damage localization; not corrective ECC."]
        self.box.configure(state="normal");self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))
        self.box.configure(state="disabled");self.status.config(text=f"{len(rows)} RECORD(S)")
    def verify(self):
        results=self.context.services.integrity.verify_all();bad=[r for r in results if not r.ok]
        self.status.config(text="ALL VERIFIED" if not bad else f"{len(bad)} INTEGRITY FAILURE(S)",
                           fg=TEXT if not bad else RED)

class BackupManagerApp(AeonApplication):
    app_id="backups";title="Backups"
    def build(self,parent):
        _title(parent,"TRANSACTIONAL WRITES & BACKUPS",
               "Verified atomic file replacement with immutable prior-version preservation.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        tk.Button(bar,text="VERIFY ALL",command=self.verify,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left",padx=5)
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def refresh(self):
        rows=self.context.services.transactional_files.backups();lines=[]
        for b in rows:lines.append(f"{b.size_bytes:>12} B {b.sha256[:16]} {b.backup_id} -> {b.target_path}")
        if not rows:lines=["NO BACKUPS CREATED YET"]
        lines+=["","Prior versions are preserved before replacement and verified by SHA-256.",
                "Rollback policy is intentionally deferred to P022; P021 does not auto-restore."]
        self.box.configure(state="normal");self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))
        self.box.configure(state="disabled");self.status.config(text=f"{len(rows)} BACKUP(S)")
    def verify(self):
        rows=self.context.services.transactional_files.backups();bad=[]
        for b in rows:
            ok,msg=self.context.services.transactional_files.verify_backup(b.backup_id)
            if not ok:bad.append(b)
        self.status.config(text="ALL VERIFIED" if not bad else f"{len(bad)} FAILED",fg=TEXT if not bad else RED)

class RecoveryManagerApp(AeonApplication):
    app_id="recovery";title="Recovery"
    def build(self,parent):
        _title(parent,"RECOVERY / ROLLBACK",
               "Verified recovery history. Rollback operations preserve the state they replace.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def refresh(self):
        rows=self.context.services.recovery.list();lines=[]
        for r in rows:lines.append(f"{r.status:<10} {r.recovery_id} <- {r.backup_id}  {r.restored_sha256[:16]}  {r.target_path}")
        if not rows:lines=["NO RECOVERY EVENTS"]
        lines+=["","Rollback API verifies the selected backup before replacement and the restored target afterward.",
                "The displaced current target is itself backed up first, allowing reversal of a rollback.",
                "No automatic rollback is performed solely because corruption is detected."]
        self.box.configure(state="normal");self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))
        self.box.configure(state="disabled");self.status.config(text=f"{len(rows)} RECOVERY EVENT(S)")

class NodeProtocolApp(AeonApplication):
    app_id="nodes";title="Nodes"
    def build(self,parent):
        _title(parent,"DISTRIBUTED NODE PROTOCOL",
               "Authenticated protocol foundation and persistent known-peer state.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def refresh(self):
        rows=self.context.services.nodes.list();lines=[]
        for p in rows:lines.append(f"{p.status:<10} v{p.protocol_version} {p.node_id:<28} {p.address} last={p.last_seen_unix:.3f}")
        if not rows:lines=["NO KNOWN PEERS — automatic cluster discovery begins in P024."]
        lines+=["","P023 uses length-framed authenticated JSON messages with HMAC-SHA256.",
                "Authentication/integrity does not imply encryption; transport confidentiality is a deployment layer.",
                "No remote job execution is enabled by this patch."]
        self.box.configure(state="normal");self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))
        self.box.configure(state="disabled");self.status.config(text=f"{len(rows)} KNOWN PEER(S)")

class ClusterManagerApp(AeonApplication):
    app_id="cluster";title="Cluster"
    def build(self,parent):
        _title(parent,"CLUSTER DISCOVERY & MANAGEMENT",
               "Opt-in LAN presence discovery and peer liveness. No remote execution.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        for text,cmd in (("START DISCOVERY",self.start),("STOP",self.stop),("REFRESH",self.refresh)):
            tk.Button(bar,text=text,command=cmd,bg=BG,fg=RED,activebackground=RED,
                      activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left",padx=2)
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="none");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def start(self):
        try:self.context.services.cluster.start();self.refresh()
        except Exception as exc:self.status.config(text=str(exc),fg=RED)
    def stop(self):
        self.context.services.cluster.stop();self.refresh()
    def refresh(self):
        c=self.context.services.cluster;c.refresh_liveness();rows=self.context.services.nodes.list()
        lines=[f"LOCAL NODE  {c.local.node_id}",f"HOST        {c.local.hostname}",f"DISCOVERY   {'RUNNING' if c.running else 'STOPPED'}",""]
        for p in rows:lines.append(f"{p.status:<10} {p.node_id:<38} {p.address}  last={p.last_seen_unix:.3f}")
        if not rows:lines.append("NO PEERS DISCOVERED")
        lines+=["","Discovery is explicitly opt-in and broadcasts presence on the local network.",
                "A discovered peer is not automatically authorized to execute work.",
                "Remote job execution is not enabled until P025."]
        self.box.configure(state="normal");self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines));self.box.configure(state="disabled")
        self.status.config(text=f"{len(rows)} PEER(S)")

class DistributedJobsApp(AeonApplication):
    app_id="distributed_jobs"; title="Distributed Jobs"
    def build(self,parent):
        _title(parent,"DISTRIBUTED JOB EXECUTION","Authenticated, explicitly authorized remote jobs governed by local scheduler/resource controls.")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="none")
        self.box.pack(fill="both",expand=True,padx=18,pady=18); self.refresh()
    def refresh(self):
        rows=self.context.services.distributed_jobs.list()
        lines=[f"{r.state:<12} {r.remote_job_id} node={r.node_id} local={r.local_job_id}" for r in rows]
        if not rows: lines=["NO REMOTE JOBS"]
        lines += ["","Discovery alone grants no execution authority.","Requests require authenticated P023 messages plus explicit node authorization.","Accepted work passes through P015 scheduler and P014 resource admission."]
        self.box.delete("1.0","end"); self.box.insert("1.0","\n".join(lines))

class GuardianCoreApp(AeonApplication):
    app_id="guardian";title="Guardian"
    def build(self,parent):
        _title(parent,"AEON GUARDIAN","Supervisory evidence service. Advisory intelligence is subordinate to deterministic safety authority.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",10,"bold"));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",
                         font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
        self.refresh()
    def refresh(self):
        g=self.context.services.guardian;rows=g.list(100)
        lines=["GUARDIAN CORE STATUS: "+g.status,
               "AUTHORITY: SUPERVISORY / ADVISORY — NOT FINAL SAFETY AUTHORITY",
               "P026 DOES NOT PROVIDE AN LLM OR AUTOMATIC SAFETY INTERVENTION.",""]
        for o in rows:
            conf="" if o.confidence is None else f" confidence={o.confidence:.3f}"
            lines.append(f"[{o.status}] {o.source} | {o.confidence_kind}{conf} | {o.provenance}")
            lines.append("  "+o.summary)
            for e in o.evidence: lines.append("    evidence: "+e)
        if not rows: lines.append("NO GUARDIAN OBSERVATIONS RECORDED")
        self.box.configure(state="normal");self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines));self.box.configure(state="disabled")
        self.status.config(text=g.status)

class GuardianAnomalyApp(AeonApplication):
    app_id="guardian_anomaly";title="Guardian Anomaly"
    def build(self,parent):
        _title(parent,"GUARDIAN ANOMALY DETECTION","Explicit statistical monitoring of real telemetry; anomaly does not equal diagnosis.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="REFRESH",command=self.refresh,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="",bg=PANEL,fg=MUTED,font=("Consolas",9));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word")
        self.box.pack(fill="both",expand=True,padx=18,pady=(0,18));self.refresh()
    def refresh(self):
        stream=self.context.services.telemetry_stream;det=self.context.services.guardian_anomaly
        channels=stream.channels();lines=[]
        for ch in channels:
            try:
                a=det.assess_channel(ch)
                z="n/a" if a.z_score is None else f"{a.z_score:.3f}"
                lines.append(f"{a.severity:<9} {ch:<32} latest={a.latest:g} mean={a.baseline_mean:g} z={z} n={a.sample_count}")
            except Exception as exc: lines.append(f"OBSERVING {ch:<32} {exc}")
        if not channels:lines=["NO HIGH-RATE TELEMETRY CHANNELS AVAILABLE"]
        lines+=["","Method: latest sample versus preceding-window population mean/stddev.",
                "ADVISORY |z| >= 3.0; WARNING |z| >= 4.0 by default.",
                "These are statistical deviations, not automatic hardware/data/cognitive fault diagnoses.",
                "P028 adds deterministic Guardian safety governor/interlocks."]
        self.box.configure(state="normal");self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines));self.box.configure(state="disabled")
        self.status.config(text=f"{len(channels)} CHANNEL(S)")

class SafetyKernelApp(AeonApplication):
    app_id="safety";title="Safety Kernel"
    def build(self,parent):
        _title(parent,"AEON SAFETY KERNEL","Deterministic rule authority. Guardian cannot override these interlocks.")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word")
        self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
    def refresh(self):
        k=self.context.services.safety_kernel
        lines=[f"HOLD NEW WORK: {'ACTIVE' if k.hold_new_work else 'CLEAR'}","",
               "RULES"]
        for r in k.list_rules():lines.append(f"{r.rule_id}  {r.metric} {r.operator} {r.threshold:g} -> {r.action} [{r.level}]")
        if not k.list_rules():lines.append("NO SAFETY RULES CONFIGURED")
        lines+=["","RECENT DECISIONS"]
        for d in k.decisions(50):lines.append(f"{d.level:<20} {d.metric}={d.value:g} -> {d.action} executed={d.executed}")
        if not k.decisions(50):lines.append("NO INTERLOCK DECISIONS")
        lines+=["","Only explicit deterministic rules can intervene.","AI/Guardian hypotheses cannot directly actuate this kernel."]
        self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class NeuralSafetyApp(AeonApplication):
    app_id="neural_safety";title="Neural Safety"
    def build(self,parent):
        _title(parent,"NEURAL SAFETY & GENESIS GATE","Model-specific deterministic bounds and pre-tick executable-state validation.")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word")
        self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
    def refresh(self):
        p=self.context.services.neural_safety.list()
        lines=["REGISTERED MODEL-SPECIFIC POLICIES",""]
        for x in p:lines.append(f"{x['metric']} min={x['minimum']} max={x['maximum']} -> {x['action']}")
        if not p:lines.append("NO MODEL-SPECIFIC NEURAL BOUNDS REGISTERED")
        lines+=["","GENESIS STATE VALIDATION IS ACTIVE AS A FOUNDATION SERVICE.",
                "A future executable neural runtime must present a passing GenesisResult before tick 0.",
                "Recurrent loops and self-connections are not rejected by simplistic graph rules.",
                "No universal firing-rate, voltage, or biological threshold is invented by AEON."]
        self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class IntegrationDiagnosticsApp(AeonApplication):
    app_id="integration";title="Integration"
    def build(self,parent):
        _title(parent,"AEON OS INTEGRATION DIAGNOSTICS","Cross-service foundation qualification. No synthetic PASS states.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="RUN DIAGNOSTICS",command=self.run,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="NOT RUN",bg=PANEL,fg=MUTED,font=("Consolas",10,"bold"));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word")
        self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
    def run(self):
        from .integration import IntegrationDiagnostics
        r=IntegrationDiagnostics(self.context.services,self.context.services.audit).run()
        lines=[f"REPORT {r.report_id}",f"RESULT {'PASS' if r.passed else 'FAIL'}",""]
        for c in r.checks:lines.append(f"{'PASS' if c.passed else 'FAIL':<5} {c.name:<28} {c.detail}")
        self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines));self.status.config(text="PASS" if r.passed else "FAIL")

# Compatibility surface retained for the original P003 registry contract.
from dataclasses import dataclass as _dataclass
@_dataclass(frozen=True)
class AppSpec:
    app_id:str
    title:str
    factory:object
class AppRegistry:
    def __init__(self): self._apps={}
    def register(self,spec):
        if spec.app_id in self._apps: raise ValueError(f"duplicate app: {spec.app_id}")
        self._apps[spec.app_id]=spec; return spec
    def get(self,app_id): return self._apps[app_id]
    def list(self): return tuple(self._apps[k] for k in sorted(self._apps))
    def all(self): return self.list()

class FailureQualificationApp(AeonApplication):
    app_id="qualification";title="Qualification"
    def build(self,parent):
        _title(parent,"FAILURE & RECOVERY QUALIFICATION","Destructive tests run only against disposable temporary artifacts.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="RUN QUALIFICATION",command=self.run,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="NOT RUN",bg=PANEL,fg=MUTED,font=("Consolas",10,"bold"));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word")
        self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
    def run(self):
        from .failure_qualification import FailureQualification
        r=FailureQualification(self.context.services,self.context.services.audit).run()
        lines=[f"REPORT {r.report_id}",f"RESULT {'PASS' if r.passed else 'FAIL'}",
               "SCOPE: DISPOSABLE ARTIFACTS ONLY",""]
        for c in r.cases:lines.append(f"{'PASS' if c.passed else 'FAIL':<5} {c.name:<34} {c.detail}")
        self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines));self.status.config(text="PASS" if r.passed else "FAIL")

class OSReleaseApp(AeonApplication):
    app_id="os_release";title="AEON OS 1.0"
    def build(self,parent):
        _title(parent,"AEON OS 1.0 RELEASE QUALIFICATION","Runtime release gates for the P001–P032 foundation.")
        bar=tk.Frame(parent,bg=PANEL);bar.pack(fill="x",padx=18,pady=(0,8))
        tk.Button(bar,text="RUN RELEASE GATES",command=self.run,bg=BG,fg=RED,activebackground=RED,
                  activeforeground=TEXT,relief="flat",padx=10,pady=6,font=("Segoe UI",9,"bold")).pack(side="left")
        self.status=tk.Label(bar,text="NOT RUN",bg=PANEL,fg=MUTED,font=("Consolas",10,"bold"));self.status.pack(side="right")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word")
        self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
    def run(self):
        from .os_release import OSReleaseQualifier
        r=OSReleaseQualifier(self.context.services,self.context.services.audit).run(False)
        lines=[f"AEON OS {r.version}",f"QUALIFICATION {r.qualification_id}",
               f"RESULT {'PASS' if r.passed else 'FAIL'}",""]
        for g in r.gates:lines.append(f"{'PASS' if g.passed else 'FAIL':<5} {g.name:<34} {g.detail}")
        lines+=["","P031 destructive qualification is intentionally not rerun by this button.",
                "It remains available through QUALIFY using disposable artifacts."]
        self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines));self.status.config(text="PASS" if r.passed else "FAIL")

class ApotheosisDataLabApp(AeonApplication):
    app_id="apotheosis_data_lab";title="Apotheosis Data Lab"
    def build(self,parent):
        _title(parent,"APOTHEOSIS DATA LABORATORY","Scientific datasets with explicit evidence class, provenance, and immutable-source preservation.")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word")
        self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
    def refresh(self):
        ds=self.context.services.apotheosis_data_lab.list()
        lines=["DATASET CATALOG",""]
        for d in ds:
            lines.append(f"{d.dataset_id}  {d.name}")
            lines.append(f"  evidence={d.evidence_class} provenance={d.provenance} format={d.format} bytes={d.size_bytes}")
            lines.append(f"  sha256={d.sha256}")
        if not ds:lines+=["NO APOTHEOSIS DATASETS REGISTERED","",
            "Datasets are added through the Data Lab service/API in P033.",
            "P034 adds the dedicated Dataset Importer workflow."]
        lines+=["","SIMULATION / IMPORTED / HOST / HARDWARE remain distinct evidence classes.",
                "AI reconstruction is never silently relabeled as measured source information."]
        self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class DatasetImporterApp(AeonApplication):
    app_id="dataset_importer";title="Dataset Importer"
    def build(self,parent):
        from tkinter import filedialog,messagebox
        _title(parent,"APOTHEOSIS DATASET IMPORTER","Validated scientific-source ingestion. Import never changes the source file.")
        form=tk.Frame(parent,bg=PANEL);form.pack(fill="x",padx=18,pady=(0,8))
        self.path=tk.StringVar();self.name=tk.StringVar();self.ev=tk.StringVar(value="IMPORTED");self.prov=tk.StringVar(value="MEASURED")
        for label,var in (("SOURCE",self.path),("NAME",self.name)):
            row=tk.Frame(form,bg=PANEL);row.pack(fill="x",pady=3);tk.Label(row,text=label,width=12,anchor="w",bg=PANEL,fg=MUTED).pack(side="left")
            tk.Entry(row,textvariable=var,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",fill="x",expand=True)
        row=tk.Frame(form,bg=PANEL);row.pack(fill="x",pady=3)
        tk.Label(row,text="EVIDENCE",width=12,anchor="w",bg=PANEL,fg=MUTED).pack(side="left")
        tk.OptionMenu(row,self.ev,"SIMULATION","IMPORTED","HOST","HARDWARE").pack(side="left")
        tk.Label(row,text="PROVENANCE",bg=PANEL,fg=MUTED).pack(side="left",padx=(12,4))
        tk.OptionMenu(row,self.prov,"MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN").pack(side="left")
        buttons=tk.Frame(parent,bg=PANEL);buttons.pack(fill="x",padx=18,pady=6)
        def browse():
            p=filedialog.askopenfilename()
            if p:self.path.set(p);self.name.set(self.name.get() or __import__("pathlib").Path(p).stem);preview()
        def preview():
            try:
                v=self.context.services.dataset_importer.preview(__import__("pathlib").Path(self.path.get()))
                self.box.delete("1.0","end");self.box.insert("1.0",f"FORMAT {v.format}\nBYTES {v.size_bytes}\nROWS PREVIEWED {v.rows_previewed}\nCOLUMNS {v.column_count}\nHEADERS {v.headers}\nWARNINGS {v.warnings}")
            except Exception as e:messagebox.showerror("Import preview",str(e))
        def commit():
            try:
                d=self.context.services.dataset_importer.import_file(__import__("pathlib").Path(self.path.get()),self.name.get(),self.ev.get(),self.prov.get())
                self.box.delete("1.0","end");self.box.insert("1.0",f"IMPORTED\n{d.dataset_id}\n{d.sha256}\n\nImmutable preservation completed.")
            except Exception as e:messagebox.showerror("Import failed",str(e))
        for text,cmd in (("BROWSE",browse),("PREVIEW",preview),("IMPORT",commit)):
            tk.Button(buttons,text=text,command=cmd,bg=BG,fg=RED,activebackground=RED,activeforeground=TEXT,relief="flat",padx=10,pady=6).pack(side="left",padx=(0,6))
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word")
        self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))

class ScientificVisualizationStudioApp(AeonApplication):
    app_id="scientific_visualization_studio";title="Visualization Studio"
    def build(self,parent):
        _title(parent,"SCIENTIFIC VISUALIZATION STUDIO","Dataset-backed quantitative plots. No synthetic or decorative scientific data.")
        controls=tk.Frame(parent,bg=PANEL);controls.pack(fill="x",padx=18,pady=(0,8))
        ds=self.context.services.apotheosis_data_lab.list()
        self.ds=tk.StringVar(value=ds[0].dataset_id if ds else "")
        self.x=tk.StringVar();self.y=tk.StringVar()
        for label,var in (("DATASET",self.ds),("X COLUMN",self.x),("Y COLUMN",self.y)):
            tk.Label(controls,text=label,bg=PANEL,fg=MUTED).pack(side="left",padx=(0,4))
            tk.Entry(controls,textvariable=var,width=18,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=(0,8))
        tk.Button(controls,text="COLUMNS",command=self.columns,bg=BG,fg=RED,relief="flat").pack(side="left",padx=3)
        tk.Button(controls,text="PLOT",command=self.plot,bg=BG,fg=RED,relief="flat").pack(side="left",padx=3)
        self.canvas=tk.Canvas(parent,bg=BG,highlightthickness=0);self.canvas.pack(fill="both",expand=True,padx=18,pady=(0,8))
        self.info=tk.Label(parent,text="Select a registered CSV dataset.",anchor="w",justify="left",bg=PANEL,fg=MUTED,font=("Consolas",9))
        self.info.pack(fill="x",padx=18,pady=(0,18))
    def columns(self):
        try:
            cols=self.context.services.visualization_studio.numeric_columns(self.ds.get())
            self.info.config(text="\n".join(f"{c.name}: n={c.count} min={c.minimum:g} max={c.maximum:g} mean={c.mean:g}" for c in cols) or "No numeric columns.")
        except Exception as e:self.info.config(text=f"ERROR: {e}")
    def plot(self):
        try:p=self.context.services.visualization_studio.make_plot(self.ds.get(),self.x.get(),self.y.get())
        except Exception as e:self.info.config(text=f"ERROR: {e}");return
        c=self.canvas;c.delete("all");c.update_idletasks();w=max(c.winfo_width(),300);h=max(c.winfo_height(),200);m=45
        xmin,xmax=min(p.x),max(p.x);ymin,ymax=min(p.y),max(p.y)
        xr=(xmax-xmin) or 1.0;yr=(ymax-ymin) or 1.0
        pts=[]
        for x,y in zip(p.x,p.y):
            pts.extend((m+(x-xmin)/xr*(w-2*m),h-m-(y-ymin)/yr*(h-2*m)))
        c.create_line(m,h-m,w-m,h-m,fill="#777");c.create_line(m,m,m,h-m,fill="#777")
        if len(pts)>=4:c.create_line(*pts,fill="#ff3030",width=1)
        c.create_text(w//2,h-15,text=p.x_name,fill="#aaa");c.create_text(15,h//2,text=p.y_name,fill="#aaa",angle=90)
        self.info.config(text=f"{len(p.x)} samples | evidence={p.evidence_class} | provenance={p.provenance} | dataset={p.dataset_id}")

class NeuralDatasetExplorerApp(AeonApplication):
    app_id="neural_dataset_explorer";title="Neural Dataset Explorer"
    def build(self,parent):
        _title(parent,"NEURAL DATASET EXPLORER","Neural-aware source inspection with explicit evidence and provenance boundaries.")
        row=tk.Frame(parent,bg=PANEL);row.pack(fill="x",padx=18,pady=(0,8));ds=self.context.services.apotheosis_data_lab.list()
        self.ds=tk.StringVar(value=ds[0].dataset_id if ds else "");self.role=tk.StringVar(value="OTHER")
        tk.Entry(row,textvariable=self.ds,width=34,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=6)
        tk.OptionMenu(row,self.role,"NEURON","EDGE","SYNAPSE","TRACE","VOLUME","CELL","MOLECULAR","GLIAL","DYNAMIC","OTHER").pack(side="left",padx=6)
        tk.Button(row,text="PROFILE",command=self.profile,bg=BG,fg=RED,relief="flat").pack(side="left")
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
    def profile(self):
        try:p=self.context.services.neural_dataset_explorer.profile(self.ds.get(),self.role.get())
        except Exception as e:self.box.delete("1.0","end");self.box.insert("1.0",f"ERROR: {e}");return
        lines=[f"DATASET {p.dataset_id}",f"ROLE {p.role}",f"EVIDENCE {p.evidence_class}",f"PROVENANCE {p.provenance}",f"FORMAT {p.format}",f"RECORDS {p.records_examined}","",f"FIELDS {', '.join(p.fields)}",f"NUMERIC {', '.join(p.numeric_fields)}","","MISSING"]+[f"  {k}: {v}" for k,v in p.missing_counts]+["","Role is operator-supplied; AEON does not infer biological meaning from column names."]
        self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class ExperimentLaboratoryApp(AeonApplication):
    app_id="experiment_laboratory";title="Experiment Laboratory"
    def build(self,parent):
        _title(parent,"EXPERIMENT LABORATORY","Persistent scientific experiment definitions. DEFINED does not mean EXECUTED.")
        row=tk.Frame(parent,bg=PANEL);row.pack(fill="x",padx=18,pady=(0,8))
        self.name=tk.StringVar();self.mode=tk.StringVar(value="SIMULATION");self.datasets=tk.StringVar()
        for label,var,width in (("NAME",self.name,22),("DATASET IDS",self.datasets,32)):
            tk.Label(row,text=label,bg=PANEL,fg=MUTED).pack(side="left",padx=(0,4));tk.Entry(row,textvariable=var,width=width,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=(0,8))
        tk.OptionMenu(row,self.mode,"SIMULATION","IMPORTED","HOST","HARDWARE").pack(side="left")
        tk.Button(row,text="DEFINE",command=self.define,bg=BG,fg=RED,relief="flat").pack(side="left",padx=6)
        self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18));self.refresh()
    def define(self):
        try:
            ids=tuple(x.strip() for x in self.datasets.get().split(",") if x.strip())
            self.context.services.experiment_laboratory.define(self.name.get(),self.mode.get(),ids)
            self.refresh()
        except Exception as e:self.box.delete("1.0","end");self.box.insert("1.0",f"ERROR: {e}")
    def refresh(self):
        rows=self.context.services.experiment_laboratory.list()
        lines=["EXPERIMENT DEFINITIONS",""]
        for e in rows:lines += [f"{e.experiment_id}  {e.name}",f"  {e.status} | evidence={e.evidence_mode} | datasets={len(e.dataset_ids)}",f"  definition={e.definition_sha256}",""]
        if not rows:lines.append("NO EXPERIMENT DEFINITIONS")
        lines += ["","Definitions are auditable plans, not evidence that execution or measurement occurred."]
        self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class StatisticalUncertaintyAnalysisApp(AeonApplication):
 app_id="statistical_uncertainty";title="Statistics & Uncertainty"
 def build(self,parent):
  _title(parent,"STATISTICAL & UNCERTAINTY ANALYSIS","Quantitative summaries and explicit uncertainty; assumptions remain visible.")
  row=tk.Frame(parent,bg=PANEL);row.pack(fill="x",padx=18,pady=(0,8));ds=self.context.services.apotheosis_data_lab.list();self.ds=tk.StringVar(value=ds[0].dataset_id if ds else "");self.field=tk.StringVar()
  tk.Entry(row,textvariable=self.ds,width=34,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=4);tk.Entry(row,textvariable=self.field,width=20,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=4);tk.Button(row,text="SUMMARIZE",command=self.run,bg=BG,fg=RED,relief="flat").pack(side="left",padx=4)
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
 def run(self):
  try:s=self.context.services.statistical_uncertainty.summarize(self.ds.get(),self.field.get())
  except Exception as e:self.box.delete("1.0","end");self.box.insert("1.0",f"ERROR: {e}");return
  lines=[f"DATASET {s.dataset_id}",f"FIELD {s.field}",f"N {s.n}",f"MEAN {s.mean:.12g}",f"MEDIAN {s.median:.12g}",f"STDDEV {s.stddev}",f"STANDARD ERROR {s.standard_error}",f"MIN {s.minimum:.12g}",f"MAX {s.maximum:.12g}","",f"EVIDENCE {s.evidence_class}",f"PROVENANCE {s.provenance}","","Standard error is not automatically measurement uncertainty."]
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class ModelComparisonLaboratoryApp(AeonApplication):
 app_id="model_comparison_laboratory";title="Model Comparison Laboratory"
 def build(self,parent):
  _title(parent,"MODEL COMPARISON LABORATORY","Quantitative residual metrics without automatic scientific verdicts.")
  row=tk.Frame(parent,bg=PANEL);row.pack(fill="x",padx=18,pady=(0,8));ds=self.context.services.apotheosis_data_lab.list()
  self.ds=tk.StringVar(value=ds[0].dataset_id if ds else "");self.obs=tk.StringVar();self.pred=tk.StringVar()
  for var,w in ((self.ds,30),(self.obs,18),(self.pred,18)):tk.Entry(row,textvariable=var,width=w,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=4)
  tk.Button(row,text="EVALUATE",command=self.run,bg=BG,fg=RED,relief="flat").pack(side="left",padx=4)
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18))
 def run(self):
  try:q=self.context.services.model_comparison_laboratory.evaluate(self.ds.get(),self.obs.get(),self.pred.get())
  except Exception as e:self.box.delete("1.0","end");self.box.insert("1.0",f"ERROR: {e}");return
  lines=[f"DATASET {q.dataset_id}",f"OBSERVED {q.observed_field}",f"PREDICTED {q.predicted_field}",f"N {q.n}",f"MAE {q.mae:.12g}",f"RMSE {q.rmse:.12g}",f"MEAN ERROR {q.mean_error:.12g}",f"CORRELATION {q.correlation if q.correlation is not None else 'UNAVAILABLE'}","",f"EVIDENCE {q.evidence_class}",f"PROVENANCE {q.provenance}","","These metrics describe fit to selected observations; they do not establish model truth or cognitive equivalence."]
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class ProvenanceReproducibilityStudioApp(AeonApplication):
 app_id="provenance_reproducibility";title="Provenance & Reproducibility"
 def build(self,parent):
  _title(parent,"PROVENANCE & REPRODUCIBILITY STUDIO","Experiment definitions, dataset hashes, software/environment and reproducibility claims.")
  row=tk.Frame(parent,bg=PANEL);row.pack(fill="x",padx=18,pady=(0,8));ex=self.context.services.experiment_laboratory.list()
  self.exp=tk.StringVar(value=ex[0].experiment_id if ex else "");self.level=tk.StringVar(value="NON-DETERMINISTIC")
  tk.Entry(row,textvariable=self.exp,width=36,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=4)
  tk.OptionMenu(row,self.level,"BIT-EXACT","NUMERICALLY-REPRODUCIBLE","BEHAVIORALLY-REPRODUCIBLE","NON-DETERMINISTIC").pack(side="left",padx=4)
  tk.Button(row,text="CAPTURE",command=self.capture,bg=BG,fg=RED,relief="flat").pack(side="left",padx=4)
  tk.Button(row,text="VERIFY",command=self.verify_latest,bg=BG,fg=RED,relief="flat").pack(side="left",padx=4)
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18));self.refresh()
 def capture(self):
  try:self.context.services.provenance_reproducibility.capture(self.exp.get(),self.level.get(),software={"aeon_version":__import__("aeon").__version__})
  except Exception as e:self.box.delete("1.0","end");self.box.insert("1.0",f"ERROR: {e}");return
  self.refresh()
 def verify_latest(self):
  rows=self.context.services.provenance_reproducibility.list()
  if not rows:self.box.delete("1.0","end");self.box.insert("1.0","NO REPRODUCIBILITY RECORDS");return
  q=rows[0];v=self.context.services.provenance_reproducibility.verify(q.record_id);self.box.delete("1.0","end");self.box.insert("1.0",f"{q.record_id}\n{v}")
 def refresh(self):
  rows=self.context.services.provenance_reproducibility.list();lines=["REPRODUCIBILITY RECORDS",""]
  for q in rows:lines += [f"{q.record_id}",f"  experiment={q.experiment_id}",f"  level={q.level}",f"  definition={q.definition_sha256}",f"  manifest={q.record_sha256}",""]
  lines += ["","A declared reproducibility level is metadata to be verified by replay/qualification; capture alone does not prove the claim."]
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class NeuroimagingIngestionApp(AeonApplication):
 app_id="neuroimaging_ingestion";title="Neuroimaging Ingestion"
 def build(self,parent):
  _title(parent,"COGNITIVE INJECTION — NEUROIMAGING INGESTION","Register preserved imaging datasets without inventing acquisition facts.")
  row=tk.Frame(parent,bg=PANEL);row.pack(fill="x",padx=18,pady=(0,8));ds=self.context.services.apotheosis_data_lab.list()
  self.ds=tk.StringVar(value=ds[0].dataset_id if ds else "");self.mod=tk.StringVar(value="OTHER");self.prep=tk.StringVar()
  tk.Entry(row,textvariable=self.ds,width=30,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=3)
  tk.OptionMenu(row,self.mod,"MRI","FMRI","DTI","DWI","CT","PET","SPECT","EM","SEM","TEM","LIGHT-MICROSCOPY","TWO-PHOTON","CALCIUM-IMAGING","OTHER").pack(side="left",padx=3)
  tk.Entry(row,textvariable=self.prep,width=22,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=3)
  tk.Button(row,text="REGISTER",command=self.register,bg=BG,fg=RED,relief="flat").pack(side="left",padx=3)
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18));self.refresh()
 def register(self):
  try:self.context.services.neuroimaging_ingestion.register(self.ds.get(),self.mod.get(),preparation=self.prep.get())
  except Exception as e:self.box.delete("1.0","end");self.box.insert("1.0",f"ERROR: {e}");return
  self.refresh()
 def refresh(self):
  rows=self.context.services.neuroimaging_ingestion.list();lines=["NEUROIMAGING RECORDS",""]
  for q in rows:
   c=self.context.services.neuroimaging_ingestion.completeness(q.imaging_id);lines += [f"{q.imaging_id}  {q.modality}",f"  dataset={q.dataset_id}",f"  source={q.source_sha256}",f"  missing metadata={', '.join(c['missing']) if c['missing'] else 'none'}",""]
  lines += ["","Missing acquisition facts remain UNKNOWN. Registration does not establish information sufficiency for mind reconstruction."]
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class VolumeReconstructionApp(AeonApplication):
 app_id="volume_reconstruction";title="Volume Reconstruction"
 def build(self,parent):
  _title(parent,"COGNITIVE INJECTION — VOLUME RECONSTRUCTION","Define source-bound volume geometry and transformations without fabricating image content.")
  row=tk.Frame(parent,bg=PANEL);row.pack(fill="x",padx=18,pady=(0,8));imgs=self.context.services.neuroimaging_ingestion.list()
  self.img=tk.StringVar(value=imgs[0].imaging_id if imgs else "");self.shape=tk.StringVar(value="1,1,1");self.frame=tk.StringVar(value="SOURCE")
  for var,w in ((self.img,30),(self.shape,14),(self.frame,16)):tk.Entry(row,textvariable=var,width=w,bg=BG,fg=TEXT,insertbackground=RED,relief="flat").pack(side="left",padx=3)
  tk.Button(row,text="DEFINE",command=self.define,bg=BG,fg=RED,relief="flat").pack(side="left",padx=3)
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=(0,18));self.refresh()
 def define(self):
  try:
   shape=tuple(int(x.strip()) for x in self.shape.get().split(","))
   img=self.context.services.neuroimaging_ingestion.get(self.img.get())
   voxel=img.resolution if img.resolution else {"declared_unitless":1.0}
   self.context.services.volume_reconstruction.define(self.img.get(),shape,voxel,self.frame.get(),known_losses=img.known_losses)
  except Exception as e:self.box.delete("1.0","end");self.box.insert("1.0",f"ERROR: {e}");return
  self.refresh()
 def refresh(self):
  rows=self.context.services.volume_reconstruction.list();lines=["VOLUME DEFINITIONS",""]
  for q in rows:lines += [f"{q.volume_id}",f"  source={q.imaging_id} dataset={q.dataset_id}",f"  shape={q.shape} voxel={q.voxel_size}",f"  frame={q.coordinate_frame} provenance={q.provenance}",f"  definition={q.definition_sha256}",""]
  lines += ["","A volume definition records reconstruction geometry. It does not imply missing biological state was measured or recovered."]
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class NeuronSegmentationApp(AeonApplication):
 app_id="neuron_segmentation";title="Neuron Segmentation"
 def build(self,parent):
  _title(parent,"COGNITIVE INJECTION — NEURON SEGMENTATION","Register source-bound candidate cellular segments with explicit confidence and provenance.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.neuron_segmentation.list();lines=["SEGMENTATION RECORDS",""]
  for q in rows:
   s=self.context.services.neuron_segmentation.summary(q.segmentation_id);lines += [f"{q.segmentation_id}",f"  volume={q.volume_id}",f"  method={q.method} {q.method_version}",f"  segments={s['segments']} voxels={s['voxels']}",f"  mean confidence={s['mean_confidence'] if s['mean_confidence'] is not None else 'UNKNOWN'}",f"  {s['note']}",""]
  if not rows:lines.append("NO SEGMENTATION RECORDS — use the service/API to register actual algorithm outputs.")
  lines += ["","AEON does not generate synthetic segmentation masks or call every segmented object a neuron."]
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class NeuriteTracingApp(AeonApplication):
 app_id="neurite_tracing";title="Axon / Dendrite Tracing"
 def build(self,parent):
  _title(parent,"COGNITIVE INJECTION — AXON / DENDRITE TRACING","Source-bound neurite topology with explicit uncertainty and provenance.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.neurite_tracing.list();lines=["NEURITE TRACES",""]
  for q in rows:
   s=self.context.services.neurite_tracing.summary(q.trace_id);lines += [f"{q.trace_id}",f"  segment={q.segment_id} segmentation={q.segmentation_id}",f"  method={q.method} {q.method_version}",f"  nodes={s['nodes']} edges={s['edges']} self-edges={s['self_edges']}",f"  {s['note']}",""]
  if not rows:lines.append("NO TRACE RECORDS — ingest actual tracing outputs through the service/API.")
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class SynapseDetectionApp(AeonApplication):
 app_id="synapse_detection";title="Synapse Detection"
 def build(self,parent):
  _title(parent,"COGNITIVE INJECTION — SYNAPSE DETECTION","Candidate synaptic contacts with explicit source binding, confidence and provenance.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.synapse_detection.list();lines=["SYNAPSE DETECTION RECORDS",""]
  for q in rows:
   s=self.context.services.synapse_detection.summary(q.detection_id);lines += [f"{q.detection_id}",f"  method={q.method} {q.method_version}",f"  candidates={s['candidates']} chemical={s['chemical']} electrical={s['electrical']} unknown={s['unknown_kind']}",f"  {s['note']}",""]
  if not rows:lines.append("NO SYNAPSE DETECTIONS — ingest actual detector/manual-review outputs through the service/API.")
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class CellClassificationApp(AeonApplication):
 app_id="cell_classification";title="Cell Classification"
 def build(self,parent):
  _title(parent,"COGNITIVE INJECTION — CELL CLASSIFICATION","Evidence-bearing classifications remain hypotheses unless their provenance/evidence supports stronger claims.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.cell_classification.list();lines=["CELL CLASSIFICATIONS",""]
  for q in rows:lines += [f"{q.classification_id}",f"  segment={q.segment_id}  {q.taxonomy}:{q.cell_type}{('/'+q.subtype) if q.subtype else ''}",f"  provenance={q.provenance} confidence={q.confidence if q.confidence is not None else 'UNKNOWN'}",f"  method={q.method} {q.method_version} evidence-items={len(q.evidence)}",""]
  if not rows:lines.append("NO CELL CLASSIFICATIONS — classifications are created only from explicit operator/algorithm outputs.")
  lines += ["","AEON does not infer cell identity from a segment label or geometry alone."]
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class ConnectomeReconstructionApp(AeonApplication):
 app_id="connectome_reconstruction";title="Connectome Reconstruction"
 def build(self,parent):
  _title(parent,"COGNITIVE INJECTION — CONNECTOME RECONSTRUCTION","Auditable structural graph assembled only from explicit upstream reconstruction records.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.connectome_reconstruction.list();lines=["CONNECTOMES",""]
  for q in rows:
   s=self.context.services.connectome_reconstruction.summary(q.connectome_id);lines += [f"{q.connectome_id}  {q.name}",f"  nodes={s['nodes']} edges={s['edges']} partial={s['partial_edges']}",f"  sha256={q.definition_sha256}",f"  {s['note']}",""]
  if not rows:lines.append("NO CONNECTOMES — reconstruction requires explicit segment nodes and synapse-detection records.")
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class CognitiveInjectionWorkbenchApp(AeonApplication):
 app_id="cognitive_injection_workbench";title="Cognitive Injection"
 def build(self,parent):
  _title(parent,"COGNITIVE-INJECTION PROTOCOL — WORKBENCH 1.0","Unified P041-P047 reconstruction workflow with integrity and epistemic boundaries.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.cognitive_injection_workbench.list();lines=["COGNITIVE INJECTION CASES",""]
  for q in rows:
   s=self.context.services.cognitive_injection_workbench.status(q.case_id)
   lines += [f"{q.case_id}  {q.name}",f"  stages={s['completed_stages']}/{s['total_stages']} integrity={s['integrity']['all_ok']}",f"  information sufficiency={s['information_sufficiency']}",f"  {s['note']}",""]
  if not rows:lines.append("NO WORKBENCH CASES — create a case from explicit P041-P047 records through the service/API.")
  lines += ["","AEON does not convert pipeline completion into a claim of consciousness capture, identity continuity, or upload feasibility."]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class ANISpecificationApp(AeonApplication):
 app_id="ani_specification";title="ANI Specification"
 def build(self,parent):
  _title(parent,"APOTHEOSIS NEURAL IMAGE — SPECIFICATION","Versioned neural-state schema with explicit provenance, uncertainty and unmeasured domains.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.ani_specification.list();lines=["ANI SPECIFICATIONS",""]
  for q in rows:
   c=self.context.services.ani_specification.completeness(q.ani_spec_id)
   lines += [f"{q.ani_spec_id}  {q.name}",f"  schema={q.schema_name} {q.schema_version} fields={len(q.fields)}",f"  represented={', '.join(c['represented_domains']) or 'NONE'}",f"  unmeasured={', '.join(c['explicitly_unmeasured']) or 'NOT DECLARED'}",f"  information sufficiency={c['information_sufficiency']}",f"  {c['note']}",""]
  if not rows:lines.append("NO ANI SPECIFICATIONS — create an explicit schema through the service/API.")
  lines += ["","ANI specification is a data contract, not an executable mind or consciousness claim."]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class ANITopologyApp(AeonApplication):
 app_id="ani_topology";title="ANI Topology"
 def build(self,parent):
  _title(parent,"APOTHEOSIS NEURAL IMAGE — TOPOLOGY","Formal source-bound neural graph; topology constraints remain model-aware.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.ani_topology.list();lines=["ANI TOPOLOGIES",""]
  for q in rows:
   s=self.context.services.ani_topology.summary(q.topology_id);lines += [f"{q.topology_id}",f"  model={s['model_family']} nodes={s['nodes']} edges={s['edges']}",f"  partial={s['partial_edges']} self-edges={s['self_edges']}",f"  sha256={q.definition_sha256}",f"  {s['note']}",""]
  if not rows:lines.append("NO ANI TOPOLOGIES — create one from a verified ANI specification and connectome.")
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class ANISynapticStateApp(AeonApplication):
 app_id="ani_synaptic_state";title="ANI Synaptic State"
 def build(self,parent):
  _title(parent,"APOTHEOSIS NEURAL IMAGE — SYNAPTIC STATE","Explicit functional synaptic parameters with provenance, uncertainty and missing-state declarations.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.ani_synaptic_state.list();lines=["ANI SYNAPTIC STATES",""]
  for q in rows:
   s=self.context.services.ani_synaptic_state.summary(q.synaptic_state_id);lines += [f"{q.synaptic_state_id}",f"  topology={q.topology_id} model={q.model_family}",f"  parameters={s['parameters']} explicitly-unmeasured={s['explicitly_unmeasured']}",f"  {s['note']}",""]
  if not rows:lines.append("NO ANI SYNAPTIC STATES — populate only parameters supported by explicit evidence/reconstruction.")
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class ANIDynamicStateApp(AeonApplication):
 app_id="ani_dynamic_state";title="ANI Dynamic State"
 def build(self,parent):
  _title(parent,"APOTHEOSIS NEURAL IMAGE — DYNAMIC STATE","Time-dependent neural state with measured, inferred and initialized values kept distinct.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.ani_dynamic_state.list();lines=["ANI DYNAMIC STATES",""]
  for q in rows:
   s=self.context.services.ani_dynamic_state.summary(q.dynamic_state_id);lines += [f"{q.dynamic_state_id}",f"  topology={q.topology_id} variables={s['variables']} unmeasured={s['explicitly_unmeasured']}",f"  measured={s['measured']} inferred/AI={s['initialized_or_inferred']}",f"  init-policy={q.initialization_policy}",f"  {s['note']}",""]
  if not rows:lines.append("NO ANI DYNAMIC STATES — dynamic values must be explicitly supplied with provenance.")
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class ANIReconstructionMetadataApp(AeonApplication):
 app_id="ani_reconstruction_metadata";title="ANI Uncertainty"
 def build(self,parent):
  _title(parent,"APOTHEOSIS NEURAL IMAGE — UNCERTAINTY & RECONSTRUCTION","Auditable reconstruction claims, confidence, uncertainty, methods, assumptions and unresolved unknowns.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.ani_reconstruction_metadata.list();lines=["ANI RECONSTRUCTION METADATA",""]
  for q in rows:
   s=self.context.services.ani_reconstruction_metadata.summary(q.metadata_id);lines += [f"{q.metadata_id}",f"  claims={s['claims']} unknowns={s['unknowns']}",f"  provenance={s['provenance_counts']}",f"  information sufficiency={s['information_sufficiency']}",f"  {s['note']}",""]
  if not rows:lines.append("NO ANI RECONSTRUCTION METADATA — claims must be explicitly created with provenance.")
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class ANIManagerApp(AeonApplication):
 app_id="ani_manager";title="ANI Manager"
 def build(self,parent):
  _title(parent,"APOTHEOSIS NEURAL IMAGE — MANAGER 1.0","Integrity-bound ANI manifests. Assembly never implies information sufficiency or permission to execute.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.ani_manager.list();lines=["APOTHEOSIS NEURAL IMAGES",""]
  for q in rows:
   r=self.context.services.ani_manager.readiness(q.ani_id);lines += [f"{q.ani_id}  {q.name}",f"  status={q.status} integrity={r['integrity']['all_ok']}",f"  synaptic={r['has_synaptic_state']} dynamic={r['has_dynamic_state']} metadata={r['has_reconstruction_metadata']}",f"  information sufficiency={r['information_sufficiency']} genesis={r['genesis_status']} executable={r['executable']}",f"  {r['note']}",""]
  if not rows:lines.append("NO ANI IMAGES — assemble only from verified P049-P053 components.")
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class NeuronSimulationApp(AeonApplication):
 app_id="neuron_simulation";title="Neuron Engine"
 def build(self,parent):
  _title(parent,"NEURAL SIMULACRUM — NEURON SIMULATION ENGINE","Deterministic mathematical neuron stepping; ANI execution remains locked behind later runtime/Genesis integration.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.neuron_simulation.summary();lines=["NEURON SIMULATION ENGINE",f"models={s['models']} states={s['states']}",f"supported={', '.join(s['supported_models'])}","",s["note"]]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class SynapseEngineApp(AeonApplication):
 app_id="synapse_engine";title="Synapse Engine"
 def build(self,parent):
  _title(parent,"NEURAL SIMULACRUM — SYNAPSE ENGINE","Deterministic event delivery and synaptic-current dynamics from explicit model parameters.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.synapse_engine.summary();lines=["SYNAPSE ENGINE",f"models={s['models']} states={s['states']}",f"supported={', '.join(s['supported_models'])}","",s["note"]]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class SNNEngineApp(AeonApplication):
 app_id="snn_engine";title="SNN Engine"
 def build(self,parent):
  _title(parent,"NEURAL SIMULACRUM — SNN ENGINE","Deterministic CPU spiking-network coordinator using explicit neuron and synapse models.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.snn_engine.summary();lines=["SPIKING NEURAL NETWORK ENGINE",f"networks={s['networks']} backend={s['backend']}","",s["note"]]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class NeuralClockApp(AeonApplication):
 app_id="neural_clock";title="Neural Clock"
 def build(self,parent):
  _title(parent,"NEURAL SIMULACRUM — NEURAL CLOCK","Explicit model/run timebase and synchronization checks; no universal neural timestep.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.neural_clock.summary();lines=["NEURAL CLOCK",f"clocks={s['clocks']} modes={', '.join(s['modes'])}","",s["note"]]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class NeuralPartitionApp(AeonApplication):
 app_id="neural_partition";title="Neural Partition"
 def build(self,parent):
  _title(parent,"NEURAL SIMULACRUM — GRAPH PARTITIONING","Deterministic logical SNN partition plans with explicit cross-partition edge accounting.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  rows=self.context.services.neural_partition.list();lines=["NEURAL PARTITION PLANS",""]
  for q in rows:
   d=self.context.services.neural_partition.describe(q.plan_id);lines += [f"{q.plan_id}",f"  network={q.network_id} strategy={d['strategy']}",f"  sizes={d['partition_sizes']} cut_edges={d['cut_edges']}",""]
  if not rows:lines.append("NO PARTITION PLANS")
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class GPUExecutionApp(AeonApplication):
 app_id="gpu_execution";title="GPU Execution"
 def build(self,parent):
  _title(parent,"NEURAL SIMULACRUM — GPU EXECUTION","Detected accelerator execution with explicit backend/device reporting and CPU fallback.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.gpu_execution.summary();lines=["GPU EXECUTION",f"preferred={s['preferred_backend']} device={s['preferred_device']}",""]
  for b in s["backends"]:lines.append(f"{b[0]} | {b[1]} | available={b[2]} | {b[3]}")
  lines += ["",s["note"]];self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class DistributedNeuralApp(AeonApplication):
 app_id="distributed_neural";title="Distributed Neural"
 def build(self,parent):
  _title(parent,"NEURAL SIMULACRUM — DISTRIBUTED EXECUTION","Partition assignment and synchronization control without overstating transport/security maturity.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.distributed_neural.summary();lines=["DISTRIBUTED NEURAL EXECUTION",f"runs={s['runs']}",f"transport={s['transport']}","",s["note"]]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class NeuralSimulacrumApp(AeonApplication):
 app_id="neural_simulacrum";title="Neural Simulacrum 1.0"
 def build(self,parent):
  _title(parent,"NEURAL SIMULACRUM 1.0","Integrated mathematical neural runtime — neuron, synapse, SNN, clock, partition, accelerator and distributed coordination layers.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.neural_simulacrum.summary();lines=[s["release"],f"runtimes={s['runtimes']}","",s["note"]]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class CognitiveAnomalyApp(AeonApplication):
 app_id="cognitive_anomaly";title="Cognitive Anomaly"
 def build(self,parent):
  _title(parent,"COGNITIVE GUARDIAN — ANOMALY DETECTOR","Provenance-aware, non-mutating anomaly analytics for neural/cognitive telemetry.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.cognitive_anomaly.summary();lines=["COGNITIVE ANOMALY DETECTOR",f"observations={s['observations']} anomalies={s['anomalies']}",f"method={s['method']}","",s["note"]]
  for a in self.context.services.cognitive_anomaly.list_anomalies(20):lines += ["",f"{a.severity} {a.metric} score={a.score:.4g} confidence={a.confidence:.3f}",f"  {a.anomaly_id}"]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class CognitiveStateComparatorApp(AeonApplication):
 app_id="cognitive_state_comparator";title="Cognitive State Comparator"
 def build(self,parent):
  _title(parent,"COGNITIVE GUARDIAN — STATE COMPARATOR","Quantified state differences with provenance, confidence, missing-variable and unit-compatibility accounting.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.cognitive_state_comparator.summary();lines=["COGNITIVE STATE COMPARATOR",f"states={s['states']} comparisons={s['comparisons']}",f"metrics={', '.join(s['metrics'])}","",s["note"]]
  for c in self.context.services.cognitive_state_comparator.list_comparisons(20):lines += ["",f"{c.comparison_id}",f"  comparable={c.metrics['comparable_count']} MAE={c.metrics['mae']} RMSE={c.metrics['rmse']}"]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class ReconstructionConfidenceApp(AeonApplication):
 app_id="reconstruction_confidence";title="Reconstruction Confidence"
 def build(self,parent):
  _title(parent,"COGNITIVE GUARDIAN — RECONSTRUCTION CONFIDENCE","Evidence-quality assessment without converting inferred reconstruction into measured source information.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.reconstruction_confidence.summary();lines=["RECONSTRUCTION CONFIDENCE",f"assessments={s['assessments']}",f"information_sufficiency={s['information_sufficiency']}","",s["note"]]
  for a in self.context.services.reconstruction_confidence.list(20):
   lines += ["",f"{a.assessment_id}",f"  claims={a.claim_count} unknowns={a.unknown_count} mean_confidence={a.confidence_stats['mean']}",f"  provenance={a.provenance_counts}"]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class CandidateReconstructionApp(AeonApplication):
 app_id="candidate_reconstruction";title="Candidate Reconstruction"
 def build(self,parent):
  _title(parent,"COGNITIVE GUARDIAN — CANDIDATE RECONSTRUCTION","Explicit reconstruction hypotheses with immutable inferred/AI-reconstructed provenance.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.candidate_reconstruction.summary();lines=["CANDIDATE RECONSTRUCTION",f"candidates={s['candidates']}",f"allowed provenance={', '.join(s['allowed_provenance'])}","",s["note"]]
  for c in self.context.services.candidate_reconstruction.list(20):lines += ["",f"{c.name} [{c.status}] {c.candidate_id}",f"  values={len(c.values)} source={c.metadata_id}"]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class CognitiveDivergenceApp(AeonApplication):
 app_id="cognitive_divergence";title="Cognitive Divergence"
 def build(self,parent):
  _title(parent,"COGNITIVE GUARDIAN — DIVERGENCE","Time-indexed numerical divergence from explicit reference states; descriptive, not an identity test.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.cognitive_divergence.summary();lines=["COGNITIVE DIVERGENCE",f"samples={s['samples']}","",s["note"]]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class CognitiveGuardianApp(AeonApplication):
 app_id="cognitive_guardian";title="Cognitive Guardian 1.0"
 def build(self,parent):
  _title(parent,"COGNITIVE GUARDIAN 1.0","Integrated cognitive-state analytics under deterministic AEON safety authority.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  s=self.context.services.cognitive_guardian.summary()
  lines=[s["release"],f"cases={s['cases']} open={s['open_cases']}","", "CAPABILITIES"]+[f"  {x}" for x in s["capabilities"]]+["",s["note"]]
  for c in self.context.services.cognitive_guardian.list_cases(20):lines += ["",f"{c.name} [{c.status}] {c.case_id}"]
  self.box.delete("1.0","end");self.box.insert("1.0","\\n".join(lines))

class ComputeNodeServerApp(AeonApplication):
 app_id="compute_node_server";title="Compute Node Server"
 def build(self,parent):
  _title(parent,"EXA-EXECUTION — COMPUTE NODE SERVER","Authenticated bounded node-control protocol; arbitrary command execution is not exposed.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  box.insert("1.0","P069 COMPUTE NODE SERVER\n\nAllowed operations: PING / CAPABILITIES / STATUS\nAuthentication: HMAC-SHA256\nFreshness + nonce replay rejection: ENABLED\nArbitrary argv/shell execution: DISABLED\n\nP069 establishes a bounded node endpoint. TLS/key-management and high-speed data transport remain later qualification work.")

class DistributedTransportApp(AeonApplication):
 app_id="distributed_transport";title="Distributed Transport"
 def build(self,parent):
  _title(parent,"EXA-EXECUTION — DISTRIBUTED TRANSPORT","Authenticated chunked binary data plane with end-to-end SHA-256 verification.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  box.insert("1.0","P070 HIGH-SPEED DISTRIBUTED TRANSPORT\n\nChunked binary TCP: ENABLED\nHMAC-SHA256 header authentication: ENABLED\nNonce/freshness replay protection: ENABLED\nPayload SHA-256 verification: ENABLED\nBounded transfer/header/chunk sizes: ENABLED\nPayload execution: DISABLED\n\nTLS and production key management are not claimed by P070.")

class ExaGraphPartitionerApp(AeonApplication):
 app_id="exa_graph_partitioner";title="Exa Graph Partitioner"
 def build(self,parent):
  _title(parent,"EXA-EXECUTION — NEURAL GRAPH PARTITIONER","Deterministic resource-weighted neural placement bound to verified network signatures.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.exa_graph_partitioner.summary();box.insert("1.0",f"P071 NEURAL GRAPH PARTITIONER\\n\\nplans={s['plans']}\\nstrategy={s['strategy']}\\n\\n{s['note']}")

class DistributedCheckpointApp(AeonApplication):
 app_id="exa_distributed_checkpoint";title="Distributed Checkpoint"
 def build(self,parent):
  _title(parent,"EXA-EXECUTION — DISTRIBUTED CHECKPOINT","Consistent-instant checkpoint manifests across distributed neural nodes.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.exa_distributed_checkpoint.summary();box.insert("1.0",f"P072 DISTRIBUTED CHECKPOINT\n\ncheckpoints={s['checkpoints']}\n\n{s['note']}")

class ExaClusterControlApp(AeonApplication):
 app_id="exa_cluster_control";title="Exa Cluster Control"
 def build(self,parent):
  _title(parent,"EXA-EXECUTION — CLUSTER VISUALIZATION & CONTROL","Persistent node health, placement/checkpoint overview, and bounded hold/release controls.")
  self.box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");self.box.pack(fill="both",expand=True,padx=18,pady=18);self.refresh()
 def refresh(self):
  d=self.context.services.exa_cluster_control.dashboard(self.context.services.exa_graph_partitioner,self.context.services.exa_distributed_checkpoint)
  lines=["P073 CLUSTER VISUALIZATION & CONTROL",f"nodes={d['nodes']} partition_plans={d['partition_plans']} distributed_checkpoints={d['distributed_checkpoints']}",f"status={d['status_counts']}","",f"arbitrary_remote_execution={d['arbitrary_remote_execution']}"]
  for n in d["records"]:lines+=["",f"{n['node_id']} [{n['status']}]",f"  {n['host']} control={n['control_port']} transport={n['transport_port']}"]
  self.box.delete("1.0","end");self.box.insert("1.0","\n".join(lines))

class ExaExecutionEngineApp(AeonApplication):
 app_id="exa_execution_engine";title="Exa-Execution Engine 1.0"
 def build(self,parent):
  _title(parent,"EXA-EXECUTION ENGINE 1.0","Integrated bounded control, transport, placement, checkpoint and cluster coordination.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.exa_execution_engine.summary()
  box.insert("1.0",f"P074 EXA-EXECUTION ENGINE 1.0\n\nruns={s['runs']} active={s['active']}\n\nControl: P069 authenticated bounded node protocol\nTransport: P070 verified chunked binary data plane\nPlacement: P071 resource-aware neural graph partitioning\nCheckpoint: P072 consistent-instant manifests\nCluster: P073 persistent visualization/control\n\nProduction security qualification: NOT YET CLAIMED\nDeterministic Safety Kernel remains authoritative.")

class NeuralCacheVirtualDeviceApp(AeonApplication):
 app_id="neural_cache_virtual_device";title="Neural Cache Virtual Device"
 def build(self,parent):
  _title(parent,"NEURAL CACHE — VIRTUAL DEVICE","Host-filesystem-backed capacity and lifecycle abstraction for future Neural Cache storage.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.neural_cache_virtual_device.summary();box.insert("1.0",f"P075 NEURAL CACHE VIRTUAL DEVICE\\n\\ndevices={s['devices']}\\nlogical_capacity_bytes={s['logical_capacity_bytes']}\\nreserved_bytes={s['reserved_bytes']}\\n\\n{s['note']}")

class NeuralCacheBlockStoreApp(AeonApplication):
 app_id="neural_cache_block_store";title="Neural Cache Block Format"
 def build(self,parent):
  _title(parent,"NEURAL CACHE — BLOCK FORMAT","Self-describing neural-state blocks with transactional writes and independent integrity checks.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.neural_cache_block_store.summary();box.insert("1.0",f"P076 NEURAL CACHE BLOCK FORMAT\n\nblocks={s['blocks']}\npayload_bytes={s['payload_bytes']}\nstored_bytes={s['stored_bytes']}\n\n{s['integrity']}")

class NeuralCacheRedundantStorageApp(AeonApplication):
 app_id="neural_cache_redundancy";title="Neural Cache Redundant Storage"
 def build(self,parent):
  _title(parent,"NEURAL CACHE — REDUNDANT STORAGE","Independent verified block replicas and recovery from a surviving valid copy.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.neural_cache_redundancy.summary();box.insert("1.0",f"P077 NEURAL CACHE REDUNDANT STORAGE\n\nreplica_sets={s['replica_sets']}\n\n{s['note']}")

class NeuralCacheStateCheckpointApp(AeonApplication):
 app_id="neural_cache_state_checkpoint";title="Neural Cache State Checkpoint"
 def build(self,parent):
  _title(parent,"NEURAL CACHE — STATE CHECKPOINTING","Coherent execution-state manifests over verified Neural Cache blocks.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.neural_cache_state_checkpoint.summary();box.insert("1.0",f"P078 NEURAL CACHE STATE CHECKPOINTING\n\ncheckpoints={s['checkpoints']}\n\n{s['note']}")

class NeuralCacheMigrationApp(AeonApplication):
 app_id="neural_cache_migration";title="Neural Cache Migration & Replication"
 def build(self,parent):
  _title(parent,"NEURAL CACHE — MIGRATION & REPLICATION","Verified cross-device neural-state transfer with source preservation.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.neural_cache_migration.summary();box.insert("1.0",f"P079 NEURAL CACHE MIGRATION & REPLICATION\n\ntransfers={s['transfers']}\nmodes={s['modes']}\n\n{s['note']}")

class NeuralCacheApp(AeonApplication):
 app_id="neural_cache";title="Neural Cache 1.0"
 def build(self,parent):
  _title(parent,"NEURAL CACHE 1.0","Integrated software-backed neural-state storage, integrity, redundancy, checkpoint and migration environment.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.neural_cache.health()
  box.insert("1.0",f"NEURAL CACHE 1.0\n\nphysical_hardware={s['physical_hardware']}\ndevices={s['devices']}\nblocks={s['blocks']}\nreplica_sets={s['replica_sets']}\ncheckpoints={s['checkpoints']}\nmigrations={s['migrations']}\ncorrective_ecc={s['corrective_ecc']}\nsource_retirement_after_migrate={s['source_retirement_after_migrate']}\n\n{s['note']}")

class FailureCorruptionQualificationApp(AeonApplication):
 app_id="failure_corruption_qualification";title="Failure & Corruption Validation I"
 def build(self,parent):
  _title(parent,"FAILURE & CORRUPTION VALIDATION I","Controlled destructive qualification against explicitly disposable storage artifacts.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.failure_corruption_qualification.summary();box.insert("1.0",f"P081 FAILURE & CORRUPTION VALIDATION I\\n\\nexecuted={s['executed']}\\npassed={s['passed']}\\n\\n{s['scope']}")

class ProcessFailureQualificationApp(AeonApplication):
 app_id="process_failure_qualification";title="Failure & Corruption Validation II"
 def build(self,parent):
  _title(parent,"FAILURE & CORRUPTION VALIDATION II","Disposable worker crash, hard-exit and hang containment qualification.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.process_failure_qualification.summary();box.insert("1.0",f"P082 FAILURE & CORRUPTION VALIDATION II\n\nexecuted={s['executed']}\ncontained={s['contained']}\n\n{s['scope']}")

class DistributedFailureQualificationApp(AeonApplication):
 app_id="distributed_failure_qualification";title="Failure & Corruption Validation III"
 def build(self,parent):
  _title(parent,"FAILURE & CORRUPTION VALIDATION III","Distributed node and communications fault qualification.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.distributed_failure_qualification.summary();box.insert("1.0",f"P083 FAILURE & CORRUPTION VALIDATION III\n\nexecuted={s['executed']}\npassed={s['passed']}\n\n{s['scope']}")

class ResourceFailureQualificationApp(AeonApplication):
 app_id="resource_failure_qualification";title="Failure & Corruption Validation IV"
 def build(self,parent):
  _title(parent,"FAILURE & CORRUPTION VALIDATION IV","Resource exhaustion, interrupted-write and simulated hardware-limit qualification.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.resource_failure_qualification.summary();box.insert("1.0",f"P084 FAILURE & CORRUPTION VALIDATION IV\n\nexecuted={s['executed']}\npassed={s['passed']}\n\n{s['scope']}")

class NeuralDataFailureQualificationApp(AeonApplication):
 app_id="neural_data_failure_qualification";title="Failure & Corruption Validation V"
 def build(self,parent):
  _title(parent,"FAILURE & CORRUPTION VALIDATION V","Malformed neural state and reconstruction/provenance fault qualification.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.neural_data_failure_qualification.summary();box.insert("1.0",f"P085 FAILURE & CORRUPTION VALIDATION V\n\nexecuted={s['executed']}\npassed={s['passed']}\n\n{s['scope']}")

class FailureValidationCampaignApp(AeonApplication):
 app_id="failure_validation_campaign";title="Failure & Corruption Validation VI"
 def build(self,parent):
  _title(parent,"FAILURE & CORRUPTION VALIDATION VI","Phase-level qualification evidence and residual-risk boundary.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.failure_validation_campaign.readiness();box.insert("1.0",f"P086 FAILURE & CORRUPTION VALIDATION VI\n\nstatus={s['status']}\n\nCOVERED\n- "+"\n- ".join(s["covered"])+"\n\nNOT YET QUALIFIED\n- "+"\n- ".join(s["not_qualified"])+"\n\n"+s["claim"])

class PerformanceBenchmarkApp(AeonApplication):
 app_id="performance_benchmark";title="Performance Instrumentation & Benchmarking"
 def build(self,parent):
  _title(parent,"PERFORMANCE INSTRUMENTATION & BENCHMARKING","P087 measured local workload timing; no synthetic performance claims.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.performance_benchmark.summary();box.insert("1.0",f"P087 PERFORMANCE & CLUSTER OPTIMIZATION I\n\nbenchmarks={s['benchmarks']}\nclock={s['clock']}\n\n{s['scope']}")

class WorkloadOptimizerApp(AeonApplication):
 app_id="workload_optimizer";title="Compute / Workload Optimization"
 def build(self,parent):
  _title(parent,"COMPUTE / WORKLOAD OPTIMIZATION","P088 bounded CPU/memory-aware execution planning.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.workload_optimizer.summary();box.insert("1.0",f"P088 PERFORMANCE & CLUSTER OPTIMIZATION II\n\nplans={s['plans']}\n\n{s['scope']}")

class ClusterPerformanceOptimizerApp(AeonApplication):
 app_id="cluster_performance_optimizer";title="Distributed / Cluster Performance Optimization"
 def build(self,parent):
  _title(parent,"DISTRIBUTED / CLUSTER PERFORMANCE OPTIMIZATION","P089 capacity-weighted deterministic cluster placement.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.cluster_performance_optimizer.summary();box.insert("1.0",f"P089 PERFORMANCE & CLUSTER OPTIMIZATION III\n\nplans={s['plans']}\n\n{s['scope']}")

class PerformanceOptimizationQualificationApp(AeonApplication):
 app_id="performance_optimization_qualification";title="Performance & Cluster Optimization IV"
 def build(self,parent):
  _title(parent,"PERFORMANCE & CLUSTER OPTIMIZATION IV","P090 evidence qualification and performance-claim boundaries.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.performance_optimization_qualification.readiness();box.insert("1.0",f"P090 PERFORMANCE & CLUSTER OPTIMIZATION IV\n\nstatus={s['status']}\n\nQUALIFIED SCOPE\n- "+"\n- ".join(s["qualified_scope"])+"\n\nNOT CLAIMED\n- "+"\n- ".join(s["not_claimed"])+"\n\n"+s["claim"])

class PersistentSafetyGateApp(AeonApplication):
 app_id="persistent_safety_gate";title="Security & Safety Qualification I"
 def build(self,parent):
  _title(parent,"SECURITY & SAFETY QUALIFICATION I","P091 persistent deterministic safety holds and authority boundaries.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.persistent_safety_gate.status();box.insert("1.0",f"P091 SECURITY & SAFETY QUALIFICATION I\n\nauthority={s['authority']}\nactive gate records={len(s['gates'])}\n\n{s['scope']}")

class GenesisExecutionGateApp(AeonApplication):
 app_id="genesis_execution_gate";title="Security & Safety Qualification II"
 def build(self,parent):
  _title(parent,"SECURITY & SAFETY QUALIFICATION II","P092 persistent evidence-bound Genesis pre-execution gate.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.genesis_execution_gate.status();box.insert("1.0",f"P092 SECURITY & SAFETY QUALIFICATION II\n\ncertificates={s['certificates']}\nvalidator={s['validator_version']}\n\n{s['scope']}")

class SecuritySafetyQualificationIIIApp(AeonApplication):
 app_id="security_safety_qualification_iii";title="Security & Safety Qualification III"
 def build(self,parent):
  _title(parent,"SECURITY & SAFETY QUALIFICATION III","P093 execution admission and independent watchdog interlock.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.execution_admission.status();box.insert("1.0",f"P093 SECURITY & SAFETY QUALIFICATION III\n\nadmission records={s['admission_records']}\n\n{s['scope']}\n\n{s['boundary']}")

class FullSystemIntegrationRCIApp(AeonApplication):
 app_id="full_system_integration_rc_i";title="Full-System Integration / RC I"
 def build(self,parent):
  _title(parent,"FULL-SYSTEM INTEGRATION / RC I","P094 guarded integrated execution front door.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.integrated_execution_controller.readiness();box.insert("1.0",f"P094 FULL-SYSTEM INTEGRATION / RC I\n\nfront door={s['front_door']}\n\nENFORCED\n- "+"\n- ".join(s["enforced"])+"\n\nREMAINING\n- "+"\n- ".join(s["remaining"])+"\n\n"+s["claim"])

class FullSystemIntegrationRCIIApp(AeonApplication):
 app_id="full_system_integration_rc_ii";title="Full-System Integration / RC II"
 def build(self,parent):
  _title(parent,"FULL-SYSTEM INTEGRATION / RC II","P095 guarded-stack release-candidate qualification.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.release_candidate_qualifier.readiness();box.insert("1.0",f"P095 FULL-SYSTEM INTEGRATION / RC II\n\nQUALIFIED\n- "+"\n- ".join(s["qualified"])+"\n\nRESIDUAL DEBT\n- "+"\n- ".join(s["release_blockers_or_residual_debt"])+"\n\n"+s["claim"])

class ApotheosisResearchStackApp(AeonApplication):
 app_id="apotheosis_research_stack";title="APOTHEOSIS RESEARCH STACK 1.0"
 def build(self,parent):
  _title(parent,"APOTHEOSIS RESEARCH STACK 1.0","P096 final research-stack release surface.")
  box=tk.Text(parent,bg=BG,fg=TEXT,insertbackground=RED,relief="flat",font=("Consolas",9),wrap="word");box.pack(fill="both",expand=True,padx=18,pady=18)
  s=self.context.services.apotheosis_research_stack.status();box.insert("1.0",f"{s['release']}\nAEON {s['aeon_version']}\n\nqualified release records={s['qualified_release_records']}\n\nSCIENTIFIC BOUNDARY\n{s['scientific_boundary']}\n\nENGINEERING BOUNDARY\n{s['engineering_boundary']}")
