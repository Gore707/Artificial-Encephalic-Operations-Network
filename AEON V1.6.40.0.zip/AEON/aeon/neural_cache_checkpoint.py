from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class NeuralCacheCheckpointError(RuntimeError):pass

@dataclass(frozen=True)
class NeuralCacheStateCheckpoint:
 checkpoint_id:str;created_unix:float;run_id:str;logical_step:int;simulation_time:float;time_unit:str
 block_ids:tuple;payload_sha256s:tuple;status:str;manifest_sha256:str

class NeuralCacheStateCheckpointService:
 """Coherent Neural Cache checkpoint manifests over P076 verified blocks."""
 def __init__(self,db,audit,blocks):
  self.db=db;self.audit=audit;self.blocks=blocks;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS neural_cache_state_checkpoints(
   checkpoint_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,run_id TEXT NOT NULL,logical_step INTEGER NOT NULL,
   simulation_time REAL NOT NULL,time_unit TEXT NOT NULL,block_ids_json TEXT NOT NULL,payload_sha256s_json TEXT NOT NULL,
   status TEXT NOT NULL,manifest_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 def create(self,run_id,logical_step,simulation_time,time_unit,block_ids):
  run=str(run_id).strip();unit=str(time_unit).strip();ids=tuple(str(x) for x in block_ids);step=int(logical_step);sim=float(simulation_time)
  if not run or not unit or step<0 or sim<0 or not ids:raise NeuralCacheCheckpointError("valid run, instant, unit and blocks required")
  if len(set(ids))!=len(ids):raise NeuralCacheCheckpointError("duplicate checkpoint block")
  digests=[]
  for bid in ids:
   if not self.blocks.verify(bid)["all_ok"]:raise NeuralCacheCheckpointError("checkpoint contains an invalid block")
   digests.append(self.blocks.get(bid).sha256)
  payload={"run_id":run,"logical_step":step,"simulation_time":sim,"time_unit":unit,"block_ids":list(ids),"payload_sha256s":digests}
  cid="ncckpt-"+uuid.uuid4().hex;mh=self._sha(payload)
  with self.db.transaction() as c:c.execute("INSERT INTO neural_cache_state_checkpoints VALUES(?,?,?,?,?,?,?,?,?,?)",
   (cid,time.time(),run,step,sim,unit,json.dumps(ids),json.dumps(digests),"CONSISTENT",mh))
  self.audit.append("INFO","neural_cache.state_checkpoint","created",subject=cid,details={"run_id":run,"logical_step":step,"blocks":len(ids)})
  return self.get(cid)
 def get(self,cid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM neural_cache_state_checkpoints WHERE checkpoint_id=?",(cid,)).fetchone()
  if r is None:raise NeuralCacheCheckpointError("unknown Neural Cache checkpoint")
  return NeuralCacheStateCheckpoint(r["checkpoint_id"],r["created_unix"],r["run_id"],r["logical_step"],r["simulation_time"],r["time_unit"],
   tuple(json.loads(r["block_ids_json"])),tuple(json.loads(r["payload_sha256s_json"])),r["status"],r["manifest_sha256"])
 def verify(self,cid):
  q=self.get(cid);payload={"run_id":q.run_id,"logical_step":q.logical_step,"simulation_time":q.simulation_time,"time_unit":q.time_unit,
   "block_ids":list(q.block_ids),"payload_sha256s":list(q.payload_sha256s)}
  manifest=self._sha(payload)==q.manifest_sha256;checks=[]
  for bid,digest in zip(q.block_ids,q.payload_sha256s):
   try:v=self.blocks.verify(bid);ok=v["all_ok"] and self.blocks.get(bid).sha256==digest
   except Exception:ok=False
   checks.append({"block_id":bid,"valid":ok})
  all_blocks=bool(checks) and all(x["valid"] for x in checks)
  return {"manifest_ok":manifest,"blocks":checks,"all_blocks_ok":all_blocks,"status_ok":q.status=="CONSISTENT","all_ok":manifest and all_blocks and q.status=="CONSISTENT"}
 def restore(self,cid):
  q=self.get(cid);v=self.verify(cid)
  if not v["all_ok"]:raise NeuralCacheCheckpointError("checkpoint integrity verification failed")
  payloads=tuple(self.blocks.read(bid) for bid in q.block_ids)
  self.audit.append("INFO","neural_cache.state_checkpoint","restored",subject=cid,details={"blocks":len(payloads)})
  return {"checkpoint_id":cid,"run_id":q.run_id,"logical_step":q.logical_step,"simulation_time":q.simulation_time,"time_unit":q.time_unit,"payloads":payloads}
 def list(self):
  with self.db._connect() as c:ids=[r["checkpoint_id"] for r in c.execute("SELECT checkpoint_id FROM neural_cache_state_checkpoints ORDER BY created_unix").fetchall()]
  return tuple(self.get(x) for x in ids)
 def summary(self):
  qs=self.list();return {"checkpoints":len(qs),"note":"P078 restores only checkpoints whose manifest and every referenced P076 block verify. It does not infer or repair missing neural state."}
