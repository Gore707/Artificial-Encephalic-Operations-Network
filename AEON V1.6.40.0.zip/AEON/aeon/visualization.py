from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence
import csv, json, math, time, uuid

class VisualizationError(RuntimeError): pass

@dataclass(frozen=True)
class Series:
    name:str
    x:tuple[float,...]
    y:tuple[float,...]
    x_unit:str=""
    y_unit:str=""
    provenance:str="UNKNOWN"
    source_id:str|None=None

@dataclass(frozen=True)
class FigureSpec:
    figure_id:str
    title:str
    x_label:str
    y_label:str
    series:tuple[Series,...]
    created_unix:float

class VisualizationStore:
    """Scientific figure specification and reproducible data export.

    The framework stores quantitative series and units, not rendered pixels.
    Rendering surfaces consume the same FigureSpec, so exports and displays
    remain tied to the underlying values.
    """
    VALID_PROVENANCE={"MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN"}

    def __init__(self,state_db,audit,state_dir:Path):
        self.db=state_db;self.audit=audit
        self.export_dir=Path(state_dir)/"visualizations"
        self.export_dir.mkdir(parents=True,exist_ok=True)
        self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS figures(
              figure_id TEXT PRIMARY KEY,title TEXT NOT NULL,x_label TEXT NOT NULL,
              y_label TEXT NOT NULL,spec_json TEXT NOT NULL,created_unix REAL NOT NULL)""")

    def create(self,title:str,x_label:str,y_label:str,series:Sequence[Series])->FigureSpec:
        title=title.strip()
        if not title:raise VisualizationError("Figure title is required")
        if not series:raise VisualizationError("At least one quantitative series is required")
        clean=tuple(self._validate_series(s) for s in series)
        fid="fig-"+uuid.uuid4().hex;now=time.time()
        payload={"series":[self._series_dict(s) for s in clean]}
        with self.db.transaction() as c:
            c.execute("INSERT INTO figures VALUES(?,?,?,?,?,?)",
                      (fid,title,x_label,y_label,json.dumps(payload,separators=(",",":")),now))
        self.audit.append("INFO","visualization","figure_created",subject=fid,
                          details={"title":title,"series_count":len(clean)})
        return FigureSpec(fid,title,x_label,y_label,clean,now)

    def get(self,fid:str)->FigureSpec:
        with self.db._connect() as c:r=c.execute("SELECT * FROM figures WHERE figure_id=?",(fid,)).fetchone()
        if r is None:raise VisualizationError(f"Unknown figure: {fid}")
        p=json.loads(r["spec_json"])
        ss=tuple(Series(s["name"],tuple(s["x"]),tuple(s["y"]),s["x_unit"],s["y_unit"],
                        s["provenance"],s.get("source_id")) for s in p["series"])
        return FigureSpec(r["figure_id"],r["title"],r["x_label"],r["y_label"],ss,r["created_unix"])

    def list(self,limit=200)->tuple[FigureSpec,...]:
        with self.db._connect() as c:
            ids=[r["figure_id"] for r in c.execute(
                "SELECT figure_id FROM figures ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get(i) for i in ids)

    def export_csv(self,fid:str,path:Path|None=None)->Path:
        f=self.get(fid);path=Path(path) if path else self.export_dir/f"{fid}.csv"
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open("w",newline="",encoding="utf-8") as h:
            w=csv.writer(h);w.writerow(["series","x","y","x_unit","y_unit","provenance","source_id"])
            for s in f.series:
                for x,y in zip(s.x,s.y):
                    w.writerow([s.name,x,y,s.x_unit,s.y_unit,s.provenance,s.source_id or ""])
        self.audit.append("INFO","visualization","figure_data_exported",subject=fid,
                          details={"format":"csv","path":str(path)})
        return path

    def export_spec(self,fid:str,path:Path|None=None)->Path:
        f=self.get(fid);path=Path(path) if path else self.export_dir/f"{fid}.json"
        payload={"figure_id":f.figure_id,"title":f.title,"x_label":f.x_label,"y_label":f.y_label,
                 "created_unix":f.created_unix,"series":[self._series_dict(s) for s in f.series]}
        tmp=path.with_suffix(path.suffix+".tmp");path.parent.mkdir(parents=True,exist_ok=True)
        tmp.write_text(json.dumps(payload,indent=2),encoding="utf-8");tmp.replace(path)
        return path

    @classmethod
    def _validate_series(cls,s:Series)->Series:
        if not s.name.strip():raise VisualizationError("Series name is required")
        if len(s.x)!=len(s.y) or not s.x:raise VisualizationError("x/y must be non-empty and equal length")
        if s.provenance not in cls.VALID_PROVENANCE:raise VisualizationError("Invalid provenance class")
        for v in (*s.x,*s.y):
            if not isinstance(v,(int,float)) or not math.isfinite(float(v)):
                raise VisualizationError("Series values must be finite numbers")
        return Series(s.name,tuple(float(v) for v in s.x),tuple(float(v) for v in s.y),
                      s.x_unit,s.y_unit,s.provenance,s.source_id)

    @staticmethod
    def _series_dict(s):
        return {"name":s.name,"x":list(s.x),"y":list(s.y),"x_unit":s.x_unit,
                "y_unit":s.y_unit,"provenance":s.provenance,"source_id":s.source_id}
