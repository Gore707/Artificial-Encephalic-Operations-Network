from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import csv,hashlib,json,time,uuid

EVIDENCE_CLASSES=("SIMULATION","IMPORTED","HOST","HARDWARE")
PROVENANCE_CLASSES=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")

class DataLabError(RuntimeError):pass

@dataclass(frozen=True)
class LabDataset:
    dataset_id:str;name:str;evidence_class:str;provenance:str;created_unix:float
    source_path:str;sha256:str;size_bytes:int;format:str;metadata:dict

class ApotheosisDataLab:
    """Scientific dataset catalog/workbench for the Apotheosis stack.

    Source files are registered immutably through AEON's source store.
    Evidence class and epistemic provenance are mandatory and separate.
    """
    def __init__(self,db,audit,immutable_sources):
        self.db=db;self.audit=audit;self.immutable_sources=immutable_sources;self._ensure_schema()
    def _ensure_schema(self):
        with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS apotheosis_datasets(
          dataset_id TEXT PRIMARY KEY,name TEXT NOT NULL,evidence_class TEXT NOT NULL,provenance TEXT NOT NULL,
          created_unix REAL NOT NULL,source_path TEXT NOT NULL,sha256 TEXT NOT NULL,size_bytes INTEGER NOT NULL,
          format TEXT NOT NULL,metadata_json TEXT NOT NULL)""")
    def register_file(self,path:Path,name:str,evidence_class:str,provenance:str,metadata=None):
        p=Path(path)
        if not p.is_file():raise DataLabError("dataset source does not exist")
        if evidence_class not in EVIDENCE_CLASSES:raise DataLabError("invalid evidence class")
        if provenance not in PROVENANCE_CLASSES:raise DataLabError("invalid provenance class")
        if not str(name).strip():raise DataLabError("dataset name required")
        digest=hashlib.sha256(p.read_bytes()).hexdigest();size=p.stat().st_size
        # P008 immutable store is authoritative preservation mechanism.
        immutable_path, immutable_digest, immutable_size=self.immutable_sources.ingest(p)
        if immutable_digest != digest or immutable_size != size:
            raise DataLabError("immutable-source ingest verification mismatch")
        did="ads-"+uuid.uuid4().hex;now=time.time();fmt=p.suffix.lower().lstrip(".") or "binary";md=dict(metadata or {})
        md["immutable_sha256"]=immutable_digest
        md["immutable_path"]=str(immutable_path)
        with self.db.transaction() as c:c.execute("INSERT INTO apotheosis_datasets VALUES(?,?,?,?,?,?,?,?,?,?)",
            (did,str(name).strip(),evidence_class,provenance,now,str(p),digest,size,fmt,json.dumps(md,separators=(",",":"),sort_keys=True)))
        self.audit.append("INFO","apotheosis.data","dataset_registered",subject=did,
                          details={"name":name,"evidence_class":evidence_class,"provenance":provenance,
                                   "sha256":digest,"size_bytes":size,"format":fmt})
        return self.get(did)
    def get(self,did):
        with self.db._connect() as c:r=c.execute("SELECT * FROM apotheosis_datasets WHERE dataset_id=?",(did,)).fetchone()
        if r is None:raise DataLabError("unknown dataset")
        return LabDataset(r["dataset_id"],r["name"],r["evidence_class"],r["provenance"],r["created_unix"],
                          r["source_path"],r["sha256"],r["size_bytes"],r["format"],json.loads(r["metadata_json"]))
    def list(self,limit=500):
        with self.db._connect() as c:ids=[r["dataset_id"] for r in c.execute(
            "SELECT dataset_id FROM apotheosis_datasets ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get(x) for x in ids)
    def verify_source(self,did):
        d=self.get(did);p=Path(d.source_path)
        if not p.is_file():return False,"original locator unavailable; immutable copy remains catalogued"
        actual=hashlib.sha256(p.read_bytes()).hexdigest()
        return actual==d.sha256,actual
    def inspect_tabular(self,did,max_rows=50):
        d=self.get(did)
        if d.format!="csv":raise DataLabError("tabular inspection currently supports CSV")
        p=Path(d.source_path)
        if not p.is_file():raise DataLabError("original locator unavailable")
        with p.open("r",encoding="utf-8-sig",newline="") as f:
            reader=csv.reader(f);rows=[]
            for i,row in enumerate(reader):
                rows.append(tuple(row))
                if i+1>=max_rows:break
        widths=max((len(r) for r in rows),default=0)
        return {"dataset_id":did,"rows":tuple(rows),"column_count":widths,"truncated":len(rows)>=max_rows}
