from __future__ import annotations
from dataclasses import dataclass
import json,time,uuid

class FailureCampaignError(RuntimeError):pass

@dataclass(frozen=True)
class FailureCampaignResult:
 campaign_id:str;created_unix:float;status:str;checks_json:str

class FailureValidationCampaign:
 """P086 phase-level qualification aggregator.
 Executes deterministic, disposable scenarios from P081-P085 and records evidence.
 It is not a production-safety certification.
 """
 def __init__(self,db,audit,p081,p082,p083,p084,p085):
  self.db=db;self.audit=audit;self.p081=p081;self.p082=p082;self.p083=p083;self.p084=p084;self.p085=p085;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p086_failure_validation_campaigns(
   campaign_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,status TEXT NOT NULL,checks_json TEXT NOT NULL)""")
 def run_non_destructive_suite(self):
  checks=[]
  # P082 creates/kills only its own disposable workers.
  for s in ("EXCEPTION","HARD_EXIT","HANG"):
   r=self.p082.run(s,.15);o=json.loads(r.observed_json);checks.append({"check":"process_"+s.lower(),"pass":r.contained and o.get("passed",False)})
  checks += [
   {"check":"node_stale","pass":self.p083.node_stale(10,30,5).passed},
   {"check":"packet_loss","pass":self.p083.packet_loss((1,2,3),(1,3)).passed},
   {"check":"desync","pass":self.p083.desync({"a":10,"b":12},0).passed},
   {"check":"replay","pass":self.p083.replay(("n1","n2","n1")).passed},
   {"check":"disk_refusal","pass":self.p084.disk_capacity(100,90,20).passed},
   {"check":"interrupted_write","pass":self.p084.interrupted_write(b"good",b"partial",False).passed},
   {"check":"thermal_simulation","pass":self.p084.thermal_limit(95,75,90).passed},
   {"check":"memory_pressure_simulation","pass":self.p084.memory_pressure(98,100,.95).passed},
   {"check":"nonfinite_state","pass":self.p085.nonfinite_state((0.0,float("nan"))).passed},
   {"check":"topology_reference","pass":self.p085.invalid_topology_reference(("a",),(("a","missing"),)).passed},
   {"check":"provenance","pass":self.p085.unlabeled_reconstruction(({"value":1},)).passed},
   {"check":"ai_confidence","pass":self.p085.low_confidence_ai_reconstruction(.2,.8).passed},
  ]
  status="PASS" if all(x["pass"] for x in checks) else "FAIL";cid="p086-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p086_failure_validation_campaigns VALUES(?,?,?,?)",(cid,time.time(),status,json.dumps(checks,sort_keys=True)))
  self.audit.append("INFO" if status=="PASS" else "CRITICAL","failure_qualification.p086","campaign_complete",subject=cid,details={"status":status,"checks":len(checks)})
  return self.get(cid)
 def get(self,cid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p086_failure_validation_campaigns WHERE campaign_id=?",(cid,)).fetchone()
  if r is None:raise FailureCampaignError("unknown P086 campaign")
  return FailureCampaignResult(r["campaign_id"],r["created_unix"],r["status"],r["checks_json"])
 def readiness(self):
  return {"phase":"P081-P086 FAILURE & CORRUPTION VALIDATION","status":"QUALIFICATION HARNESS AVAILABLE",
   "covered":["disposable storage corruption","replica recovery","owned worker crash/hang","stale node/loss/desync/replay models","capacity/interrupted-write models","simulated thermal/memory limits","malformed neural/provenance inputs"],
   "not_qualified":["production independent watchdog","hard OS quotas/thermal enforcement","live multi-node chaos testing","TLS/key management","persistent replay cache","full GSVL execution gate","corrective ECC","production security"],
   "claim":"Passing this campaign demonstrates the implemented test scenarios behaved as expected; it is not proof of total safety, fault tolerance, or production readiness."}
