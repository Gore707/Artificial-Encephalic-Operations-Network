from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class ConnectomeReconstructionError(RuntimeError):pass

@dataclass(frozen=True)
class ConnectomeNode:
 node_id:str;segmentation_id:str;segment_id:str;classification_id:str|None;provenance:str

@dataclass(frozen=True)
class ConnectomeEdge:
 edge_id:str;synapse_id:str;source_node_id:str|None;target_node_id:str|None;kind:str;direction:str;provenance:str;confidence:float|None

@dataclass(frozen=True)
class Connectome:
 connectome_id:str;created_unix:float;name:str;nodes:tuple[ConnectomeNode,...];edges:tuple[ConnectomeEdge,...]
 source_hashes:tuple[tuple[str,str],...];definition_sha256:str

class ConnectomeReconstructionService:
 """Builds an auditable structural connectome from explicit upstream records."""
 def __init__(self,db,audit,segmentations,synapses,classifications):
  self.db=db;self.audit=audit;self.segmentations=segmentations;self.synapses=synapses;self.classifications=classifications;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS cognitive_injection_connectomes(
   connectome_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,name TEXT NOT NULL,nodes_json TEXT NOT NULL,
   edges_json TEXT NOT NULL,source_hashes_json TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def reconstruct(self,name,node_specs,synapse_detection_ids):
  name=str(name).strip()
  if not name:raise ConnectomeReconstructionError("connectome name required")
  nodes=[];node_ids=set();segment_to_node={};sources={}
  for raw in node_specs:
   x=dict(raw);sgid=str(x["segmentation_id"]);sid=str(x["segment_id"]);ss=self.segmentations.get(sgid)
   if not self.segmentations.verify(sgid)["all_ok"]:raise ConnectomeReconstructionError("segmentation integrity failed")
   seg=next((s for s in ss.segments if s.segment_id==sid),None)
   if seg is None:raise ConnectomeReconstructionError("segment absent from segmentation")
   nid=str(x.get("node_id") or ("cell-"+uuid.uuid4().hex))
   if nid in node_ids:raise ConnectomeReconstructionError("duplicate connectome node id")
   node_ids.add(nid);key=(sgid,sid)
   if key in segment_to_node:raise ConnectomeReconstructionError("segment mapped to multiple connectome nodes")
   segment_to_node[key]=nid;sources["segmentation:"+sgid]=ss.definition_sha256
   cid=x.get("classification_id")
   if cid is not None:
    cl=self.classifications.get(str(cid))
    if cl.segmentation_id!=sgid or cl.segment_id!=sid:raise ConnectomeReconstructionError("classification does not belong to node segment")
    if not self.classifications.verify(str(cid))["all_ok"]:raise ConnectomeReconstructionError("classification integrity failed")
    sources["classification:"+str(cid)]=cl.definition_sha256
   nodes.append(ConnectomeNode(nid,sgid,sid,str(cid) if cid is not None else None,seg.provenance))
  if not nodes:raise ConnectomeReconstructionError("at least one node required")
  edges=[]
  for did in synapse_detection_ids:
   det=self.synapses.get(str(did))
   if not self.synapses.verify(str(did))["all_ok"]:raise ConnectomeReconstructionError("synapse detection integrity failed")
   sources["synapse_detection:"+str(did)]=det.definition_sha256
   for s in det.candidates:
    src=dst=None
    if s.pre_trace_id is not None:
     tr=self.synapses.traces.get(s.pre_trace_id);src=segment_to_node.get((tr.segmentation_id,tr.segment_id))
    if s.post_trace_id is not None:
     tr=self.synapses.traces.get(s.post_trace_id);dst=segment_to_node.get((tr.segmentation_id,tr.segment_id))
    # Preserve partial/unknown endpoints instead of fabricating a connection.
    if src is None and dst is None:continue
    edges.append(ConnectomeEdge("conn-"+s.synapse_id,s.synapse_id,src,dst,s.kind,s.direction,s.provenance,s.confidence))
  bindings=tuple(sorted(sources.items()))
  payload={"name":name,"nodes":[n.__dict__ for n in nodes],"edges":[e.__dict__ for e in edges],"source_hashes":bindings}
  sha=hashlib.sha256(self._canon(payload).encode()).hexdigest();cid="connectome-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_injection_connectomes VALUES(?,?,?,?,?,?,?)",
   (cid,now,name,json.dumps(payload["nodes"],sort_keys=True),json.dumps(payload["edges"],sort_keys=True),json.dumps(bindings),sha))
  self.audit.append("INFO","cognitive_injection.connectome","reconstructed",subject=cid,details={"nodes":len(nodes),"edges":len(edges),"definition_sha256":sha})
  return self.get(cid)
 def get(self,cid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_injection_connectomes WHERE connectome_id=?",(cid,)).fetchone()
  if r is None:raise ConnectomeReconstructionError("unknown connectome")
  ns=tuple(ConnectomeNode(**x) for x in json.loads(r["nodes_json"]));es=tuple(ConnectomeEdge(**x) for x in json.loads(r["edges_json"]))
  return Connectome(r["connectome_id"],r["created_unix"],r["name"],ns,es,tuple(tuple(x) for x in json.loads(r["source_hashes_json"])),r["definition_sha256"])
 def verify(self,cid):
  q=self.get(cid);source_ok=True
  for key,sha in q.source_hashes:
   typ,rid=key.split(":",1)
   try:
    obj={"segmentation":self.segmentations,"classification":self.classifications,"synapse_detection":self.synapses}[typ].get(rid)
    source_ok &= obj.definition_sha256==sha
   except Exception:source_ok=False
  payload={"name":q.name,"nodes":[n.__dict__ for n in q.nodes],"edges":[e.__dict__ for e in q.edges],"source_hashes":q.source_hashes}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  return {"definition_ok":definition_ok,"source_ok":bool(source_ok),"all_ok":definition_ok and bool(source_ok)}
 def summary(self,cid):
  q=self.get(cid)
  return {"nodes":len(q.nodes),"edges":len(q.edges),"partial_edges":sum(e.source_node_id is None or e.target_node_id is None for e in q.edges),
   "note":"This is a structural reconstruction. It does not establish complete synaptic physiology, dynamic neural state, or Minimum Sufficient Cognitive State."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["connectome_id"] for r in c.execute("SELECT connectome_id FROM cognitive_injection_connectomes ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
