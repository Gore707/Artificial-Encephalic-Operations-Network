from __future__ import annotations
from dataclasses import dataclass
import json,time,uuid

class ResourceFailureQualificationError(RuntimeError):pass

@dataclass(frozen=True)
class ResourceFailureResult:
 qualification_id:str;created_unix:float;scenario:str;passed:bool;observed_json:str

class ResourceFailureQualification:
 """P084 deterministic resource/storage/thermal fault qualification.
 Inputs are simulated/disposable observations. No host thermal controls are asserted here.
 """
 SCENARIOS=("DISK_CAPACITY","INTERRUPTED_WRITE","THERMAL_LIMIT","MEMORY_PRESSURE")
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p084_resource_failure_qualifications(
   qualification_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,scenario TEXT NOT NULL,passed INTEGER NOT NULL,observed_json TEXT NOT NULL)""")
 def _record(self,scenario,passed,obs):
  qid="p084-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p084_resource_failure_qualifications VALUES(?,?,?,?,?)",(qid,time.time(),scenario,1 if passed else 0,json.dumps(obs,sort_keys=True)))
  self.audit.append("INFO" if passed else "CRITICAL","failure_qualification.p084",scenario.lower(),subject=qid,details=obs);return self.get(qid)
 def disk_capacity(self,free_bytes,required_bytes,reserve_bytes=0):
  free=int(free_bytes);req=int(required_bytes);reserve=int(reserve_bytes)
  if min(free,req,reserve)<0:raise ResourceFailureQualificationError("negative capacity")
  admitted=req+reserve<=free;passed=not admitted
  return self._record("DISK_CAPACITY",passed,{"free_bytes":free,"required_bytes":req,"reserve_bytes":reserve,"admitted":admitted,"expected":"REFUSE"})
 def interrupted_write(self,original:bytes,candidate:bytes,commit_complete:bool):
  # Models transactional visibility: incomplete candidate must never replace committed original.
  visible=candidate if bool(commit_complete) else original
  passed=(visible==original) if not commit_complete else (visible==candidate)
  return self._record("INTERRUPTED_WRITE",passed,{"original_bytes":len(original),"candidate_bytes":len(candidate),"commit_complete":bool(commit_complete),"preserved_original":visible==original})
 def thermal_limit(self,temperature_c,warning_c,critical_c):
  t=float(temperature_c);w=float(warning_c);c=float(critical_c)
  if not (w<c):raise ResourceFailureQualificationError("warning must be below critical")
  action="HOLD" if t>=c else ("THROTTLE" if t>=w else "ALLOW")
  passed=(t>=c and action=="HOLD") or (w<=t<c and action=="THROTTLE") or (t<w and action=="ALLOW")
  return self._record("THERMAL_LIMIT",passed,{"temperature_c":t,"warning_c":w,"critical_c":c,"action":action,"source":"SIMULATION"})
 def memory_pressure(self,used_bytes,total_bytes,critical_fraction=.95):
  used=int(used_bytes);total=int(total_bytes);f=float(critical_fraction)
  if total<=0 or used<0 or not 0<f<=1:raise ResourceFailureQualificationError("invalid memory inputs")
  fraction=used/total;action="HOLD_NEW_WORK" if fraction>=f else "ALLOW"
  return self._record("MEMORY_PRESSURE",action=="HOLD_NEW_WORK",{"used_bytes":used,"total_bytes":total,"fraction":fraction,"critical_fraction":f,"action":action,"source":"SIMULATION"})
 def get(self,qid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p084_resource_failure_qualifications WHERE qualification_id=?",(qid,)).fetchone()
  if r is None:raise ResourceFailureQualificationError("unknown P084 qualification")
  return ResourceFailureResult(r["qualification_id"],r["created_unix"],r["scenario"],bool(r["passed"]),r["observed_json"])
 def summary(self):
  with self.db._connect() as c:
   total=c.execute("SELECT COUNT(*) n FROM p084_resource_failure_qualifications").fetchone()["n"];passed=c.execute("SELECT COUNT(*) n FROM p084_resource_failure_qualifications WHERE passed=1").fetchone()["n"]
  return {"phase":"FAILURE & CORRUPTION VALIDATION IV","executed":total,"passed":passed,
   "scope":"Capacity refusal, interrupted-write visibility, simulated thermal action, simulated memory pressure. Does not claim hard OS quotas or production thermal enforcement."}
