from __future__ import annotations
from dataclasses import dataclass
import json,math,time,uuid

class ReconstructionConfidenceError(RuntimeError):pass

@dataclass(frozen=True)
class ReconstructionConfidenceAssessment:
 assessment_id:str;created_unix:float;metadata_id:str;claim_count:int;unknown_count:int
 provenance_counts:dict;confidence_stats:dict;coverage:dict;information_sufficiency:str;details:dict

class ReconstructionConfidenceService:
 """Evidence-quality assessment for P053 reconstruction metadata.
 Confidence summarizes declared evidence quality; it never changes provenance class.
 """
 PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")
 def __init__(self,db,audit,reconstruction_metadata):
  self.db=db;self.audit=audit;self.metadata=reconstruction_metadata;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS reconstruction_confidence_assessments(
   assessment_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,metadata_id TEXT NOT NULL,claim_count INTEGER NOT NULL,
   unknown_count INTEGER NOT NULL,provenance_counts_json TEXT NOT NULL,confidence_stats_json TEXT NOT NULL,
   coverage_json TEXT NOT NULL,information_sufficiency TEXT NOT NULL,details_json TEXT NOT NULL)""")
 def assess(self,metadata_id):
  m=self.metadata.get(metadata_id)
  verification=self.metadata.verify(metadata_id)
  if not verification.get("all_ok",False):raise ReconstructionConfidenceError("reconstruction metadata integrity verification failed")
  claims=list(m.claims);counts={k:0 for k in self.PROVENANCE};vals=[]
  targets=set();properties=set()
  for c in claims:
   p=str(c.provenance).upper()
   if p not in counts:raise ReconstructionConfidenceError("unsupported provenance in reconstruction claim")
   conf=float(c.confidence)
   if not math.isfinite(conf) or not 0<=conf<=1:raise ReconstructionConfidenceError("invalid claim confidence")
   counts[p]+=1;vals.append(conf);targets.add(c.target_ref);properties.add(c.property_name)
  stats={"minimum":min(vals) if vals else None,"maximum":max(vals) if vals else None,
         "mean":sum(vals)/len(vals) if vals else None,"claim_count":len(vals)}
  coverage={"unique_targets_with_claims":len(targets),"unique_properties_with_claims":len(properties),
            "unknown_count":len(m.unknowns)}
  details={"source_verification":verification,
   "measured_fraction":(counts["MEASURED"]/len(claims)) if claims else None,
   "nonmeasured_fraction":((counts["DERIVED"]+counts["INFERRED"]+counts["AI-RECONSTRUCTED"]+counts["UNKNOWN"])/len(claims)) if claims else None,
   "interpretation":"Confidence does not promote DERIVED, INFERRED, AI-RECONSTRUCTED, or UNKNOWN information to MEASURED. Coverage and confidence do not prove Minimum Sufficient Cognitive State."}
  aid="reconconf-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO reconstruction_confidence_assessments VALUES(?,?,?,?,?,?,?,?,?,?)",
   (aid,time.time(),metadata_id,len(claims),len(m.unknowns),json.dumps(counts,sort_keys=True),json.dumps(stats,sort_keys=True),
    json.dumps(coverage,sort_keys=True),"UNDETERMINED",json.dumps(details,sort_keys=True)))
  self.audit.append("INFO","cognitive_guardian.reconstruction_confidence","assessed",subject=aid,
   details={"metadata_id":metadata_id,"claims":len(claims),"unknowns":len(m.unknowns),"information_sufficiency":"UNDETERMINED"})
  return self.get(aid)
 def get(self,aid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM reconstruction_confidence_assessments WHERE assessment_id=?",(aid,)).fetchone()
  if r is None:raise ReconstructionConfidenceError("unknown reconstruction confidence assessment")
  return ReconstructionConfidenceAssessment(r["assessment_id"],r["created_unix"],r["metadata_id"],r["claim_count"],r["unknown_count"],
   json.loads(r["provenance_counts_json"]),json.loads(r["confidence_stats_json"]),json.loads(r["coverage_json"]),
   r["information_sufficiency"],json.loads(r["details_json"]))
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["assessment_id"] for r in c.execute("SELECT assessment_id FROM reconstruction_confidence_assessments ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM reconstruction_confidence_assessments").fetchone()["n"]
  return {"assessments":n,"information_sufficiency":"UNDETERMINED",
   "note":"P065 quantifies declared reconstruction evidence quality while preserving provenance classes. It does not certify MSCS or upload sufficiency."}
