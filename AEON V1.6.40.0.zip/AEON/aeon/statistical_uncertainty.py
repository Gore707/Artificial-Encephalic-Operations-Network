from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import csv,math,statistics
class UncertaintyAnalysisError(RuntimeError):pass
@dataclass(frozen=True)
class StatisticalSummary:
 dataset_id:str;field:str;n:int;mean:float;median:float;stddev:float|None;standard_error:float|None;minimum:float;maximum:float;evidence_class:str;provenance:str
@dataclass(frozen=True)
class UncertainEstimate:
 value:float;standard_uncertainty:float;lower:float;upper:float;coverage_factor:float;method:str;contributors:tuple[tuple[str,float],...]
class StatisticalUncertaintyAnalysis:
 def __init__(self,data_lab,audit):self.data_lab=data_lab;self.audit=audit
 def _numeric(self,dataset_id,field,max_rows=500000):
  d=self.data_lab.get(dataset_id)
  if d.format not in ("csv","tsv"):raise UncertaintyAnalysisError("numeric analysis requires CSV/TSV")
  p=Path(d.source_path)
  if not p.is_file():raise UncertaintyAnalysisError("original dataset locator unavailable")
  vals=[];delim="\t" if d.format=="tsv" else ","
  with p.open("r",encoding="utf-8-sig",newline="") as f:
   r=csv.DictReader(f,delimiter=delim)
   if field not in (r.fieldnames or ()):raise UncertaintyAnalysisError("field absent")
   for row in r:
    if len(vals)>=max_rows:break
    try:v=float(row[field])
    except (TypeError,ValueError):continue
    if math.isfinite(v):vals.append(v)
  if not vals:raise UncertaintyAnalysisError("no finite numeric observations")
  return d,vals
 def summarize(self,dataset_id,field,max_rows=500000):
  d,v=self._numeric(dataset_id,field,max_rows);n=len(v);sd=statistics.stdev(v) if n>=2 else None;se=sd/math.sqrt(n) if sd is not None else None
  s=StatisticalSummary(dataset_id,field,n,statistics.fmean(v),statistics.median(v),sd,se,min(v),max(v),d.evidence_class,d.provenance)
  self.audit.append("INFO","apotheosis.uncertainty","statistical_summary",subject=dataset_id,details={"field":field,"n":n,"evidence":d.evidence_class,"provenance":d.provenance});return s
 def propagate_independent(self,value,contributors,coverage_factor=1.0):
  items=tuple((str(k),float(v)) for k,v in contributors.items())
  if not items:raise UncertaintyAnalysisError("at least one uncertainty contributor required")
  if any(not math.isfinite(u) or u<0 for _,u in items):raise UncertaintyAnalysisError("uncertainties must be finite and nonnegative")
  k=float(coverage_factor);v=float(value)
  if not math.isfinite(k) or k<=0 or not math.isfinite(v):raise UncertaintyAnalysisError("invalid estimate or coverage factor")
  u=math.sqrt(sum(x*x for _,x in items));return UncertainEstimate(v,u,v-k*u,v+k*u,k,"root-sum-square; independent standard uncertainties",items)
 def mean_interval_normal_approx(self,dataset_id,field,coverage_factor=1.96):
  s=self.summarize(dataset_id,field)
  if s.standard_error is None:raise UncertaintyAnalysisError("at least two observations required")
  k=float(coverage_factor)
  if not math.isfinite(k) or k<=0:raise UncertaintyAnalysisError("coverage factor must be positive")
  return UncertainEstimate(s.mean,s.standard_error,s.mean-k*s.standard_error,s.mean+k*s.standard_error,k,"normal-approximation interval on sample mean; coverage depends on assumptions",(("sampling_standard_error",s.standard_error),))
