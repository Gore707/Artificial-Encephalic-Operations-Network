from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class ReleaseCandidateQualificationError(RuntimeError):pass

@dataclass(frozen=True)
class ReleaseCandidateQualification:
 qualification_id:str;created_unix:float;status:str;checks_json:str;evidence_sha256:str

class ReleaseCandidateQualifier:
 """P095 RC-II qualification of the guarded P091-P094 execution chain.
 This is software integration qualification, not biological validity or production safety certification.
 """
 def __init__(self,db,audit,safety_gate,genesis,watchdog,admission,integrated):
  self.db=db;self.audit=audit;self.safety_gate=safety_gate;self.genesis=genesis;self.watchdog=watchdog;self.admission=admission;self.integrated=integrated;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p095_rc_qualifications(
   qualification_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,status TEXT NOT NULL,checks_json TEXT NOT NULL,evidence_sha256 TEXT NOT NULL)""")
 def run(self):
  token=uuid.uuid4().hex[:12];subject="rc-"+token;state=("AEON-RC-"+token).encode()
  desc={"model_version":"RC-P095","topology":{"nodes":[{"id":"n0"},{"id":"n1"}],"edges":[["n0","n1"]]},"provenance":["MEASURED","DERIVED"]}
  checks=[]
  cert=self.genesis.validate(subject,state,desc)
  checks.append({"check":"genesis_pass","pass":cert.status=="PASS","evidence":cert.certificate_id})
  run=self.integrated.admit(subject,state,cert.certificate_id)
  checks.append({"check":"guarded_admission","pass":run.status=="ADMITTED","evidence":run.admission_id})
  self.watchdog.register("rc-worker-"+token,5.0,now=100.0)
  healthy=self.watchdog.evaluate(now=101.0)
  checks.append({"check":"watchdog_healthy_path","pass":healthy["healthy"],"evidence":healthy})
  running=self.integrated.transition(run.run_id,"RUNNING")
  checks.append({"check":"run_transition","pass":running.status=="RUNNING","evidence":run.run_id})
  completed=self.integrated.transition(run.run_id,"COMPLETED")
  checks.append({"check":"completion","pass":completed.status=="COMPLETED","evidence":run.run_id})
  checks.append({"check":"safety_gates_clear","pass":all(not self.safety_gate.get(g).held for g in ("NEW_WORK","GENESIS_EXECUTION","WATCHDOG")),"evidence":["NEW_WORK","GENESIS_EXECUTION","WATCHDOG"]})
  status="PASS" if all(c["pass"] for c in checks) else "FAIL"
  canonical=json.dumps(checks,sort_keys=True,separators=(",",":"));sha=hashlib.sha256(canonical.encode()).hexdigest();qid="p095-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p095_rc_qualifications VALUES(?,?,?,?,?)",(qid,time.time(),status,canonical,sha))
  self.audit.append("INFO" if status=="PASS" else "CRITICAL","integration.p095","rc_qualification",subject=qid,details={"status":status,"checks":len(checks)})
  return self.get(qid)
 def get(self,qid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p095_rc_qualifications WHERE qualification_id=?",(qid,)).fetchone()
  if r is None:raise ReleaseCandidateQualificationError("unknown RC qualification")
  return ReleaseCandidateQualification(r["qualification_id"],r["created_unix"],r["status"],r["checks_json"],r["evidence_sha256"])
 def verify(self,qid):
  r=self.get(qid);return {"qualification_id":qid,"all_ok":hashlib.sha256(r.checks_json.encode()).hexdigest()==r.evidence_sha256,"status":r.status}
 def readiness(self):
  return {"phase":"FULL-SYSTEM INTEGRATION / RC II",
   "qualified":["persistent deterministic safety-gate chain","exact-state Genesis certificate chain","watchdog healthy-path integration","guarded admission","integrated RUNNING/COMPLETED lifecycle","qualification evidence integrity"],
   "release_blockers_or_residual_debt":["legacy/direct low-level APIs remain callable by trusted in-process code","hard OS quotas and thermal enforcement remain incomplete","production TLS/key management/replay protection remains incomplete","corrective ECC remains unimplemented","full model-specific biological plausibility/dynamic GSVL remains incomplete","deterministic seed/input event journal and replay remains incomplete","no claim of consciousness transfer or information sufficiency"],
   "claim":"RC-II validates the guarded software integration path under its tested conditions. P096 may package Research Stack 1.0 only with these residual limitations stated, not hidden."}
