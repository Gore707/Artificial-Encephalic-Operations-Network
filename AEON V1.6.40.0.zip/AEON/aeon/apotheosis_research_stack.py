from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class ResearchStackReleaseError(RuntimeError):pass

@dataclass(frozen=True)
class ResearchStackRelease:
 release_id:str;created_unix:float;version:str;status:str;manifest_json:str;manifest_sha256:str

class ApotheosisResearchStack:
 """P096 APOTHEOSIS RESEARCH STACK 1.0 release surface.
 The release is a research-software baseline, not evidence that mind uploading,
 information sufficiency, consciousness transfer, or identity continuity is solved.
 """
 VERSION="1.0.0"
 EVIDENCE_CLASSES=("ESTABLISHED_SCIENCE","DEMONSTRATED_TECHNOLOGY","EXTRAPOLATED_ENGINEERING","SPECULATIVE_UNRESOLVED")
 PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")
 def __init__(self,db,audit,rc_qualifier,safety_gate,genesis,watchdog,integrated):
  self.db=db;self.audit=audit;self.rc=rc_qualifier;self.safety_gate=safety_gate;self.genesis=genesis;self.watchdog=watchdog;self.integrated=integrated;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p096_research_stack_releases(
   release_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,version TEXT NOT NULL,status TEXT NOT NULL,manifest_json TEXT NOT NULL,manifest_sha256 TEXT NOT NULL)""")
 def qualify_release(self):
  rc=self.rc.run()
  manifest={
   "program":"GNS-2025-INITIATIVE-APOTHEOSIS","product":"AEON — Artificial Encephalic Operations Network",
   "release":"APOTHEOSIS RESEARCH STACK 1.0","version":self.VERSION,"rc_qualification_id":rc.qualification_id,
   "rc_status":rc.status,"evidence_classes":list(self.EVIDENCE_CLASSES),"provenance_classes":list(self.PROVENANCE),
   "guarded_execution":{"persistent_safety_gates":True,"genesis_exact_state_binding":True,"watchdog_interlock":True,"integrated_execution_front_door":True},
   "scientific_status":{"information_sufficiency":"UNDETERMINED","consciousness_transfer":"UNDETERMINED","personal_identity_continuity":"UNDETERMINED","brain_uploading_currently_demonstrated":False},
   "residual_engineering_debt":[
    "legacy/direct low-level APIs remain callable by trusted in-process code",
    "hard OS resource quotas and production thermal enforcement remain incomplete",
    "production TLS/key management and persistent transport replay protection remain incomplete",
    "corrective ECC remains unimplemented",
    "full model-specific biological plausibility and bounded dynamic GSVL remain incomplete",
    "deterministic seed/input event journal and replay remains incomplete",
    "Guardian does not yet include a production local LLM backend"
   ],
   "release_scope":"Research software baseline for acquisition/reconstruction/provenance/ANI/simulation/Guardian/compute/cache/failure/performance/safety integration. Not a production medical, consciousness-transfer, or safety-certified system."
  }
  status="PASS_WITH_RESIDUAL_DEBT" if rc.status=="PASS" else "FAIL"
  canonical=json.dumps(manifest,sort_keys=True,separators=(",",":"));sha=hashlib.sha256(canonical.encode()).hexdigest();rid="apotheosis-1.0-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p096_research_stack_releases VALUES(?,?,?,?,?,?)",(rid,time.time(),self.VERSION,status,canonical,sha))
  self.audit.append("INFO" if rc.status=="PASS" else "CRITICAL","release.p096","research_stack_release",subject=rid,details={"version":self.VERSION,"status":status,"rc":rc.qualification_id})
  return self.get(rid)
 def get(self,rid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p096_research_stack_releases WHERE release_id=?",(rid,)).fetchone()
  if r is None:raise ResearchStackReleaseError("unknown research stack release")
  return ResearchStackRelease(r["release_id"],r["created_unix"],r["version"],r["status"],r["manifest_json"],r["manifest_sha256"])
 def verify(self,rid):
  r=self.get(rid);return {"release_id":rid,"all_ok":hashlib.sha256(r.manifest_json.encode()).hexdigest()==r.manifest_sha256,"status":r.status}
 def status(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM p096_research_stack_releases").fetchone()["n"]
  return {"release":"APOTHEOSIS RESEARCH STACK 1.0","aeon_version":"1.64.0","qualified_release_records":n,
   "scientific_boundary":"Information sufficiency, consciousness transfer, personal identity continuity, and demonstrated brain uploading remain unresolved.",
   "engineering_boundary":"1.0 is a research-software baseline with explicitly recorded residual engineering debt; it is not production safety certification."}
