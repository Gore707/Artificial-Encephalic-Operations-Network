from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,time,uuid
from .resources import ResourceRequest

class ExperimentError(RuntimeError):pass

@dataclass(frozen=True)
class ExperimentDefinition:
    experiment_id:str;name:str;mode:str;command:tuple[str,...];parameters:dict
    request:ResourceRequest;created_unix:float;definition_hash:str

@dataclass(frozen=True)
class ExperimentRun:
    run_id:str;experiment_id:str;job_id:str;state:str;submitted_unix:float
    definition_hash:str;mode:str

class ExperimentManager:
    """Versioned experiment definitions submitted through the P015 scheduler."""
    MODES={"SIMULATION","IMPORTED","HOST","HARDWARE"}

    def __init__(self,db,audit,jobs):
        self.db=db;self.audit=audit;self.jobs=jobs;self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS experiments(
             experiment_id TEXT PRIMARY KEY,name TEXT NOT NULL,mode TEXT NOT NULL,
             command_json TEXT NOT NULL,parameters_json TEXT NOT NULL,
             cpu_logical INTEGER NOT NULL,memory_bytes INTEGER NOT NULL,
             storage_bytes INTEGER NOT NULL,gpu_memory_bytes INTEGER NOT NULL,
             created_unix REAL NOT NULL,definition_hash TEXT NOT NULL)""")
            c.execute("""CREATE TABLE IF NOT EXISTS experiment_runs(
             run_id TEXT PRIMARY KEY,experiment_id TEXT NOT NULL,job_id TEXT NOT NULL,
             state TEXT NOT NULL,submitted_unix REAL NOT NULL,definition_hash TEXT NOT NULL,
             mode TEXT NOT NULL,FOREIGN KEY(experiment_id) REFERENCES experiments(experiment_id))""")

    def create(self,name,mode,command,parameters=None,request=None):
        name=name.strip();mode=mode.strip().upper()
        if not name or not command:raise ExperimentError("name and command are required")
        if mode not in self.MODES:raise ExperimentError(f"mode must be one of {sorted(self.MODES)}")
        parameters=dict(parameters or {});request=request or ResourceRequest()
        payload={"name":name,"mode":mode,"command":list(command),"parameters":parameters,
                 "resources":{"cpu_logical":request.cpu_logical,"memory_bytes":request.memory_bytes,
                 "storage_bytes":request.storage_bytes,"gpu_memory_bytes":request.gpu_memory_bytes}}
        try:canonical=json.dumps(payload,sort_keys=True,separators=(",",":"),allow_nan=False)
        except (TypeError,ValueError) as exc:raise ExperimentError(f"parameters are not canonical JSON: {exc}") from exc
        digest=hashlib.sha256(canonical.encode()).hexdigest();eid="exp-"+uuid.uuid4().hex;now=time.time()
        with self.db.transaction() as c:
            c.execute("""INSERT INTO experiments VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
             (eid,name,mode,json.dumps(list(command)),json.dumps(parameters,sort_keys=True),
              request.cpu_logical,request.memory_bytes,request.storage_bytes,request.gpu_memory_bytes,now,digest))
        self.audit.append("INFO","experiment","definition_created",subject=eid,
                          details={"mode":mode,"definition_hash":digest})
        return self.get(eid)

    def get(self,eid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM experiments WHERE experiment_id=?",(eid,)).fetchone()
        if r is None:raise ExperimentError(f"Unknown experiment: {eid}")
        return ExperimentDefinition(r["experiment_id"],r["name"],r["mode"],tuple(json.loads(r["command_json"])),
          json.loads(r["parameters_json"]),ResourceRequest(r["cpu_logical"],r["memory_bytes"],r["storage_bytes"],
          r["gpu_memory_bytes"]),r["created_unix"],r["definition_hash"])

    def list(self,limit=200):
        with self.db._connect() as c:
            ids=[r["experiment_id"] for r in c.execute(
                "SELECT experiment_id FROM experiments ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get(i) for i in ids)

    def run(self,eid,owner):
        e=self.get(eid)
        # Immutable definition hash is attached to every run; the job scheduler
        # remains the sole local execution path and therefore enforces P014.
        job=self.jobs.submit(f"experiment:{e.name}",owner,e.command,e.request)
        rid="run-"+uuid.uuid4().hex;now=time.time()
        with self.db.transaction() as c:
            c.execute("INSERT INTO experiment_runs VALUES(?,?,?,?,?,?,?)",
                      (rid,e.experiment_id,job.job_id,"SUBMITTED",now,e.definition_hash,e.mode))
        self.audit.append("INFO","experiment","run_submitted",subject=rid,
                          details={"experiment_id":eid,"job_id":job.job_id,"mode":e.mode,
                                   "definition_hash":e.definition_hash})
        return self.get_run(rid)

    def get_run(self,rid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM experiment_runs WHERE run_id=?",(rid,)).fetchone()
        if r is None:raise ExperimentError(f"Unknown run: {rid}")
        state=self.jobs.get(r["job_id"]).state
        if state!=r["state"]:
            with self.db.transaction() as c:c.execute("UPDATE experiment_runs SET state=? WHERE run_id=?",(state,rid))
        return ExperimentRun(r["run_id"],r["experiment_id"],r["job_id"],state,r["submitted_unix"],
                             r["definition_hash"],r["mode"])

    def runs(self,limit=200):
        with self.db._connect() as c:
            ids=[r["run_id"] for r in c.execute(
                "SELECT run_id FROM experiment_runs ORDER BY submitted_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get_run(i) for i in ids)
