from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Callable, Mapping
import logging
import tkinter as tk

class AppAPIError(RuntimeError): pass

@dataclass(frozen=True)
class AeonServices:
    root: Path
    config: Any
    logger: logging.Logger
    telemetry: Any
    workspaces: Any
    state_db: Any
    data_objects: Any
    provenance: Any
    immutable_sources: Any
    audit: Any
    diagnostics: Any
    identity: Any
    session: Any
    processes: Any
    hardware: Any
    accelerators: Any
    resources: Any
    jobs: Any
    visualizations: Any
    telemetry_stream: Any
    experiments: Any
    checkpoints: Any
    integrity: Any
    transactional_files: Any
    recovery: Any
    nodes: Any
    cluster: Any
    distributed_jobs: Any
    guardian: Any
    guardian_anomaly: Any
    safety_kernel: Any
    safety_governor: Any
    neural_safety: Any
    genesis: Any
    apotheosis_data_lab: Any
    dataset_importer: Any
    visualization_studio: Any
    neural_dataset_explorer: Any
    experiment_laboratory: Any
    statistical_uncertainty: Any
    model_comparison_laboratory: Any
    provenance_reproducibility: Any
    neuroimaging_ingestion: Any
    volume_reconstruction: Any
    neuron_segmentation: Any
    neurite_tracing: Any
    synapse_detection: Any
    cell_classification: Any
    connectome_reconstruction: Any
    cognitive_injection_workbench: Any
    ani_specification: Any
    ani_topology: Any
    ani_synaptic_state: Any
    ani_dynamic_state: Any
    ani_reconstruction_metadata: Any
    ani_manager: Any
    neuron_simulation: Any
    synapse_engine: Any
    snn_engine: Any
    neural_clock: Any
    neural_partition: Any
    gpu_execution: Any
    distributed_neural: Any
    neural_simulacrum: Any
    cognitive_anomaly: Any
    cognitive_state_comparator: Any
    reconstruction_confidence: Any
    candidate_reconstruction: Any
    cognitive_divergence: Any
    cognitive_guardian: Any
    compute_node_server: Any
    distributed_transport: Any
    exa_graph_partitioner: Any
    exa_distributed_checkpoint: Any
    exa_cluster_control: Any
    exa_execution_engine: Any
    neural_cache_virtual_device: Any
    neural_cache_block_store: Any
    neural_cache_redundancy: Any
    neural_cache_state_checkpoint: Any
    neural_cache_migration: Any
    neural_cache: Any
    failure_corruption_qualification: Any
    process_failure_qualification: Any
    distributed_failure_qualification: Any
    resource_failure_qualification: Any
    neural_data_failure_qualification: Any
    failure_validation_campaign: Any
    performance_benchmark: Any
    workload_optimizer: Any
    cluster_performance_optimizer: Any
    performance_optimization_qualification: Any
    persistent_safety_gate: Any
    genesis_execution_gate: Any
    independent_watchdog: Any
    execution_admission: Any
    integrated_execution_controller: Any
    release_candidate_qualifier: Any
    apotheosis_research_stack: Any

    def config_get(self, key: str, default: Any = None) -> Any:
        return self.config.get(key, default)
    def path(self, key: str) -> Path:
        return self.config.path(key)
    def host_snapshot(self):
        return self.telemetry.snapshot()
    def state_get(self, namespace: str, key: str, default: Any = None) -> Any:
        return self.state_db.get(namespace, key, default)
    def state_set(self, namespace: str, key: str, value: Any) -> None:
        self.state_db.set(namespace, key, value)
    def audit_event(self, severity: str, category: str, action: str, **kwargs):
        return self.audit.append(severity, category, action, **kwargs)
    def require_permission(self, permission: str, *, action: str, subject: str | None = None) -> None:
        self.identity.require(self.session.user_id, permission, action=action, subject=subject)

@dataclass(frozen=True)
class AppDescriptor:
    app_id: str
    title: str
    version: str
    factory: Callable[["AppContext"], "AeonApplication"]

@dataclass(frozen=True)
class AppContext:
    services: AeonServices
    open_app: Callable[[str], None]

class AeonApplication:
    app_id = ""
    title = ""
    version = "1.0"
    def __init__(self, context: AppContext): self.context = context
    def build(self, parent: tk.Widget) -> None: raise NotImplementedError
    def on_focus(self) -> None: pass
    def on_close(self) -> None: pass

class AppRegistry:
    def __init__(self): self._descriptors: dict[str, AppDescriptor] = {}
    def register(self, descriptor: AppDescriptor) -> None:
        if not descriptor.app_id.strip(): raise AppAPIError("Application id cannot be empty")
        if not descriptor.title.strip(): raise AppAPIError("Application title cannot be empty")
        if descriptor.app_id in self._descriptors:
            raise AppAPIError(f"Application already registered: {descriptor.app_id}")
        self._descriptors[descriptor.app_id] = descriptor
    def get(self, app_id: str) -> AppDescriptor:
        try: return self._descriptors[app_id]
        except KeyError as exc: raise AppAPIError(f"Unknown application: {app_id}") from exc
    def all(self) -> tuple[AppDescriptor, ...]: return tuple(self._descriptors.values())
    def snapshot(self) -> Mapping[str, AppDescriptor]:
        return MappingProxyType(dict(self._descriptors))
