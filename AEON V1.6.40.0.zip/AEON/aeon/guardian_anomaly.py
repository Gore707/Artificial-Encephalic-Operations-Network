from __future__ import annotations
from dataclasses import dataclass
import math,time

class AnomalyError(RuntimeError): pass

@dataclass(frozen=True)
class AnomalyAssessment:
    channel:str
    sample_count:int
    latest:float
    baseline_mean:float
    baseline_stddev:float
    z_score:float|None
    severity:str
    anomalous:bool
    provenance:str

class GuardianAnomalyDetector:
    """Lightweight deterministic/statistical anomaly analysis.

    P027 intentionally does not use an LLM. Thresholds are explicit and
    configurable. Statistical anomalies are evidence, not proof of hardware,
    data, or cognitive failure.
    """
    def __init__(self,guardian,telemetry_stream,audit,warning_z=4.0,advisory_z=3.0,min_samples=8):
        if warning_z<=advisory_z or advisory_z<=0: raise AnomalyError("invalid z thresholds")
        if min_samples<3: raise AnomalyError("min_samples must be >= 3")
        self.guardian=guardian;self.stream=telemetry_stream;self.audit=audit
        self.warning_z=float(warning_z);self.advisory_z=float(advisory_z);self.min_samples=int(min_samples)

    def assess_values(self,channel,values,provenance="MEASURED"):
        vals=tuple(float(v) for v in values)
        if len(vals)<self.min_samples: raise AnomalyError("insufficient samples")
        if any(not math.isfinite(v) for v in vals): raise AnomalyError("non-finite sample")
        baseline=vals[:-1];latest=vals[-1]
        mean=sum(baseline)/len(baseline)
        variance=sum((v-mean)**2 for v in baseline)/len(baseline)
        sd=math.sqrt(variance)
        if sd==0:
            z=0.0 if latest==mean else None
            anomalous=latest!=mean
            severity="WARNING" if anomalous else "NOMINAL"
        else:
            z=(latest-mean)/sd;az=abs(z)
            if az>=self.warning_z: severity="WARNING";anomalous=True
            elif az>=self.advisory_z: severity="ADVISORY";anomalous=True
            else: severity="NOMINAL";anomalous=False
        return AnomalyAssessment(str(channel),len(vals),latest,mean,sd,z,severity,anomalous,str(provenance))

    def assess_channel(self,channel,limit=64):
        samples=self.stream.read(channel=str(channel),limit=max(self.min_samples,int(limit)))
        if len(samples)<self.min_samples: raise AnomalyError("insufficient telemetry samples")
        units={s.unit for s in samples};provs={s.provenance for s in samples}
        if len(units)!=1: raise AnomalyError("mixed units cannot share a statistical baseline")
        provenance=next(iter(provs)) if len(provs)==1 else "MIXED"
        result=self.assess_values(channel,[s.value for s in samples],provenance)
        if result.anomalous:
            ztext="undefined-zero-variance" if result.z_score is None else f"{result.z_score:.4f}"
            confidence=min(0.999,0.50+(abs(result.z_score or self.warning_z)/(2*self.warning_z))*0.49)
            self.guardian.observe(
                "guardian.anomaly",
                f"Statistical deviation detected on {result.channel}; this is not by itself a fault diagnosis.",
                evidence=(f"latest={result.latest} {next(iter(units))}",
                          f"baseline_mean={result.baseline_mean}",
                          f"baseline_stddev={result.baseline_stddev}",f"z_score={ztext}",
                          f"sample_count={result.sample_count}"),
                status=result.severity,confidence_kind="STATISTICAL",
                confidence=confidence,provenance=result.provenance)
            self.audit.append("WARNING","guardian.anomaly","deviation_detected",subject=result.channel,
                              details={"severity":result.severity,"z_score":result.z_score,
                                       "sample_count":result.sample_count})
        return result
