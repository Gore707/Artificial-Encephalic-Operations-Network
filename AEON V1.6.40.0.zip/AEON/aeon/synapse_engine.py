from __future__ import annotations
from dataclasses import dataclass
import json,math,time,uuid

class SynapseEngineError(RuntimeError):pass

@dataclass(frozen=True)
class SynapseModel:
 model_id:str;model_type:str;parameters:dict;units:dict

@dataclass(frozen=True)
class SynapseState:
 state_id:str;model_id:str;created_unix:float;simulation_time_ms:float;values:dict

class SynapseEngine:
 """Deterministic executable synapse primitives; does not infer missing ANI physiology."""
 SUPPORTED=("CURRENT_EXPONENTIAL",)
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:
   c.execute("""CREATE TABLE IF NOT EXISTS synapse_models(model_id TEXT PRIMARY KEY,model_type TEXT NOT NULL,parameters_json TEXT NOT NULL,units_json TEXT NOT NULL)""")
   c.execute("""CREATE TABLE IF NOT EXISTS synapse_states(state_id TEXT PRIMARY KEY,model_id TEXT NOT NULL,created_unix REAL NOT NULL,simulation_time_ms REAL NOT NULL,values_json TEXT NOT NULL)""")
 @staticmethod
 def _finite(x,name):
  v=float(x)
  if not math.isfinite(v):raise SynapseEngineError(name+" must be finite")
  return v
 def create_current_exponential(self,weight_na,tau_ms=5.0,delay_ms=0.0):
  p={"weight_na":self._finite(weight_na,"weight_na"),"tau_ms":self._finite(tau_ms,"tau_ms"),"delay_ms":self._finite(delay_ms,"delay_ms")}
  if p["tau_ms"]<=0 or p["delay_ms"]<0:raise SynapseEngineError("tau must be > 0 and delay >= 0")
  mid="synapse-model-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO synapse_models VALUES(?,?,?,?)",(mid,"CURRENT_EXPONENTIAL",json.dumps(p,sort_keys=True),json.dumps({"time":"ms","current":"nA"})))
  self.audit.append("INFO","neural_simulacrum.synapse","model_created",subject=mid,details={"model_type":"CURRENT_EXPONENTIAL"})
  return self.get_model(mid)
 def get_model(self,mid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM synapse_models WHERE model_id=?",(mid,)).fetchone()
  if r is None:raise SynapseEngineError("unknown synapse model")
  return SynapseModel(r["model_id"],r["model_type"],json.loads(r["parameters_json"]),json.loads(r["units_json"]))
 def initialize(self,model_id):
  self.get_model(model_id);sid="synapse-state-"+uuid.uuid4().hex;now=time.time()
  vals={"current_na":0.0,"pending_events":[]}
  with self.db.transaction() as c:c.execute("INSERT INTO synapse_states VALUES(?,?,?,?,?)",(sid,model_id,now,0.0,json.dumps(vals,sort_keys=True)))
  return self.get_state(sid)
 def get_state(self,sid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM synapse_states WHERE state_id=?",(sid,)).fetchone()
  if r is None:raise SynapseEngineError("unknown synapse state")
  return SynapseState(r["state_id"],r["model_id"],r["created_unix"],r["simulation_time_ms"],json.loads(r["values_json"]))
 def emit_presynaptic_spike(self,state_id,amplitude_scale=1.0):
  s=self.get_state(state_id);m=self.get_model(s.model_id);scale=self._finite(amplitude_scale,"amplitude_scale")
  vals=dict(s.values);events=list(vals["pending_events"]);events.append({"delivery_ms":s.simulation_time_ms+m.parameters["delay_ms"],"delta_na":m.parameters["weight_na"]*scale})
  events.sort(key=lambda x:x["delivery_ms"]);vals["pending_events"]=events
  with self.db.transaction() as c:c.execute("UPDATE synapse_states SET values_json=? WHERE state_id=?",(json.dumps(vals,sort_keys=True),state_id))
  return self.get_state(state_id)
 def step(self,state_id,dt_ms):
  s=self.get_state(state_id);m=self.get_model(s.model_id);dt=self._finite(dt_ms,"dt_ms")
  if dt<=0:raise SynapseEngineError("dt_ms must be > 0")
  start=s.simulation_time_ms;end=start+dt;events=list(s.values["pending_events"]);cur=float(s.values["current_na"])
  # Exact exponential decay across subintervals; events are delivered at their scheduled time.
  cursor=start;remaining=[]
  for ev in events:
   t=float(ev["delivery_ms"])
   if t>end:
    remaining.append(ev);continue
   delivery=max(t,cursor);cur*=math.exp(-(delivery-cursor)/m.parameters["tau_ms"]);cursor=delivery;cur+=float(ev["delta_na"])
  cur*=math.exp(-(end-cursor)/m.parameters["tau_ms"])
  vals={"current_na":cur,"pending_events":remaining}
  with self.db.transaction() as c:c.execute("UPDATE synapse_states SET simulation_time_ms=?,values_json=? WHERE state_id=?",(end,json.dumps(vals,sort_keys=True),state_id))
  return self.get_state(state_id)
 def current(self,state_id):return float(self.get_state(state_id).values["current_na"])
 def summary(self):
  with self.db._connect() as c:
   models=c.execute("SELECT COUNT(*) n FROM synapse_models").fetchone()["n"];states=c.execute("SELECT COUNT(*) n FROM synapse_states").fetchone()["n"]
  return {"models":models,"states":states,"supported_models":self.SUPPORTED,
   "note":"Executable synapse parameters are explicit model inputs. Missing biological weight, delay, receptor, transmitter or plasticity state is never inferred here."}
