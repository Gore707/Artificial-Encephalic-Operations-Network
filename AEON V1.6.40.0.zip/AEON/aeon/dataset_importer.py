from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import csv,json,time,uuid
from .apotheosis_data_lab import EVIDENCE_CLASSES,PROVENANCE_CLASSES,DataLabError

class DatasetImportError(RuntimeError):pass

@dataclass(frozen=True)
class ImportPreview:
    path:str;format:str;size_bytes:int;rows_previewed:int;column_count:int|None
    headers:tuple[str,...];warnings:tuple[str,...]

class DatasetImporter:
    """Validated front door for scientific source-data ingestion."""
    SUPPORTED=("csv","json","jsonl","txt","tsv","bin","dat")
    def __init__(self,data_lab,audit):
        self.data_lab=data_lab;self.audit=audit
    def preview(self,path:Path,max_rows=20):
        p=Path(path)
        if not p.is_file():raise DatasetImportError("source file does not exist")
        fmt=p.suffix.lower().lstrip(".") or "bin"
        if fmt not in self.SUPPORTED:raise DatasetImportError(f"unsupported import format: {fmt}")
        warnings=[];headers=();rows=0;cols=None
        if fmt in ("csv","tsv"):
            delim="\t" if fmt=="tsv" else ","
            try:
                with p.open("r",encoding="utf-8-sig",newline="") as f:
                    r=csv.reader(f,delimiter=delim)
                    first=next(r,None)
                    if first is not None:
                        headers=tuple(first);cols=len(first);rows=1
                        for row in r:
                            rows+=1
                            if len(row)!=cols:warnings.append(f"row {rows} has {len(row)} columns; expected {cols}")
                            if rows>=max_rows:break
            except UnicodeDecodeError as exc:raise DatasetImportError("tabular source is not valid UTF-8") from exc
        elif fmt=="json":
            try:
                obj=json.loads(p.read_text(encoding="utf-8"))
                rows=len(obj) if isinstance(obj,list) else 1
                if isinstance(obj,list) and obj and isinstance(obj[0],dict):headers=tuple(obj[0].keys());cols=len(headers)
                elif isinstance(obj,dict):headers=tuple(obj.keys());cols=len(headers)
            except (UnicodeDecodeError,json.JSONDecodeError) as exc:raise DatasetImportError(f"invalid JSON: {exc}") from exc
        elif fmt=="jsonl":
            try:
                with p.open("r",encoding="utf-8") as f:
                    for n,line in enumerate(f,1):
                        if not line.strip():continue
                        obj=json.loads(line);rows+=1
                        if rows==1 and isinstance(obj,dict):headers=tuple(obj.keys());cols=len(headers)
                        if rows>=max_rows:break
            except (UnicodeDecodeError,json.JSONDecodeError) as exc:raise DatasetImportError(f"invalid JSONL: {exc}") from exc
        return ImportPreview(str(p),fmt,p.stat().st_size,rows,cols,headers,tuple(warnings))
    def import_file(self,path:Path,name:str,evidence_class:str,provenance:str,metadata=None):
        preview=self.preview(path)
        if evidence_class not in EVIDENCE_CLASSES:raise DatasetImportError("invalid evidence class")
        if provenance not in PROVENANCE_CLASSES:raise DatasetImportError("invalid provenance class")
        md=dict(metadata or {})
        md.update({"import_format":preview.format,"import_preview_rows":preview.rows_previewed,
                   "import_warnings":list(preview.warnings)})
        d=self.data_lab.register_file(Path(path),name,evidence_class,provenance,md)
        self.audit.append("INFO","apotheosis.import","dataset_imported",subject=d.dataset_id,
                          details={"format":preview.format,"warnings":list(preview.warnings)})
        return d
