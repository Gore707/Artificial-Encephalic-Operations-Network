from __future__ import annotations
from dataclasses import dataclass
import hashlib, json, time, uuid

class CognitiveInjectionWorkbenchError(RuntimeError):
    pass

STAGES = (
    "NEUROIMAGING",
    "VOLUME",
    "SEGMENTATION",
    "TRACING",
    "SYNAPSE_DETECTION",
    "CELL_CLASSIFICATION",
    "CONNECTOME",
)

@dataclass(frozen=True)
class CognitiveInjectionCase:
    case_id: str
    name: str
    created_unix: float
    imaging_id: str | None
    volume_id: str | None
    segmentation_id: str | None
    trace_ids: tuple[str, ...]
    synapse_detection_ids: tuple[str, ...]
    classification_ids: tuple[str, ...]
    connectome_id: str | None
    notes: str
    manifest_sha256: str

class CognitiveInjectionWorkbench:
    """Unified, integrity-checked P041-P047 workflow manifest.

    This service coordinates existing reconstruction records. It does not
    manufacture missing biological state and does not claim MSCS sufficiency.
    """
    def __init__(self, db, audit, neuroimaging, volumes, segmentations, traces,
                 synapses, classifications, connectomes):
        self.db = db
        self.audit = audit
        self.neuroimaging = neuroimaging
        self.volumes = volumes
        self.segmentations = segmentations
        self.traces = traces
        self.synapses = synapses
        self.classifications = classifications
        self.connectomes = connectomes
        self._schema()

    def _schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS cognitive_injection_cases(
                case_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                created_unix REAL NOT NULL,
                imaging_id TEXT,
                volume_id TEXT,
                segmentation_id TEXT,
                trace_ids_json TEXT NOT NULL,
                synapse_detection_ids_json TEXT NOT NULL,
                classification_ids_json TEXT NOT NULL,
                connectome_id TEXT,
                notes TEXT NOT NULL,
                manifest_sha256 TEXT NOT NULL
            )""")

    @staticmethod
    def _canon(value):
        return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    def _validate_chain(self, imaging_id=None, volume_id=None, segmentation_id=None,
                        trace_ids=(), synapse_detection_ids=(), classification_ids=(),
                        connectome_id=None):
        bindings = {}
        imaging = volume = segmentation = None

        if imaging_id is not None:
            imaging = self.neuroimaging.get(str(imaging_id))
            if not self.neuroimaging.verify(str(imaging_id))["all_ok"]:
                raise CognitiveInjectionWorkbenchError("neuroimaging integrity verification failed")
            bindings["NEUROIMAGING"] = imaging.metadata_sha256

        if volume_id is not None:
            volume = self.volumes.get(str(volume_id))
            if not self.volumes.verify(str(volume_id))["all_ok"]:
                raise CognitiveInjectionWorkbenchError("volume integrity verification failed")
            if imaging_id is not None and volume.imaging_id != str(imaging_id):
                raise CognitiveInjectionWorkbenchError("volume is not derived from selected neuroimaging record")
            bindings["VOLUME"] = volume.definition_sha256

        if segmentation_id is not None:
            segmentation = self.segmentations.get(str(segmentation_id))
            if not self.segmentations.verify(str(segmentation_id))["all_ok"]:
                raise CognitiveInjectionWorkbenchError("segmentation integrity verification failed")
            if volume_id is not None and segmentation.volume_id != str(volume_id):
                raise CognitiveInjectionWorkbenchError("segmentation is not bound to selected volume")
            bindings["SEGMENTATION"] = segmentation.definition_sha256

        for tid in tuple(str(x) for x in trace_ids):
            tr = self.traces.get(tid)
            if not self.traces.verify(tid)["all_ok"]:
                raise CognitiveInjectionWorkbenchError("trace integrity verification failed")
            if segmentation_id is not None and tr.segmentation_id != str(segmentation_id):
                raise CognitiveInjectionWorkbenchError("trace is not bound to selected segmentation")
            bindings["TRACE:" + tid] = tr.definition_sha256

        for did in tuple(str(x) for x in synapse_detection_ids):
            det = self.synapses.get(did)
            if not self.synapses.verify(did)["all_ok"]:
                raise CognitiveInjectionWorkbenchError("synapse detection integrity verification failed")
            bindings["SYNAPSE_DETECTION:" + did] = det.definition_sha256

        for cid in tuple(str(x) for x in classification_ids):
            cl = self.classifications.get(cid)
            if not self.classifications.verify(cid)["all_ok"]:
                raise CognitiveInjectionWorkbenchError("classification integrity verification failed")
            if segmentation_id is not None and cl.segmentation_id != str(segmentation_id):
                raise CognitiveInjectionWorkbenchError("classification is not bound to selected segmentation")
            bindings["CELL_CLASSIFICATION:" + cid] = cl.definition_sha256

        if connectome_id is not None:
            conn = self.connectomes.get(str(connectome_id))
            if not self.connectomes.verify(str(connectome_id))["all_ok"]:
                raise CognitiveInjectionWorkbenchError("connectome integrity verification failed")
            bindings["CONNECTOME"] = conn.definition_sha256

        return tuple(sorted(bindings.items()))

    def create_case(self, name, imaging_id=None, volume_id=None, segmentation_id=None,
                    trace_ids=(), synapse_detection_ids=(), classification_ids=(),
                    connectome_id=None, notes=""):
        name = str(name).strip()
        if not name:
            raise CognitiveInjectionWorkbenchError("case name required")
        trace_ids = tuple(str(x) for x in trace_ids)
        synapse_detection_ids = tuple(str(x) for x in synapse_detection_ids)
        classification_ids = tuple(str(x) for x in classification_ids)
        bindings = self._validate_chain(
            imaging_id, volume_id, segmentation_id, trace_ids,
            synapse_detection_ids, classification_ids, connectome_id
        )
        payload = {
            "name": name,
            "imaging_id": str(imaging_id) if imaging_id is not None else None,
            "volume_id": str(volume_id) if volume_id is not None else None,
            "segmentation_id": str(segmentation_id) if segmentation_id is not None else None,
            "trace_ids": trace_ids,
            "synapse_detection_ids": synapse_detection_ids,
            "classification_ids": classification_ids,
            "connectome_id": str(connectome_id) if connectome_id is not None else None,
            "notes": str(notes),
            "bindings": bindings,
        }
        sha = hashlib.sha256(self._canon(payload).encode("utf-8")).hexdigest()
        case_id = "ci-" + uuid.uuid4().hex
        now = time.time()
        with self.db.transaction() as c:
            c.execute(
                "INSERT INTO cognitive_injection_cases VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (case_id, name, now, payload["imaging_id"], payload["volume_id"],
                 payload["segmentation_id"], json.dumps(trace_ids),
                 json.dumps(synapse_detection_ids), json.dumps(classification_ids),
                 payload["connectome_id"], payload["notes"], sha)
            )
        self.audit.append(
            "INFO", "cognitive_injection.workbench", "case_created", subject=case_id,
            details={"name": name, "bindings": dict(bindings), "manifest_sha256": sha}
        )
        return self.get(case_id)

    def get(self, case_id):
        with self.db._connect() as c:
            r = c.execute("SELECT * FROM cognitive_injection_cases WHERE case_id=?", (case_id,)).fetchone()
        if r is None:
            raise CognitiveInjectionWorkbenchError("unknown Cognitive Injection case")
        return CognitiveInjectionCase(
            r["case_id"], r["name"], r["created_unix"], r["imaging_id"], r["volume_id"],
            r["segmentation_id"], tuple(json.loads(r["trace_ids_json"])),
            tuple(json.loads(r["synapse_detection_ids_json"])),
            tuple(json.loads(r["classification_ids_json"])), r["connectome_id"],
            r["notes"], r["manifest_sha256"]
        )

    def verify(self, case_id):
        q = self.get(case_id)
        try:
            bindings = self._validate_chain(
                q.imaging_id, q.volume_id, q.segmentation_id, q.trace_ids,
                q.synapse_detection_ids, q.classification_ids, q.connectome_id
            )
            source_ok = True
        except Exception:
            bindings = ()
            source_ok = False
        payload = {
            "name": q.name, "imaging_id": q.imaging_id, "volume_id": q.volume_id,
            "segmentation_id": q.segmentation_id, "trace_ids": q.trace_ids,
            "synapse_detection_ids": q.synapse_detection_ids,
            "classification_ids": q.classification_ids,
            "connectome_id": q.connectome_id, "notes": q.notes, "bindings": bindings,
        }
        manifest_ok = hashlib.sha256(self._canon(payload).encode("utf-8")).hexdigest() == q.manifest_sha256
        return {"manifest_ok": manifest_ok, "source_ok": source_ok, "all_ok": manifest_ok and source_ok}

    def status(self, case_id):
        q = self.get(case_id)
        present = {
            "NEUROIMAGING": q.imaging_id is not None,
            "VOLUME": q.volume_id is not None,
            "SEGMENTATION": q.segmentation_id is not None,
            "TRACING": bool(q.trace_ids),
            "SYNAPSE_DETECTION": bool(q.synapse_detection_ids),
            "CELL_CLASSIFICATION": bool(q.classification_ids),
            "CONNECTOME": q.connectome_id is not None,
        }
        return {
            "case_id": case_id,
            "stages": present,
            "completed_stages": sum(present.values()),
            "total_stages": len(STAGES),
            "integrity": self.verify(case_id),
            "information_sufficiency": "UNDETERMINED",
            "note": "Pipeline completion is not proof of Minimum Sufficient Cognitive State or upload feasibility.",
        }

    def list(self, limit=250):
        with self.db._connect() as c:
            ids = [r["case_id"] for r in c.execute(
                "SELECT case_id FROM cognitive_injection_cases ORDER BY created_unix DESC LIMIT ?",
                (int(limit),)
            ).fetchall()]
        return tuple(self.get(x) for x in ids)
