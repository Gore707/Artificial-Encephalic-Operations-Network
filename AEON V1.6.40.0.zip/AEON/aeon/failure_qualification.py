from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,os,tempfile,time,uuid

@dataclass(frozen=True)
class QualificationCase:
    name:str;passed:bool;detail:str
@dataclass(frozen=True)
class QualificationReport:
    report_id:str;created_unix:float;passed:bool;cases:tuple[QualificationCase,...]

class FailureQualification:
    """Destructive qualification using disposable artifacts only.

    This service never corrupts catalogued source ANI/data or live user files.
    It creates isolated temporary artifacts and verifies detection/recovery
    behavior against them.
    """
    def __init__(self,services,audit):
        self.s=services;self.audit=audit

    def run(self):
        cases=[]
        def case(name,fn):
            try: cases.append(QualificationCase(name,True,str(fn())))
            except Exception as exc: cases.append(QualificationCase(name,False,f"{type(exc).__name__}: {exc}"))
        case("bit_flip.detected",self._bit_flip)
        case("truncation.detected",self._truncate)
        case("transaction.stale_write_blocked",self._stale_write)
        case("backup.rollback.verified",self._rollback)
        case("genesis.corruption.lockout",self._genesis_lockout)
        rid="qrep-"+uuid.uuid4().hex;now=time.time();passed=all(c.passed for c in cases)
        self.audit.append("INFO" if passed else "CRITICAL","qualification","failure_injection",subject=rid,
                          details={"passed":passed,"failed":[c.name for c in cases if not c.passed]})
        return QualificationReport(rid,now,passed,tuple(cases))

    def _bit_flip(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"disposable.bin";p.write_bytes(b"A"*8192)
            rec=self.s.integrity.register_file("qualification","bitflip",p)
            b=bytearray(p.read_bytes());b[4097]^=0x01;p.write_bytes(b)
            v=self.s.integrity.verify(rec.record_id)
            if v.ok:raise RuntimeError("deliberate bit flip was not detected")
            return f"detected; bad_chunks={v.bad_chunks}"

    def _truncate(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"disposable.bin";p.write_bytes(b"B"*8192)
            rec=self.s.integrity.register_file("qualification","truncate",p)
            p.write_bytes(b"B"*1024)
            v=self.s.integrity.verify(rec.record_id)
            if v.ok:raise RuntimeError("deliberate truncation was not detected")
            return "detected"

    def _stale_write(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"mutable.bin";p.write_bytes(b"v1")
            expected=hashlib.sha256(b"v1").hexdigest()
            p.write_bytes(b"externally-changed")
            try:self.s.transactional_files.write_bytes(p,b"v2",expected_sha256=expected)
            except Exception:return "stale expected digest rejected"
            raise RuntimeError("stale write unexpectedly succeeded")

    def _rollback(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"recover.bin"
            self.s.transactional_files.write_bytes(p,b"v1")
            self.s.transactional_files.write_bytes(p,b"v2")
            backups=self.s.transactional_files.backups(target=p)
            if not backups:raise RuntimeError("no pre-replacement backup")
            b=backups[0]
            self.s.recovery.rollback(b.backup_id,expected_current_sha256=hashlib.sha256(b"v2").hexdigest())
            if p.read_bytes()!=b"v1":raise RuntimeError("rollback content mismatch")
            return "verified v2 -> v1; displaced state preserved by transactional layer"

    def _genesis_lockout(self):
        state={"nodes":[{"id":"dup"},{"id":"dup"}],
               "edges":[{"source":"dup","target":"missing"}],
               "parameters":{"x":float("inf")},
               "provenance":{"x":"UNKNOWN"},
               "model_checks":[]}
        r=self.s.genesis.validate("qualification-corrupt",state)
        if r.passed:raise RuntimeError("corrupt Genesis state passed")
        try:self.s.genesis.require_pass(r)
        except Exception:return "invalid executable neural state locked before tick 0"
        raise RuntimeError("Genesis lockout failed")


@dataclass(frozen=True)
class P081QualificationRecord:
 qualification_id:str;created_unix:float;scenario:str;subject:str;expected_containment:str;observed_json:str;passed:bool

class FailureCorruptionQualification:
 """P081 disposable Neural Cache fault qualification; legacy P031 API remains intact."""
 SCENARIOS=("NEURAL_CACHE_BIT_FLIP","NEURAL_CACHE_TRUNCATION","REPLICA_RECOVERY")
 def __init__(self,db,audit,blocks,redundancy):
  self.db=db;self.audit=audit;self.blocks=blocks;self.redundancy=redundancy;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p081_failure_corruption_qualifications(
   qualification_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,scenario TEXT NOT NULL,subject TEXT NOT NULL,
   expected_containment TEXT NOT NULL,observed_json TEXT NOT NULL,passed INTEGER NOT NULL)""")
 def _record(self,scenario,subject,expected,observed,passed):
  import uuid,time,json
  qid="p081-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p081_failure_corruption_qualifications VALUES(?,?,?,?,?,?,?)",(qid,time.time(),scenario,subject,expected,json.dumps(observed,sort_keys=True),1 if passed else 0))
  self.audit.append("INFO" if passed else "CRITICAL","failure_qualification.p081",scenario.lower(),subject=qid,details={"target":subject,"passed":passed,"expected":expected})
  return self.get(qid)
 def _require_disposable(self,bid):
  b=self.blocks.get(bid)
  if not bool(b.metadata.get("disposable_failure_test",False)):raise RuntimeError("fault injection requires disposable_failure_test=true")
  return b
 def bit_flip(self,bid):
  from pathlib import Path
  b=self._require_disposable(bid);p=Path(b.path);raw=bytearray(p.read_bytes())
  if not raw:raise RuntimeError("empty test artifact")
  raw[-1]^=1;p.write_bytes(raw);v=self.blocks.verify(bid)
  return self._record("NEURAL_CACHE_BIT_FLIP",bid,"P076 integrity gate rejects corrupted block",v,not v["all_ok"])
 def truncate(self,bid):
  from pathlib import Path
  b=self._require_disposable(bid);p=Path(b.path);raw=p.read_bytes()
  if len(raw)<2:raise RuntimeError("artifact too small")
  p.write_bytes(raw[:len(raw)//2]);v=self.blocks.verify(bid)
  return self._record("NEURAL_CACHE_TRUNCATION",bid,"P076 integrity gate rejects truncated block",v,not v["all_ok"])
 def replica_recovery(self,rid):
  from pathlib import Path
  r=self.redundancy.get(rid);src=self._require_disposable(r.source_block_id);p=Path(src.path);raw=bytearray(p.read_bytes());raw[-1]^=1;p.write_bytes(raw)
  v=self.redundancy.verify(rid);recovered=None
  try:recovered=self.redundancy.recover(rid);ok=v["recoverable"] and recovered is not None
  except Exception:ok=False
  return self._record("REPLICA_RECOVERY",rid,"corrupt primary rejected and verified replica recoverable",{"status":v["status"],"recoverable":v["recoverable"],"recovered_bytes":0 if recovered is None else len(recovered)},ok)
 def get(self,qid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p081_failure_corruption_qualifications WHERE qualification_id=?",(qid,)).fetchone()
  if r is None:raise RuntimeError("unknown P081 qualification")
  return P081QualificationRecord(r["qualification_id"],r["created_unix"],r["scenario"],r["subject"],r["expected_containment"],r["observed_json"],bool(r["passed"]))
 def summary(self):
  with self.db._connect() as c:
   total=c.execute("SELECT COUNT(*) n FROM p081_failure_corruption_qualifications").fetchone()["n"];passed=c.execute("SELECT COUNT(*) n FROM p081_failure_corruption_qualifications WHERE passed=1").fetchone()["n"]
  return {"phase":"FAILURE & CORRUPTION VALIDATION I","executed":total,"passed":passed,"scope":"Disposable Neural Cache artifacts only; live/source ANI mutation is forbidden."}
