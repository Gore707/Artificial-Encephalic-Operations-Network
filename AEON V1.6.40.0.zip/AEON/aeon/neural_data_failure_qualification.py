from __future__ import annotations
from dataclasses import dataclass
import json,math,time,uuid

class NeuralDataFailureQualificationError(RuntimeError):pass

@dataclass(frozen=True)
class NeuralDataFailureResult:
 qualification_id:str;created_unix:float;scenario:str;passed:bool;observed_json:str

class NeuralDataFailureQualification:
 """P085 malformed-neural-data and reconstruction provenance fault qualification.
 Deterministic test vectors only; no identity/consciousness or biological-sufficiency claim.
 """
 SCENARIOS=("NONFINITE_STATE","INVALID_TOPOLOGY_REFERENCE","UNLABELED_RECONSTRUCTION","LOW_CONFIDENCE_AI_RECONSTRUCTION")
 VALID_PROVENANCE={"MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN"}
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p085_neural_data_failure_qualifications(
   qualification_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,scenario TEXT NOT NULL,passed INTEGER NOT NULL,observed_json TEXT NOT NULL)""")
 def _record(self,scenario,passed,obs):
  qid="p085-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p085_neural_data_failure_qualifications VALUES(?,?,?,?,?)",(qid,time.time(),scenario,1 if passed else 0,json.dumps(obs,sort_keys=True)))
  self.audit.append("INFO" if passed else "CRITICAL","failure_qualification.p085",scenario.lower(),subject=qid,details=obs);return self.get(qid)
 def nonfinite_state(self,values):
  vals=tuple(float(x) for x in values);bad=[i for i,v in enumerate(vals) if not math.isfinite(v)]
  detected=bool(bad);return self._record("NONFINITE_STATE",detected,{"count":len(vals),"nonfinite_indices":bad,"execution_allowed":not detected})
 def invalid_topology_reference(self,node_ids,edges):
  nodes=set(str(x) for x in node_ids);bad=[]
  for i,e in enumerate(edges):
   if len(e)!=2 or str(e[0]) not in nodes or str(e[1]) not in nodes:bad.append(i)
  detected=bool(bad);return self._record("INVALID_TOPOLOGY_REFERENCE",detected,{"nodes":len(nodes),"edges":len(tuple(edges)),"invalid_edge_indices":bad,"execution_allowed":not detected})
 def unlabeled_reconstruction(self,records):
  bad=[]
  for i,r in enumerate(records):
   p=str(dict(r).get("provenance","")).upper()
   if p not in self.VALID_PROVENANCE:bad.append(i)
  detected=bool(bad);return self._record("UNLABELED_RECONSTRUCTION",detected,{"records":len(records),"invalid_provenance_indices":bad,"accepted":not detected})
 def low_confidence_ai_reconstruction(self,confidence,minimum):
  c=float(confidence);m=float(minimum)
  if not 0<=c<=1 or not 0<=m<=1:raise NeuralDataFailureQualificationError("confidence must be [0,1]")
  flagged=c<m
  return self._record("LOW_CONFIDENCE_AI_RECONSTRUCTION",flagged,{"provenance":"AI-RECONSTRUCTED","confidence":c,"minimum":m,"flagged":flagged,"treated_as_measured":False})
 def get(self,qid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p085_neural_data_failure_qualifications WHERE qualification_id=?",(qid,)).fetchone()
  if r is None:raise NeuralDataFailureQualificationError("unknown P085 qualification")
  return NeuralDataFailureResult(r["qualification_id"],r["created_unix"],r["scenario"],bool(r["passed"]),r["observed_json"])
 def summary(self):
  with self.db._connect() as c:
   total=c.execute("SELECT COUNT(*) n FROM p085_neural_data_failure_qualifications").fetchone()["n"];passed=c.execute("SELECT COUNT(*) n FROM p085_neural_data_failure_qualifications WHERE passed=1").fetchone()["n"]
  return {"phase":"FAILURE & CORRUPTION VALIDATION V","executed":total,"passed":passed,
   "scope":"Malformed numeric state, dangling topology references, missing provenance, and low-confidence AI reconstruction. These tests do not close the broader GSVL execution-gate debt."}
