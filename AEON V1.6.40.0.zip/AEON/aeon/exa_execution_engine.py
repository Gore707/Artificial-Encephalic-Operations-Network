from __future__ import annotations
from dataclasses import dataclass
import time,uuid

class ExaExecutionError(RuntimeError):pass

@dataclass(frozen=True)
class ExaExecutionRun:
 run_id:str;created_unix:float;network_id:str;plan_id:str;status:str;logical_step:int;simulation_time:float;time_unit:str

class ExaExecutionEngine:
 """P074 integration boundary for bounded distributed neural execution.
 Does not grant arbitrary remote execution or override deterministic safety controls.
 """
 STATUSES=("CREATED","READY","RUNNING","HELD","STOPPED")
 def __init__(self,db,audit,node_server,transport,partitioner,checkpoints,cluster):
  self.db=db;self.audit=audit;self.node_server=node_server;self.transport=transport;self.partitioner=partitioner
  self.checkpoints=checkpoints;self.cluster=cluster;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS exa_execution_runs(
   run_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,network_id TEXT NOT NULL,plan_id TEXT NOT NULL,status TEXT NOT NULL,
   logical_step INTEGER NOT NULL,simulation_time REAL NOT NULL,time_unit TEXT NOT NULL)""")
 def create_run(self,network_id,plan_id,time_unit):
  v=self.partitioner.verify(plan_id);p=self.partitioner.get(plan_id)
  if not v.get("all_ok",False) or p.network_id!=network_id:raise ExaExecutionError("verified matching partition plan required")
  nodes={n.node_id:n for n in self.cluster.list_nodes()}
  required=set(p.assignments.values())
  missing=required-set(nodes)
  if missing:raise ExaExecutionError("partition plan references unregistered nodes: "+",".join(sorted(missing)))
  unavailable=[n for n in required if nodes[n].status not in ("REGISTERED","ONLINE")]
  if unavailable:raise ExaExecutionError("required nodes are unavailable: "+",".join(sorted(unavailable)))
  unit=str(time_unit).strip()
  if not unit:raise ExaExecutionError("time_unit required")
  rid="exarun-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO exa_execution_runs VALUES(?,?,?,?,?,?,?,?)",(rid,time.time(),network_id,plan_id,"READY",0,0.0,unit))
  self.audit.append("INFO","exa_execution.engine","run_created",subject=rid,details={"network_id":network_id,"plan_id":plan_id,"nodes":len(required)})
  return self.get(rid)
 def get(self,rid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM exa_execution_runs WHERE run_id=?",(rid,)).fetchone()
  if r is None:raise ExaExecutionError("unknown Exa run")
  return ExaExecutionRun(r["run_id"],r["created_unix"],r["network_id"],r["plan_id"],r["status"],r["logical_step"],r["simulation_time"],r["time_unit"])
 def _set(self,rid,status,step=None,sim=None):
  q=self.get(rid)
  with self.db.transaction() as c:c.execute("UPDATE exa_execution_runs SET status=?,logical_step=?,simulation_time=? WHERE run_id=?",(status,q.logical_step if step is None else int(step),q.simulation_time if sim is None else float(sim),rid))
  return self.get(rid)
 def start(self,rid):
  q=self.get(rid)
  if q.status!="READY":raise ExaExecutionError("only READY runs may start")
  p=self.partitioner.get(q.plan_id);nodes={n.node_id:n for n in self.cluster.list_nodes()}
  bad=[n for n in set(p.assignments.values()) if n not in nodes or nodes[n].status!="ONLINE"]
  if bad:raise ExaExecutionError("all required nodes must be ONLINE before start")
  out=self._set(rid,"RUNNING");self.audit.append("INFO","exa_execution.engine","run_started",subject=rid,details={});return out
 def commit(self,rid,logical_step,simulation_time):
  q=self.get(rid)
  if q.status!="RUNNING":raise ExaExecutionError("run is not RUNNING")
  step=int(logical_step);sim=float(simulation_time)
  if step!=q.logical_step+1 or sim<q.simulation_time:raise ExaExecutionError("non-monotonic distributed commit")
  return self._set(rid,"RUNNING",step,sim)
 def hold(self,rid,reason):
  q=self.get(rid);reason=str(reason).strip()
  if q.status not in ("READY","RUNNING") or not reason:raise ExaExecutionError("active run and hold reason required")
  out=self._set(rid,"HELD");self.audit.append("WARNING","exa_execution.engine","run_held",subject=rid,details={"reason":reason});return out
 def stop(self,rid):
  q=self.get(rid)
  if q.status=="STOPPED":return q
  out=self._set(rid,"STOPPED");self.audit.append("INFO","exa_execution.engine","run_stopped",subject=rid,details={});return out
 def attach_checkpoint(self,rid,checkpoint_id):
  q=self.get(rid);c=self.checkpoints.get(checkpoint_id);v=self.checkpoints.verify(checkpoint_id)
  if not v.get("all_ok",False) or c.run_id!=rid or c.plan_id!=q.plan_id:raise ExaExecutionError("checkpoint does not belong to this verified run/plan")
  if c.logical_step!=q.logical_step or c.simulation_time!=q.simulation_time or c.time_unit!=q.time_unit:raise ExaExecutionError("checkpoint instant does not match run")
  return {"run_id":rid,"checkpoint_id":checkpoint_id,"verified":True}
 def readiness(self,rid):
  q=self.get(rid);p=self.partitioner.verify(q.plan_id)
  nodes={n.node_id:n.status for n in self.cluster.list_nodes()};req=set(self.partitioner.get(q.plan_id).assignments.values())
  return {"run_id":rid,"status":q.status,"partition_plan_ok":bool(p.get("all_ok",False)),
   "required_nodes":sorted(req),"node_status":{n:nodes.get(n,"MISSING") for n in sorted(req)},
   "control_protocol":"AEON-EXA-NODE/1","data_transport":"AEONX1","arbitrary_remote_execution":False,
   "safety_authority":"AEON SAFETY KERNEL / DETERMINISTIC",
   "production_security_qualified":False,
   "note":"P074 integrates Exa services; TLS/key management, hard resource enforcement, watchdog/replay journal and production safety/security qualification remain later work."}
 def summary(self):
  with self.db._connect() as c:
   total=c.execute("SELECT COUNT(*) n FROM exa_execution_runs").fetchone()["n"]
   active=c.execute("SELECT COUNT(*) n FROM exa_execution_runs WHERE status IN ('READY','RUNNING','HELD')").fetchone()["n"]
  return {"release":"EXA-EXECUTION ENGINE 1.0","runs":total,"active":active}
