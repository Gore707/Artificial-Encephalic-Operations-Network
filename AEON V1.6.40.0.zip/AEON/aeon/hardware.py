from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import ctypes
import os
import platform
import shutil
import time


@dataclass(frozen=True)
class CPUInfo:
    logical_processors: int
    architecture: str
    vendor: str | None
    model: str | None


@dataclass(frozen=True)
class MemoryInfo:
    total_bytes: int | None
    available_bytes: int | None


@dataclass(frozen=True)
class StorageVolume:
    path: str
    total_bytes: int
    used_bytes: int
    free_bytes: int


@dataclass(frozen=True)
class HardwareInventory:
    timestamp_unix: float
    operating_system: str
    machine: str
    cpu: CPUInfo
    memory: MemoryInfo
    storage: tuple[StorageVolume, ...]


class HardwareDiscovery:
    """Measured CPU, physical-memory, and mounted-storage inventory.

    Discovery uses operating-system interfaces only. Unknown fields remain None;
    AEON does not synthesize hardware names or capacities.
    """

    def __init__(self, root: Path):
        self.root = Path(root)

    def discover(self) -> HardwareInventory:
        return HardwareInventory(
            timestamp_unix=time.time(),
            operating_system=platform.platform(),
            machine=platform.machine(),
            cpu=self._cpu(),
            memory=self._memory(),
            storage=self._storage(),
        )

    def _cpu(self) -> CPUInfo:
        model = None
        vendor = None
        system = platform.system()

        if system == "Windows":
            try:
                import winreg
                with winreg.OpenKey(
                    winreg.HKEY_LOCAL_MACHINE,
                    r"HARDWARE\DESCRIPTION\System\CentralProcessor\0"
                ) as key:
                    model = str(winreg.QueryValueEx(key, "ProcessorNameString")[0]).strip() or None
                    try:
                        vendor = str(winreg.QueryValueEx(key, "VendorIdentifier")[0]).strip() or None
                    except OSError:
                        pass
            except (OSError, ImportError):
                pass
        elif system == "Linux":
            try:
                fields = {}
                for line in Path("/proc/cpuinfo").read_text(
                    encoding="utf-8", errors="replace"
                ).splitlines():
                    if ":" in line:
                        k, v = line.split(":", 1)
                        fields.setdefault(k.strip(), v.strip())
                model = fields.get("model name") or fields.get("Processor")
                vendor = fields.get("vendor_id") or fields.get("CPU implementer")
            except OSError:
                pass
        else:
            model = platform.processor().strip() or None

        return CPUInfo(
            logical_processors=os.cpu_count() or 1,
            architecture=platform.machine() or "unknown",
            vendor=vendor,
            model=model,
        )

    def _memory(self) -> MemoryInfo:
        if platform.system() == "Windows":
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]
            state = MEMORYSTATUSEX()
            state.dwLength = ctypes.sizeof(state)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):
                return MemoryInfo(int(state.ullTotalPhys), int(state.ullAvailPhys))
            return MemoryInfo(None, None)

        if platform.system() == "Linux":
            try:
                values = {}
                for line in Path("/proc/meminfo").read_text().splitlines():
                    if ":" in line:
                        key, value = line.split(":", 1)
                        values[key] = int(value.strip().split()[0]) * 1024
                return MemoryInfo(values.get("MemTotal"), values.get("MemAvailable"))
            except (OSError, ValueError):
                return MemoryInfo(None, None)

        try:
            pages = os.sysconf("SC_PHYS_PAGES")
            page_size = os.sysconf("SC_PAGE_SIZE")
            avail_pages = os.sysconf("SC_AVPHYS_PAGES")
            return MemoryInfo(int(pages * page_size), int(avail_pages * page_size))
        except (AttributeError, OSError, ValueError):
            return MemoryInfo(None, None)

    def _storage(self) -> tuple[StorageVolume, ...]:
        paths: list[str] = []
        if platform.system() == "Windows":
            mask = ctypes.windll.kernel32.GetLogicalDrives()
            for i in range(26):
                if mask & (1 << i):
                    root = f"{chr(65+i)}:\\"
                    # Only report volumes whose capacity can actually be queried.
                    try:
                        shutil.disk_usage(root)
                    except OSError:
                        continue
                    paths.append(root)
        elif platform.system() == "Linux":
            try:
                pseudo = {
                    "proc","sysfs","tmpfs","devtmpfs","devpts","cgroup","cgroup2",
                    "securityfs","pstore","debugfs","tracefs","configfs","fusectl",
                    "mqueue","hugetlbfs","rpc_pipefs","overlay"
                }
                for line in Path("/proc/mounts").read_text(
                    encoding="utf-8", errors="replace"
                ).splitlines():
                    parts = line.split()
                    if len(parts) >= 3 and parts[2] not in pseudo:
                        mount = parts[1].replace(r"\040", " ")
                        if os.path.isdir(mount):
                            paths.append(mount)
            except OSError:
                pass
        else:
            paths.append(str(self.root.anchor or "/"))

        # Always include the filesystem containing AEON itself.
        try:
            root_resolved = self.root.resolve()
            candidate = root_resolved.anchor or "/"
            paths.append(candidate)
        except OSError:
            pass

        seen = set()
        volumes = []
        for path in paths:
            try:
                canonical = os.path.realpath(path)
                usage = shutil.disk_usage(path)
            except OSError:
                continue
            key = (canonical, usage.total)
            if key in seen:
                continue
            seen.add(key)
            volumes.append(StorageVolume(
                path=path,
                total_bytes=int(usage.total),
                used_bytes=int(usage.used),
                free_bytes=int(usage.free),
            ))
        return tuple(volumes)
