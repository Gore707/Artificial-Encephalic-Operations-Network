from __future__ import annotations
from dataclasses import dataclass
import json,socket,threading,time,uuid
from .node_protocol import PROTOCOL_VERSION,NodeProtocolError

class ClusterError(RuntimeError):pass

DISCOVERY_MAGIC="AEON_DISCOVERY_V1"

@dataclass(frozen=True)
class LocalNode:
    node_id:str;hostname:str;listen_port:int;protocol_version:int=PROTOCOL_VERSION

class ClusterManager:
    """Conservative LAN discovery and peer liveness management.

    Discovery is opt-in: start() must be called explicitly. It uses UDP broadcast
    only for presence announcements; it does not execute commands or trust peers
    for work. P025 adds controlled distributed execution.
    """
    def __init__(self,db,audit,nodes,port=48230,stale_seconds=15.0):
        self.db=db;self.audit=audit;self.nodes=nodes;self.port=int(port);self.stale=float(stale_seconds)
        self.local=self._load_local();self._stop=threading.Event();self._thread=None;self._sock=None

    def _load_local(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS cluster_local(
              singleton INTEGER PRIMARY KEY CHECK(singleton=1),node_id TEXT NOT NULL,
              hostname TEXT NOT NULL,listen_port INTEGER NOT NULL)""")
            r=c.execute("SELECT * FROM cluster_local WHERE singleton=1").fetchone()
            if r is None:
                nid="node-"+uuid.uuid4().hex;host=socket.gethostname()
                c.execute("INSERT INTO cluster_local VALUES(1,?,?,?)",(nid,host,self.port))
                return LocalNode(nid,host,self.port)
            return LocalNode(r["node_id"],r["hostname"],r["listen_port"])

    @property
    def running(self):return bool(self._thread and self._thread.is_alive())

    def start(self):
        if self.running:return
        self._stop.clear()
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM,socket.IPPROTO_UDP)
        s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        s.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1)
        s.bind(("",self.port));s.settimeout(.5);self._sock=s
        self._thread=threading.Thread(target=self._loop,name="aeon-cluster-discovery",daemon=True);self._thread.start()
        self.audit.append("INFO","cluster","discovery_started",subject=self.local.node_id,details={"port":self.port})

    def stop(self):
        self._stop.set()
        if self._sock:
            try:self._sock.close()
            except OSError:pass
        if self._thread:self._thread.join(timeout=2)
        self._thread=None;self._sock=None

    def announce(self,address="255.255.255.255"):
        if not self._sock:raise ClusterError("cluster discovery is not running")
        payload={"magic":DISCOVERY_MAGIC,"node_id":self.local.node_id,"hostname":self.local.hostname,
                 "protocol_version":PROTOCOL_VERSION,"service_port":self.local.listen_port}
        self._sock.sendto(json.dumps(payload,separators=(",",":")).encode(),(address,self.port))

    def ingest(self,data:bytes,address):
        try:d=json.loads(data.decode())
        except Exception as exc:raise ClusterError("malformed discovery packet") from exc
        if d.get("magic")!=DISCOVERY_MAGIC:raise ClusterError("not an AEON discovery packet")
        if d.get("protocol_version")!=PROTOCOL_VERSION:raise ClusterError("incompatible protocol")
        nid=str(d.get("node_id",""))
        if not nid or nid==self.local.node_id:return None
        service_port=int(d.get("service_port",self.port))
        peer=self.nodes.observe(nid,f"{address[0]}:{service_port}","ONLINE",PROTOCOL_VERSION)
        return peer

    def refresh_liveness(self,now=None):
        now=time.time() if now is None else float(now);changed=[]
        for p in self.nodes.list():
            desired="ONLINE" if now-p.last_seen_unix<=self.stale else "STALE"
            if desired!=p.status:
                changed.append(self.nodes.observe(p.node_id,p.address,desired,p.protocol_version))
        return tuple(changed)

    def _loop(self):
        last_announce=0.0
        while not self._stop.is_set():
            now=time.time()
            if now-last_announce>=5:
                try:self.announce()
                except OSError:pass
                last_announce=now
            try:
                data,addr=self._sock.recvfrom(65535)
                try:self.ingest(data,addr)
                except ClusterError:pass
            except (socket.timeout,OSError):pass
            self.refresh_liveness()
