from __future__ import annotations
from dataclasses import dataclass
import json,time

class PersistentSafetyGateError(RuntimeError):pass

@dataclass(frozen=True)
class SafetyGateState:
 gate:str;held:bool;reason:str;authority:str;updated_unix:float

class PersistentSafetyGate:
 """P091 restart-persistent deterministic execution holds.
 Guardian may explain/recommend, but only this gate's authorized control path mutates holds.
 """
 AUTHORIZED={"HUMAN_OPERATOR","AEON_GOVERNOR","SAFETY_KERNEL"}
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p091_safety_gates(
   gate TEXT PRIMARY KEY,held INTEGER NOT NULL,reason TEXT NOT NULL,authority TEXT NOT NULL,updated_unix REAL NOT NULL)""")
 def _auth(self,authority):
  a=str(authority).upper()
  if a not in self.AUTHORIZED:raise PersistentSafetyGateError("authority cannot mutate deterministic safety gate")
  return a
 def hold(self,gate,reason,authority):
  g=str(gate).strip().upper();r=str(reason).strip();a=self._auth(authority)
  if not g or not r:raise PersistentSafetyGateError("gate and reason required")
  now=time.time()
  with self.db.transaction() as c:c.execute("""INSERT INTO p091_safety_gates VALUES(?,?,?,?,?)
   ON CONFLICT(gate) DO UPDATE SET held=excluded.held,reason=excluded.reason,authority=excluded.authority,updated_unix=excluded.updated_unix""",(g,1,r,a,now))
  self.audit.append("CRITICAL","safety.p091","gate_held",subject=g,details={"reason":r,"authority":a});return self.get(g)
 def release(self,gate,reason,authority):
  g=str(gate).strip().upper();r=str(reason).strip();a=self._auth(authority)
  if not g or not r:raise PersistentSafetyGateError("gate and reason required")
  now=time.time()
  with self.db.transaction() as c:c.execute("""INSERT INTO p091_safety_gates VALUES(?,?,?,?,?)
   ON CONFLICT(gate) DO UPDATE SET held=excluded.held,reason=excluded.reason,authority=excluded.authority,updated_unix=excluded.updated_unix""",(g,0,r,a,now))
  self.audit.append("WARNING","safety.p091","gate_released",subject=g,details={"reason":r,"authority":a});return self.get(g)
 def get(self,gate):
  g=str(gate).strip().upper()
  with self.db._connect() as c:r=c.execute("SELECT * FROM p091_safety_gates WHERE gate=?",(g,)).fetchone()
  if r is None:return SafetyGateState(g,False,"UNSET","SYSTEM_DEFAULT",0.0)
  return SafetyGateState(r["gate"],bool(r["held"]),r["reason"],r["authority"],r["updated_unix"])
 def require_clear(self,*gates):
  held=[self.get(g) for g in gates if self.get(g).held]
  if held:raise PersistentSafetyGateError("execution blocked by: "+",".join(x.gate for x in held))
  return True
 def status(self):
  with self.db._connect() as c:rows=c.execute("SELECT * FROM p091_safety_gates ORDER BY gate").fetchall()
  return {"phase":"SECURITY & SAFETY QUALIFICATION I","gates":[dict(r) for r in rows],
   "authority":"HUMAN_OPERATOR / AEON_GOVERNOR / SAFETY_KERNEL; Guardian is not authorized to release/hold directly",
   "scope":"Restart-persistent deterministic gate foundation. Scheduler/runtime integration and full GSVL binding continue in P092-P093."}
