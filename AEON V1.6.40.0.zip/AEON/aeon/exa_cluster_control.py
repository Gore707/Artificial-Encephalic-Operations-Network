from __future__ import annotations
from dataclasses import dataclass
import json,time

class ExaClusterControlError(RuntimeError):pass

@dataclass(frozen=True)
class ExaNodeRecord:
 node_id:str;host:str;control_port:int;transport_port:int;status:str;last_seen_unix:float;capabilities:dict

class ExaClusterControl:
 """Persistent Exa node inventory and bounded operator controls. No arbitrary remote execution."""
 STATUSES=("REGISTERED","ONLINE","DEGRADED","OFFLINE","HELD")
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS exa_cluster_nodes(
   node_id TEXT PRIMARY KEY,host TEXT NOT NULL,control_port INTEGER NOT NULL,transport_port INTEGER NOT NULL,
   status TEXT NOT NULL,last_seen_unix REAL NOT NULL,capabilities_json TEXT NOT NULL)""")
 def register(self,node_id,host,control_port,transport_port,capabilities=None):
  node_id=str(node_id).strip();host=str(host).strip();cp=int(control_port);tp=int(transport_port)
  if not node_id or not host or not 1<=cp<=65535 or not 1<=tp<=65535:raise ExaClusterControlError("valid node identity, host and ports required")
  caps=dict(capabilities or {});json.dumps(caps);now=time.time()
  with self.db.transaction() as c:c.execute("""INSERT INTO exa_cluster_nodes VALUES(?,?,?,?,?,?,?)
   ON CONFLICT(node_id) DO UPDATE SET host=excluded.host,control_port=excluded.control_port,transport_port=excluded.transport_port,
   status='REGISTERED',last_seen_unix=excluded.last_seen_unix,capabilities_json=excluded.capabilities_json""",
   (node_id,host,cp,tp,"REGISTERED",now,json.dumps(caps,sort_keys=True)))
  self.audit.append("INFO","exa_execution.cluster_control","node_registered",subject=node_id,details={"host":host,"control_port":cp,"transport_port":tp})
  return self.get(node_id)
 def get(self,node_id):
  with self.db._connect() as c:r=c.execute("SELECT * FROM exa_cluster_nodes WHERE node_id=?",(node_id,)).fetchone()
  if r is None:raise ExaClusterControlError("unknown Exa node")
  return ExaNodeRecord(r["node_id"],r["host"],r["control_port"],r["transport_port"],r["status"],r["last_seen_unix"],json.loads(r["capabilities_json"]))
 def heartbeat(self,node_id,status="ONLINE",capabilities=None):
  q=self.get(node_id);status=str(status).upper()
  if status not in self.STATUSES:raise ExaClusterControlError("invalid node status")
  caps=q.capabilities if capabilities is None else dict(capabilities);now=time.time()
  with self.db.transaction() as c:c.execute("UPDATE exa_cluster_nodes SET status=?,last_seen_unix=?,capabilities_json=? WHERE node_id=?",(status,now,json.dumps(caps,sort_keys=True),node_id))
  return self.get(node_id)
 def hold(self,node_id,reason):
  q=self.get(node_id);reason=str(reason).strip()
  if not reason:raise ExaClusterControlError("hold reason required")
  with self.db.transaction() as c:c.execute("UPDATE exa_cluster_nodes SET status='HELD' WHERE node_id=?",(node_id,))
  self.audit.append("WARNING","exa_execution.cluster_control","node_held",subject=node_id,details={"reason":reason})
  return self.get(node_id)
 def release(self,node_id):
  q=self.get(node_id)
  if q.status!="HELD":raise ExaClusterControlError("node is not held")
  with self.db.transaction() as c:c.execute("UPDATE exa_cluster_nodes SET status='REGISTERED' WHERE node_id=?",(node_id,))
  self.audit.append("INFO","exa_execution.cluster_control","node_released",subject=node_id,details={})
  return self.get(node_id)
 def mark_stale(self,timeout_seconds,now=None):
  timeout=float(timeout_seconds);now=time.time() if now is None else float(now)
  if timeout<=0:raise ExaClusterControlError("positive stale timeout required")
  # Deliberately do not refresh last_seen while changing liveness state.
  with self.db.transaction() as c:
   rows=c.execute("SELECT node_id,last_seen_unix,status FROM exa_cluster_nodes").fetchall()
   stale=[r["node_id"] for r in rows if r["status"]!="HELD" and now-r["last_seen_unix"]>timeout]
   for nid in stale:c.execute("UPDATE exa_cluster_nodes SET status='OFFLINE' WHERE node_id=?",(nid,))
  return tuple(stale)
 def list_nodes(self):
  with self.db._connect() as c:ids=[r["node_id"] for r in c.execute("SELECT node_id FROM exa_cluster_nodes ORDER BY node_id").fetchall()]
  return tuple(self.get(x) for x in ids)
 def dashboard(self,partitioner=None,checkpoints=None):
  nodes=self.list_nodes();counts={s:0 for s in self.STATUSES}
  for n in nodes:counts[n.status]=counts.get(n.status,0)+1
  out={"nodes":len(nodes),"status_counts":counts,"records":[n.__dict__ for n in nodes],
       "control_surface":("REGISTER","HEARTBEAT","HOLD","RELEASE","MARK_STALE"),
       "arbitrary_remote_execution":False}
  if partitioner:out["partition_plans"]=partitioner.summary()["plans"]
  if checkpoints:out["distributed_checkpoints"]=checkpoints.summary()["checkpoints"]
  return out
