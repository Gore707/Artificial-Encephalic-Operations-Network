from __future__ import annotations
from dataclasses import dataclass
import ctypes
import os
import platform
import shutil
import time

@dataclass(frozen=True)
class HostSnapshot:
    timestamp: float
    cpu_percent: float | None
    ram_used_bytes: int | None
    ram_total_bytes: int | None
    disk_used_bytes: int
    disk_total_bytes: int

class HostTelemetry:
    """P002 host telemetry. Values are measured from the host; unavailable metrics remain None."""
    def __init__(self, root):
        self.root = root
        self._last_cpu = self._read_cpu_times()

    def _read_cpu_times(self):
        if platform.system() != "Windows":
            return None
        class FILETIME(ctypes.Structure):
            _fields_ = [("low", ctypes.c_uint32), ("high", ctypes.c_uint32)]
        idle, kernel, user = FILETIME(), FILETIME(), FILETIME()
        ok = ctypes.windll.kernel32.GetSystemTimes(
            ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)
        )
        if not ok:
            return None
        def value(ft):
            return (ft.high << 32) | ft.low
        return value(idle), value(kernel), value(user)

    def _cpu_percent(self):
        current = self._read_cpu_times()
        previous = self._last_cpu
        self._last_cpu = current
        if current is None or previous is None:
            try:
                load = os.getloadavg()[0]
                cpus = os.cpu_count() or 1
                return max(0.0, min(100.0, (load / cpus) * 100.0))
            except (AttributeError, OSError):
                return None
        idle = current[0] - previous[0]
        kernel = current[1] - previous[1]
        user = current[2] - previous[2]
        total = kernel + user
        if total <= 0:
            return 0.0
        return max(0.0, min(100.0, (1.0 - idle / total) * 100.0))

    def _memory(self):
        if platform.system() != "Windows":
            return None, None
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]
        state = MEMORYSTATUSEX()
        state.dwLength = ctypes.sizeof(state)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):
            return None, None
        return state.ullTotalPhys - state.ullAvailPhys, state.ullTotalPhys

    def snapshot(self) -> HostSnapshot:
        disk = shutil.disk_usage(self.root)
        used, total = self._memory()
        return HostSnapshot(
            timestamp=time.time(),
            cpu_percent=self._cpu_percent(),
            ram_used_bytes=used,
            ram_total_bytes=total,
            disk_used_bytes=disk.used,
            disk_total_bytes=disk.total,
        )
