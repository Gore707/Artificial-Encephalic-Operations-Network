from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,os,shutil,time,uuid

class TransactionalWriteError(RuntimeError):pass

@dataclass(frozen=True)
class BackupRecord:
    backup_id:str;target_path:str;backup_path:str;sha256:str;size_bytes:int;created_unix:float

class TransactionalFileStore:
    """Crash-conscious replace-with-backup service for mutable AEON files.

    Writes occur to a sibling temporary file, are flushed/fsynced, optionally
    verify an expected current digest, preserve the prior target as an immutable
    backup, then atomically replace the target. This protects a single filesystem
    mutation boundary; P022 supplies explicit rollback/recovery policy.
    """
    def __init__(self,db,audit,state_dir:Path):
        self.db=db;self.audit=audit
        self.backup_root=Path(state_dir)/"backups";self.backup_root.mkdir(parents=True,exist_ok=True)
        self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS file_backups(
             backup_id TEXT PRIMARY KEY,target_path TEXT NOT NULL,backup_path TEXT NOT NULL,
             sha256 TEXT NOT NULL,size_bytes INTEGER NOT NULL,created_unix REAL NOT NULL)""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_backup_target ON file_backups(target_path,created_unix)")

    def write_bytes(self,target:Path,data:bytes,expected_sha256:str|None=None):
        target=Path(target)
        if not isinstance(data,(bytes,bytearray,memoryview)):raise TransactionalWriteError("data must be bytes-like")
        data=bytes(data);target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists() and not target.is_file():raise TransactionalWriteError("target exists and is not a file")
        current_digest=self._hash(target)[0] if target.is_file() else None
        if expected_sha256 is not None and current_digest!=expected_sha256:
            raise TransactionalWriteError("target changed since expected digest")
        backup=self._backup(target) if target.is_file() else None
        tmp=target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
        try:
            with tmp.open("wb") as h:
                h.write(data);h.flush();os.fsync(h.fileno())
            if self._hash(tmp)[0]!=hashlib.sha256(data).hexdigest():
                raise TransactionalWriteError("temporary write verification failed")
            os.replace(tmp,target)
            self._fsync_dir(target.parent)
        finally:
            try:
                if tmp.exists():tmp.unlink()
            except OSError:pass
        self.audit.append("INFO","transactional_write","committed",subject=str(target),
                          details={"size_bytes":len(data),"backup_id":backup.backup_id if backup else None})
        return backup

    def write_text(self,target:Path,text:str,encoding="utf-8",expected_sha256=None):
        return self.write_bytes(target,text.encode(encoding),expected_sha256)

    def backups(self,target:Path|None=None,limit=200):
        sql="SELECT backup_id FROM file_backups";args=[]
        if target is not None:sql+=" WHERE target_path=?";args.append(str(Path(target)))
        sql+=" ORDER BY created_unix DESC LIMIT ?";args.append(int(limit))
        with self.db._connect() as c:ids=[r["backup_id"] for r in c.execute(sql,args).fetchall()]
        return tuple(self.get(i) for i in ids)

    def get(self,bid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM file_backups WHERE backup_id=?",(bid,)).fetchone()
        if r is None:raise TransactionalWriteError(f"Unknown backup: {bid}")
        return BackupRecord(r["backup_id"],r["target_path"],r["backup_path"],r["sha256"],r["size_bytes"],r["created_unix"])

    def verify_backup(self,bid):
        b=self.get(bid);p=Path(b.backup_path)
        if not p.is_file():return False,"backup missing"
        digest,size=self._hash(p)
        if size!=b.size_bytes:return False,"size mismatch"
        if digest!=b.sha256:return False,"sha256 mismatch"
        return True,"ok"

    def _backup(self,target):
        digest,size=self._hash(target);bid="bak-"+uuid.uuid4().hex
        folder=self.backup_root/digest[:2]/digest[2:4];folder.mkdir(parents=True,exist_ok=True)
        dst=folder/f"{bid}.bin";tmp=folder/f".{bid}.tmp"
        shutil.copyfile(target,tmp)
        with tmp.open("rb") as h:os.fsync(h.fileno())
        os.replace(tmp,dst);self._fsync_dir(folder)
        try:dst.chmod(0o444)
        except OSError:pass
        now=time.time()
        with self.db.transaction() as c:
            c.execute("INSERT INTO file_backups VALUES(?,?,?,?,?,?)",(bid,str(target),str(dst),digest,size,now))
        return self.get(bid)

    @staticmethod
    def _hash(path):
        h=hashlib.sha256();size=0
        with Path(path).open("rb") as f:
            for block in iter(lambda:f.read(1024*1024),b""):h.update(block);size+=len(block)
        return h.hexdigest(),size

    @staticmethod
    def _fsync_dir(path):
        if os.name=="nt":return
        try:
            fd=os.open(str(path),os.O_RDONLY)
            try:os.fsync(fd)
            finally:os.close(fd)
        except OSError:pass
