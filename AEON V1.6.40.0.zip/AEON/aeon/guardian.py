from __future__ import annotations
from dataclasses import dataclass
import json,time,uuid

class GuardianError(RuntimeError): pass

STATUSES=("NOMINAL","OBSERVING","ADVISORY","WARNING","INTERVENTION","DEGRADED","OFFLINE")
CONFIDENCE_KINDS=("DETERMINISTIC","STATISTICAL","MODEL","HYPOTHESIS")

@dataclass(frozen=True)
class GuardianObservation:
    observation_id:str
    created_unix:float
    status:str
    source:str
    summary:str
    evidence:tuple[str,...]
    confidence_kind:str
    confidence:float|None
    provenance:str

class GuardianService:
    """AEON Guardian core.

    P026 is the supervisory service and evidence model, not an LLM and not the
    Safety Kernel. It consumes structured evidence and records bounded,
    provenance-labelled observations. It has no direct process, hardware,
    recovery, permission, or Safety-Kernel bypass capability.
    """
    def __init__(self,db,audit,telemetry_stream=None):
        self.db=db;self.audit=audit;self.telemetry_stream=telemetry_stream
        self._status="NOMINAL";self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS guardian_observations(
              observation_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,status TEXT NOT NULL,
              source TEXT NOT NULL,summary TEXT NOT NULL,evidence_json TEXT NOT NULL,
              confidence_kind TEXT NOT NULL,confidence REAL,provenance TEXT NOT NULL)""")

    @property
    def status(self): return self._status

    def set_status(self,status,reason):
        status=str(status).upper()
        if status not in STATUSES: raise GuardianError("invalid Guardian status")
        if not str(reason).strip(): raise GuardianError("status change requires reason")
        old=self._status;self._status=status
        self.audit.append("WARNING" if status not in ("NOMINAL","OBSERVING") else "INFO",
                          "guardian","status_changed",subject="AEON Guardian",
                          details={"old":old,"new":status,"reason":str(reason)})
        return status

    def observe(self,source,summary,evidence=(),status="OBSERVING",
                confidence_kind="DETERMINISTIC",confidence=None,provenance="MEASURED"):
        status=str(status).upper(); confidence_kind=str(confidence_kind).upper()
        if status not in STATUSES: raise GuardianError("invalid Guardian status")
        if confidence_kind not in CONFIDENCE_KINDS: raise GuardianError("invalid confidence kind")
        if not str(source).strip() or not str(summary).strip(): raise GuardianError("source and summary required")
        ev=tuple(str(x) for x in evidence if str(x).strip())
        if confidence is not None:
            confidence=float(confidence)
            if not 0.0<=confidence<=1.0: raise GuardianError("confidence must be in [0,1]")
        if confidence_kind=="DETERMINISTIC" and confidence is not None:
            raise GuardianError("deterministic observations do not use probabilistic confidence")
        oid="gobs-"+uuid.uuid4().hex;now=time.time()
        with self.db.transaction() as c:
            c.execute("INSERT INTO guardian_observations VALUES(?,?,?,?,?,?,?,?,?)",
                      (oid,now,status,str(source),str(summary),json.dumps(ev),
                       confidence_kind,confidence,str(provenance)))
        self.audit.append("INFO","guardian","observation_recorded",subject=oid,
                          details={"source":source,"status":status,"confidence_kind":confidence_kind,
                                   "confidence":confidence,"provenance":provenance})
        self._status=status
        return self.get(oid)

    def get(self,oid):
        with self.db._connect() as c:
            r=c.execute("SELECT * FROM guardian_observations WHERE observation_id=?",(oid,)).fetchone()
        if r is None: raise GuardianError(f"unknown observation: {oid}")
        return GuardianObservation(r["observation_id"],r["created_unix"],r["status"],r["source"],
                                   r["summary"],tuple(json.loads(r["evidence_json"])),
                                   r["confidence_kind"],r["confidence"],r["provenance"])

    def list(self,limit=200):
        with self.db._connect() as c:
            ids=[r["observation_id"] for r in c.execute(
                "SELECT observation_id FROM guardian_observations ORDER BY created_unix DESC LIMIT ?",
                (int(limit),)).fetchall()]
        return tuple(self.get(i) for i in ids)

    def telemetry_window(self,channel,seconds=5.0):
        if self.telemetry_stream is None: raise GuardianError("telemetry stream unavailable")
        w=self.telemetry_stream.aggregate(str(channel),float(seconds))
        # Return structured evidence only. P027 decides whether it is anomalous.
        return {"channel":w.channel,"seconds":w.seconds,"count":w.count,"minimum":w.minimum,
                "maximum":w.maximum,"mean":w.mean,"latest":w.latest,"unit":w.unit,
                "provenance":w.provenance}
