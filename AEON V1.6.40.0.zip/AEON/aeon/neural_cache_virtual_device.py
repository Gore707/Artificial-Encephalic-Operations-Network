from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,time,uuid,shutil
class NeuralCacheError(RuntimeError):pass
@dataclass(frozen=True)
class NeuralCacheDevice:
 device_id:str;created_unix:float;label:str;root_path:str;capacity_bytes:int;block_size:int;status:str;used_bytes:int;manifest_sha256:str
class NeuralCacheVirtualDevice:
 STATUSES=("ONLINE","READ_ONLY","OFFLINE")
 def __init__(self,db,audit,root):
  self.db=db;self.audit=audit;self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True);self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS neural_cache_devices(device_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,label TEXT NOT NULL,root_path TEXT NOT NULL,capacity_bytes INTEGER NOT NULL,block_size INTEGER NOT NULL,status TEXT NOT NULL,used_bytes INTEGER NOT NULL,manifest_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 def create(self,label,capacity_bytes,block_size=4096):
  label=str(label).strip();cap=int(capacity_bytes);bs=int(block_size)
  if not label or cap<=0 or bs<512 or bs&(bs-1):raise NeuralCacheError("label, positive capacity and power-of-two block size >=512 required")
  if cap>shutil.disk_usage(self.root).free:raise NeuralCacheError("logical device capacity exceeds available host filesystem space")
  did="ncache-"+uuid.uuid4().hex;path=self.root/did;path.mkdir()
  payload={"device_id":did,"label":label,"root_path":str(path.resolve()),"capacity_bytes":cap,"block_size":bs};sha=self._sha(payload)
  with self.db.transaction() as c:c.execute("INSERT INTO neural_cache_devices VALUES(?,?,?,?,?,?,?,?,?)",(did,time.time(),label,payload["root_path"],cap,bs,"ONLINE",0,sha))
  self.audit.append("INFO","neural_cache.virtual_device","created",subject=did,details={"capacity_bytes":cap,"block_size":bs});return self.get(did)
 def get(self,did):
  with self.db._connect() as c:r=c.execute("SELECT * FROM neural_cache_devices WHERE device_id=?",(did,)).fetchone()
  if r is None:raise NeuralCacheError("unknown Neural Cache device")
  return NeuralCacheDevice(r["device_id"],r["created_unix"],r["label"],r["root_path"],r["capacity_bytes"],r["block_size"],r["status"],r["used_bytes"],r["manifest_sha256"])
 def verify(self,did):
  q=self.get(did);payload={"device_id":q.device_id,"label":q.label,"root_path":q.root_path,"capacity_bytes":q.capacity_bytes,"block_size":q.block_size};m=self._sha(payload)==q.manifest_sha256;p=Path(q.root_path).is_dir();u=0<=q.used_bytes<=q.capacity_bytes
  return {"manifest_ok":m,"path_ok":p,"usage_ok":u,"all_ok":m and p and u}
 def reserve(self,did,byte_count):
  q=self.get(did);n=int(byte_count)
  if q.status!="ONLINE":raise NeuralCacheError("device is not writable")
  if n<0 or q.used_bytes+n>q.capacity_bytes:raise NeuralCacheError("Neural Cache capacity exceeded")
  if n>shutil.disk_usage(q.root_path).free:raise NeuralCacheError("host filesystem lacks requested free space")
  with self.db.transaction() as c:c.execute("UPDATE neural_cache_devices SET used_bytes=used_bytes+? WHERE device_id=?",(n,did))
  return self.get(did)
 def release(self,did,byte_count):
  q=self.get(did);n=int(byte_count)
  if n<0 or n>q.used_bytes:raise NeuralCacheError("invalid release")
  with self.db.transaction() as c:c.execute("UPDATE neural_cache_devices SET used_bytes=used_bytes-? WHERE device_id=?",(n,did))
  return self.get(did)
 def set_status(self,did,status):
  self.get(did);status=str(status).upper()
  if status not in self.STATUSES:raise NeuralCacheError("invalid device status")
  with self.db.transaction() as c:c.execute("UPDATE neural_cache_devices SET status=? WHERE device_id=?",(status,did))
  self.audit.append("INFO","neural_cache.virtual_device","status_changed",subject=did,details={"status":status});return self.get(did)
 def list_devices(self):
  with self.db._connect() as c:ids=[r["device_id"] for r in c.execute("SELECT device_id FROM neural_cache_devices ORDER BY created_unix").fetchall()]
  return tuple(self.get(x) for x in ids)
 def summary(self):
  ds=self.list_devices();return {"devices":len(ds),"logical_capacity_bytes":sum(x.capacity_bytes for x in ds),"reserved_bytes":sum(x.used_bytes for x in ds),"note":"P075 is a host-filesystem-backed virtual device abstraction, not proposed future physical Neural Cache hardware."}
