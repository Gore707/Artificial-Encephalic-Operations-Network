from __future__ import annotations
from dataclasses import dataclass
import json,math,time,uuid

class CognitiveDivergenceError(RuntimeError):pass

@dataclass(frozen=True)
class DivergenceSample:
 sample_id:str;created_unix:float;series_id:str;reference_state_id:str;observed_state_id:str
 simulation_time:float;time_unit:str;comparable_count:int;rmse:float|None;mae:float|None
 weighted_mae:float|None;missing_count:int;details:dict

class CognitiveDivergenceService:
 """Tracks descriptive numerical divergence from an explicit reference state over time."""
 def __init__(self,db,audit,comparator):
  self.db=db;self.audit=audit;self.comparator=comparator;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS cognitive_divergence_samples(
   sample_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,series_id TEXT NOT NULL,reference_state_id TEXT NOT NULL,
   observed_state_id TEXT NOT NULL,simulation_time REAL NOT NULL,time_unit TEXT NOT NULL,comparable_count INTEGER NOT NULL,
   rmse REAL,mae REAL,weighted_mae REAL,missing_count INTEGER NOT NULL,details_json TEXT NOT NULL,
   UNIQUE(series_id,observed_state_id,simulation_time,time_unit))""")
 def record(self,series_id,reference_state_id,observed_state_id,simulation_time,time_unit):
  series=str(series_id).strip();unit=str(time_unit).strip();t=float(simulation_time)
  if not series or not unit or not math.isfinite(t):raise CognitiveDivergenceError("series, finite time, and time unit required")
  cmp=self.comparator.compare(reference_state_id,observed_state_id);m=cmp.metrics
  missing=len(cmp.missing_left)+len(cmp.missing_right)
  details={"comparison_id":cmp.comparison_id,"shared_variables":list(cmp.shared_variables),
   "missing_left":list(cmp.missing_left),"missing_right":list(cmp.missing_right),
   "interpretation":"Divergence is numerical/model-relative. It does not establish loss of identity, continuity, biological equivalence, consciousness, or personhood."}
  sid="div-"+uuid.uuid4().hex
  try:
   with self.db.transaction() as c:c.execute("INSERT INTO cognitive_divergence_samples VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
    (sid,time.time(),series,reference_state_id,observed_state_id,t,unit,int(m["comparable_count"]),m["rmse"],m["mae"],m["confidence_weighted_mae"],missing,json.dumps(details,sort_keys=True)))
  except Exception as exc:
   # Preserve idempotence for repeated evaluation of the same observed state/time.
   with self.db._connect() as c:r=c.execute("""SELECT sample_id FROM cognitive_divergence_samples
    WHERE series_id=? AND observed_state_id=? AND simulation_time=? AND time_unit=?""",(series,observed_state_id,t,unit)).fetchone()
   if r:return self.get(r["sample_id"])
   raise
  self.audit.append("INFO","cognitive_guardian.divergence","sample_recorded",subject=sid,
   details={"series_id":series,"simulation_time":t,"time_unit":unit,"comparable_count":m["comparable_count"]})
  return self.get(sid)
 def get(self,sid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_divergence_samples WHERE sample_id=?",(sid,)).fetchone()
  if r is None:raise CognitiveDivergenceError("unknown divergence sample")
  return DivergenceSample(r["sample_id"],r["created_unix"],r["series_id"],r["reference_state_id"],r["observed_state_id"],
   r["simulation_time"],r["time_unit"],r["comparable_count"],r["rmse"],r["mae"],r["weighted_mae"],r["missing_count"],json.loads(r["details_json"]))
 def series(self,series_id):
  with self.db._connect() as c:ids=[r["sample_id"] for r in c.execute("SELECT sample_id FROM cognitive_divergence_samples WHERE series_id=? ORDER BY simulation_time,created_unix",(str(series_id),)).fetchall()]
  return tuple(self.get(x) for x in ids)
 def trend(self,series_id):
  rows=self.series(series_id);usable=[x for x in rows if x.rmse is not None]
  if len(usable)<2:return {"sample_count":len(rows),"usable_count":len(usable),"rmse_slope_per_time_unit":None,"classification":"INSUFFICIENT_DATA"}
  units={x.time_unit for x in usable}
  if len(units)!=1:raise CognitiveDivergenceError("trend requires one time unit")
  xs=[x.simulation_time for x in usable];ys=[x.rmse for x in usable];mx=sum(xs)/len(xs);my=sum(ys)/len(ys)
  den=sum((x-mx)**2 for x in xs);slope=None if den==0 else sum((x-mx)*(y-my) for x,y in zip(xs,ys))/den
  return {"sample_count":len(rows),"usable_count":len(usable),"rmse_slope_per_time_unit":slope,"time_unit":next(iter(units)),
   "classification":"DESCRIPTIVE_ONLY","note":"Slope describes this metric series only; no universal cognitive-failure threshold is inferred."}
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM cognitive_divergence_samples").fetchone()["n"]
  return {"samples":n,"note":"P067 records model-relative divergence over explicit simulation time. No universal identity/consciousness threshold is asserted."}
