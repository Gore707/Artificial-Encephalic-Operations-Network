from __future__ import annotations
from dataclasses import dataclass
import json,time,uuid,math

class SNNEngineError(RuntimeError):pass

@dataclass(frozen=True)
class SNNNetwork:
 network_id:str;created_unix:float;name:str;neuron_states:tuple[tuple[str,str],...]
 synapses:tuple[dict,...];simulation_time_ms:float;step_index:int

class SNNEngine:
 """Deterministic CPU SNN coordinator over P055 neuron and P056 synapse primitives."""
 def __init__(self,db,audit,neurons,synapses):
  self.db=db;self.audit=audit;self.neurons=neurons;self.synapses=synapses;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS snn_networks(
   network_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,name TEXT NOT NULL,neuron_states_json TEXT NOT NULL,
   synapses_json TEXT NOT NULL,simulation_time_ms REAL NOT NULL,step_index INTEGER NOT NULL)""")
 def create(self,name,neurons,synapses=()):
  name=str(name).strip()
  if not name:raise SNNEngineError("network name required")
  ns=[];seen=set()
  for raw in neurons:
   x=dict(raw);nid=str(x.get("node_id","")).strip();sid=str(x.get("state_id","")).strip()
   if not nid or nid in seen:raise SNNEngineError("unique node_id required")
   self.neurons.get_state(sid);seen.add(nid);ns.append((nid,sid))
  if not ns:raise SNNEngineError("at least one neuron required")
  ss=[];edgeids=set()
  for raw in synapses:
   x=dict(raw);eid=str(x.get("edge_id","")).strip();pre=str(x.get("source_node_id",""));post=str(x.get("target_node_id",""));sid=str(x.get("state_id",""))
   if not eid or eid in edgeids:raise SNNEngineError("unique edge_id required")
   if pre not in seen or post not in seen:raise SNNEngineError("synapse endpoints must exist")
   self.synapses.get_state(sid);edgeids.add(eid);ss.append({"edge_id":eid,"source_node_id":pre,"target_node_id":post,"state_id":sid})
  nid="snn-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO snn_networks VALUES(?,?,?,?,?,?,?)",(nid,now,name,json.dumps(ns),json.dumps(ss,sort_keys=True),0.0,0))
  self.audit.append("INFO","neural_simulacrum.snn","network_created",subject=nid,details={"neurons":len(ns),"synapses":len(ss)})
  return self.get(nid)
 def get(self,nid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM snn_networks WHERE network_id=?",(nid,)).fetchone()
  if r is None:raise SNNEngineError("unknown SNN network")
  return SNNNetwork(r["network_id"],r["created_unix"],r["name"],tuple(tuple(x) for x in json.loads(r["neuron_states_json"])),
   tuple(json.loads(r["synapses_json"])),r["simulation_time_ms"],r["step_index"])
 def step(self,network_id,dt_ms,external_currents=None):
  n=self.get(network_id);dt=float(dt_ms)
  if not math.isfinite(dt) or dt<=0:raise SNNEngineError("dt_ms must be finite and > 0")
  ext={str(k):float(v) for k,v in dict(external_currents or {}).items()}
  nodeids={x[0] for x in n.neuron_states}
  if any(k not in nodeids or not math.isfinite(v) for k,v in ext.items()):raise SNNEngineError("invalid external current")
  # Advance synaptic currents first. Events emitted by spikes this tick are therefore available no earlier than next tick.
  incoming={k:0.0 for k in nodeids}
  for e in n.synapses:
   st=self.synapses.step(e["state_id"],dt);incoming[e["target_node_id"]]+=float(st.values["current_na"])
  spikes=[]
  for node,state_id in n.neuron_states:
   st=self.neurons.step(state_id,dt,incoming[node]+ext.get(node,0.0))
   if st.values["spike"]:spikes.append(node)
  for e in n.synapses:
   if e["source_node_id"] in spikes:self.synapses.emit_presynaptic_spike(e["state_id"])
  nt=n.simulation_time_ms+dt;idx=n.step_index+1
  with self.db.transaction() as c:c.execute("UPDATE snn_networks SET simulation_time_ms=?,step_index=? WHERE network_id=?",(nt,idx,network_id))
  return {"network_id":network_id,"simulation_time_ms":nt,"step_index":idx,"spikes":tuple(spikes),
   "incoming_current_na":incoming,"external_current_na":ext}
 def run(self,network_id,dt_ms,steps,external_current_fn=None):
  count=int(steps)
  if count<0:raise SNNEngineError("steps must be >= 0")
  out=[]
  for i in range(count):
   ext={} if external_current_fn is None else dict(external_current_fn(i,self.get(network_id)) or {})
   out.append(self.step(network_id,dt_ms,ext))
  return tuple(out)
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM snn_networks").fetchone()["n"]
  return {"networks":n,"backend":"CPU/DETERMINISTIC","note":"P057 coordinates explicit neuron/synapse models. ANI loading, Genesis execution authorization, GPU and distributed execution are not enabled here."}
