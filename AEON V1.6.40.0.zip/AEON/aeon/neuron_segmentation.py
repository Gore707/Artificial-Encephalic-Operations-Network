from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid,math

class NeuronSegmentationError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")

@dataclass(frozen=True)
class Segment:
 segment_id:str;label:str;voxel_count:int;centroid:tuple[float,float,float]|None
 confidence:float|None;provenance:str;attributes:dict

@dataclass(frozen=True)
class SegmentationRecord:
 segmentation_id:str;volume_id:str;created_unix:float;method:str;method_version:str
 segments:tuple[Segment,...];source_volume_sha256:str;definition_sha256:str

class NeuronSegmentationService:
 """Stores explicit segmentation outputs bound to a verified reconstructed volume.

 Segments are candidate cellular objects. This service never promotes them to
 confirmed neurons merely from geometry or labels.
 """
 def __init__(self,db,audit,volumes):
  self.db=db;self.audit=audit;self.volumes=volumes;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS cognitive_injection_segmentations(
   segmentation_id TEXT PRIMARY KEY,volume_id TEXT NOT NULL,created_unix REAL NOT NULL,method TEXT NOT NULL,
   method_version TEXT NOT NULL,segments_json TEXT NOT NULL,source_volume_sha256 TEXT NOT NULL,
   definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def create(self,volume_id,method,method_version,segments):
  vol=self.volumes.get(volume_id)
  if not self.volumes.verify(volume_id)["all_ok"]:raise NeuronSegmentationError("source volume failed integrity verification")
  method=str(method).strip();version=str(method_version).strip()
  if not method or not version:raise NeuronSegmentationError("method and method version required")
  out=[];seen=set()
  for raw in segments:
   x=dict(raw);sid=str(x.get("segment_id") or ("seg-"+uuid.uuid4().hex))
   if sid in seen:raise NeuronSegmentationError("duplicate segment id")
   seen.add(sid);count=int(x.get("voxel_count",0))
   if count<=0:raise NeuronSegmentationError("voxel_count must be positive")
   prov=str(x.get("provenance","DERIVED"))
   if prov not in PROVENANCE:raise NeuronSegmentationError("invalid segment provenance")
   conf=x.get("confidence")
   if conf is not None:
    conf=float(conf)
    if not math.isfinite(conf) or not 0<=conf<=1:raise NeuronSegmentationError("confidence must be within [0,1]")
   cen=x.get("centroid")
   if cen is not None:
    try:cen=tuple(float(v) for v in cen)
    except Exception as exc:raise NeuronSegmentationError("centroid must contain numeric coordinates") from exc
    if len(cen)!=3 or any(not math.isfinite(v) for v in cen):raise NeuronSegmentationError("centroid must contain three finite coordinates")
   attrs=dict(x.get("attributes") or {})
   out.append(Segment(sid,str(x.get("label","UNCLASSIFIED")),count,cen,conf,prov,attrs))
  if not out:raise NeuronSegmentationError("at least one segment required")
  payload={"volume_id":volume_id,"method":method,"method_version":version,"source_volume_sha256":vol.definition_sha256,
   "segments":[{"segment_id":s.segment_id,"label":s.label,"voxel_count":s.voxel_count,"centroid":s.centroid,
    "confidence":s.confidence,"provenance":s.provenance,"attributes":s.attributes} for s in out]}
  try:raw=self._canon(payload)
  except (TypeError,ValueError) as exc:raise NeuronSegmentationError("segmentation must be JSON-serializable") from exc
  sha=hashlib.sha256(raw.encode("utf-8")).hexdigest();rid="segmentset-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_injection_segmentations VALUES(?,?,?,?,?,?,?,?)",
   (rid,volume_id,now,method,version,json.dumps(payload["segments"],sort_keys=True),vol.definition_sha256,sha))
  self.audit.append("INFO","cognitive_injection.segmentation","created",subject=rid,
   details={"volume_id":volume_id,"method":method,"method_version":version,"segments":len(out),"definition_sha256":sha})
  return self.get(rid)
 def get(self,rid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_injection_segmentations WHERE segmentation_id=?",(rid,)).fetchone()
  if r is None:raise NeuronSegmentationError("unknown segmentation")
  ss=[]
  for x in json.loads(r["segments_json"]):
   ss.append(Segment(x["segment_id"],x["label"],x["voxel_count"],tuple(x["centroid"]) if x["centroid"] is not None else None,x["confidence"],x["provenance"],x["attributes"]))
  return SegmentationRecord(r["segmentation_id"],r["volume_id"],r["created_unix"],r["method"],r["method_version"],tuple(ss),r["source_volume_sha256"],r["definition_sha256"])
 def verify(self,rid):
  q=self.get(rid);vol=self.volumes.get(q.volume_id)
  payload={"volume_id":q.volume_id,"method":q.method,"method_version":q.method_version,"source_volume_sha256":q.source_volume_sha256,
   "segments":[{"segment_id":s.segment_id,"label":s.label,"voxel_count":s.voxel_count,"centroid":s.centroid,
    "confidence":s.confidence,"provenance":s.provenance,"attributes":s.attributes} for s in q.segments]}
  definition_ok=hashlib.sha256(self._canon(payload).encode("utf-8")).hexdigest()==q.definition_sha256
  volume_ok=vol.definition_sha256==q.source_volume_sha256 and self.volumes.verify(q.volume_id)["all_ok"]
  return {"definition_ok":definition_ok,"volume_ok":volume_ok,"all_ok":definition_ok and volume_ok}
 def summary(self,rid):
  q=self.get(rid);conf=[s.confidence for s in q.segments if s.confidence is not None]
  return {"segmentation_id":rid,"segments":len(q.segments),"voxels":sum(s.voxel_count for s in q.segments),
   "confidence_count":len(conf),"mean_confidence":sum(conf)/len(conf) if conf else None,
   "provenance_counts":{p:sum(s.provenance==p for s in q.segments) for p in PROVENANCE},
   "note":"Segment count is not a neuron count; cellular identity requires classification/validation."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["segmentation_id"] for r in c.execute("SELECT segmentation_id FROM cognitive_injection_segmentations ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
