from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import copy
import tomllib

class ConfigurationError(RuntimeError):
    pass

def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result

@dataclass(frozen=True)
class AeonConfig:
    root: Path
    values: dict[str, Any]

    def get(self, dotted: str, default: Any = None) -> Any:
        node: Any = self.values
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    def path(self, dotted: str) -> Path:
        raw = self.get(dotted)
        if not isinstance(raw, str) or not raw.strip():
            raise ConfigurationError(f"Missing path setting: {dotted}")
        p = Path(raw)
        return p if p.is_absolute() else (self.root / p)

def _read_toml(path: Path) -> dict[str, Any]:
    try:
        with path.open("rb") as fh:
            return tomllib.load(fh)
    except FileNotFoundError:
        return {}
    except tomllib.TOMLDecodeError as exc:
        raise ConfigurationError(f"Invalid TOML in {path}: {exc}") from exc

def load_config(root: Path) -> AeonConfig:
    default_path = root / "config" / "default.toml"
    if not default_path.exists():
        raise ConfigurationError(f"Required configuration missing: {default_path}")
    merged = _read_toml(default_path)
    local_path = root / "config" / "local.toml"
    if local_path.exists():
        merged = _deep_merge(merged, _read_toml(local_path))
    required = ("aeon.name", "aeon.project", "paths.runtime", "paths.logs", "paths.state")
    cfg = AeonConfig(root=root, values=merged)
    missing = [key for key in required if cfg.get(key) in (None, "")]
    if missing:
        raise ConfigurationError("Missing required settings: " + ", ".join(missing))
    return cfg
