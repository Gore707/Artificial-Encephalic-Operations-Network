from __future__ import annotations
from dataclasses import dataclass
import time,uuid

class ExecutionAdmissionError(RuntimeError):pass

@dataclass(frozen=True)
class AdmissionDecision:
 admission_id:str;created_unix:float;subject_id:str;certificate_id:str;allowed:bool;reason:str

class ExecutionAdmission:
 """P093 deterministic admission boundary joining P091 safety gates and P092 Genesis certificates."""
 def __init__(self,db,audit,safety_gate,genesis_gate,watchdog):
  self.db=db;self.audit=audit;self.safety_gate=safety_gate;self.genesis_gate=genesis_gate;self.watchdog=watchdog;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p093_execution_admissions(
   admission_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,subject_id TEXT NOT NULL,certificate_id TEXT NOT NULL,allowed INTEGER NOT NULL,reason TEXT NOT NULL)""")
 def admit(self,subject_id,subject_bytes,certificate_id):
  aid="p093-"+uuid.uuid4().hex;allowed=False;reason="DENIED"
  try:
   self.safety_gate.require_clear("NEW_WORK","GENESIS_EXECUTION","WATCHDOG")
   self.genesis_gate.require_pass(certificate_id,subject_bytes)
   allowed=True;reason="GENESIS_PASS_AND_SAFETY_GATES_CLEAR"
  except Exception as e:reason=str(e)
  with self.db.transaction() as c:c.execute("INSERT INTO p093_execution_admissions VALUES(?,?,?,?,?,?)",(aid,time.time(),str(subject_id),str(certificate_id),1 if allowed else 0,reason))
  self.audit.append("INFO" if allowed else "CRITICAL","safety.p093","execution_admission",subject=aid,details={"subject_id":str(subject_id),"allowed":allowed,"reason":reason})
  if not allowed:raise ExecutionAdmissionError(reason)
  return AdmissionDecision(aid,time.time(),str(subject_id),str(certificate_id),True,reason)
 def status(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM p093_execution_admissions").fetchone()["n"]
  return {"phase":"SECURITY & SAFETY QUALIFICATION III","admission_records":n,
   "scope":"Deterministic admission service requires clear persistent gates plus an exact-state P092 Genesis PASS certificate. Independent heartbeat records can place WATCHDOG hold.",
   "boundary":"Existing legacy execution paths must call this admission service to inherit enforcement; P094-P095 full-system integration will audit and wire remaining paths."}
