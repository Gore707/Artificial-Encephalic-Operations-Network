from __future__ import annotations
from dataclasses import dataclass
import json,time,uuid

class DistributedNeuralError(RuntimeError):pass

@dataclass(frozen=True)
class DistributedNeuralRun:
 run_id:str;plan_id:str;clock_id:str;created_unix:float;partition_nodes:tuple[tuple[int,str],...]
 status:str;step_index:int;simulation_time:float

class DistributedNeuralExecution:
 """Coordinates logical neural partitions across explicitly assigned AEON node identities.
 P061 does not provide a new network transport; remote execution remains constrained by the existing distributed-job layer.
 """
 def __init__(self,db,audit,partitions,clocks,snn):
  self.db=db;self.audit=audit;self.partitions=partitions;self.clocks=clocks;self.snn=snn;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS distributed_neural_runs(
   run_id TEXT PRIMARY KEY,plan_id TEXT NOT NULL,clock_id TEXT NOT NULL,created_unix REAL NOT NULL,
   partition_nodes_json TEXT NOT NULL,status TEXT NOT NULL,step_index INTEGER NOT NULL,simulation_time REAL NOT NULL)""")
 def create(self,plan_id,clock_id,partition_nodes):
  p=self.partitions.get(plan_id)
  if not self.partitions.verify(plan_id)["all_ok"]:raise DistributedNeuralError("partition plan integrity failed")
  clk=self.clocks.get(clock_id)
  if clk.status!="READY":raise DistributedNeuralError("neural clock must be READY")
  mapping={int(k):str(v).strip() for k,v in dict(partition_nodes).items()}
  if set(mapping)!=set(range(p.partition_count)):raise DistributedNeuralError("every partition must have exactly one node assignment")
  if any(not v for v in mapping.values()):raise DistributedNeuralError("node identity cannot be empty")
  rid="dnrun-"+uuid.uuid4().hex;now=time.time();pairs=tuple(sorted(mapping.items()))
  with self.db.transaction() as c:c.execute("INSERT INTO distributed_neural_runs VALUES(?,?,?,?,?,?,?,?)",
   (rid,plan_id,clock_id,now,json.dumps(pairs),"READY",0,clk.current_time))
  self.audit.append("INFO","neural_simulacrum.distributed","run_created",subject=rid,details={"partitions":p.partition_count,"nodes":len(set(mapping.values()))})
  return self.get(rid)
 def get(self,rid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM distributed_neural_runs WHERE run_id=?",(rid,)).fetchone()
  if r is None:raise DistributedNeuralError("unknown distributed neural run")
  return DistributedNeuralRun(r["run_id"],r["plan_id"],r["clock_id"],r["created_unix"],tuple((int(x[0]),str(x[1])) for x in json.loads(r["partition_nodes_json"])),
   r["status"],r["step_index"],r["simulation_time"])
 def synchronization(self,rid,participant_times,tolerance):
  q=self.get(rid);p=self.partitions.get(q.plan_id);mapping=dict(q.partition_nodes)
  expected={f"partition-{i}@{mapping[i]}":float(participant_times[i]) for i in range(p.partition_count) if i in participant_times}
  if len(expected)!=p.partition_count:raise DistributedNeuralError("participant time required for every partition")
  return self.clocks.synchronize(q.clock_id,expected,tolerance)
 def commit_step(self,rid,participant_times,tolerance):
  q=self.get(rid)
  if q.status!="READY":raise DistributedNeuralError("run is not READY")
  sync=self.synchronization(rid,participant_times,tolerance)
  if not sync["synchronized"]:
   with self.db.transaction() as c:c.execute("UPDATE distributed_neural_runs SET status=? WHERE run_id=?",("DESYNCHRONIZED",rid))
   self.audit.append("WARNING","neural_simulacrum.distributed","desynchronized",subject=rid,details={"participants":sync["participants"]})
   return {"committed":False,"status":"DESYNCHRONIZED","synchronization":sync}
  clk=self.clocks.get(q.clock_id)
  with self.db.transaction() as c:c.execute("UPDATE distributed_neural_runs SET step_index=?,simulation_time=? WHERE run_id=?",(q.step_index+1,clk.current_time,rid))
  return {"committed":True,"status":"READY","step_index":q.step_index+1,"simulation_time":clk.current_time,"synchronization":sync}
 def hold(self,rid,reason):
  self.get(rid)
  with self.db.transaction() as c:c.execute("UPDATE distributed_neural_runs SET status=? WHERE run_id=?",("HELD",rid))
  self.audit.append("WARNING","neural_simulacrum.distributed","held",subject=rid,details={"reason":str(reason)})
  return self.get(rid)
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM distributed_neural_runs").fetchone()["n"]
  return {"runs":n,"transport":"EXISTING AEON DISTRIBUTED-JOB LAYER / NOT EXTENDED BY P061",
   "note":"P061 provides partition assignment and synchronization/commit control. It does not claim hardened live neural transport, replay protection, TLS, or production cluster safety."}
