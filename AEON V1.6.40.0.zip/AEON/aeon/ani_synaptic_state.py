from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid,math

class ANISynapticStateError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")
KNOWN_PROPERTIES=("WEIGHT","DELAY","RELEASE_PROBABILITY","REVERSAL_POTENTIAL","RECEPTOR_STATE","NEUROTRANSMITTER","PLASTICITY","CONDUCTANCE","OTHER")

@dataclass(frozen=True)
class SynapticParameter:
 parameter_id:str;edge_id:str;property_name:str;value:object;unit:str;provenance:str;confidence:float|None;source_ref:str|None;uncertainty:dict

@dataclass(frozen=True)
class ANISynapticState:
 synaptic_state_id:str;topology_id:str;created_unix:float;model_family:str;parameters:tuple[SynapticParameter,...]
 explicitly_unmeasured:tuple[tuple[str,str],...];assumptions:tuple[str,...];source_topology_sha256:str;definition_sha256:str

class ANISynapticStateService:
 """Explicit synaptic parameters; absent physiology is never synthesized silently."""
 def __init__(self,db,audit,topologies):
  self.db=db;self.audit=audit;self.topologies=topologies;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS ani_synaptic_states(
   synaptic_state_id TEXT PRIMARY KEY,topology_id TEXT NOT NULL,created_unix REAL NOT NULL,model_family TEXT NOT NULL,
   parameters_json TEXT NOT NULL,unmeasured_json TEXT NOT NULL,assumptions_json TEXT NOT NULL,
   source_topology_sha256 TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def create(self,topology_id,parameters=(),explicitly_unmeasured=(),assumptions=()):
  topo=self.topologies.get(topology_id)
  if not self.topologies.verify(topology_id)["all_ok"]:raise ANISynapticStateError("ANI topology integrity failed")
  edgeids={e.edge_id for e in topo.edges};out=[];seen=set()
  for raw in parameters:
   x=dict(raw);edge=str(x.get("edge_id",""));prop=str(x.get("property_name","")).upper()
   if edge not in edgeids:raise ANISynapticStateError("parameter references absent topology edge")
   if prop not in KNOWN_PROPERTIES:raise ANISynapticStateError("invalid synaptic property")
   key=(edge,prop)
   if key in seen:raise ANISynapticStateError("duplicate edge/property parameter")
   seen.add(key);prov=str(x.get("provenance","UNKNOWN"))
   if prov not in PROVENANCE:raise ANISynapticStateError("invalid provenance")
   conf=x.get("confidence")
   if conf is not None:
    conf=float(conf)
    if not math.isfinite(conf) or not 0<=conf<=1:raise ANISynapticStateError("confidence must be within [0,1]")
   value=x.get("value")
   if isinstance(value,float) and not math.isfinite(value):raise ANISynapticStateError("numeric parameter must be finite")
   pid=str(x.get("parameter_id") or ("synparam-"+uuid.uuid4().hex))
   out.append(SynapticParameter(pid,edge,prop,value,str(x.get("unit","")),prov,conf,
    str(x["source_ref"]) if x.get("source_ref") is not None else None,dict(x.get("uncertainty") or {})))
  missing=[]
  for pair in explicitly_unmeasured:
   if len(pair)!=2:raise ANISynapticStateError("unmeasured entry must be edge/property pair")
   edge,prop=str(pair[0]),str(pair[1]).upper()
   if edge not in edgeids or prop not in KNOWN_PROPERTIES:raise ANISynapticStateError("invalid unmeasured edge/property")
   if (edge,prop) in seen:raise ANISynapticStateError("property cannot be both supplied and explicitly unmeasured")
   missing.append((edge,prop))
  payload={"topology_id":topology_id,"model_family":topo.model_family,"parameters":[p.__dict__ for p in out],
   "explicitly_unmeasured":tuple(sorted(set(missing))),"assumptions":tuple(str(x) for x in assumptions),"source_topology_sha256":topo.definition_sha256}
  try:raw=self._canon(payload)
  except (TypeError,ValueError) as exc:raise ANISynapticStateError("synaptic state must be JSON-serializable") from exc
  sha=hashlib.sha256(raw.encode()).hexdigest();sid="ani-syn-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO ani_synaptic_states VALUES(?,?,?,?,?,?,?,?,?)",
   (sid,topology_id,now,topo.model_family,json.dumps(payload["parameters"],sort_keys=True),json.dumps(payload["explicitly_unmeasured"]),
    json.dumps(payload["assumptions"]),topo.definition_sha256,sha))
  self.audit.append("INFO","ani.synaptic_state","created",subject=sid,details={"parameters":len(out),"unmeasured":len(missing),"definition_sha256":sha})
  return self.get(sid)
 def get(self,sid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM ani_synaptic_states WHERE synaptic_state_id=?",(sid,)).fetchone()
  if r is None:raise ANISynapticStateError("unknown ANI synaptic state")
  return ANISynapticState(r["synaptic_state_id"],r["topology_id"],r["created_unix"],r["model_family"],
   tuple(SynapticParameter(**x) for x in json.loads(r["parameters_json"])),tuple(tuple(x) for x in json.loads(r["unmeasured_json"])),
   tuple(json.loads(r["assumptions_json"])),r["source_topology_sha256"],r["definition_sha256"])
 def verify(self,sid):
  q=self.get(sid)
  try:t=self.topologies.get(q.topology_id);source_ok=t.definition_sha256==q.source_topology_sha256 and self.topologies.verify(q.topology_id)["all_ok"]
  except Exception:source_ok=False
  payload={"topology_id":q.topology_id,"model_family":q.model_family,"parameters":[p.__dict__ for p in q.parameters],
   "explicitly_unmeasured":q.explicitly_unmeasured,"assumptions":q.assumptions,"source_topology_sha256":q.source_topology_sha256}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  return {"definition_ok":definition_ok,"source_ok":bool(source_ok),"all_ok":definition_ok and bool(source_ok)}
 def summary(self,sid):
  q=self.get(sid)
  return {"parameters":len(q.parameters),"explicitly_unmeasured":len(q.explicitly_unmeasured),
   "provenance_counts":{p:sum(x.provenance==p for x in q.parameters) for p in PROVENANCE},
   "note":"Structural synapse detection does not supply missing weight, receptor, transmitter, plasticity, release or conductance state."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["synaptic_state_id"] for r in c.execute("SELECT synaptic_state_id FROM ani_synaptic_states ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
