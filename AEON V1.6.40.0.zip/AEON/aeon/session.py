from __future__ import annotations
from dataclasses import dataclass
import threading
import time

@dataclass(frozen=True)
class SessionSnapshot:
    user_id: str | None
    username: str | None
    authenticated_unix: float | None

class SessionManager:
    def __init__(self):
        self._lock=threading.RLock()
        self._user=None
        self._authenticated_unix=None

    def login(self,user):
        with self._lock:
            self._user=user
            self._authenticated_unix=time.time()

    def logout(self):
        with self._lock:
            self._user=None
            self._authenticated_unix=None

    @property
    def user_id(self):
        with self._lock:
            return self._user.user_id if self._user else None

    @property
    def user(self):
        with self._lock:
            return self._user

    def snapshot(self):
        with self._lock:
            return SessionSnapshot(
                self._user.user_id if self._user else None,
                self._user.username if self._user else None,
                self._authenticated_unix)
