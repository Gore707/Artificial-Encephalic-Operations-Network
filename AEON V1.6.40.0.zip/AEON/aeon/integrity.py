from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,os,time,uuid,zlib

class IntegrityError(RuntimeError):pass

@dataclass(frozen=True)
class IntegrityRecord:
    record_id:str;object_type:str;object_id:str;path:str;algorithm:str
    digest:str;size_bytes:int;chunk_size:int;chunk_crc32:tuple[str,...]
    created_unix:float

@dataclass(frozen=True)
class IntegrityResult:
    record_id:str;ok:bool;reason:str;bad_chunks:tuple[int,...]
    expected_size:int;actual_size:int|None

class IntegrityService:
    """AEON file integrity catalog using SHA-256 plus per-chunk CRC32.

    CRC32 provides fast localization of damaged chunks; SHA-256 is the
    authoritative content-integrity digest. This is detection, not correction:
    P020 never claims ECC can reconstruct bytes without redundant source data.
    """
    def __init__(self,db,audit):
        self.db=db;self.audit=audit;self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS integrity_records(
             record_id TEXT PRIMARY KEY,object_type TEXT NOT NULL,object_id TEXT NOT NULL,
             path TEXT NOT NULL,algorithm TEXT NOT NULL,digest TEXT NOT NULL,
             size_bytes INTEGER NOT NULL,chunk_size INTEGER NOT NULL,
             chunk_crc_json TEXT NOT NULL,created_unix REAL NOT NULL)""")
            c.execute("""CREATE INDEX IF NOT EXISTS idx_integrity_object
                         ON integrity_records(object_type,object_id,created_unix)""")

    def register_file(self,object_type,object_id,path:Path,chunk_size=1024*1024):
        object_type=object_type.strip();object_id=object_id.strip();p=Path(path)
        if not object_type or not object_id:raise IntegrityError("object type/id required")
        if not p.is_file():raise IntegrityError(f"file not found: {p}")
        if not isinstance(chunk_size,int) or chunk_size<4096:raise IntegrityError("chunk_size must be >= 4096")
        digest,crcs,size=self._scan(p,chunk_size)
        rid="int-"+uuid.uuid4().hex;now=time.time()
        with self.db.transaction() as c:
            c.execute("INSERT INTO integrity_records VALUES(?,?,?,?,?,?,?,?,?,?)",
              (rid,object_type,object_id,str(p),"SHA-256",digest,size,chunk_size,
               json.dumps(crcs,separators=(",",":")),now))
        self.audit.append("INFO","integrity","registered",subject=rid,
          details={"object_type":object_type,"object_id":object_id,"sha256":digest,"size_bytes":size})
        return self.get(rid)

    def get(self,rid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM integrity_records WHERE record_id=?",(rid,)).fetchone()
        if r is None:raise IntegrityError(f"Unknown integrity record: {rid}")
        return IntegrityRecord(r["record_id"],r["object_type"],r["object_id"],r["path"],r["algorithm"],
          r["digest"],r["size_bytes"],r["chunk_size"],tuple(json.loads(r["chunk_crc_json"])),r["created_unix"])

    def list(self,limit=200):
        with self.db._connect() as c:
            ids=[r["record_id"] for r in c.execute(
                "SELECT record_id FROM integrity_records ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get(i) for i in ids)

    def verify(self,rid,audit_failure=True):
        rec=self.get(rid);p=Path(rec.path)
        if not p.is_file():
            result=IntegrityResult(rid,False,"file missing",(),rec.size_bytes,None)
            if audit_failure:self._audit_failure(rec,result)
            return result
        digest,crcs,size=self._scan(p,rec.chunk_size)
        bad=tuple(i for i,(expected,actual) in enumerate(zip(rec.chunk_crc32,crcs)) if expected!=actual)
        if len(crcs)!=len(rec.chunk_crc32):
            bad=tuple(sorted(set(bad)|set(range(min(len(crcs),len(rec.chunk_crc32)),max(len(crcs),len(rec.chunk_crc32))))))
        reasons=[]
        if size!=rec.size_bytes:reasons.append("size mismatch")
        if bad:reasons.append(f"{len(bad)} damaged chunk(s)")
        if digest!=rec.digest:reasons.append("SHA-256 mismatch")
        result=IntegrityResult(rid,not reasons,"ok" if not reasons else "; ".join(reasons),bad,rec.size_bytes,size)
        if not result.ok and audit_failure:self._audit_failure(rec,result)
        return result

    def verify_all(self):
        return tuple(self.verify(r.record_id) for r in self.list(limit=100000))

    def _audit_failure(self,rec,result):
        self.audit.append("CRITICAL","integrity","verification_failed",subject=rec.record_id,
          details={"object_type":rec.object_type,"object_id":rec.object_id,
                   "reason":result.reason,"bad_chunks":list(result.bad_chunks)})

    @staticmethod
    def _scan(path,chunk_size):
        h=hashlib.sha256();crcs=[];size=0
        with Path(path).open("rb") as f:
            while True:
                block=f.read(chunk_size)
                if not block:break
                h.update(block);size+=len(block)
                crcs.append(f"{zlib.crc32(block)&0xffffffff:08x}")
        return h.hexdigest(),crcs,size
