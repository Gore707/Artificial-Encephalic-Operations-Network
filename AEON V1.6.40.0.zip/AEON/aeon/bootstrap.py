from __future__ import annotations
from pathlib import Path
import argparse, sys, traceback

from . import __version__
from .config import load_config, ConfigurationError
from .logging_setup import configure_logging
from .preflight import run_preflight, write_report

def project_root() -> Path:
    return Path(__file__).resolve().parents[1]

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="AEON")
    parser.add_argument("--preflight", action="store_true", help="Run startup qualification and exit.")
    parser.add_argument("--version", action="store_true", help="Print AEON version and exit.")
    parser.add_argument("--no-ui", action="store_true", help="Initialize and qualify without opening the desktop.")
    args = parser.parse_args(argv)

    if args.version:
        print(f"AEON {__version__}")
        return 0

    root = project_root()
    try:
        cfg = load_config(root)
        logger = configure_logging(
            cfg.path("paths.logs"),
            str(cfg.get("logging.level", "INFO")),
            int(cfg.get("logging.max_bytes", 5_242_880)),
            int(cfg.get("logging.backup_count", 5)),
        )
        logger.info("AEON bootstrap starting | version=%s | root=%s", __version__, root)
        ok, checks = run_preflight(root, cfg)
        report = write_report(cfg.path("paths.state"), checks)
        for check in checks:
            logger.info("PREFLIGHT %-20s %s | %s", check.name, "PASS" if check.ok else "FAIL", check.detail)
        if not ok:
            logger.critical("AEON preflight failed. Report: %s", report)
            return 2
        if args.preflight:
            print(f"AEON {__version__} preflight: PASS")
            return 0
        if args.no_ui:
            print(f"AEON {__version__} initialized successfully.")
            return 0

        from .desktop import AeonDesktop
        AeonDesktop(root, cfg, logger).run()
        return 0
    except ConfigurationError as exc:
        print(f"[AEON] Configuration failure: {exc}", file=sys.stderr)
        return 3
    except Exception:
        traceback.print_exc()
        return 99

if __name__ == "__main__":
    raise SystemExit(main())
