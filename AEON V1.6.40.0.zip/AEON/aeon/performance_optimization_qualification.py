from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class PerformanceQualificationError(RuntimeError):pass

@dataclass(frozen=True)
class PerformanceQualification:
 qualification_id:str;created_unix:float;status:str;checks_json:str;evidence_sha256:str

class PerformanceOptimizationQualification:
 """P090 evidence-bound qualification for P087-P089.
 Evaluates recorded measurements/plans without inventing a universal performance target.
 """
 def __init__(self,db,audit,p087,p088,p089):
  self.db=db;self.audit=audit;self.p087=p087;self.p088=p088;self.p089=p089;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p090_performance_qualifications(
   qualification_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,status TEXT NOT NULL,checks_json TEXT NOT NULL,evidence_sha256 TEXT NOT NULL)""")
 def qualify(self,benchmark_id,workload_plan_id,cluster_plan_id,node_capacities):
  b=self.p087.get(benchmark_id);bp=self.p087.verify(benchmark_id)
  w=self.p088.get(workload_plan_id);wp=self.p088.verify(workload_plan_id)
  c=self.p089.get(cluster_plan_id);cp=self.p089.verify(cluster_plan_id,node_capacities)
  checks=[
   {"check":"benchmark_integrity","pass":bool(bp["all_ok"]),"evidence":benchmark_id},
   {"check":"benchmark_samples","pass":b.iterations>0 and b.minimum_ns>0 and b.p95_ns>=b.minimum_ns,"evidence":{"iterations":b.iterations,"median_ns":b.median_ns,"p95_ns":b.p95_ns}},
   {"check":"local_plan_integrity","pass":bool(wp["all_ok"]),"evidence":workload_plan_id},
   {"check":"local_plan_bounds","pass":1<=w.workers<=w.host_logical_cpus and w.chunk_size>=1 and w.memory_budget_bytes>=1,"evidence":{"workers":w.workers,"host_logical_cpus":w.host_logical_cpus,"chunk_size":w.chunk_size}},
   {"check":"cluster_plan_integrity","pass":bool(cp["all_ok"]),"evidence":cluster_plan_id},
   {"check":"cluster_accounting","pass":sum(json.loads(c.assignments_json).values())==c.total_units,"evidence":{"total_units":c.total_units,"assignments":json.loads(c.assignments_json)}},
  ]
  status="PASS" if all(x["pass"] for x in checks) else "FAIL"
  canonical=json.dumps(checks,sort_keys=True,separators=(",",":"));sha=hashlib.sha256(canonical.encode()).hexdigest();qid="p090-"+uuid.uuid4().hex
  with self.db.transaction() as db:db.execute("INSERT INTO p090_performance_qualifications VALUES(?,?,?,?,?)",(qid,time.time(),status,canonical,sha))
  self.audit.append("INFO" if status=="PASS" else "CRITICAL","performance.p090","qualification_complete",subject=qid,details={"status":status,"checks":len(checks)})
  return self.get(qid)
 def get(self,qid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p090_performance_qualifications WHERE qualification_id=?",(qid,)).fetchone()
  if r is None:raise PerformanceQualificationError("unknown performance qualification")
  return PerformanceQualification(r["qualification_id"],r["created_unix"],r["status"],r["checks_json"],r["evidence_sha256"])
 def verify(self,qid):
  r=self.get(qid);sha=hashlib.sha256(r.checks_json.encode()).hexdigest()
  return {"qualification_id":qid,"all_ok":sha==r.evidence_sha256,"status":r.status}
 def readiness(self):
  return {"phase":"P087-P090 PERFORMANCE & CLUSTER OPTIMIZATION","status":"MEASUREMENT/PLANNING QUALIFICATION AVAILABLE",
   "qualified_scope":["local callable timing evidence","integrity-bound benchmark records","bounded cooperative local workload plans","capacity-weighted deterministic cluster placement","cross-layer evidence qualification"],
   "not_claimed":["whole-brain performance","GPU/SNN throughput without benchmark evidence","measured multi-node speedup","network-aware live scheduling","hard OS resource enforcement","thermal safety enforcement"],
   "claim":"P090 qualifies integrity and internal consistency of measured/planned performance evidence; it does not certify a universal speedup or production performance envelope."}
