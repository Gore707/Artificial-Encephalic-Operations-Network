from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,math,time,uuid

class ClusterOptimizationError(RuntimeError):pass

@dataclass(frozen=True)
class ClusterOptimizationPlan:
 plan_id:str;created_unix:float;workload:str;total_units:int;assignments_json:str;estimated_imbalance:float;plan_sha256:str

class ClusterPerformanceOptimizer:
 """P089 deterministic capacity-weighted cluster placement.
 Capacity values are explicit inputs/evidence, not invented hardware benchmarks.
 """
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p089_cluster_optimization_plans(
   plan_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,workload TEXT NOT NULL,total_units INTEGER NOT NULL,
   assignments_json TEXT NOT NULL,estimated_imbalance REAL NOT NULL,plan_sha256 TEXT NOT NULL)""")
 def plan(self,workload,total_units,node_capacities):
  name=str(workload).strip();units=int(total_units)
  caps={str(k):float(v) for k,v in dict(node_capacities).items()}
  if not name or units<1 or not caps or any((not math.isfinite(v) or v<=0) for v in caps.values()):raise ClusterOptimizationError("invalid workload/capacities")
  total=sum(caps.values());raw={k:units*v/total for k,v in caps.items()};assigned={k:int(math.floor(v)) for k,v in raw.items()}
  remaining=units-sum(assigned.values())
  order=sorted(caps,key=lambda k:(-(raw[k]-assigned[k]),k))
  for k in order[:remaining]:assigned[k]+=1
  normalized=[assigned[k]/caps[k] for k in caps];imbalance=(max(normalized)-min(normalized)) if len(normalized)>1 else 0.0
  assignments=json.dumps(assigned,sort_keys=True,separators=(",",":"))
  payload={"workload":name,"total_units":units,"assignments":assigned,"estimated_imbalance":imbalance}
  sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest();pid="p089-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p089_cluster_optimization_plans VALUES(?,?,?,?,?,?,?)",(pid,time.time(),name,units,assignments,imbalance,sha))
  self.audit.append("INFO","performance.p089","cluster_plan",subject=pid,details={"workload":name,"total_units":units,"nodes":len(caps),"estimated_imbalance":imbalance})
  return self.get(pid)
 def get(self,pid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p089_cluster_optimization_plans WHERE plan_id=?",(pid,)).fetchone()
  if r is None:raise ClusterOptimizationError("unknown cluster plan")
  return ClusterOptimizationPlan(r["plan_id"],r["created_unix"],r["workload"],r["total_units"],r["assignments_json"],r["estimated_imbalance"],r["plan_sha256"])
 def verify(self,pid,node_capacities):
  r=self.get(pid);a=json.loads(r.assignments_json);caps={str(k):float(v) for k,v in dict(node_capacities).items()}
  if set(a)!=set(caps) or sum(a.values())!=r.total_units:return {"plan_id":pid,"all_ok":False,"reason":"node set or unit total mismatch"}
  normalized=[a[k]/caps[k] for k in caps];imb=(max(normalized)-min(normalized)) if len(normalized)>1 else 0.0
  payload={"workload":r.workload,"total_units":r.total_units,"assignments":a,"estimated_imbalance":imb}
  sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
  return {"plan_id":pid,"all_ok":sha==r.plan_sha256 and abs(imb-r.estimated_imbalance)<1e-12,"computed_sha256":sha}
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM p089_cluster_optimization_plans").fetchone()["n"]
  return {"phase":"PERFORMANCE & CLUSTER OPTIMIZATION III","plans":n,"scope":"Deterministic capacity-weighted placement using supplied node capacities. No claim of live network-aware scheduling, RDMA, or measured multi-node speedup."}
