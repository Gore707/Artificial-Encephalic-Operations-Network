from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class ANITopologyError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")

@dataclass(frozen=True)
class ANITopologyNode:
 node_id:str;source_node_id:str|None;cell_classification_id:str|None;provenance:str;attributes:dict

@dataclass(frozen=True)
class ANITopologyEdge:
 edge_id:str;source_node_id:str|None;target_node_id:str|None;source_synapse_id:str|None
 kind:str;direction:str;provenance:str;confidence:float|None;attributes:dict

@dataclass(frozen=True)
class ANITopology:
 topology_id:str;ani_spec_id:str;created_unix:float;model_family:str;nodes:tuple[ANITopologyNode,...]
 edges:tuple[ANITopologyEdge,...];source_hashes:tuple[tuple[str,str],...];definition_sha256:str

class ANITopologyService:
 """Formal ANI topology with model-aware, non-universal graph semantics."""
 def __init__(self,db,audit,specifications,connectomes):
  self.db=db;self.audit=audit;self.specifications=specifications;self.connectomes=connectomes;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS ani_topologies(
   topology_id TEXT PRIMARY KEY,ani_spec_id TEXT NOT NULL,created_unix REAL NOT NULL,model_family TEXT NOT NULL,
   nodes_json TEXT NOT NULL,edges_json TEXT NOT NULL,source_hashes_json TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def create_from_connectome(self,ani_spec_id,connectome_id,model_family,extra_node_attributes=None,extra_edge_attributes=None):
  spec=self.specifications.get(ani_spec_id)
  if not self.specifications.verify(ani_spec_id)["all_ok"]:raise ANITopologyError("ANI specification integrity failed")
  conn=self.connectomes.get(connectome_id)
  if not self.connectomes.verify(connectome_id)["all_ok"]:raise ANITopologyError("connectome integrity failed")
  if spec.source_connectome_id is not None and spec.source_connectome_id!=connectome_id:raise ANITopologyError("ANI specification is bound to a different connectome")
  mf=str(model_family).strip()
  if not mf:raise ANITopologyError("model family required")
  na=dict(extra_node_attributes or {});ea=dict(extra_edge_attributes or {})
  nodes=tuple(ANITopologyNode(n.node_id,n.node_id,n.classification_id,n.provenance,dict(na.get(n.node_id,{}) or {})) for n in conn.nodes)
  nodeids={n.node_id for n in nodes}
  edges=[]
  for e in conn.edges:
   if e.source_node_id is not None and e.source_node_id not in nodeids:raise ANITopologyError("edge source absent")
   if e.target_node_id is not None and e.target_node_id not in nodeids:raise ANITopologyError("edge target absent")
   # Partial endpoints, self-edges and cycles are retained; the selected neural model decides whether they are valid.
   edges.append(ANITopologyEdge(e.edge_id,e.source_node_id,e.target_node_id,e.synapse_id,e.kind,e.direction,e.provenance,e.confidence,dict(ea.get(e.edge_id,{}) or {})))
  bindings=(("ANI_SPEC:"+ani_spec_id,spec.definition_sha256),("CONNECTOME:"+connectome_id,conn.definition_sha256))
  payload={"ani_spec_id":ani_spec_id,"model_family":mf,"nodes":[n.__dict__ for n in nodes],"edges":[e.__dict__ for e in edges],"source_hashes":bindings}
  sha=hashlib.sha256(self._canon(payload).encode()).hexdigest();tid="ani-topology-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO ani_topologies VALUES(?,?,?,?,?,?,?,?)",
   (tid,ani_spec_id,now,mf,json.dumps(payload["nodes"],sort_keys=True),json.dumps(payload["edges"],sort_keys=True),json.dumps(bindings),sha))
  self.audit.append("INFO","ani.topology","created",subject=tid,details={"model_family":mf,"nodes":len(nodes),"edges":len(edges),"definition_sha256":sha})
  return self.get(tid)
 def get(self,tid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM ani_topologies WHERE topology_id=?",(tid,)).fetchone()
  if r is None:raise ANITopologyError("unknown ANI topology")
  return ANITopology(r["topology_id"],r["ani_spec_id"],r["created_unix"],r["model_family"],
   tuple(ANITopologyNode(**x) for x in json.loads(r["nodes_json"])),tuple(ANITopologyEdge(**x) for x in json.loads(r["edges_json"])),
   tuple(tuple(x) for x in json.loads(r["source_hashes_json"])),r["definition_sha256"])
 def verify(self,tid):
  q=self.get(tid);source_ok=True
  for key,sha in q.source_hashes:
   try:
    typ,rid=key.split(":",1)
    svc=self.specifications if typ=="ANI_SPEC" else self.connectomes
    obj=svc.get(rid);source_ok &= obj.definition_sha256==sha and svc.verify(rid)["all_ok"]
   except Exception:source_ok=False
  payload={"ani_spec_id":q.ani_spec_id,"model_family":q.model_family,"nodes":[n.__dict__ for n in q.nodes],"edges":[e.__dict__ for e in q.edges],"source_hashes":q.source_hashes}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  return {"definition_ok":definition_ok,"source_ok":bool(source_ok),"all_ok":definition_ok and bool(source_ok)}
 def summary(self,tid):
  q=self.get(tid)
  return {"nodes":len(q.nodes),"edges":len(q.edges),
   "partial_edges":sum(e.source_node_id is None or e.target_node_id is None for e in q.edges),
   "self_edges":sum(e.source_node_id is not None and e.source_node_id==e.target_node_id for e in q.edges),
   "model_family":q.model_family,
   "note":"Topology integrity is structural. Biological validity of recurrence, termination and connectivity is model-aware and belongs to Genesis validation."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["topology_id"] for r in c.execute("SELECT topology_id FROM ani_topologies ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
