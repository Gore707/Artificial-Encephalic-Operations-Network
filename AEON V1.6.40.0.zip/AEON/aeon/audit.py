from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib, json, os, platform, sys, time, uuid

class AuditError(RuntimeError):
    pass

@dataclass(frozen=True)
class AuditEvent:
    event_id: str
    sequence: int
    timestamp_unix: float
    severity: str
    category: str
    action: str
    actor: str
    subject: str | None
    details: dict[str, Any]
    previous_hash: str
    event_hash: str

class AuditTrail:
    SEVERITIES = ("INFO","ADVISORY","WARNING","CRITICAL","SAFETY_INTERVENTION")

    def __init__(self, state_db):
        self.db = state_db
        self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS audit_events(
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT NOT NULL UNIQUE,
                timestamp_unix REAL NOT NULL,
                severity TEXT NOT NULL,
                category TEXT NOT NULL,
                action TEXT NOT NULL,
                actor TEXT NOT NULL,
                subject TEXT,
                details_json TEXT NOT NULL,
                previous_hash TEXT NOT NULL,
                event_hash TEXT NOT NULL UNIQUE)""")
            conn.execute("""CREATE TRIGGER IF NOT EXISTS audit_events_no_update
                BEFORE UPDATE ON audit_events BEGIN
                SELECT RAISE(ABORT,'AEON audit events are append-only'); END""")
            conn.execute("""CREATE TRIGGER IF NOT EXISTS audit_events_no_delete
                BEFORE DELETE ON audit_events BEGIN
                SELECT RAISE(ABORT,'AEON audit events are append-only'); END""")

    @staticmethod
    def _hash(payload):
        raw=json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
        return hashlib.sha256(raw).hexdigest()

    def append(self,severity,category,action,*,actor="AEON",subject=None,details=None):
        severity=severity.strip().upper()
        if severity not in self.SEVERITIES:
            raise AuditError(f"Invalid audit severity: {severity}")
        category,action,actor=category.strip(),action.strip(),actor.strip()
        if not category or not action or not actor:
            raise AuditError("category, action, and actor are required")
        details=dict(details or {})
        json.dumps(details)
        eid="evt-"+uuid.uuid4().hex
        ts=time.time()
        with self.db.transaction() as conn:
            row=conn.execute("SELECT event_hash FROM audit_events ORDER BY sequence DESC LIMIT 1").fetchone()
            prev=row["event_hash"] if row else "GENESIS"
            payload={"event_id":eid,"timestamp_unix":ts,"severity":severity,
                     "category":category,"action":action,"actor":actor,
                     "subject":subject,"details":details,"previous_hash":prev}
            digest=self._hash(payload)
            cur=conn.execute("""INSERT INTO audit_events(
                event_id,timestamp_unix,severity,category,action,actor,subject,
                details_json,previous_hash,event_hash) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (eid,ts,severity,category,action,actor,subject,
                 json.dumps(details,sort_keys=True,separators=(",",":"),ensure_ascii=False),
                 prev,digest))
            seq=int(cur.lastrowid)
        return AuditEvent(eid,seq,ts,severity,category,action,actor,subject,details,prev,digest)

    def recent(self,limit=200):
        limit=max(1,min(int(limit),5000))
        with self.db._connect() as conn:
            rows=conn.execute("SELECT * FROM audit_events ORDER BY sequence DESC LIMIT ?",(limit,)).fetchall()
        return tuple(self._row(r) for r in reversed(rows))

    def verify(self):
        with self.db._connect() as conn:
            rows=conn.execute("SELECT * FROM audit_events ORDER BY sequence").fetchall()
        prev="GENESIS"
        for r in rows:
            try: details=json.loads(r["details_json"])
            except json.JSONDecodeError:
                return False,f"Invalid details JSON at sequence {r['sequence']}"
            if r["previous_hash"] != prev:
                return False,f"Broken hash chain at sequence {r['sequence']}"
            payload={"event_id":r["event_id"],"timestamp_unix":float(r["timestamp_unix"]),
                     "severity":r["severity"],"category":r["category"],"action":r["action"],
                     "actor":r["actor"],"subject":r["subject"],"details":details,
                     "previous_hash":r["previous_hash"]}
            if self._hash(payload) != r["event_hash"]:
                return False,f"Hash mismatch at sequence {r['sequence']}"
            prev=r["event_hash"]
        return True,f"Audit chain verified: {len(rows)} event(s)"

    def _row(self,r):
        return AuditEvent(r["event_id"],int(r["sequence"]),float(r["timestamp_unix"]),
                          r["severity"],r["category"],r["action"],r["actor"],r["subject"],
                          json.loads(r["details_json"]),r["previous_hash"],r["event_hash"])

class Diagnostics:
    def __init__(self,root,config,state_db,audit):
        self.root=Path(root); self.config=config; self.db=state_db; self.audit=audit

    def snapshot(self):
        db_ok,db_detail=self.db.integrity_check()
        audit_ok,audit_detail=self.audit.verify()
        return {"timestamp_unix":time.time(),"aeon_root":str(self.root),
                "python":sys.version.split()[0],"platform":platform.platform(),
                "database":{"ok":db_ok,"detail":db_detail},
                "audit":{"ok":audit_ok,"detail":audit_detail},
                "paths":{"state":str(self.config.path("paths.state")),
                         "logs":str(self.config.path("paths.logs")),
                         "data":str(self.config.path("paths.data"))}}

    def write_snapshot(self):
        d=self.config.path("paths.state")/"diagnostics"; d.mkdir(parents=True,exist_ok=True)
        target=d/"latest.json"; tmp=target.with_suffix(".tmp")
        with tmp.open("w",encoding="utf-8") as f:
            f.write(json.dumps(self.snapshot(),indent=2,sort_keys=True)); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,target)
        return target
