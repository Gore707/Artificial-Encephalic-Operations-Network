from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import csv,math,statistics

class VisualizationStudioError(RuntimeError):pass

@dataclass(frozen=True)
class NumericColumn:
    name:str;values:tuple[float,...];count:int;minimum:float;maximum:float;mean:float
@dataclass(frozen=True)
class DatasetPlot:
    dataset_id:str;x_name:str;y_name:str;x:tuple[float,...];y:tuple[float,...]
    evidence_class:str;provenance:str;units_x:str;units_y:str

class ScientificVisualizationStudio:
    """Dataset-backed scientific plotting preparation.

    No random/demo telemetry is generated. Every plotted value comes from the
    selected registered dataset, and evidence/provenance travel with the plot.
    """
    def __init__(self,data_lab,audit):
        self.data_lab=data_lab;self.audit=audit
    def numeric_columns(self,dataset_id,max_rows=200000):
        d=self.data_lab.get(dataset_id)
        if d.format!="csv":raise VisualizationStudioError("P035 numeric visualization currently requires CSV")
        p=Path(d.source_path)
        if not p.is_file():raise VisualizationStudioError("original dataset locator unavailable")
        with p.open("r",encoding="utf-8-sig",newline="") as f:
            r=csv.DictReader(f)
            if not r.fieldnames:raise VisualizationStudioError("CSV has no header")
            vals={h:[] for h in r.fieldnames}
            for i,row in enumerate(r):
                if i>=max_rows:break
                for h in r.fieldnames:
                    try:v=float(row[h])
                    except (TypeError,ValueError):continue
                    if math.isfinite(v):vals[h].append(v)
        out=[]
        for h,v in vals.items():
            if v:out.append(NumericColumn(h,tuple(v),len(v),min(v),max(v),statistics.fmean(v)))
        return tuple(out)
    def make_plot(self,dataset_id,x_name,y_name,units_x="",units_y="",max_rows=200000):
        d=self.data_lab.get(dataset_id)
        if d.format!="csv":raise VisualizationStudioError("P035 plotting currently requires CSV")
        p=Path(d.source_path);xs=[];ys=[]
        with p.open("r",encoding="utf-8-sig",newline="") as f:
            r=csv.DictReader(f)
            if x_name not in (r.fieldnames or ()) or y_name not in (r.fieldnames or ()):
                raise VisualizationStudioError("selected column not present")
            for i,row in enumerate(r):
                if i>=max_rows:break
                try:x=float(row[x_name]);y=float(row[y_name])
                except (TypeError,ValueError):continue
                if math.isfinite(x) and math.isfinite(y):xs.append(x);ys.append(y)
        if not xs:raise VisualizationStudioError("no paired finite numeric samples")
        self.audit.append("INFO","apotheosis.visualization","dataset_plot_prepared",subject=dataset_id,
                          details={"x":x_name,"y":y_name,"samples":len(xs),"evidence":d.evidence_class,"provenance":d.provenance})
        return DatasetPlot(dataset_id,x_name,y_name,tuple(xs),tuple(ys),d.evidence_class,d.provenance,str(units_x),str(units_y))
