from __future__ import annotations
from dataclasses import dataclass
import time,uuid

class CognitiveGuardianError(RuntimeError):pass

@dataclass(frozen=True)
class CognitiveGuardianCase:
 case_id:str;created_unix:float;name:str;reference_state_id:str|None;reconstruction_metadata_id:str|None
 divergence_series_id:str|None;status:str

class CognitiveGuardian:
 """P068 integration boundary for Cognitive Guardian research analytics.
 Advisory/analytical only: deterministic AEON Safety Kernel remains the final machine safety authority.
 """
 def __init__(self,db,audit,anomaly,comparator,recon_conf,candidates,divergence):
  self.db=db;self.audit=audit;self.anomaly=anomaly;self.comparator=comparator
  self.recon_conf=recon_conf;self.candidates=candidates;self.divergence=divergence;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS cognitive_guardian_cases(
   case_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,name TEXT NOT NULL,reference_state_id TEXT,
   reconstruction_metadata_id TEXT,divergence_series_id TEXT,status TEXT NOT NULL)""")
 def create_case(self,name,reference_state_id=None,reconstruction_metadata_id=None,divergence_series_id=None):
  name=str(name).strip()
  if not name:raise CognitiveGuardianError("case name required")
  if reference_state_id:self.comparator.get_state(reference_state_id)
  if reconstruction_metadata_id:
   v=self.recon_conf.metadata.verify(reconstruction_metadata_id)
   if not v.get("all_ok",False):raise CognitiveGuardianError("reconstruction metadata verification failed")
  cid="cogguard-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_guardian_cases VALUES(?,?,?,?,?,?,?)",
   (cid,time.time(),name,reference_state_id,reconstruction_metadata_id,divergence_series_id,"OPEN"))
  self.audit.append("INFO","cognitive_guardian","case_created",subject=cid,details={"name":name})
  return self.get_case(cid)
 def get_case(self,cid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_guardian_cases WHERE case_id=?",(cid,)).fetchone()
  if r is None:raise CognitiveGuardianError("unknown Cognitive Guardian case")
  return CognitiveGuardianCase(r["case_id"],r["created_unix"],r["name"],r["reference_state_id"],r["reconstruction_metadata_id"],r["divergence_series_id"],r["status"])
 def assess_reconstruction(self,cid):
  q=self.get_case(cid)
  if not q.reconstruction_metadata_id:raise CognitiveGuardianError("case has no reconstruction metadata")
  return self.recon_conf.assess(q.reconstruction_metadata_id)
 def compare_to_reference(self,cid,observed_state_id):
  q=self.get_case(cid)
  if not q.reference_state_id:raise CognitiveGuardianError("case has no reference state")
  return self.comparator.compare(q.reference_state_id,observed_state_id)
 def record_divergence(self,cid,observed_state_id,simulation_time,time_unit):
  q=self.get_case(cid)
  if not q.reference_state_id or not q.divergence_series_id:raise CognitiveGuardianError("case requires reference state and divergence series")
  return self.divergence.record(q.divergence_series_id,q.reference_state_id,observed_state_id,simulation_time,time_unit)
 def status_report(self,cid):
  q=self.get_case(cid);report={"case_id":cid,"status":q.status,"reference_state_id":q.reference_state_id,
   "reconstruction_metadata_id":q.reconstruction_metadata_id,"divergence_series_id":q.divergence_series_id,
   "information_sufficiency":"UNDETERMINED","safety_authority":"AEON SAFETY KERNEL / DETERMINISTIC",
   "guardian_authority":"ANALYTICAL_ADVISORY","identity_status":"UNDETERMINED","consciousness_status":"UNDETERMINED"}
  if q.divergence_series_id:report["divergence_trend"]=self.divergence.trend(q.divergence_series_id)
  return report
 def close_case(self,cid):
  self.get_case(cid)
  with self.db.transaction() as c:c.execute("UPDATE cognitive_guardian_cases SET status='CLOSED' WHERE case_id=?",(cid,))
  self.audit.append("INFO","cognitive_guardian","case_closed",subject=cid,details={});return self.get_case(cid)
 def list_cases(self,limit=250):
  with self.db._connect() as c:ids=[r["case_id"] for r in c.execute("SELECT case_id FROM cognitive_guardian_cases ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get_case(x) for x in ids)
 def summary(self):
  with self.db._connect() as c:
   total=c.execute("SELECT COUNT(*) n FROM cognitive_guardian_cases").fetchone()["n"]
   opened=c.execute("SELECT COUNT(*) n FROM cognitive_guardian_cases WHERE status='OPEN'").fetchone()["n"]
  return {"release":"COGNITIVE GUARDIAN 1.0","cases":total,"open_cases":opened,
   "capabilities":("ANOMALY_DETECTION","STATE_COMPARISON","RECONSTRUCTION_CONFIDENCE","CANDIDATE_RECONSTRUCTION","COGNITIVE_DIVERGENCE"),
   "note":"Guardian analytics remain subordinate to deterministic safety controls and cannot certify identity, consciousness, MSCS, or upload sufficiency."}
