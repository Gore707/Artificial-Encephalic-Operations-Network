from __future__ import annotations
from dataclasses import dataclass
import math,time,uuid

class NeuronSimulationError(RuntimeError):pass

@dataclass(frozen=True)
class NeuronModel:
 model_id:str;model_type:str;parameters:dict;units:dict

@dataclass(frozen=True)
class NeuronState:
 state_id:str;model_id:str;created_unix:float;values:dict;simulation_time:float

class NeuronSimulationEngine:
 """Deterministic single-neuron stepping foundation. No ANI is executed here."""
 SUPPORTED=("LEAKY_INTEGRATE_AND_FIRE",)
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:
   c.execute("""CREATE TABLE IF NOT EXISTS neuron_models(model_id TEXT PRIMARY KEY,model_type TEXT NOT NULL,parameters_json TEXT NOT NULL,units_json TEXT NOT NULL)""")
   c.execute("""CREATE TABLE IF NOT EXISTS neuron_states(state_id TEXT PRIMARY KEY,model_id TEXT NOT NULL,created_unix REAL NOT NULL,values_json TEXT NOT NULL,simulation_time REAL NOT NULL)""")
 @staticmethod
 def _finite(x,name):
  v=float(x)
  if not math.isfinite(v):raise NeuronSimulationError(name+" must be finite")
  return v
 def create_lif_model(self,tau_m_ms=20.0,v_rest_mv=-65.0,v_reset_mv=-65.0,v_threshold_mv=-50.0,resistance_mohm=100.0):
  p={"tau_m_ms":self._finite(tau_m_ms,"tau_m_ms"),"v_rest_mv":self._finite(v_rest_mv,"v_rest_mv"),
     "v_reset_mv":self._finite(v_reset_mv,"v_reset_mv"),"v_threshold_mv":self._finite(v_threshold_mv,"v_threshold_mv"),
     "resistance_mohm":self._finite(resistance_mohm,"resistance_mohm")}
  if p["tau_m_ms"]<=0 or p["resistance_mohm"]<0:raise NeuronSimulationError("invalid LIF parameter domain")
  if p["v_reset_mv"]>=p["v_threshold_mv"]:raise NeuronSimulationError("reset must be below threshold")
  mid="neuron-model-"+uuid.uuid4().hex
  import json
  with self.db.transaction() as c:c.execute("INSERT INTO neuron_models VALUES(?,?,?,?)",(mid,"LEAKY_INTEGRATE_AND_FIRE",json.dumps(p,sort_keys=True),json.dumps({"time":"ms","voltage":"mV","current":"nA","resistance":"MOhm"})))
  self.audit.append("INFO","neural_simulacrum.neuron","model_created",subject=mid,details={"model_type":"LEAKY_INTEGRATE_AND_FIRE"})
  return self.get_model(mid)
 def get_model(self,mid):
  import json
  with self.db._connect() as c:r=c.execute("SELECT * FROM neuron_models WHERE model_id=?",(mid,)).fetchone()
  if r is None:raise NeuronSimulationError("unknown neuron model")
  return NeuronModel(r["model_id"],r["model_type"],json.loads(r["parameters_json"]),json.loads(r["units_json"]))
 def initialize(self,model_id,v_mv=None):
  m=self.get_model(model_id);v=m.parameters["v_rest_mv"] if v_mv is None else self._finite(v_mv,"v_mv")
  sid="neuron-state-"+uuid.uuid4().hex;now=time.time();vals={"v_mv":v,"spike":False}
  import json
  with self.db.transaction() as c:c.execute("INSERT INTO neuron_states VALUES(?,?,?,?,?)",(sid,model_id,now,json.dumps(vals,sort_keys=True),0.0))
  return self.get_state(sid)
 def get_state(self,sid):
  import json
  with self.db._connect() as c:r=c.execute("SELECT * FROM neuron_states WHERE state_id=?",(sid,)).fetchone()
  if r is None:raise NeuronSimulationError("unknown neuron state")
  return NeuronState(r["state_id"],r["model_id"],r["created_unix"],json.loads(r["values_json"]),r["simulation_time"])
 def step(self,state_id,dt_ms,input_current_na=0.0):
  """Forward-Euler LIF step. Caller supplies dt; no universal neural timestep is assumed."""
  import json
  s=self.get_state(state_id);m=self.get_model(s.model_id);dt=self._finite(dt_ms,"dt_ms");i=self._finite(input_current_na,"input_current_na")
  if dt<=0:raise NeuronSimulationError("dt_ms must be > 0")
  p=m.parameters;v=float(s.values["v_mv"])
  dv=dt*((p["v_rest_mv"]-v)+(p["resistance_mohm"]*i))/p["tau_m_ms"]
  nv=v+dv;spike=nv>=p["v_threshold_mv"]
  if spike:nv=p["v_reset_mv"]
  vals={"v_mv":nv,"spike":bool(spike)};nt=s.simulation_time+dt
  with self.db.transaction() as c:c.execute("UPDATE neuron_states SET values_json=?,simulation_time=? WHERE state_id=?",(json.dumps(vals,sort_keys=True),nt,state_id))
  return self.get_state(state_id)
 def simulate(self,state_id,dt_ms,input_currents):
  out=[]
  for current in input_currents:out.append(self.step(state_id,dt_ms,current))
  return tuple(out)
 def summary(self):
  with self.db._connect() as c:
   models=c.execute("SELECT COUNT(*) n FROM neuron_models").fetchone()["n"];states=c.execute("SELECT COUNT(*) n FROM neuron_states").fetchone()["n"]
  return {"models":models,"states":states,"supported_models":self.SUPPORTED,
   "note":"P055 simulates explicit mathematical neuron models only. It does not execute ANI, establish biological equivalence, or claim consciousness."}
