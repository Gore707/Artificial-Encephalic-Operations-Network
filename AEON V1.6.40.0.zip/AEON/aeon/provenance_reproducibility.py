from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class ReproducibilityError(RuntimeError):pass
LEVELS=("BIT-EXACT","NUMERICALLY-REPRODUCIBLE","BEHAVIORALLY-REPRODUCIBLE","NON-DETERMINISTIC")

@dataclass(frozen=True)
class ReproducibilityRecord:
 record_id:str;experiment_id:str;created_unix:float;level:str;definition_sha256:str
 dataset_bindings:tuple[tuple[str,str],...];software:dict;seeds:dict;environment:dict
 notes:str;record_sha256:str

class ProvenanceReproducibilityStudio:
 """Immutable-style reproducibility manifests bound to experiment and dataset hashes."""
 def __init__(self,db,audit,data_lab,experiment_laboratory):
  self.db=db;self.audit=audit;self.data_lab=data_lab;self.experiments=experiment_laboratory;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS apotheosis_reproducibility(
   record_id TEXT PRIMARY KEY,experiment_id TEXT NOT NULL,created_unix REAL NOT NULL,level TEXT NOT NULL,
   definition_sha256 TEXT NOT NULL,dataset_bindings_json TEXT NOT NULL,software_json TEXT NOT NULL,
   seeds_json TEXT NOT NULL,environment_json TEXT NOT NULL,notes TEXT NOT NULL,record_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canonical(payload):return json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def capture(self,experiment_id,level,software=None,seeds=None,environment=None,notes=""):
  if level not in LEVELS:raise ReproducibilityError("invalid reproducibility level")
  e=self.experiments.get(experiment_id);ok,actual=self.experiments.verify_definition(experiment_id)
  if not ok:raise ReproducibilityError("experiment definition hash verification failed")
  bindings=[]
  for did in e.dataset_ids:
   d=self.data_lab.get(did);bindings.append((did,d.sha256))
  payload={"experiment_id":experiment_id,"level":level,"definition_sha256":actual,
           "dataset_bindings":bindings,"software":dict(software or {}),"seeds":dict(seeds or {}),
           "environment":dict(environment or {}),"notes":str(notes)}
  try:canonical=self._canonical(payload)
  except (TypeError,ValueError) as exc:raise ReproducibilityError("manifest fields must be JSON-serializable") from exc
  sha=hashlib.sha256(canonical.encode("utf-8")).hexdigest();rid="repro-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO apotheosis_reproducibility VALUES(?,?,?,?,?,?,?,?,?,?,?)",
   (rid,experiment_id,now,level,actual,json.dumps(bindings),json.dumps(payload["software"],sort_keys=True),
    json.dumps(payload["seeds"],sort_keys=True),json.dumps(payload["environment"],sort_keys=True),str(notes),sha))
  self.audit.append("INFO","apotheosis.reproducibility","manifest_captured",subject=rid,
   details={"experiment_id":experiment_id,"level":level,"record_sha256":sha,"dataset_count":len(bindings)})
  return self.get(rid)
 def get(self,rid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM apotheosis_reproducibility WHERE record_id=?",(rid,)).fetchone()
  if r is None:raise ReproducibilityError("unknown reproducibility record")
  return ReproducibilityRecord(r["record_id"],r["experiment_id"],r["created_unix"],r["level"],r["definition_sha256"],
   tuple(tuple(x) for x in json.loads(r["dataset_bindings_json"])),json.loads(r["software_json"]),json.loads(r["seeds_json"]),
   json.loads(r["environment_json"]),r["notes"],r["record_sha256"])
 def verify(self,rid):
  q=self.get(rid);e=self.experiments.get(q.experiment_id);definition_ok=e.definition_sha256==q.definition_sha256
  datasets=[]
  for did,sha in q.dataset_bindings:
   try:d=self.data_lab.get(did);datasets.append((did,d.sha256==sha))
   except Exception:datasets.append((did,False))
  payload={"experiment_id":q.experiment_id,"level":q.level,"definition_sha256":q.definition_sha256,
   "dataset_bindings":[list(x) for x in q.dataset_bindings],"software":q.software,"seeds":q.seeds,"environment":q.environment,"notes":q.notes}
  record_ok=hashlib.sha256(self._canonical(payload).encode("utf-8")).hexdigest()==q.record_sha256
  return {"record_ok":record_ok,"definition_ok":definition_ok,"datasets":tuple(datasets),"all_ok":record_ok and definition_ok and all(x[1] for x in datasets)}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["record_id"] for r in c.execute("SELECT record_id FROM apotheosis_reproducibility ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
