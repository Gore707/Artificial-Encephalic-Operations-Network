from __future__ import annotations
from dataclasses import dataclass
import json,math,time,uuid

class CognitiveStateComparisonError(RuntimeError):pass

@dataclass(frozen=True)
class CognitiveState:
 state_id:str;created_unix:float;name:str;values:dict;units:dict;provenance:dict;confidence:dict;source_refs:dict

@dataclass(frozen=True)
class CognitiveStateComparison:
 comparison_id:str;created_unix:float;left_state_id:str;right_state_id:str;shared_variables:tuple[str,...]
 missing_left:tuple[str,...];missing_right:tuple[str,...];metrics:dict;details:dict

class CognitiveStateComparator:
 """Quantified state comparison. Similarity/difference is not an identity or consciousness test."""
 PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:
   c.execute("""CREATE TABLE IF NOT EXISTS cognitive_states(
    state_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,name TEXT NOT NULL,values_json TEXT NOT NULL,units_json TEXT NOT NULL,
    provenance_json TEXT NOT NULL,confidence_json TEXT NOT NULL,source_refs_json TEXT NOT NULL)""")
   c.execute("""CREATE TABLE IF NOT EXISTS cognitive_state_comparisons(
    comparison_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,left_state_id TEXT NOT NULL,right_state_id TEXT NOT NULL,
    shared_json TEXT NOT NULL,missing_left_json TEXT NOT NULL,missing_right_json TEXT NOT NULL,metrics_json TEXT NOT NULL,details_json TEXT NOT NULL)""")
 def create_state(self,name,values,units,provenance,confidence,source_refs):
  name=str(name).strip()
  if not name:raise CognitiveStateComparisonError("state name required")
  vals={str(k):float(v) for k,v in dict(values).items()}
  if not vals or any(not math.isfinite(v) for v in vals.values()):raise CognitiveStateComparisonError("finite state values required")
  units={str(k):str(v).strip() for k,v in dict(units).items()};prov={str(k):str(v).upper() for k,v in dict(provenance).items()}
  conf={str(k):float(v) for k,v in dict(confidence).items()};refs={str(k):str(v).strip() for k,v in dict(source_refs).items()}
  keys=set(vals)
  if set(units)!=keys or set(prov)!=keys or set(conf)!=keys or set(refs)!=keys:raise CognitiveStateComparisonError("metadata required for every state variable")
  if any(not units[k] or prov[k] not in self.PROVENANCE or not math.isfinite(conf[k]) or not 0<=conf[k]<=1 or not refs[k] for k in keys):raise CognitiveStateComparisonError("invalid variable metadata")
  sid="cogstate-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_states VALUES(?,?,?,?,?,?,?,?)",(sid,time.time(),name,json.dumps(vals,sort_keys=True),json.dumps(units,sort_keys=True),json.dumps(prov,sort_keys=True),json.dumps(conf,sort_keys=True),json.dumps(refs,sort_keys=True)))
  return self.get_state(sid)
 def get_state(self,sid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_states WHERE state_id=?",(sid,)).fetchone()
  if r is None:raise CognitiveStateComparisonError("unknown cognitive state")
  return CognitiveState(r["state_id"],r["created_unix"],r["name"],json.loads(r["values_json"]),json.loads(r["units_json"]),json.loads(r["provenance_json"]),json.loads(r["confidence_json"]),json.loads(r["source_refs_json"]))
 def compare(self,left_state_id,right_state_id):
  a=self.get_state(left_state_id);b=self.get_state(right_state_id);ka=set(a.values);kb=set(b.values)
  shared=tuple(sorted(ka&kb));ml=tuple(sorted(kb-ka));mr=tuple(sorted(ka-kb))
  comparable=[];per={}
  for k in shared:
   if a.units[k]!=b.units[k]:
    per[k]={"comparable":False,"reason":"UNIT_MISMATCH","left_unit":a.units[k],"right_unit":b.units[k]};continue
   d=b.values[k]-a.values[k];ad=abs(d);den=max(abs(a.values[k]),abs(b.values[k]))
   rel=None if den==0 else ad/den;weight=min(a.confidence[k],b.confidence[k])
   per[k]={"comparable":True,"delta":d,"absolute_delta":ad,"relative_delta":rel,"unit":a.units[k],
           "confidence_weight":weight,"left_provenance":a.provenance[k],"right_provenance":b.provenance[k]}
   comparable.append((k,d,ad,weight))
  if comparable:
   mae=sum(x[2] for x in comparable)/len(comparable);rmse=math.sqrt(sum(x[1]**2 for x in comparable)/len(comparable))
   wsum=sum(x[3] for x in comparable);wmae=None if wsum==0 else sum(x[2]*x[3] for x in comparable)/wsum
  else:mae=rmse=wmae=None
  metrics={"comparable_count":len(comparable),"mae":mae,"rmse":rmse,"confidence_weighted_mae":wmae}
  details={"variables":per,"interpretation":"Numerical similarity is descriptive only; it does not establish personal identity, continuity, biological equivalence, or consciousness."}
  cid="cogcmp-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_state_comparisons VALUES(?,?,?,?,?,?,?,?,?)",(cid,time.time(),a.state_id,b.state_id,json.dumps(shared),json.dumps(ml),json.dumps(mr),json.dumps(metrics,sort_keys=True),json.dumps(details,sort_keys=True)))
  self.audit.append("INFO","cognitive_guardian.comparator","comparison_created",subject=cid,details={"comparable_count":len(comparable),"missing_left":len(ml),"missing_right":len(mr)})
  return self.get_comparison(cid)
 def get_comparison(self,cid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_state_comparisons WHERE comparison_id=?",(cid,)).fetchone()
  if r is None:raise CognitiveStateComparisonError("unknown comparison")
  return CognitiveStateComparison(r["comparison_id"],r["created_unix"],r["left_state_id"],r["right_state_id"],tuple(json.loads(r["shared_json"])),tuple(json.loads(r["missing_left_json"])),tuple(json.loads(r["missing_right_json"])),json.loads(r["metrics_json"]),json.loads(r["details_json"]))
 def list_comparisons(self,limit=250):
  with self.db._connect() as c:ids=[r["comparison_id"] for r in c.execute("SELECT comparison_id FROM cognitive_state_comparisons ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get_comparison(x) for x in ids)
 def summary(self):
  with self.db._connect() as c:
   s=c.execute("SELECT COUNT(*) n FROM cognitive_states").fetchone()["n"];p=c.execute("SELECT COUNT(*) n FROM cognitive_state_comparisons").fetchone()["n"]
  return {"states":s,"comparisons":p,"metrics":("MAE","RMSE","CONFIDENCE_WEIGHTED_MAE"),"note":"Comparisons preserve provenance/confidence and explicitly report missing or unit-incompatible variables."}
