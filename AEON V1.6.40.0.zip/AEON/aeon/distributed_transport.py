from __future__ import annotations
from dataclasses import dataclass
import hashlib,hmac,json,socket,struct,threading,time,uuid

class DistributedTransportError(RuntimeError):pass

@dataclass(frozen=True)
class TransferReceipt:
 transfer_id:str;node_id:str;byte_count:int;chunk_count:int;sha256:str;elapsed_seconds:float;verified:bool

class DistributedTransportServer:
 """Authenticated chunked binary data plane. Payloads are data only and are never executed."""
 MAGIC=b"AEONX1";MAX_HEADER=65536
 def __init__(self,node_id,secret,sink,host="127.0.0.1",port=0,max_bytes=1024**3,max_age_seconds=30):
  self.node_id=str(node_id);self.secret=bytes(secret);self.sink=sink;self.host=host;self.port=int(port)
  self.max_bytes=int(max_bytes);self.max_age=float(max_age_seconds);self._seen={};self._sock=None;self._thread=None;self._stop=threading.Event()
  if not self.node_id or len(self.secret)<16 or not callable(sink):raise DistributedTransportError("node_id, secret, and sink required")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":")).encode()
 def sign_header(self,h):
  body={k:v for k,v in h.items() if k!="signature"}
  return hmac.new(self.secret,self._canon(body),hashlib.sha256).hexdigest()
 def _verify_header(self,h):
  for k in ("transfer_id","issued_unix","nonce","byte_count","sha256","chunk_bytes","signature"):
   if k not in h:raise DistributedTransportError("malformed transfer header")
  now=time.time();issued=float(h["issued_unix"]);n=int(h["byte_count"]);chunk=int(h["chunk_bytes"])
  if abs(now-issued)>self.max_age:raise DistributedTransportError("stale transfer")
  if n<0 or n>self.max_bytes or chunk<=0 or chunk>16*1024*1024:raise DistributedTransportError("transfer bounds rejected")
  nonce=str(h["nonce"])
  if nonce in self._seen:raise DistributedTransportError("replayed transfer")
  if not hmac.compare_digest(self.sign_header(h),str(h["signature"])):raise DistributedTransportError("authentication failed")
  self._seen={k:v for k,v in self._seen.items() if now-v<=self.max_age};self._seen[nonce]=now
 def start(self):
  s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind((self.host,self.port));s.listen(8);s.settimeout(.25)
  self._sock=s;self._stop.clear();self._thread=threading.Thread(target=self._loop,daemon=True,name="AEON-DistributedTransport");self._thread.start();return s.getsockname()
 def stop(self):
  self._stop.set()
  if self._sock:
   try:self._sock.close()
   except OSError:pass
  if self._thread:self._thread.join(timeout=2)
  self._sock=None;self._thread=None
 def _loop(self):
  while not self._stop.is_set():
   try:c,_=self._sock.accept()
   except socket.timeout:continue
   except OSError:break
   threading.Thread(target=self._conn,args=(c,),daemon=True).start()
 @staticmethod
 def _recv_exact(c,n):
  b=bytearray()
  while len(b)<n:
   x=c.recv(min(1024*1024,n-len(b)))
   if not x:raise DistributedTransportError("unexpected EOF")
   b.extend(x)
  return bytes(b)
 def _conn(self,c):
  started=time.perf_counter()
  try:
   c.settimeout(10)
   if self._recv_exact(c,len(self.MAGIC))!=self.MAGIC:raise DistributedTransportError("bad transport magic")
   hlen=struct.unpack("!I",self._recv_exact(c,4))[0]
   if hlen<=0 or hlen>self.MAX_HEADER:raise DistributedTransportError("header too large")
   h=json.loads(self._recv_exact(c,hlen));self._verify_header(h)
   remaining=int(h["byte_count"]);digest=hashlib.sha256();parts=[];chunks=0
   while remaining:
    take=min(int(h["chunk_bytes"]),remaining);data=self._recv_exact(c,take);digest.update(data);parts.append(data);remaining-=len(data);chunks+=1
   got=digest.hexdigest()
   if got!=h["sha256"]:raise DistributedTransportError("payload SHA-256 mismatch")
   payload=b"".join(parts);self.sink(h["transfer_id"],payload,dict(h.get("metadata",{})))
   receipt={"transfer_id":h["transfer_id"],"node_id":self.node_id,"byte_count":len(payload),"chunk_count":chunks,
    "sha256":got,"elapsed_seconds":time.perf_counter()-started,"verified":True}
   c.sendall(json.dumps({"ok":True,"receipt":receipt},sort_keys=True).encode()+b"\n")
  except Exception as exc:
   try:c.sendall(json.dumps({"ok":False,"error":str(exc)},sort_keys=True).encode()+b"\n")
   except Exception:pass
  finally:c.close()

class DistributedTransportClient:
 def __init__(self,secret,chunk_bytes=1024*1024):
  self.secret=bytes(secret);self.chunk_bytes=int(chunk_bytes)
  if len(self.secret)<16 or self.chunk_bytes<=0 or self.chunk_bytes>16*1024*1024:raise DistributedTransportError("invalid client configuration")
 def send(self,address,payload,metadata=None,timeout=10):
  data=bytes(payload);h={"transfer_id":"xfer-"+uuid.uuid4().hex,"issued_unix":time.time(),"nonce":uuid.uuid4().hex,
   "byte_count":len(data),"sha256":hashlib.sha256(data).hexdigest(),"chunk_bytes":self.chunk_bytes,"metadata":dict(metadata or {})}
  h["signature"]=hmac.new(self.secret,json.dumps(h,sort_keys=True,separators=(",",":")).encode(),hashlib.sha256).hexdigest()
  raw=json.dumps(h,sort_keys=True,separators=(",",":")).encode()
  with socket.create_connection(address,timeout) as c:
   c.sendall(DistributedTransportServer.MAGIC+struct.pack("!I",len(raw))+raw)
   for i in range(0,len(data),self.chunk_bytes):c.sendall(data[i:i+self.chunk_bytes])
   buf=b""
   while b"\n" not in buf:
    x=c.recv(65536)
    if not x:break
    buf+=x
  r=json.loads(buf.split(b"\n",1)[0])
  if not r["ok"]:raise DistributedTransportError(r["error"])
  q=r["receipt"];return TransferReceipt(q["transfer_id"],q["node_id"],q["byte_count"],q["chunk_count"],q["sha256"],q["elapsed_seconds"],q["verified"])
