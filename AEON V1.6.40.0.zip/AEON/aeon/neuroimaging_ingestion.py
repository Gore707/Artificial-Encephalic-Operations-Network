from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,time,uuid

class NeuroimagingIngestionError(RuntimeError):pass
MODALITIES=("MRI","FMRI","DTI","DWI","CT","PET","SPECT","EM","SEM","TEM","LIGHT-MICROSCOPY","TWO-PHOTON","CALCIUM-IMAGING","OTHER")

@dataclass(frozen=True)
class NeuroimagingRecord:
 imaging_id:str;dataset_id:str;modality:str;created_unix:float;source_sha256:str
 preparation:str;resolution:dict;channels:tuple[str,...];timing:dict
 transformations:tuple[str,...];known_losses:tuple[str,...];uncertainty:dict
 acquisition_metadata:dict;metadata_sha256:str

class NeuroimagingIngestion:
 """Registers explicit neuroimaging acquisition metadata around preserved datasets.
 No modality, resolution, channel, timing, loss, or uncertainty is inferred.
 """
 def __init__(self,db,audit,data_lab):
  self.db=db;self.audit=audit;self.data_lab=data_lab;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS cognitive_injection_neuroimaging(
   imaging_id TEXT PRIMARY KEY,dataset_id TEXT NOT NULL UNIQUE,modality TEXT NOT NULL,created_unix REAL NOT NULL,
   source_sha256 TEXT NOT NULL,preparation TEXT NOT NULL,resolution_json TEXT NOT NULL,channels_json TEXT NOT NULL,
   timing_json TEXT NOT NULL,transformations_json TEXT NOT NULL,known_losses_json TEXT NOT NULL,
   uncertainty_json TEXT NOT NULL,acquisition_metadata_json TEXT NOT NULL,metadata_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def register(self,dataset_id,modality,preparation="",resolution=None,channels=(),timing=None,transformations=(),known_losses=(),uncertainty=None,acquisition_metadata=None):
  if modality not in MODALITIES:raise NeuroimagingIngestionError("unsupported modality")
  d=self.data_lab.get(dataset_id)
  payload={"dataset_id":dataset_id,"source_sha256":d.sha256,"modality":modality,"preparation":str(preparation),
   "resolution":dict(resolution or {}),"channels":list(channels),"timing":dict(timing or {}),
   "transformations":list(transformations),"known_losses":list(known_losses),"uncertainty":dict(uncertainty or {}),
   "acquisition_metadata":dict(acquisition_metadata or {})}
  try:raw=self._canon(payload)
  except (TypeError,ValueError) as exc:raise NeuroimagingIngestionError("acquisition metadata must be JSON-serializable") from exc
  sha=hashlib.sha256(raw.encode("utf-8")).hexdigest();iid="img-"+uuid.uuid4().hex;now=time.time()
  try:
   with self.db.transaction() as c:c.execute("INSERT INTO cognitive_injection_neuroimaging VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
    (iid,dataset_id,modality,now,d.sha256,str(preparation),json.dumps(payload["resolution"],sort_keys=True),
     json.dumps(payload["channels"]),json.dumps(payload["timing"],sort_keys=True),json.dumps(payload["transformations"]),
     json.dumps(payload["known_losses"]),json.dumps(payload["uncertainty"],sort_keys=True),
     json.dumps(payload["acquisition_metadata"],sort_keys=True),sha))
  except Exception as exc:raise NeuroimagingIngestionError("dataset already registered or database rejected neuroimaging record") from exc
  self.audit.append("INFO","cognitive_injection.neuroimaging","registered",subject=iid,
   details={"dataset_id":dataset_id,"modality":modality,"source_sha256":d.sha256,"metadata_sha256":sha})
  return self.get(iid)
 def get(self,iid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_injection_neuroimaging WHERE imaging_id=?",(iid,)).fetchone()
  if r is None:raise NeuroimagingIngestionError("unknown neuroimaging record")
  return NeuroimagingRecord(r["imaging_id"],r["dataset_id"],r["modality"],r["created_unix"],r["source_sha256"],r["preparation"],
   json.loads(r["resolution_json"]),tuple(json.loads(r["channels_json"])),json.loads(r["timing_json"]),
   tuple(json.loads(r["transformations_json"])),tuple(json.loads(r["known_losses_json"])),json.loads(r["uncertainty_json"]),
   json.loads(r["acquisition_metadata_json"]),r["metadata_sha256"])
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["imaging_id"] for r in c.execute("SELECT imaging_id FROM cognitive_injection_neuroimaging ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
 def verify(self,iid):
  q=self.get(iid);d=self.data_lab.get(q.dataset_id)
  payload={"dataset_id":q.dataset_id,"source_sha256":q.source_sha256,"modality":q.modality,"preparation":q.preparation,
   "resolution":q.resolution,"channels":list(q.channels),"timing":q.timing,"transformations":list(q.transformations),
   "known_losses":list(q.known_losses),"uncertainty":q.uncertainty,"acquisition_metadata":q.acquisition_metadata}
  metadata_ok=hashlib.sha256(self._canon(payload).encode("utf-8")).hexdigest()==q.metadata_sha256
  return {"metadata_ok":metadata_ok,"catalog_hash_ok":d.sha256==q.source_sha256,"all_ok":metadata_ok and d.sha256==q.source_sha256}
 def completeness(self,iid):
  q=self.get(iid);missing=[]
  if not q.preparation:missing.append("preparation")
  if not q.resolution:missing.append("resolution")
  if not q.channels:missing.append("channels")
  if not q.timing:missing.append("timing")
  if not q.uncertainty:missing.append("uncertainty")
  return {"imaging_id":iid,"missing":tuple(missing),"complete_for_declared_fields":not missing,
   "note":"Completeness here covers acquisition metadata fields only; it is not an Information Sufficiency or MSCS determination."}
