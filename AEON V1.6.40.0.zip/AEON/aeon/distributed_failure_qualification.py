from __future__ import annotations
from dataclasses import dataclass
import json,time,uuid

class DistributedFailureQualificationError(RuntimeError):pass

@dataclass(frozen=True)
class DistributedFailureResult:
 qualification_id:str;created_unix:float;scenario:str;subject:str;passed:bool;observed_json:str

class DistributedFailureQualification:
 """P083 deterministic qualification of distributed node/transport failure decisions.
 Faults are injected into disposable qualification state, not a live cluster or network.
 """
 SCENARIOS=("NODE_STALE","PACKET_LOSS","DESYNC","REPLAY")
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p083_distributed_failure_qualifications(
   qualification_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,scenario TEXT NOT NULL,subject TEXT NOT NULL,
   passed INTEGER NOT NULL,observed_json TEXT NOT NULL)""")
 def _record(self,scenario,subject,passed,observed):
  qid="p083-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p083_distributed_failure_qualifications VALUES(?,?,?,?,?,?)",
   (qid,time.time(),scenario,subject,1 if passed else 0,json.dumps(observed,sort_keys=True)))
  self.audit.append("INFO" if passed else "CRITICAL","failure_qualification.p083",scenario.lower(),subject=qid,details=observed)
  return self.get(qid)
 def node_stale(self,last_seen,now,timeout):
  last=float(last_seen);now=float(now);timeout=float(timeout)
  if timeout<=0 or now<last:raise DistributedFailureQualificationError("invalid liveness inputs")
  age=now-last;status="OFFLINE" if age>timeout else "ONLINE";passed=(status=="OFFLINE")
  return self._record("NODE_STALE","disposable-node",passed,{"age":age,"timeout":timeout,"status":status,"last_seen_unchanged":last})
 def packet_loss(self,expected_sequences,received_sequences):
  exp=tuple(int(x) for x in expected_sequences);got=tuple(int(x) for x in received_sequences)
  missing=tuple(x for x in exp if x not in set(got));unexpected=tuple(x for x in got if x not in set(exp))
  detected=bool(missing or unexpected);return self._record("PACKET_LOSS","disposable-stream",detected,{"expected":exp,"received":got,"missing":missing,"unexpected":unexpected,"detected":detected})
 def desync(self,node_steps,tolerance=0):
  vals={str(k):int(v) for k,v in dict(node_steps).items()}
  if len(vals)<2:raise DistributedFailureQualificationError("at least two nodes required")
  spread=max(vals.values())-min(vals.values());detected=spread>int(tolerance)
  return self._record("DESYNC","disposable-step-set",detected,{"node_steps":vals,"spread":spread,"tolerance":int(tolerance),"detected":detected})
 def replay(self,nonces):
  seen=set();duplicate=None
  for n in tuple(str(x) for x in nonces):
   if n in seen:duplicate=n;break
   seen.add(n)
  detected=duplicate is not None
  return self._record("REPLAY","disposable-message-set",detected,{"duplicate_nonce":duplicate,"detected":detected})
 def get(self,qid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p083_distributed_failure_qualifications WHERE qualification_id=?",(qid,)).fetchone()
  if r is None:raise DistributedFailureQualificationError("unknown P083 qualification")
  return DistributedFailureResult(r["qualification_id"],r["created_unix"],r["scenario"],r["subject"],bool(r["passed"]),r["observed_json"])
 def summary(self):
  with self.db._connect() as c:
   total=c.execute("SELECT COUNT(*) n FROM p083_distributed_failure_qualifications").fetchone()["n"];passed=c.execute("SELECT COUNT(*) n FROM p083_distributed_failure_qualifications WHERE passed=1").fetchone()["n"]
  return {"phase":"FAILURE & CORRUPTION VALIDATION III","executed":total,"passed":passed,
   "scope":"Deterministic disposable node/stream fault models: stale liveness, loss, logical-step desynchronization, replay. No claim of live network chaos testing."}
