from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,math,time,uuid

class CandidateReconstructionError(RuntimeError):pass

@dataclass(frozen=True)
class CandidateValue:
 target_ref:str;property_name:str;value:object;unit:str;provenance:str;confidence:float;method:str;method_version:str;source_refs:tuple[str,...];uncertainty:dict

@dataclass(frozen=True)
class CandidateReconstruction:
 candidate_id:str;created_unix:float;metadata_id:str;name:str;values:tuple[CandidateValue,...];assumptions:tuple[str,...];status:str;definition_sha256:str

class CandidateReconstructionService:
 """Stores explicit reconstruction hypotheses without modifying source ANI/reconstruction records."""
 ALLOWED_PROVENANCE=("INFERRED","AI-RECONSTRUCTED")
 def __init__(self,db,audit,reconstruction_metadata):
  self.db=db;self.audit=audit;self.metadata=reconstruction_metadata;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS candidate_reconstructions(
   candidate_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,metadata_id TEXT NOT NULL,name TEXT NOT NULL,
   values_json TEXT NOT NULL,assumptions_json TEXT NOT NULL,status TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _sha(payload):return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 @staticmethod
 def _payload(metadata_id,name,values,assumptions):
  return {"metadata_id":metadata_id,"name":name,"values":[v.__dict__ for v in values],"assumptions":list(assumptions)}
 def create(self,metadata_id,name,values,assumptions=()):
  m=self.metadata.get(metadata_id);vfy=self.metadata.verify(metadata_id)
  if not vfy.get("all_ok",False):raise CandidateReconstructionError("source reconstruction metadata integrity failed")
  name=str(name).strip()
  if not name:raise CandidateReconstructionError("candidate name required")
  out=[];seen=set()
  for raw in values:
   d=dict(raw);target=str(d.get("target_ref","")).strip();prop=str(d.get("property_name","")).strip()
   prov=str(d.get("provenance","")).upper();method=str(d.get("method","")).strip();ver=str(d.get("method_version","")).strip()
   unit=str(d.get("unit","")).strip();conf=float(d.get("confidence",0));sources=tuple(str(x).strip() for x in d.get("source_refs",()) if str(x).strip())
   uncertainty=dict(d.get("uncertainty",{}));value=d.get("value")
   if not target or not prop or not method or not ver:raise CandidateReconstructionError("target, property, method and method_version required")
   if prov not in self.ALLOWED_PROVENANCE:raise CandidateReconstructionError("candidate values must remain INFERRED or AI-RECONSTRUCTED")
   if not math.isfinite(conf) or not 0<=conf<=1:raise CandidateReconstructionError("confidence must be finite in [0,1]")
   key=(target,prop)
   if key in seen:raise CandidateReconstructionError("duplicate target/property candidate value")
   seen.add(key)
   try:json.dumps(value);json.dumps(uncertainty)
   except Exception as exc:raise CandidateReconstructionError("candidate value/uncertainty must be JSON serializable") from exc
   out.append(CandidateValue(target,prop,value,unit,prov,conf,method,ver,sources,uncertainty))
  if not out:raise CandidateReconstructionError("at least one candidate value required")
  assumptions=tuple(str(x).strip() for x in assumptions if str(x).strip())
  payload=self._payload(metadata_id,name,tuple(out),assumptions);sha=self._sha(payload);cid="candidate-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO candidate_reconstructions VALUES(?,?,?,?,?,?,?,?)",
   (cid,time.time(),metadata_id,name,json.dumps([v.__dict__ for v in out],sort_keys=True),json.dumps(assumptions), "HYPOTHESIS",sha))
  self.audit.append("INFO","cognitive_guardian.candidate_reconstruction","created",subject=cid,
   details={"metadata_id":metadata_id,"values":len(out),"status":"HYPOTHESIS"})
  return self.get(cid)
 def get(self,cid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM candidate_reconstructions WHERE candidate_id=?",(cid,)).fetchone()
  if r is None:raise CandidateReconstructionError("unknown candidate reconstruction")
  vals=tuple(CandidateValue(x["target_ref"],x["property_name"],x["value"],x["unit"],x["provenance"],x["confidence"],x["method"],x["method_version"],tuple(x["source_refs"]),x["uncertainty"]) for x in json.loads(r["values_json"]))
  return CandidateReconstruction(r["candidate_id"],r["created_unix"],r["metadata_id"],r["name"],vals,tuple(json.loads(r["assumptions_json"])),r["status"],r["definition_sha256"])
 def verify(self,cid):
  q=self.get(cid);source=self.metadata.verify(q.metadata_id)
  own=self._sha(self._payload(q.metadata_id,q.name,q.values,q.assumptions))==q.definition_sha256
  return {"definition_ok":own,"source_ok":bool(source.get("all_ok",False)),"all_ok":own and bool(source.get("all_ok",False))}
 def compare(self,left_id,right_id):
  a=self.get(left_id);b=self.get(right_id)
  if a.metadata_id!=b.metadata_id:raise CandidateReconstructionError("candidates must share source reconstruction metadata")
  amap={(x.target_ref,x.property_name):x for x in a.values};bmap={(x.target_ref,x.property_name):x for x in b.values}
  shared=sorted(set(amap)&set(bmap));rows=[]
  for k in shared:
   x,y=amap[k],bmap[k];delta=None
   if isinstance(x.value,(int,float)) and not isinstance(x.value,bool) and isinstance(y.value,(int,float)) and not isinstance(y.value,bool) and x.unit==y.unit:
    delta=float(y.value)-float(x.value)
   rows.append({"target_ref":k[0],"property_name":k[1],"left_provenance":x.provenance,"right_provenance":y.provenance,
    "left_confidence":x.confidence,"right_confidence":y.confidence,"unit_match":x.unit==y.unit,"numeric_delta":delta})
  return {"shared_count":len(shared),"only_left":len(set(amap)-set(bmap)),"only_right":len(set(bmap)-set(amap)),"variables":tuple(rows),
   "interpretation":"Candidate comparison ranks neither truth nor identity. Candidates remain hypotheses until independently constrained or measured."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["candidate_id"] for r in c.execute("SELECT candidate_id FROM candidate_reconstructions ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM candidate_reconstructions").fetchone()["n"]
  return {"candidates":n,"allowed_provenance":self.ALLOWED_PROVENANCE,
   "note":"Candidate reconstructions are immutable hypotheses and do not modify source ANI data or become MEASURED through confidence."}
