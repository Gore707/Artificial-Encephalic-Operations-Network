from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import math
import threading
import time
from typing import Iterable


class TelemetryStreamError(RuntimeError):
    pass


@dataclass(frozen=True)
class TelemetrySample:
    sequence: int
    timestamp_unix: float
    channel: str
    value: float
    unit: str
    provenance: str
    source_id: str | None


@dataclass(frozen=True)
class TelemetryWindow:
    channel: str
    start_unix: float
    end_unix: float
    count: int
    minimum: float | None
    maximum: float | None
    mean: float | None
    latest: float | None
    unit: str
    provenance: str


class TelemetryRingBuffer:
    """Bounded, thread-safe high-frequency telemetry transport.

    Raw samples remain available within the configured ring capacity. Consumers
    such as Guardian/UI may request aggregate windows instead of ingesting every
    event. No neural simulation timestep is imposed by this service.
    """

    VALID_PROVENANCE = {
        "MEASURED", "DERIVED", "INFERRED", "AI-RECONSTRUCTED", "UNKNOWN"
    }

    def __init__(self, capacity: int = 100_000):
        if not isinstance(capacity, int) or capacity < 128:
            raise TelemetryStreamError("capacity must be an integer >= 128")
        self.capacity = capacity
        self._samples: deque[TelemetrySample] = deque(maxlen=capacity)
        self._sequence = 0
        self._lock = threading.RLock()
        self._condition = threading.Condition(self._lock)

    def publish(
        self,
        channel: str,
        value: float,
        unit: str = "",
        provenance: str = "UNKNOWN",
        source_id: str | None = None,
        timestamp_unix: float | None = None,
    ) -> TelemetrySample:
        channel = channel.strip()
        if not channel:
            raise TelemetryStreamError("channel is required")
        if provenance not in self.VALID_PROVENANCE:
            raise TelemetryStreamError("invalid provenance class")
        if not isinstance(value, (int, float)) or not math.isfinite(float(value)):
            raise TelemetryStreamError("telemetry value must be finite")
        ts = time.time() if timestamp_unix is None else float(timestamp_unix)
        if not math.isfinite(ts):
            raise TelemetryStreamError("timestamp must be finite")
        with self._condition:
            self._sequence += 1
            sample = TelemetrySample(
                self._sequence, ts, channel, float(value), unit,
                provenance, source_id
            )
            self._samples.append(sample)
            self._condition.notify_all()
            return sample

    def publish_many(self, rows: Iterable[dict]) -> tuple[TelemetrySample, ...]:
        return tuple(self.publish(**row) for row in rows)

    def latest(self, channel: str | None = None) -> TelemetrySample | None:
        with self._lock:
            if channel is None:
                return self._samples[-1] if self._samples else None
            for sample in reversed(self._samples):
                if sample.channel == channel:
                    return sample
        return None

    def read(
        self,
        *,
        channel: str | None = None,
        after_sequence: int = 0,
        limit: int = 10_000,
    ) -> tuple[TelemetrySample, ...]:
        if limit < 1:
            return ()
        with self._lock:
            rows = [
                s for s in self._samples
                if s.sequence > after_sequence and
                (channel is None or s.channel == channel)
            ]
            return tuple(rows[:limit])

    def channels(self) -> tuple[str, ...]:
        with self._lock:
            return tuple(sorted({s.channel for s in self._samples}))

    def aggregate(
        self,
        channel: str,
        *,
        seconds: float = 1.0,
        now_unix: float | None = None,
    ) -> TelemetryWindow:
        if seconds <= 0:
            raise TelemetryStreamError("seconds must be > 0")
        end = time.time() if now_unix is None else float(now_unix)
        start = end - seconds
        with self._lock:
            rows = [
                s for s in self._samples
                if s.channel == channel and start <= s.timestamp_unix <= end
            ]
        if not rows:
            return TelemetryWindow(
                channel, start, end, 0, None, None, None, None, "", "UNKNOWN"
            )
        values = [s.value for s in rows]
        units = {s.unit for s in rows}
        provenance = {s.provenance for s in rows}
        return TelemetryWindow(
            channel, start, end, len(rows), min(values), max(values),
            sum(values) / len(values), rows[-1].value,
            rows[-1].unit if len(units) == 1 else "MIXED",
            rows[-1].provenance if len(provenance) == 1 else "MIXED",
        )

    def wait_for_sequence(self, after_sequence: int, timeout: float = 1.0) -> int:
        deadline = time.monotonic() + max(0.0, timeout)
        with self._condition:
            while self._sequence <= after_sequence:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                self._condition.wait(remaining)
            return self._sequence

    @property
    def current_sequence(self) -> int:
        with self._lock:
            return self._sequence

    def stats(self) -> dict:
        with self._lock:
            return {
                "capacity": self.capacity,
                "retained": len(self._samples),
                "current_sequence": self._sequence,
                "channels": len({s.channel for s in self._samples}),
                "oldest_sequence": self._samples[0].sequence if self._samples else None,
            }
