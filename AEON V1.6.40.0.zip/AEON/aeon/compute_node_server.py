from __future__ import annotations
from dataclasses import dataclass
import hashlib,hmac,json,socket,threading,time,uuid

class ComputeNodeServerError(RuntimeError):pass

@dataclass(frozen=True)
class ComputeNodeRequest:
 request_id:str;issued_unix:float;nonce:str;operation:str;payload:dict;signature:str

@dataclass(frozen=True)
class ComputeNodeResponse:
 request_id:str;node_id:str;ok:bool;code:str;payload:dict;server_unix:float

class ComputeNodeServer:
 """Bounded Exa-Execution control endpoint. No arbitrary command/argv execution."""
 PROTOCOL="AEON-EXA-NODE/1"
 OPERATIONS=("PING","CAPABILITIES","STATUS")
 def __init__(self,node_id,secret,status_provider=None,host="127.0.0.1",port=0,max_age_seconds=30.0):
  self.node_id=str(node_id).strip();self.secret=bytes(secret);self.status_provider=status_provider
  self.host=host;self.port=int(port);self.max_age=float(max_age_seconds);self._seen={};self._sock=None;self._thread=None;self._stop=threading.Event()
  if not self.node_id or len(self.secret)<16:raise ComputeNodeServerError("node_id and >=16-byte secret required")
 @staticmethod
 def _canonical(d):return json.dumps(d,sort_keys=True,separators=(",",":")).encode()
 def sign(self,request_id,issued_unix,nonce,operation,payload):
  body={"request_id":request_id,"issued_unix":float(issued_unix),"nonce":nonce,"operation":operation,"payload":payload}
  return hmac.new(self.secret,self._canonical(body),hashlib.sha256).hexdigest()
 def make_request(self,operation,payload=None):
  op=str(operation).upper();rid="req-"+uuid.uuid4().hex;ts=time.time();nonce=uuid.uuid4().hex;p=dict(payload or {})
  return ComputeNodeRequest(rid,ts,nonce,op,p,self.sign(rid,ts,nonce,op,p))
 def _verify(self,d):
  required=("request_id","issued_unix","nonce","operation","payload","signature")
  if any(k not in d for k in required):raise ComputeNodeServerError("malformed request")
  op=str(d["operation"]).upper()
  if op not in self.OPERATIONS:raise ComputeNodeServerError("operation not allowed")
  now=time.time();issued=float(d["issued_unix"])
  if not abs(now-issued)<=self.max_age:raise ComputeNodeServerError("stale request")
  nonce=str(d["nonce"])
  if nonce in self._seen:raise ComputeNodeServerError("replayed request")
  expected=self.sign(str(d["request_id"]),issued,nonce,op,dict(d["payload"]))
  if not hmac.compare_digest(expected,str(d["signature"])):raise ComputeNodeServerError("authentication failed")
  self._seen={k:v for k,v in self._seen.items() if now-v<=self.max_age};self._seen[nonce]=now
  return op
 def handle(self,d):
  try:
   op=self._verify(d)
   if op=="PING":payload={"protocol":self.PROTOCOL,"pong":True}
   elif op=="CAPABILITIES":payload={"protocol":self.PROTOCOL,"operations":self.OPERATIONS,"arbitrary_execution":False}
   else:
    raw=self.status_provider() if self.status_provider else {}
    payload={"protocol":self.PROTOCOL,"status":dict(raw)}
   return ComputeNodeResponse(str(d.get("request_id","")),self.node_id,True,"OK",payload,time.time())
  except Exception as exc:return ComputeNodeResponse(str(d.get("request_id","")),self.node_id,False,"REJECTED",{"error":str(exc)},time.time())
 @staticmethod
 def _wire_response(r):return json.dumps(r.__dict__,sort_keys=True,separators=(",",":")).encode()+b"\n"
 def _serve_conn(self,conn):
  conn.settimeout(5);buf=b""
  try:
   while b"\n" not in buf:
    chunk=conn.recv(65536)
    if not chunk:break
    buf+=chunk
    if len(buf)>1024*1024:raise ComputeNodeServerError("request too large")
   d=json.loads(buf.split(b"\n",1)[0].decode());conn.sendall(self._wire_response(self.handle(d)))
  except Exception as exc:
   conn.sendall(self._wire_response(ComputeNodeResponse("",self.node_id,False,"REJECTED",{"error":str(exc)},time.time())))
  finally:conn.close()
 def start(self):
  if self._sock:return self.address
  s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind((self.host,self.port));s.listen(16);s.settimeout(.25)
  self._sock=s;self._stop.clear();self._thread=threading.Thread(target=self._loop,name="AEON-ComputeNodeServer",daemon=True);self._thread.start();return self.address
 @property
 def address(self):
  if not self._sock:return None
  return self._sock.getsockname()
 def _loop(self):
  while not self._stop.is_set():
   try:c,_=self._sock.accept()
   except socket.timeout:continue
   except OSError:break
   threading.Thread(target=self._serve_conn,args=(c,),daemon=True).start()
 def stop(self):
  self._stop.set()
  if self._sock:
   try:self._sock.close()
   except OSError:pass
  if self._thread:self._thread.join(timeout=2)
  self._sock=None;self._thread=None
