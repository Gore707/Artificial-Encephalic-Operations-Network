from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable
import hashlib
import hmac
import os
import time
import uuid


class AuthorizationError(PermissionError):
    pass


class IdentityError(RuntimeError):
    pass


@dataclass(frozen=True)
class User:
    user_id: str
    username: str
    display_name: str
    enabled: bool
    created_unix: float


@dataclass(frozen=True)
class AuthorizationDecision:
    allowed: bool
    user_id: str | None
    permission: str
    reason: str


class IdentityAccessManager:
    """Local AEON identity, roles, permissions, and protected-operation gates.

    Passwords are stored only as PBKDF2-HMAC-SHA256 salted hashes. Permission
    checks are deterministic and fail closed when identity or authorization is
    missing. This layer does not claim OS-level sandboxing; process isolation
    belongs to P011.
    """

    PBKDF2_ITERATIONS = 310_000

    def __init__(self, state_db, audit):
        self.db = state_db
        self.audit = audit
        self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS users(
                user_id TEXT PRIMARY KEY,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                display_name TEXT NOT NULL,
                password_salt BLOB NOT NULL,
                password_hash BLOB NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_unix REAL NOT NULL)""")
            conn.execute("""CREATE TABLE IF NOT EXISTS roles(
                role_id TEXT PRIMARY KEY,
                description TEXT NOT NULL)""")
            conn.execute("""CREATE TABLE IF NOT EXISTS permissions(
                permission TEXT PRIMARY KEY,
                description TEXT NOT NULL)""")
            conn.execute("""CREATE TABLE IF NOT EXISTS role_permissions(
                role_id TEXT NOT NULL,
                permission TEXT NOT NULL,
                PRIMARY KEY(role_id,permission),
                FOREIGN KEY(role_id) REFERENCES roles(role_id) ON DELETE CASCADE,
                FOREIGN KEY(permission) REFERENCES permissions(permission) ON DELETE CASCADE)""")
            conn.execute("""CREATE TABLE IF NOT EXISTS user_roles(
                user_id TEXT NOT NULL,
                role_id TEXT NOT NULL,
                PRIMARY KEY(user_id,role_id),
                FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                FOREIGN KEY(role_id) REFERENCES roles(role_id) ON DELETE CASCADE)""")

        self._seed_builtin_policy()

    def _seed_builtin_policy(self):
        permissions = {
            "workspace.read": "Read workspace state",
            "workspace.manage": "Create, rename, activate, and delete workspaces",
            "data.read": "Read scientific data-object metadata",
            "data.write": "Create and modify non-immutable scientific objects",
            "source.preserve": "Ingest immutable source evidence",
            "audit.read": "Read and verify audit records",
            "diagnostics.write": "Generate diagnostic snapshots",
            "security.manage": "Manage AEON users, roles, and permissions",
            "system.protected": "Authorize protected system operations",
        }
        roles = {
            "observer": ("Read-only scientific observer",
                         ("workspace.read","data.read","audit.read")),
            "researcher": ("Scientific operator",
                           ("workspace.read","workspace.manage","data.read","data.write",
                            "source.preserve","audit.read","diagnostics.write")),
            "administrator": ("AEON local administrator", tuple(permissions)),
        }
        with self.db.transaction() as conn:
            for permission, desc in permissions.items():
                conn.execute("INSERT OR IGNORE INTO permissions(permission,description) VALUES(?,?)",
                             (permission,desc))
            for role_id, (desc, grants) in roles.items():
                conn.execute("INSERT OR IGNORE INTO roles(role_id,description) VALUES(?,?)",
                             (role_id,desc))
                for permission in grants:
                    conn.execute("""INSERT OR IGNORE INTO role_permissions(role_id,permission)
                                    VALUES(?,?)""",(role_id,permission))

    @staticmethod
    def _normalize_username(username: str) -> str:
        username = username.strip()
        if not username or len(username) > 64:
            raise IdentityError("Username must contain 1-64 characters")
        if any(c.isspace() for c in username):
            raise IdentityError("Username cannot contain whitespace")
        return username

    @classmethod
    def _hash_password(cls, password: str, salt: bytes) -> bytes:
        if len(password) < 10:
            raise IdentityError("Password must contain at least 10 characters")
        return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt,
                                   cls.PBKDF2_ITERATIONS)

    def user_count(self) -> int:
        with self.db._connect() as conn:
            return int(conn.execute("SELECT COUNT(*) FROM users").fetchone()[0])

    def create_user(self, username: str, display_name: str, password: str,
                    roles: Iterable[str] = ()) -> User:
        username = self._normalize_username(username)
        display_name = display_name.strip()
        if not display_name:
            raise IdentityError("Display name is required")
        salt = os.urandom(32)
        digest = self._hash_password(password, salt)
        user_id = "usr-" + uuid.uuid4().hex
        created = time.time()
        role_ids = tuple(dict.fromkeys(r.strip() for r in roles if r.strip()))

        with self.db.transaction() as conn:
            for role_id in role_ids:
                if conn.execute("SELECT 1 FROM roles WHERE role_id=?",(role_id,)).fetchone() is None:
                    raise IdentityError(f"Unknown role: {role_id}")
            conn.execute("""INSERT INTO users(
                user_id,username,display_name,password_salt,password_hash,enabled,created_unix)
                VALUES(?,?,?,?,?,?,?)""",
                (user_id,username,display_name,salt,digest,1,created))
            for role_id in role_ids:
                conn.execute("INSERT INTO user_roles(user_id,role_id) VALUES(?,?)",
                             (user_id,role_id))
        self.audit.append("INFO","security","user_created",actor="AEON",
                          subject=user_id,details={"username":username,"roles":list(role_ids)})
        return User(user_id,username,display_name,True,created)

    def bootstrap_administrator(self, username: str, display_name: str, password: str) -> User:
        if self.user_count() != 0:
            raise IdentityError("Administrator bootstrap is permitted only before the first user exists")
        user = self.create_user(username,display_name,password,("administrator",))
        self.audit.append("WARNING","security","administrator_bootstrapped",
                          actor=user.user_id,subject=user.user_id)
        return user

    def authenticate(self, username: str, password: str) -> User | None:
        username = self._normalize_username(username)
        with self.db._connect() as conn:
            row = conn.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE",
                               (username,)).fetchone()
        if row is None or not bool(row["enabled"]):
            self.audit.append("WARNING","security","authentication_failed",
                              actor="anonymous",details={"username":username})
            return None
        candidate = self._hash_password(password,bytes(row["password_salt"]))
        if not hmac.compare_digest(candidate,bytes(row["password_hash"])):
            self.audit.append("WARNING","security","authentication_failed",
                              actor="anonymous",subject=row["user_id"],
                              details={"username":username})
            return None
        user=self._row_user(row)
        self.audit.append("INFO","security","authentication_succeeded",
                          actor=user.user_id,subject=user.user_id)
        return user

    def roles_for(self, user_id: str) -> tuple[str,...]:
        with self.db._connect() as conn:
            rows=conn.execute("""SELECT role_id FROM user_roles
                                 WHERE user_id=? ORDER BY role_id""",(user_id,)).fetchall()
        return tuple(r["role_id"] for r in rows)

    def permissions_for(self, user_id: str) -> frozenset[str]:
        with self.db._connect() as conn:
            row=conn.execute("SELECT enabled FROM users WHERE user_id=?",(user_id,)).fetchone()
            if row is None or not bool(row["enabled"]):
                return frozenset()
            rows=conn.execute("""SELECT DISTINCT rp.permission
                FROM user_roles ur JOIN role_permissions rp ON rp.role_id=ur.role_id
                WHERE ur.user_id=?""",(user_id,)).fetchall()
        return frozenset(r["permission"] for r in rows)

    def check(self, user_id: str | None, permission: str) -> AuthorizationDecision:
        if not user_id:
            return AuthorizationDecision(False,None,permission,"No authenticated identity")
        allowed = permission in self.permissions_for(user_id)
        return AuthorizationDecision(allowed,user_id,permission,
                                     "Granted by role policy" if allowed else "Permission not granted")

    def require(self, user_id: str | None, permission: str, *,
                action: str, subject: str | None = None) -> None:
        decision=self.check(user_id,permission)
        if not decision.allowed:
            self.audit.append("WARNING","authorization","access_denied",
                              actor=user_id or "anonymous",subject=subject,
                              details={"permission":permission,"action":action,
                                       "reason":decision.reason})
            raise AuthorizationError(
                f"Denied {action}: {decision.reason} ({permission})"
            )
        self.audit.append("INFO","authorization","access_granted",
                          actor=user_id,subject=subject,
                          details={"permission":permission,"action":action})

    def set_enabled(self, acting_user_id: str, target_user_id: str, enabled: bool):
        self.require(acting_user_id,"security.manage",action="set_user_enabled",
                     subject=target_user_id)
        if acting_user_id == target_user_id and not enabled:
            raise IdentityError("An administrator cannot disable the active account through itself")
        with self.db.transaction() as conn:
            cur=conn.execute("UPDATE users SET enabled=? WHERE user_id=?",
                             (1 if enabled else 0,target_user_id))
            if cur.rowcount != 1:
                raise IdentityError(f"Unknown user: {target_user_id}")
        self.audit.append("WARNING","security","user_enabled_changed",
                          actor=acting_user_id,subject=target_user_id,
                          details={"enabled":bool(enabled)})

    def assign_role(self, acting_user_id: str, target_user_id: str, role_id: str):
        self.require(acting_user_id,"security.manage",action="assign_role",
                     subject=target_user_id)
        with self.db.transaction() as conn:
            if conn.execute("SELECT 1 FROM users WHERE user_id=?",(target_user_id,)).fetchone() is None:
                raise IdentityError(f"Unknown user: {target_user_id}")
            if conn.execute("SELECT 1 FROM roles WHERE role_id=?",(role_id,)).fetchone() is None:
                raise IdentityError(f"Unknown role: {role_id}")
            conn.execute("INSERT OR IGNORE INTO user_roles(user_id,role_id) VALUES(?,?)",
                         (target_user_id,role_id))
        self.audit.append("WARNING","security","role_assigned",
                          actor=acting_user_id,subject=target_user_id,
                          details={"role":role_id})

    def list_users(self) -> tuple[User,...]:
        with self.db._connect() as conn:
            rows=conn.execute("SELECT * FROM users ORDER BY username COLLATE NOCASE").fetchall()
        return tuple(self._row_user(r) for r in rows)

    @staticmethod
    def _row_user(row) -> User:
        return User(row["user_id"],row["username"],row["display_name"],
                    bool(row["enabled"]),float(row["created_unix"]))
