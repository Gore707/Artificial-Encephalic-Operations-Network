from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any
import threading
import time
import uuid


class ResourcePolicyError(RuntimeError):
    pass


@dataclass(frozen=True)
class ResourceEnvelope:
    cpu_logical_total: int
    cpu_logical_limit: int
    memory_total_bytes: int | None
    memory_limit_bytes: int | None
    storage_free_bytes: int | None
    storage_reserve_bytes: int | None
    accelerators_detected: int
    gpu_memory_total_bytes: int | None
    gpu_memory_limit_bytes: int | None
    policy: str
    conservative_due_to_unknown_gpu_vram: bool


@dataclass(frozen=True)
class ResourceRequest:
    cpu_logical: int = 1
    memory_bytes: int = 0
    storage_bytes: int = 0
    gpu_memory_bytes: int = 0


@dataclass(frozen=True)
class ResourceLease:
    lease_id: str
    owner: str
    request: ResourceRequest
    created_unix: float


class ResourceManager:
    """Deterministic host resource envelope and admission controller.

    P014 does not overclock hardware or alter firmware/power limits. It reserves
    headroom and refuses AEON work that exceeds the configured envelope.
    Temperature-driven throttling belongs to later telemetry/safety patches.
    """

    POLICY = "CONSERVATIVE_HOST_V1"

    def __init__(self, hardware, accelerators, state_db, audit):
        self.hardware = hardware
        self.accelerators = accelerators
        self.db = state_db
        self.audit = audit
        self._lock = threading.RLock()
        self._leases: dict[str, ResourceLease] = {}
        self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS resource_policy(
                key TEXT PRIMARY KEY,
                value_json TEXT NOT NULL)""")

    def envelope(self) -> ResourceEnvelope:
        host = self.hardware.discover()
        accel = self.accelerators.discover()

        logical = max(1, host.cpu.logical_processors)
        # Leave at least one logical processor for OS/UI; on larger systems
        # reserve ~25% by default. User overrides are intentionally not added
        # until protected configuration controls are available.
        cpu_limit = 1 if logical == 1 else max(1, min(logical - 1, int(logical * 0.75)))

        mem_total = host.memory.total_bytes
        if mem_total is None:
            mem_limit = None
        else:
            # Preserve the greater of 4 GiB or 25% for OS/desktop/Guardian.
            reserve = max(4 * 1024**3, int(mem_total * 0.25))
            mem_limit = max(0, mem_total - reserve)

        # Use the volume with the greatest free capacity as the current
        # admissible storage pool. P014 does not aggregate separate filesystems.
        storage_free = max((v.free_bytes for v in host.storage), default=None)
        if storage_free is None:
            storage_reserve = None
        else:
            storage_reserve = max(10 * 1024**3, int(storage_free * 0.10))
            storage_reserve = min(storage_reserve, storage_free)

        provider_devices = [
            d for d in accel.devices if d.backend in ("CUDA", "ROCm")
        ]
        known_vram = [d.memory_total_bytes for d in provider_devices
                      if d.memory_total_bytes is not None]
        gpu_total = sum(known_vram) if known_vram else None
        unknown_gpu_vram = bool(accel.devices) and not known_vram
        # Keep 20% VRAM headroom when provider-reported capacity is known.
        gpu_limit = int(gpu_total * 0.80) if gpu_total is not None else None

        return ResourceEnvelope(
            cpu_logical_total=logical,
            cpu_logical_limit=cpu_limit,
            memory_total_bytes=mem_total,
            memory_limit_bytes=mem_limit,
            storage_free_bytes=storage_free,
            storage_reserve_bytes=storage_reserve,
            accelerators_detected=len(accel.devices),
            gpu_memory_total_bytes=gpu_total,
            gpu_memory_limit_bytes=gpu_limit,
            policy=self.POLICY,
            conservative_due_to_unknown_gpu_vram=unknown_gpu_vram,
        )

    def available(self) -> ResourceEnvelope:
        env = self.envelope()
        with self._lock:
            used_cpu = sum(x.request.cpu_logical for x in self._leases.values())
            used_mem = sum(x.request.memory_bytes for x in self._leases.values())
            used_gpu = sum(x.request.gpu_memory_bytes for x in self._leases.values())
            used_storage = sum(x.request.storage_bytes for x in self._leases.values())

        mem_limit = None if env.memory_limit_bytes is None else max(0, env.memory_limit_bytes - used_mem)
        gpu_limit = None if env.gpu_memory_limit_bytes is None else max(0, env.gpu_memory_limit_bytes - used_gpu)
        storage_free = None if env.storage_free_bytes is None else max(0, env.storage_free_bytes - used_storage)

        return ResourceEnvelope(
            env.cpu_logical_total,
            max(0, env.cpu_logical_limit - used_cpu),
            env.memory_total_bytes,
            mem_limit,
            storage_free,
            env.storage_reserve_bytes,
            env.accelerators_detected,
            env.gpu_memory_total_bytes,
            gpu_limit,
            env.policy,
            env.conservative_due_to_unknown_gpu_vram,
        )

    def admit(self, owner: str, request: ResourceRequest) -> ResourceLease:
        owner = owner.strip()
        if not owner:
            raise ResourcePolicyError("Resource owner is required")
        self._validate_request(request)

        with self._lock:
            available = self.available()
            reasons = []
            if request.cpu_logical > available.cpu_logical_limit:
                reasons.append(f"CPU request {request.cpu_logical} exceeds available limit {available.cpu_logical_limit}")
            if request.memory_bytes and available.memory_limit_bytes is None:
                reasons.append("RAM capacity is unavailable; nonzero RAM reservation denied")
            elif available.memory_limit_bytes is not None and request.memory_bytes > available.memory_limit_bytes:
                reasons.append("RAM request exceeds conservative available limit")
            if request.storage_bytes and available.storage_free_bytes is None:
                reasons.append("Storage capacity is unavailable; storage reservation denied")
            elif available.storage_free_bytes is not None:
                reserve = available.storage_reserve_bytes or 0
                usable = max(0, available.storage_free_bytes - reserve)
                if request.storage_bytes > usable:
                    reasons.append("Storage request would violate free-space reserve")
            if request.gpu_memory_bytes:
                if available.gpu_memory_limit_bytes is None:
                    reasons.append("GPU VRAM capacity is not provider-verified; VRAM reservation denied")
                elif request.gpu_memory_bytes > available.gpu_memory_limit_bytes:
                    reasons.append("GPU VRAM request exceeds conservative available limit")

            if reasons:
                self.audit.append(
                    "WARNING", "resource", "admission_denied", actor="AEON",
                    subject=owner, details={"reasons": reasons, "request": asdict(request)}
                )
                raise ResourcePolicyError("; ".join(reasons))

            lease = ResourceLease("lease-" + uuid.uuid4().hex, owner, request, time.time())
            self._leases[lease.lease_id] = lease
            self.audit.append(
                "INFO", "resource", "admission_granted", actor="AEON",
                subject=owner, details={"lease_id": lease.lease_id, "request": asdict(request)}
            )
            return lease

    def release(self, lease_id: str) -> bool:
        with self._lock:
            lease = self._leases.pop(lease_id, None)
        if lease is None:
            return False
        self.audit.append(
            "INFO", "resource", "lease_released", actor="AEON",
            subject=lease.owner, details={"lease_id": lease_id}
        )
        return True

    def leases(self) -> tuple[ResourceLease, ...]:
        with self._lock:
            return tuple(self._leases.values())

    @staticmethod
    def _validate_request(request):
        for name in ("cpu_logical", "memory_bytes", "storage_bytes", "gpu_memory_bytes"):
            value = getattr(request, name)
            if not isinstance(value, int) or value < 0:
                raise ResourcePolicyError(f"{name} must be a non-negative integer")
        if request.cpu_logical < 1:
            raise ResourcePolicyError("cpu_logical must be at least 1")
