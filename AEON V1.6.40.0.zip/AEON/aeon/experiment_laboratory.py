from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class ExperimentLabError(RuntimeError):pass
EVIDENCE_MODES=("SIMULATION","IMPORTED","HOST","HARDWARE")

@dataclass(frozen=True)
class LabExperiment:
    experiment_id:str;name:str;evidence_mode:str;created_unix:float
    dataset_ids:tuple[str,...];parameters:dict;hypothesis:str;status:str;definition_sha256:str

class ExperimentLaboratory:
    """Persistent, auditable scientific experiment definitions.

    Definitions bind named inputs and parameters before execution. This layer
    does not claim an experiment ran merely because its definition exists.
    """
    def __init__(self,db,audit,data_lab):
        self.db=db;self.audit=audit;self.data_lab=data_lab;self._schema()
    def _schema(self):
        with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS apotheosis_lab_experiments(
          experiment_id TEXT PRIMARY KEY,name TEXT NOT NULL,evidence_mode TEXT NOT NULL,created_unix REAL NOT NULL,
          dataset_ids_json TEXT NOT NULL,parameters_json TEXT NOT NULL,hypothesis TEXT NOT NULL,status TEXT NOT NULL,
          definition_sha256 TEXT NOT NULL)""")
    @staticmethod
    def _canonical(name,evidence,datasets,params,hypothesis):
        return json.dumps({"name":name,"evidence_mode":evidence,"dataset_ids":list(datasets),
                           "parameters":params,"hypothesis":hypothesis},sort_keys=True,separators=(",",":"),ensure_ascii=False)
    def define(self,name,evidence_mode,dataset_ids=(),parameters=None,hypothesis=""):
        name=str(name).strip()
        if not name:raise ExperimentLabError("experiment name required")
        if evidence_mode not in EVIDENCE_MODES:raise ExperimentLabError("invalid evidence mode")
        ids=tuple(dict.fromkeys(str(x) for x in dataset_ids))
        for did in ids:self.data_lab.get(did) # hard reference validation
        params=dict(parameters or {})
        try:canonical=self._canonical(name,evidence_mode,ids,params,str(hypothesis))
        except (TypeError,ValueError) as exc:raise ExperimentLabError("parameters must be JSON-serializable") from exc
        sha=hashlib.sha256(canonical.encode("utf-8")).hexdigest();eid="exp-"+uuid.uuid4().hex;now=time.time()
        with self.db.transaction() as c:c.execute("INSERT INTO apotheosis_lab_experiments VALUES(?,?,?,?,?,?,?,?,?)",
            (eid,name,evidence_mode,now,json.dumps(ids),json.dumps(params,sort_keys=True,separators=(",",":")),
             str(hypothesis),"DEFINED",sha))
        self.audit.append("INFO","apotheosis.experiment_lab","experiment_defined",subject=eid,
                          details={"name":name,"evidence_mode":evidence_mode,"dataset_count":len(ids),"definition_sha256":sha})
        return self.get(eid)
    def get(self,eid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM apotheosis_lab_experiments WHERE experiment_id=?",(eid,)).fetchone()
        if r is None:raise ExperimentLabError("unknown experiment")
        return LabExperiment(r["experiment_id"],r["name"],r["evidence_mode"],r["created_unix"],
          tuple(json.loads(r["dataset_ids_json"])),json.loads(r["parameters_json"]),r["hypothesis"],r["status"],r["definition_sha256"])
    def list(self,limit=250):
        with self.db._connect() as c:ids=[r["experiment_id"] for r in c.execute(
          "SELECT experiment_id FROM apotheosis_lab_experiments ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get(x) for x in ids)
    def verify_definition(self,eid):
        e=self.get(eid);actual=hashlib.sha256(self._canonical(e.name,e.evidence_mode,e.dataset_ids,e.parameters,e.hypothesis).encode("utf-8")).hexdigest()
        return actual==e.definition_sha256,actual
