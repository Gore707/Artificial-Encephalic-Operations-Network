from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class NeuralPartitionError(RuntimeError):pass

@dataclass(frozen=True)
class NeuralPartitionPlan:
 plan_id:str;network_id:str;created_unix:float;partition_count:int;strategy:str
 assignments:tuple[tuple[str,int],...];cut_edges:tuple[str,...];network_signature:str;definition_sha256:str

class NeuralPartitionService:
 """Deterministic graph partition plans for SNN execution."""
 STRATEGIES=("BALANCED_CONTIGUOUS","ROUND_ROBIN")
 def __init__(self,db,audit,snn):
  self.db=db;self.audit=audit;self.snn=snn;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS neural_partition_plans(
   plan_id TEXT PRIMARY KEY,network_id TEXT NOT NULL,created_unix REAL NOT NULL,partition_count INTEGER NOT NULL,
   strategy TEXT NOT NULL,assignments_json TEXT NOT NULL,cut_edges_json TEXT NOT NULL,network_signature TEXT NOT NULL,
   definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def _signature(self,n):
  payload={"network_id":n.network_id,"neurons":n.neuron_states,"synapses":n.synapses}
  return hashlib.sha256(self._canon(payload).encode()).hexdigest()
 def create(self,network_id,partition_count,strategy="BALANCED_CONTIGUOUS"):
  n=self.snn.get(network_id);count=int(partition_count);strategy=str(strategy).upper()
  if count<1:raise NeuralPartitionError("partition_count must be >= 1")
  if count>len(n.neuron_states):raise NeuralPartitionError("partition_count cannot exceed neuron count")
  if strategy not in self.STRATEGIES:raise NeuralPartitionError("unsupported partition strategy")
  nodes=[x[0] for x in n.neuron_states];assign={}
  if strategy=="ROUND_ROBIN":
   assign={node:i%count for i,node in enumerate(nodes)}
  else:
   # Stable near-equal contiguous chunks in stored network order.
   q,r=divmod(len(nodes),count);idx=0
   for p in range(count):
    take=q+(1 if p<r else 0)
    for node in nodes[idx:idx+take]:assign[node]=p
    idx+=take
  cuts=tuple(e["edge_id"] for e in n.synapses if assign[e["source_node_id"]]!=assign[e["target_node_id"]])
  assignments=tuple((node,assign[node]) for node in nodes);sig=self._signature(n)
  payload={"network_id":network_id,"partition_count":count,"strategy":strategy,"assignments":assignments,"cut_edges":cuts,"network_signature":sig}
  sha=hashlib.sha256(self._canon(payload).encode()).hexdigest();pid="npart-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO neural_partition_plans VALUES(?,?,?,?,?,?,?,?,?)",
   (pid,network_id,now,count,strategy,json.dumps(assignments),json.dumps(cuts),sig,sha))
  self.audit.append("INFO","neural_simulacrum.partition","created",subject=pid,details={"partitions":count,"cut_edges":len(cuts),"strategy":strategy})
  return self.get(pid)
 def get(self,pid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM neural_partition_plans WHERE plan_id=?",(pid,)).fetchone()
  if r is None:raise NeuralPartitionError("unknown partition plan")
  return NeuralPartitionPlan(r["plan_id"],r["network_id"],r["created_unix"],r["partition_count"],r["strategy"],
   tuple(tuple(x) for x in json.loads(r["assignments_json"])),tuple(json.loads(r["cut_edges_json"])),r["network_signature"],r["definition_sha256"])
 def verify(self,pid):
  q=self.get(pid)
  try:n=self.snn.get(q.network_id);network_ok=self._signature(n)==q.network_signature
  except Exception:network_ok=False
  payload={"network_id":q.network_id,"partition_count":q.partition_count,"strategy":q.strategy,"assignments":q.assignments,"cut_edges":q.cut_edges,"network_signature":q.network_signature}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  return {"definition_ok":definition_ok,"network_ok":network_ok,"all_ok":definition_ok and network_ok}
 def describe(self,pid):
  q=self.get(pid);counts={i:0 for i in range(q.partition_count)}
  for _,p in q.assignments:counts[p]+=1
  return {"partition_sizes":counts,"cut_edges":len(q.cut_edges),"strategy":q.strategy,
   "note":"P059 creates deterministic logical partitions only. It does not claim optimized placement, GPU execution, or distributed execution."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["plan_id"] for r in c.execute("SELECT plan_id FROM neural_partition_plans ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
