from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid,math

class CellClassificationError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")

@dataclass(frozen=True)
class CellClassification:
 classification_id:str;segmentation_id:str;segment_id:str;created_unix:float
 taxonomy:str;cell_type:str;subtype:str;confidence:float|None;provenance:str
 evidence:tuple[dict,...];method:str;method_version:str;source_segmentation_sha256:str;definition_sha256:str

class CellClassificationService:
 """Attaches explicit, evidence-bearing cell classifications to segmented objects."""
 def __init__(self,db,audit,segmentations):
  self.db=db;self.audit=audit;self.segmentations=segmentations;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS cognitive_injection_cell_classifications(
   classification_id TEXT PRIMARY KEY,segmentation_id TEXT NOT NULL,segment_id TEXT NOT NULL,created_unix REAL NOT NULL,
   taxonomy TEXT NOT NULL,cell_type TEXT NOT NULL,subtype TEXT NOT NULL,confidence REAL,provenance TEXT NOT NULL,
   evidence_json TEXT NOT NULL,method TEXT NOT NULL,method_version TEXT NOT NULL,
   source_segmentation_sha256 TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def classify(self,segmentation_id,segment_id,taxonomy,cell_type,subtype="",confidence=None,provenance="UNKNOWN",evidence=(),method="operator",method_version="1"):
  ss=self.segmentations.get(segmentation_id)
  if not self.segmentations.verify(segmentation_id)["all_ok"]:raise CellClassificationError("source segmentation failed integrity verification")
  if segment_id not in {s.segment_id for s in ss.segments}:raise CellClassificationError("segment absent from segmentation")
  taxonomy=str(taxonomy).strip();cell_type=str(cell_type).strip();subtype=str(subtype).strip()
  if not taxonomy or not cell_type:raise CellClassificationError("taxonomy and cell type required")
  if provenance not in PROVENANCE:raise CellClassificationError("invalid provenance")
  if confidence is not None:
   confidence=float(confidence)
   if not math.isfinite(confidence) or not 0<=confidence<=1:raise CellClassificationError("confidence must be within [0,1]")
  method=str(method).strip();version=str(method_version).strip()
  if not method or not version:raise CellClassificationError("method and method version required")
  ev=tuple(dict(x) for x in evidence)
  payload={"segmentation_id":segmentation_id,"segment_id":segment_id,"taxonomy":taxonomy,"cell_type":cell_type,
   "subtype":subtype,"confidence":confidence,"provenance":provenance,"evidence":ev,"method":method,
   "method_version":version,"source_segmentation_sha256":ss.definition_sha256}
  try:raw=self._canon(payload)
  except (TypeError,ValueError) as exc:raise CellClassificationError("classification must be JSON-serializable") from exc
  sha=hashlib.sha256(raw.encode()).hexdigest();cid="cellclass-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_injection_cell_classifications VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
   (cid,segmentation_id,segment_id,now,taxonomy,cell_type,subtype,confidence,provenance,json.dumps(ev,sort_keys=True),method,version,ss.definition_sha256,sha))
  self.audit.append("INFO","cognitive_injection.cell_classification","created",subject=cid,
   details={"segmentation_id":segmentation_id,"segment_id":segment_id,"taxonomy":taxonomy,"cell_type":cell_type,"provenance":provenance,"definition_sha256":sha})
  return self.get(cid)
 def get(self,cid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_injection_cell_classifications WHERE classification_id=?",(cid,)).fetchone()
  if r is None:raise CellClassificationError("unknown classification")
  return CellClassification(r["classification_id"],r["segmentation_id"],r["segment_id"],r["created_unix"],r["taxonomy"],r["cell_type"],r["subtype"],r["confidence"],r["provenance"],tuple(json.loads(r["evidence_json"])),r["method"],r["method_version"],r["source_segmentation_sha256"],r["definition_sha256"])
 def verify(self,cid):
  q=self.get(cid);ss=self.segmentations.get(q.segmentation_id)
  payload={"segmentation_id":q.segmentation_id,"segment_id":q.segment_id,"taxonomy":q.taxonomy,"cell_type":q.cell_type,
   "subtype":q.subtype,"confidence":q.confidence,"provenance":q.provenance,"evidence":q.evidence,"method":q.method,
   "method_version":q.method_version,"source_segmentation_sha256":q.source_segmentation_sha256}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  source_ok=ss.definition_sha256==q.source_segmentation_sha256 and self.segmentations.verify(q.segmentation_id)["all_ok"]
  return {"definition_ok":definition_ok,"source_ok":source_ok,"all_ok":definition_ok and source_ok}
 def for_segment(self,segmentation_id,segment_id):
  with self.db._connect() as c:ids=[r["classification_id"] for r in c.execute("SELECT classification_id FROM cognitive_injection_cell_classifications WHERE segmentation_id=? AND segment_id=? ORDER BY created_unix",(segmentation_id,segment_id)).fetchall()]
  return tuple(self.get(x) for x in ids)
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["classification_id"] for r in c.execute("SELECT classification_id FROM cognitive_injection_cell_classifications ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
