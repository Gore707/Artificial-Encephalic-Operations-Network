from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class NeuralCacheMigrationError(RuntimeError):pass

@dataclass(frozen=True)
class MigrationRecord:
 migration_id:str;created_unix:float;source_block_id:str;source_device_id:str;target_block_id:str;target_device_id:str
 mode:str;payload_sha256:str;status:str;manifest_sha256:str

class NeuralCacheMigration:
 """Verified COPY/MIGRATE operations between Neural Cache virtual devices.
 MIGRATE is non-destructive in P079 because P076 has no safe delete primitive yet; source retirement is explicit later work.
 """
 MODES=("COPY","MIGRATE")
 def __init__(self,db,audit,devices,blocks):
  self.db=db;self.audit=audit;self.devices=devices;self.blocks=blocks;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS neural_cache_migrations(
   migration_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,source_block_id TEXT NOT NULL,source_device_id TEXT NOT NULL,
   target_block_id TEXT NOT NULL,target_device_id TEXT NOT NULL,mode TEXT NOT NULL,payload_sha256 TEXT NOT NULL,
   status TEXT NOT NULL,manifest_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 def transfer(self,source_block_id,target_device_id,mode="COPY"):
  mode=str(mode).upper()
  if mode not in self.MODES:raise NeuralCacheMigrationError("mode must be COPY or MIGRATE")
  src=self.blocks.get(source_block_id);target=self.devices.get(target_device_id)
  if src.device_id==target.device_id:raise NeuralCacheMigrationError("source and target devices must differ")
  if not self.blocks.verify(source_block_id)["all_ok"]:raise NeuralCacheMigrationError("source block failed integrity verification")
  if target.status!="ONLINE":raise NeuralCacheMigrationError("target device is not writable")
  data=self.blocks.read(source_block_id)
  dst=self.blocks.write(target_device_id,data,kind=src.kind,metadata={**src.metadata,"migration_source":source_block_id,"migration_mode":mode})
  if not self.blocks.verify(dst.block_id)["all_ok"] or dst.sha256!=src.sha256:
   raise NeuralCacheMigrationError("target verification failed")
  payload={"source_block_id":source_block_id,"source_device_id":src.device_id,"target_block_id":dst.block_id,
   "target_device_id":target.device_id,"mode":mode,"payload_sha256":src.sha256}
  mid="ncmig-"+uuid.uuid4().hex;mh=self._sha(payload)
  with self.db.transaction() as c:c.execute("INSERT INTO neural_cache_migrations VALUES(?,?,?,?,?,?,?,?,?,?)",
   (mid,time.time(),source_block_id,src.device_id,dst.block_id,target.device_id,mode,src.sha256,"VERIFIED",mh))
  self.audit.append("INFO","neural_cache.migration","transfer_verified",subject=mid,details={"mode":mode,"source":source_block_id,"target":dst.block_id})
  return self.get(mid)
 def get(self,mid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM neural_cache_migrations WHERE migration_id=?",(mid,)).fetchone()
  if r is None:raise NeuralCacheMigrationError("unknown migration")
  return MigrationRecord(r["migration_id"],r["created_unix"],r["source_block_id"],r["source_device_id"],r["target_block_id"],r["target_device_id"],r["mode"],r["payload_sha256"],r["status"],r["manifest_sha256"])
 def verify(self,mid):
  q=self.get(mid);payload={"source_block_id":q.source_block_id,"source_device_id":q.source_device_id,"target_block_id":q.target_block_id,
   "target_device_id":q.target_device_id,"mode":q.mode,"payload_sha256":q.payload_sha256}
  manifest=self._sha(payload)==q.manifest_sha256
  checks={}
  for name,bid in (("source",q.source_block_id),("target",q.target_block_id)):
   try:v=self.blocks.verify(bid);b=self.blocks.get(bid);checks[name]=v["all_ok"] and b.sha256==q.payload_sha256
   except Exception:checks[name]=False
  return {"manifest_ok":manifest,"source_ok":checks["source"],"target_ok":checks["target"],"all_ok":manifest and checks["source"] and checks["target"]}
 def list(self):
  with self.db._connect() as c:ids=[r["migration_id"] for r in c.execute("SELECT migration_id FROM neural_cache_migrations ORDER BY created_unix").fetchall()]
  return tuple(self.get(x) for x in ids)
 def summary(self):
  return {"transfers":len(self.list()),"modes":self.MODES,"note":"P079 verifies destination bytes before recording success. MIGRATE preserves the source because safe source retirement/deletion is not yet implemented."}
