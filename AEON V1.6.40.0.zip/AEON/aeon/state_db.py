from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
import json
import sqlite3
import threading
import time
from typing import Any, Iterator


class StateDatabaseError(RuntimeError):
    pass


class StateDatabase:
    """Transactional SQLite persistence for AEON OS state.

    P006 owns generic durable key/value state and schema migration tracking.
    Domain datasets and immutable scientific source data remain separate.
    """
    SCHEMA_VERSION = 1

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = FULL")
        return conn

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            conn = self._connect()
            try:
                conn.execute("BEGIN IMMEDIATE")
                yield conn
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

    def _initialize(self) -> None:
        with self.transaction() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS schema_info (
                    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
                    version INTEGER NOT NULL,
                    updated_unix REAL NOT NULL
                )
            """)
            row = conn.execute("SELECT version FROM schema_info WHERE singleton = 1").fetchone()
            if row is None:
                conn.execute(
                    "INSERT INTO schema_info(singleton, version, updated_unix) VALUES(1, ?, ?)",
                    (self.SCHEMA_VERSION, time.time()),
                )
            elif int(row["version"]) > self.SCHEMA_VERSION:
                raise StateDatabaseError(
                    f"Database schema {row['version']} is newer than AEON supports "
                    f"({self.SCHEMA_VERSION})"
                )

            conn.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    namespace TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value_json TEXT NOT NULL,
                    updated_unix REAL NOT NULL,
                    PRIMARY KEY(namespace, key)
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS migrations (
                    migration_id TEXT PRIMARY KEY,
                    applied_unix REAL NOT NULL
                )
            """)

    def schema_version(self) -> int:
        with self._connect() as conn:
            row = conn.execute("SELECT version FROM schema_info WHERE singleton = 1").fetchone()
            if row is None:
                raise StateDatabaseError("Missing schema metadata")
            return int(row["version"])

    def set(self, namespace: str, key: str, value: Any) -> None:
        namespace = namespace.strip()
        key = key.strip()
        if not namespace or not key:
            raise StateDatabaseError("namespace and key are required")
        try:
            encoded = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            raise StateDatabaseError(f"Value is not JSON serializable: {exc}") from exc
        with self.transaction() as conn:
            conn.execute("""
                INSERT INTO settings(namespace, key, value_json, updated_unix)
                VALUES(?, ?, ?, ?)
                ON CONFLICT(namespace, key) DO UPDATE SET
                    value_json=excluded.value_json,
                    updated_unix=excluded.updated_unix
            """, (namespace, key, encoded, time.time()))

    def get(self, namespace: str, key: str, default: Any = None) -> Any:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT value_json FROM settings WHERE namespace=? AND key=?",
                (namespace, key),
            ).fetchone()
        if row is None:
            return default
        try:
            return json.loads(row["value_json"])
        except json.JSONDecodeError as exc:
            raise StateDatabaseError(
                f"Corrupt persisted setting {namespace}.{key}"
            ) from exc

    def delete(self, namespace: str, key: str) -> bool:
        with self.transaction() as conn:
            cursor = conn.execute(
                "DELETE FROM settings WHERE namespace=? AND key=?",
                (namespace, key),
            )
            return cursor.rowcount > 0

    def namespace(self, namespace: str) -> dict[str, Any]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT key, value_json FROM settings WHERE namespace=? ORDER BY key",
                (namespace,),
            ).fetchall()
        result = {}
        for row in rows:
            try:
                result[row["key"]] = json.loads(row["value_json"])
            except json.JSONDecodeError as exc:
                raise StateDatabaseError(
                    f"Corrupt persisted setting {namespace}.{row['key']}"
                ) from exc
        return result

    def migration_applied(self, migration_id: str) -> bool:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT 1 FROM migrations WHERE migration_id=?",
                (migration_id,),
            ).fetchone()
            return row is not None

    def mark_migration(self, migration_id: str, conn: sqlite3.Connection) -> None:
        conn.execute(
            "INSERT INTO migrations(migration_id, applied_unix) VALUES(?, ?)",
            (migration_id, time.time()),
        )

    def integrity_check(self) -> tuple[bool, str]:
        with self._connect() as conn:
            row = conn.execute("PRAGMA integrity_check").fetchone()
        result = str(row[0]) if row else "no result"
        return result.lower() == "ok", result
