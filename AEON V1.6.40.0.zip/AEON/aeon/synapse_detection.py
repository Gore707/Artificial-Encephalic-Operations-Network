from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid,math

class SynapseDetectionError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")
DIRECTIONS=("DIRECTED","BIDIRECTIONAL","UNKNOWN")
KINDS=("CHEMICAL","ELECTRICAL","MIXED","UNKNOWN")

@dataclass(frozen=True)
class SynapseCandidate:
 synapse_id:str;pre_trace_id:str|None;pre_node_id:str|None;post_trace_id:str|None;post_node_id:str|None
 xyz:tuple[float,float,float]|None;kind:str;direction:str;confidence:float|None;provenance:str;attributes:dict

@dataclass(frozen=True)
class SynapseDetectionRecord:
 detection_id:str;created_unix:float;method:str;method_version:str;candidates:tuple[SynapseCandidate,...]
 source_trace_hashes:tuple[tuple[str,str],...];definition_sha256:str

class SynapseDetectionService:
 """Stores candidate contacts; detection does not imply functional synaptic state."""
 def __init__(self,db,audit,traces):
  self.db=db;self.audit=audit;self.traces=traces;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS cognitive_injection_synapse_detections(
   detection_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,method TEXT NOT NULL,method_version TEXT NOT NULL,
   candidates_json TEXT NOT NULL,source_trace_hashes_json TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 @staticmethod
 def _conf(v):
  if v is None:return None
  q=float(v)
  if not math.isfinite(q) or not 0<=q<=1:raise SynapseDetectionError("confidence must be within [0,1]")
  return q
 def create(self,method,method_version,candidates):
  method=str(method).strip();version=str(method_version).strip()
  if not method or not version:raise SynapseDetectionError("method and method version required")
  out=[];seen=set();source={}
  for raw in candidates:
   x=dict(raw);sid=str(x.get("synapse_id") or ("syn-"+uuid.uuid4().hex))
   if sid in seen:raise SynapseDetectionError("duplicate synapse id")
   seen.add(sid)
   pre=x.get("pre_trace_id");post=x.get("post_trace_id");pn=x.get("pre_node_id");qn=x.get("post_node_id")
   if pre is None and post is None:raise SynapseDetectionError("candidate must reference at least one trace")
   for tid,nid in ((pre,pn),(post,qn)):
    if tid is None:
     if nid is not None:raise SynapseDetectionError("node reference requires trace reference")
     continue
    tr=self.traces.get(str(tid))
    if not self.traces.verify(str(tid))["all_ok"]:raise SynapseDetectionError("source trace failed integrity verification")
    source[str(tid)]=tr.definition_sha256
    if nid is not None and str(nid) not in {n.node_id for n in tr.nodes}:raise SynapseDetectionError("node absent from referenced trace")
   xyz=x.get("xyz")
   if xyz is not None:
    try:xyz=tuple(float(v) for v in xyz)
    except Exception as exc:raise SynapseDetectionError("xyz must be numeric") from exc
    if len(xyz)!=3 or any(not math.isfinite(v) for v in xyz):raise SynapseDetectionError("xyz must contain three finite coordinates")
   kind=str(x.get("kind","UNKNOWN"));direction=str(x.get("direction","UNKNOWN"));prov=str(x.get("provenance","DERIVED"))
   if kind not in KINDS:raise SynapseDetectionError("invalid synapse kind")
   if direction not in DIRECTIONS:raise SynapseDetectionError("invalid direction")
   if prov not in PROVENANCE:raise SynapseDetectionError("invalid provenance")
   out.append(SynapseCandidate(sid,str(pre) if pre is not None else None,str(pn) if pn is not None else None,
    str(post) if post is not None else None,str(qn) if qn is not None else None,xyz,kind,direction,self._conf(x.get("confidence")),prov,dict(x.get("attributes") or {})))
  if not out:raise SynapseDetectionError("at least one candidate required")
  bindings=tuple(sorted(source.items()))
  payload={"method":method,"method_version":version,"source_trace_hashes":bindings,
   "candidates":[{"synapse_id":s.synapse_id,"pre_trace_id":s.pre_trace_id,"pre_node_id":s.pre_node_id,"post_trace_id":s.post_trace_id,
   "post_node_id":s.post_node_id,"xyz":s.xyz,"kind":s.kind,"direction":s.direction,"confidence":s.confidence,"provenance":s.provenance,"attributes":s.attributes} for s in out]}
  raw=self._canon(payload);sha=hashlib.sha256(raw.encode()).hexdigest();did="syndet-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_injection_synapse_detections VALUES(?,?,?,?,?,?,?)",
   (did,now,method,version,json.dumps(payload["candidates"],sort_keys=True),json.dumps(bindings),sha))
  self.audit.append("INFO","cognitive_injection.synapse_detection","created",subject=did,details={"method":method,"candidates":len(out),"source_traces":len(bindings),"definition_sha256":sha})
  return self.get(did)
 def get(self,did):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_injection_synapse_detections WHERE detection_id=?",(did,)).fetchone()
  if r is None:raise SynapseDetectionError("unknown synapse detection")
  cs=[]
  for x in json.loads(r["candidates_json"]):
   cs.append(SynapseCandidate(x["synapse_id"],x["pre_trace_id"],x["pre_node_id"],x["post_trace_id"],x["post_node_id"],
    tuple(x["xyz"]) if x["xyz"] is not None else None,x["kind"],x["direction"],x["confidence"],x["provenance"],x["attributes"]))
  return SynapseDetectionRecord(r["detection_id"],r["created_unix"],r["method"],r["method_version"],tuple(cs),tuple(tuple(x) for x in json.loads(r["source_trace_hashes_json"])),r["definition_sha256"])
 def verify(self,did):
  q=self.get(did);source_ok=True
  for tid,sha in q.source_trace_hashes:
   try:tr=self.traces.get(tid);source_ok &= tr.definition_sha256==sha and self.traces.verify(tid)["all_ok"]
   except Exception:source_ok=False
  payload={"method":q.method,"method_version":q.method_version,"source_trace_hashes":q.source_trace_hashes,
   "candidates":[{"synapse_id":s.synapse_id,"pre_trace_id":s.pre_trace_id,"pre_node_id":s.pre_node_id,"post_trace_id":s.post_trace_id,
   "post_node_id":s.post_node_id,"xyz":s.xyz,"kind":s.kind,"direction":s.direction,"confidence":s.confidence,"provenance":s.provenance,"attributes":s.attributes} for s in q.candidates]}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  return {"definition_ok":definition_ok,"source_ok":bool(source_ok),"all_ok":definition_ok and bool(source_ok)}
 def summary(self,did):
  q=self.get(did)
  return {"candidates":len(q.candidates),"chemical":sum(x.kind=="CHEMICAL" for x in q.candidates),"electrical":sum(x.kind=="ELECTRICAL" for x in q.candidates),
   "unknown_kind":sum(x.kind=="UNKNOWN" for x in q.candidates),
   "note":"Candidate contact detection does not establish neurotransmitter identity, receptor state, synaptic weight, plasticity, release probability, or functional efficacy."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["detection_id"] for r in c.execute("SELECT detection_id FROM cognitive_injection_synapse_detections ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
