from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence
import json, threading, time, uuid
from .resources import ResourceRequest, ResourcePolicyError

class JobError(RuntimeError): pass

@dataclass(frozen=True)
class Job:
    job_id:str; name:str; owner:str; command:tuple[str,...]; state:str
    created_unix:float; started_unix:float|None; ended_unix:float|None
    process_id:str|None; lease_id:str|None; return_code:int|None; error:str|None
    request:ResourceRequest

class JobScheduler:
    TERMINAL={"SUCCEEDED","FAILED","CANCELLED"}
    def __init__(self,state_db,audit,resources,processes,poll_interval=.20):
        self.db=state_db;self.audit=audit;self.resources=resources;self.processes=processes
        self.poll_interval=max(.05,float(poll_interval));self._lock=threading.RLock()
        self._shutdown=threading.Event();self._ensure_schema();self._recover_interrupted()
        self._worker=threading.Thread(target=self._loop,name="aeon-job-scheduler",daemon=True)
        self._worker.start()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS jobs(
             job_id TEXT PRIMARY KEY,name TEXT NOT NULL,owner TEXT NOT NULL,
             command_json TEXT NOT NULL,state TEXT NOT NULL,created_unix REAL NOT NULL,
             started_unix REAL,ended_unix REAL,process_id TEXT,lease_id TEXT,
             return_code INTEGER,error TEXT,cpu_logical INTEGER NOT NULL,
             memory_bytes INTEGER NOT NULL,storage_bytes INTEGER NOT NULL,
             gpu_memory_bytes INTEGER NOT NULL)""")

    def _recover_interrupted(self):
        with self.db.transaction() as c:
            rows=c.execute("SELECT job_id,state FROM jobs WHERE state IN ('STARTING','RUNNING')").fetchall()
            now=time.time()
            for r in rows:
                c.execute("""UPDATE jobs SET state='FAILED',ended_unix=?,
                 error='AEON restarted before completion; prior process not adopted'
                 WHERE job_id=?""",(now,r["job_id"]))
        for r in rows:self.audit.append("WARNING","job","interrupted_job_recovered",
                                        subject=r["job_id"],details={"previous_state":r["state"]})

    def submit(self,name:str,owner:str,command:Sequence[str],request:ResourceRequest)->Job:
        name=name.strip();owner=owner.strip()
        if not name or not owner or not command:raise JobError("name, owner, and command are required")
        self.resources._validate_request(request)
        jid="job-"+uuid.uuid4().hex;now=time.time()
        with self.db.transaction() as c:
            c.execute("""INSERT INTO jobs(
             job_id,name,owner,command_json,state,created_unix,started_unix,ended_unix,
             process_id,lease_id,return_code,error,cpu_logical,memory_bytes,storage_bytes,gpu_memory_bytes)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
             (jid,name,owner,json.dumps(list(command)),"QUEUED",now,None,None,None,None,None,None,
              request.cpu_logical,request.memory_bytes,request.storage_bytes,request.gpu_memory_bytes))
        self.audit.append("INFO","job","submitted",subject=jid,details={"name":name,"owner":owner})
        return self.get(jid)

    def get(self,jid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM jobs WHERE job_id=?",(jid,)).fetchone()
        if r is None:raise JobError(f"Unknown job: {jid}")
        return self._row(r)

    def list(self,limit=200):
        with self.db._connect() as c:
            rows=c.execute("SELECT * FROM jobs ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()
        return tuple(self._row(r) for r in rows)

    def cancel(self,jid):
        with self._lock:
            j=self.get(jid)
            if j.state in self.TERMINAL:return j
            if j.process_id:
                try:self.processes.stop(j.process_id)
                except Exception as exc:raise JobError(f"Could not stop process: {exc}") from exc
            if j.lease_id:self.resources.release(j.lease_id)
            with self.db.transaction() as c:
                c.execute("UPDATE jobs SET state='CANCELLED',ended_unix=? WHERE job_id=?",(time.time(),jid))
            self.audit.append("WARNING","job","cancelled",subject=jid)
            return self.get(jid)

    def _loop(self):
        while not self._shutdown.wait(self.poll_interval):
            try:
                with self._lock:self._reconcile();self._dispatch_one()
            except Exception as exc:
                try:self.audit.append("CRITICAL","job","scheduler_error",details={"error":repr(exc)})
                except Exception:pass

    def _dispatch_one(self):
        with self.db._connect() as c:
            r=c.execute("SELECT * FROM jobs WHERE state='QUEUED' ORDER BY created_unix LIMIT 1").fetchone()
        if r is None:return
        j=self._row(r)
        try:lease=self.resources.admit(j.job_id,j.request)
        except ResourcePolicyError:return
        try:
            with self.db.transaction() as c:
                c.execute("UPDATE jobs SET state='STARTING',lease_id=?,started_unix=? WHERE job_id=?",
                          (lease.lease_id,time.time(),j.job_id))
            pid=self.processes.launch(j.name,j.command)
            with self.db.transaction() as c:
                c.execute("UPDATE jobs SET state='RUNNING',process_id=? WHERE job_id=?",(pid,j.job_id))
            self.audit.append("INFO","job","started",subject=j.job_id,
                              details={"process_id":pid,"lease_id":lease.lease_id})
        except Exception as exc:
            self.resources.release(lease.lease_id)
            with self.db.transaction() as c:
                c.execute("UPDATE jobs SET state='FAILED',ended_unix=?,error=? WHERE job_id=?",
                          (time.time(),repr(exc),j.job_id))

    def _reconcile(self):
        with self.db._connect() as c:rows=c.execute("SELECT * FROM jobs WHERE state='RUNNING'").fetchall()
        for r in rows:
            j=self._row(r)
            try:s=self.processes.snapshot(j.process_id)
            except Exception as exc:self._finish(j,"FAILED",None,f"Process lost: {exc}");continue
            if s.state=="EXITED":self._finish(j,"SUCCEEDED" if s.return_code==0 else "FAILED",s.return_code,None)
            elif s.state=="CRASHED":self._finish(j,"FAILED",s.return_code,"Child process crashed")

    def _finish(self,j,state,rc,error):
        if j.lease_id:self.resources.release(j.lease_id)
        with self.db.transaction() as c:
            c.execute("UPDATE jobs SET state=?,ended_unix=?,return_code=?,error=? WHERE job_id=?",
                      (state,time.time(),rc,error,j.job_id))
        self.audit.append("INFO" if state=="SUCCEEDED" else "WARNING","job","finished",
                          subject=j.job_id,details={"state":state,"return_code":rc})

    def shutdown(self):
        self._shutdown.set()
        if self._worker.is_alive():self._worker.join(timeout=2)
        for j in self.list():
            if j.state in ("STARTING","RUNNING"):
                try:self.cancel(j.job_id)
                except Exception:pass

    @staticmethod
    def _row(r):
        return Job(r["job_id"],r["name"],r["owner"],tuple(json.loads(r["command_json"])),r["state"],
                   r["created_unix"],r["started_unix"],r["ended_unix"],r["process_id"],r["lease_id"],
                   r["return_code"],r["error"],ResourceRequest(r["cpu_logical"],r["memory_bytes"],
                   r["storage_bytes"],r["gpu_memory_bytes"]))
