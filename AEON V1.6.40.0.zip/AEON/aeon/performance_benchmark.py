from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,math,statistics,time,uuid

class BenchmarkError(RuntimeError):pass

@dataclass(frozen=True)
class BenchmarkResult:
 benchmark_id:str;created_unix:float;name:str;iterations:int;warmup:int;median_ns:int;p95_ns:int;minimum_ns:int;maximum_ns:int;throughput_per_s:float;result_sha256:str

class PerformanceBenchmark:
 """P087 repeatable local microbenchmark instrumentation.
 Measures callable wall-clock duration with perf_counter_ns. It does not invent GPU,
 cluster, neural-model, or production throughput claims.
 """
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p087_benchmarks(
   benchmark_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,name TEXT NOT NULL,iterations INTEGER NOT NULL,warmup INTEGER NOT NULL,
   median_ns INTEGER NOT NULL,p95_ns INTEGER NOT NULL,minimum_ns INTEGER NOT NULL,maximum_ns INTEGER NOT NULL,
   throughput_per_s REAL NOT NULL,result_sha256 TEXT NOT NULL)""")
 def run(self,name,fn,iterations=50,warmup=5):
  name=str(name).strip();iterations=int(iterations);warmup=int(warmup)
  if not name or iterations<1 or iterations>100000 or warmup<0 or warmup>10000:raise BenchmarkError("invalid benchmark configuration")
  for _ in range(warmup):fn()
  samples=[]
  for _ in range(iterations):
   t0=time.perf_counter_ns();fn();samples.append(max(1,time.perf_counter_ns()-t0))
  ordered=sorted(samples);idx=max(0,min(len(ordered)-1,math.ceil(.95*len(ordered))-1))
  median=int(statistics.median(ordered));p95=int(ordered[idx]);mn=int(ordered[0]);mx=int(ordered[-1]);throughput=1e9/median
  payload={"name":name,"iterations":iterations,"warmup":warmup,"median_ns":median,"p95_ns":p95,"minimum_ns":mn,"maximum_ns":mx,"throughput_per_s":throughput}
  sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest();bid="p087-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p087_benchmarks VALUES(?,?,?,?,?,?,?,?,?,?,?)",(bid,time.time(),name,iterations,warmup,median,p95,mn,mx,throughput,sha))
  self.audit.append("INFO","performance.p087","benchmark_complete",subject=bid,details={"name":name,"iterations":iterations,"median_ns":median,"p95_ns":p95})
  return self.get(bid)
 def get(self,bid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p087_benchmarks WHERE benchmark_id=?",(bid,)).fetchone()
  if r is None:raise BenchmarkError("unknown benchmark")
  return BenchmarkResult(r["benchmark_id"],r["created_unix"],r["name"],r["iterations"],r["warmup"],r["median_ns"],r["p95_ns"],r["minimum_ns"],r["maximum_ns"],r["throughput_per_s"],r["result_sha256"])
 def verify(self,bid):
  r=self.get(bid);payload={"name":r.name,"iterations":r.iterations,"warmup":r.warmup,"median_ns":r.median_ns,"p95_ns":r.p95_ns,"minimum_ns":r.minimum_ns,"maximum_ns":r.maximum_ns,"throughput_per_s":r.throughput_per_s}
  sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
  return {"benchmark_id":bid,"all_ok":sha==r.result_sha256,"computed_sha256":sha,"stored_sha256":r.result_sha256}
 def summary(self):
  with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM p087_benchmarks").fetchone()["n"]
  return {"phase":"PERFORMANCE & CLUSTER OPTIMIZATION I","benchmarks":n,"clock":"time.perf_counter_ns","scope":"Measured local callable latency/throughput only; workload-specific results must not be generalized to whole-brain or cluster performance."}
