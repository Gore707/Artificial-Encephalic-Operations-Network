from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,platform,sys,time,uuid

@dataclass(frozen=True)
class IntegrationCheck:
    name:str;passed:bool;detail:str
@dataclass(frozen=True)
class IntegrationReport:
    report_id:str;created_unix:float;passed:bool;checks:tuple[IntegrationCheck,...]

class IntegrationDiagnostics:
    """Cross-service qualification diagnostics for AEON OS foundation."""
    def __init__(self,services,audit):
        self.services=services;self.audit=audit

    def run(self):
        checks=[]
        def check(name,fn):
            try:
                detail=fn()
                checks.append(IntegrationCheck(name,True,str(detail)))
            except Exception as exc:
                checks.append(IntegrationCheck(name,False,f"{type(exc).__name__}: {exc}"))
        s=self.services
        check("database.integrity",lambda: s.state_db.integrity_check())
        check("audit.chain",lambda: self._audit())
        check("hardware.cpu_ram",lambda: f"{s.hardware.snapshot().logical_cpu_count} logical CPUs")
        check("accelerator.discovery",lambda: f"{len(s.accelerators.discover())} accelerator(s)")
        check("telemetry.stream",lambda: f"{len(s.telemetry_stream.channels())} channel(s)")
        check("jobs.scheduler",lambda: f"{len(s.jobs.list())} job(s)")
        check("checkpoint.catalog",lambda: f"{len(s.checkpoints.list())} checkpoint(s)")
        check("integrity.catalog",lambda: f"{len(s.integrity.list())} integrity record(s)")
        check("backup.catalog",lambda: f"{len(s.transactional_files.list_backups())} backup(s)")
        check("recovery.catalog",lambda: f"{len(s.recovery.list_events())} recovery event(s)")
        check("node.protocol",lambda: f"{len(s.nodes.list())} known peer(s)")
        check("cluster.identity",lambda: s.cluster.local.node_id)
        check("guardian.core",lambda: s.guardian.status)
        check("safety.kernel",lambda: f"{len(s.safety_kernel.list_rules())} deterministic rule(s)")
        check("neural.genesis.service",lambda: type(s.genesis).__name__)
        rid="irep-"+uuid.uuid4().hex;now=time.time();passed=all(c.passed for c in checks)
        self.audit.append("INFO" if passed else "CRITICAL","integration","qualification_report",subject=rid,
                          details={"passed":passed,"failed":[c.name for c in checks if not c.passed],
                                   "python":sys.version.split()[0],"platform":platform.platform()})
        return IntegrationReport(rid,now,passed,tuple(checks))

    def _audit(self):
        ok,msg=self.audit.verify()
        if not ok:raise RuntimeError(msg)
        return msg
