from __future__ import annotations
from dataclasses import dataclass,asdict
import hashlib,hmac,json,secrets,socket,struct,threading,time,uuid

class NodeProtocolError(RuntimeError):pass

PROTOCOL_VERSION=1
MAX_FRAME_BYTES=8*1024*1024
MESSAGE_TYPES={"HELLO","HELLO_ACK","HEARTBEAT","STATUS","REQUEST","RESPONSE","ERROR","GOODBYE"}

@dataclass(frozen=True)
class NodeMessage:
    message_id:str;message_type:str;source_node:str;target_node:str|None
    timestamp_unix:float;payload:dict;protocol_version:int=PROTOCOL_VERSION

class NodeCodec:
    """Length-framed authenticated JSON protocol.

    Authentication is HMAC-SHA256 with a pre-shared cluster secret. This gives
    message integrity/authentication, not transport confidentiality; later
    deployment may place the protocol inside TLS/VPN/private cluster networks.
    """
    @staticmethod
    def encode(message:NodeMessage,secret:bytes)->bytes:
        if message.message_type not in MESSAGE_TYPES:raise NodeProtocolError("invalid message type")
        if message.protocol_version!=PROTOCOL_VERSION:raise NodeProtocolError("unsupported protocol version")
        body=json.dumps(asdict(message),sort_keys=True,separators=(",",":"),allow_nan=False).encode()
        sig=hmac.new(secret,body,hashlib.sha256).hexdigest().encode()
        envelope=json.dumps({"body":body.decode(),"hmac_sha256":sig.decode()},
                            separators=(",",":")).encode()
        if len(envelope)>MAX_FRAME_BYTES:raise NodeProtocolError("frame too large")
        return struct.pack("!I",len(envelope))+envelope

    @staticmethod
    def decode(frame:bytes,secret:bytes)->NodeMessage:
        if len(frame)<4:raise NodeProtocolError("truncated frame")
        size=struct.unpack("!I",frame[:4])[0]
        if size>MAX_FRAME_BYTES or len(frame[4:])!=size:raise NodeProtocolError("invalid frame length")
        try:
            env=json.loads(frame[4:].decode());body=env["body"].encode();sig=env["hmac_sha256"]
        except Exception as exc:raise NodeProtocolError("malformed frame") from exc
        expected=hmac.new(secret,body,hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected,sig):raise NodeProtocolError("message authentication failed")
        try:d=json.loads(body)
        except Exception as exc:raise NodeProtocolError("invalid message JSON") from exc
        if d.get("protocol_version")!=PROTOCOL_VERSION:raise NodeProtocolError("unsupported protocol version")
        if d.get("message_type") not in MESSAGE_TYPES:raise NodeProtocolError("invalid message type")
        return NodeMessage(**d)

    @staticmethod
    def recv(sock:socket.socket,secret:bytes)->NodeMessage:
        header=NodeCodec._recv_exact(sock,4)
        size=struct.unpack("!I",header)[0]
        if size>MAX_FRAME_BYTES:raise NodeProtocolError("frame too large")
        return NodeCodec.decode(header+NodeCodec._recv_exact(sock,size),secret)

    @staticmethod
    def _recv_exact(sock,n):
        chunks=[];remaining=n
        while remaining:
            b=sock.recv(remaining)
            if not b:raise NodeProtocolError("connection closed mid-frame")
            chunks.append(b);remaining-=len(b)
        return b"".join(chunks)

def message(kind,source,payload=None,target=None):
    return NodeMessage("msg-"+uuid.uuid4().hex,kind,source,target,time.time(),dict(payload or {}))

@dataclass(frozen=True)
class PeerState:
    node_id:str;address:str;last_seen_unix:float;protocol_version:int;status:str

class NodeRegistry:
    """Persistent known-peer state. Discovery policy is P024."""
    def __init__(self,db,audit):
        self.db=db;self.audit=audit;self._ensure_schema()
    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS cluster_peers(
              node_id TEXT PRIMARY KEY,address TEXT NOT NULL,last_seen_unix REAL NOT NULL,
              protocol_version INTEGER NOT NULL,status TEXT NOT NULL)""")
    def observe(self,node_id,address,status="ONLINE",protocol_version=PROTOCOL_VERSION):
        if not node_id.strip() or not address.strip():raise NodeProtocolError("node id/address required")
        now=time.time()
        with self.db.transaction() as c:
            c.execute("""INSERT INTO cluster_peers VALUES(?,?,?,?,?)
              ON CONFLICT(node_id) DO UPDATE SET address=excluded.address,
              last_seen_unix=excluded.last_seen_unix,protocol_version=excluded.protocol_version,
              status=excluded.status""",(node_id,address,now,protocol_version,status))
        return self.get(node_id)
    def get(self,node_id):
        with self.db._connect() as c:r=c.execute("SELECT * FROM cluster_peers WHERE node_id=?",(node_id,)).fetchone()
        if r is None:raise NodeProtocolError(f"unknown node: {node_id}")
        return PeerState(r["node_id"],r["address"],r["last_seen_unix"],r["protocol_version"],r["status"])
    def list(self):
        with self.db._connect() as c:rows=c.execute("SELECT * FROM cluster_peers ORDER BY node_id").fetchall()
        return tuple(PeerState(r["node_id"],r["address"],r["last_seen_unix"],r["protocol_version"],r["status"]) for r in rows)
