from __future__ import annotations
from dataclasses import dataclass
import json,socket,time,uuid
from .node_protocol import NodeCodec,NodeProtocolError,message,PROTOCOL_VERSION

class DistributedExecutionError(RuntimeError):pass

@dataclass(frozen=True)
class RemoteJob:
    remote_job_id:str;node_id:str;local_job_id:str|None;state:str
    submitted_unix:float;updated_unix:float;command:tuple[str,...]

class DistributedJobService:
    """Controlled remote-job protocol and execution receiver.

    Peers are not trusted merely because discovery found them. A remote submit
    is accepted only over an authenticated P023 message, from an explicitly
    allowed node ID, and is then passed to the local P015 scheduler so local
    resource admission/process containment remain authoritative.
    """
    def __init__(self,db,audit,nodes,jobs,secret:bytes):
        if not isinstance(secret,(bytes,bytearray)) or len(secret)<16:
            raise DistributedExecutionError("cluster secret must be at least 16 bytes")
        self.db=db;self.audit=audit;self.nodes=nodes;self.jobs=jobs;self.secret=bytes(secret);self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS cluster_authorized_nodes(
              node_id TEXT PRIMARY KEY,enabled INTEGER NOT NULL CHECK(enabled IN(0,1)))""")
            c.execute("""CREATE TABLE IF NOT EXISTS remote_jobs(
              remote_job_id TEXT PRIMARY KEY,node_id TEXT NOT NULL,local_job_id TEXT,
              state TEXT NOT NULL,submitted_unix REAL NOT NULL,updated_unix REAL NOT NULL,
              command_json TEXT NOT NULL)""")

    def authorize(self,node_id,enabled=True):
        self.nodes.get(node_id)  # cannot authorize an unknown/discovered-never-seen identity
        with self.db.transaction() as c:
            c.execute("""INSERT INTO cluster_authorized_nodes VALUES(?,?)
              ON CONFLICT(node_id) DO UPDATE SET enabled=excluded.enabled""",(node_id,1 if enabled else 0))
        self.audit.append("WARNING","cluster","node_authorization_changed",subject=node_id,
                          details={"enabled":bool(enabled)})

    def is_authorized(self,node_id):
        with self.db._connect() as c:r=c.execute("SELECT enabled FROM cluster_authorized_nodes WHERE node_id=?",(node_id,)).fetchone()
        return bool(r and r["enabled"])

    def build_submit(self,source_node,target_node,command,resources=None):
        cmd=tuple(str(x) for x in command)
        if not cmd:raise DistributedExecutionError("empty command")
        payload={"operation":"SUBMIT_JOB","command":list(cmd),"resources":dict(resources or {})}
        return NodeCodec.encode(message("REQUEST",source_node,payload,target_node),self.secret)

    def receive_frame(self,frame:bytes,address="unknown"):
        msg=NodeCodec.decode(frame,self.secret)
        if msg.message_type!="REQUEST" or msg.payload.get("operation")!="SUBMIT_JOB":
            raise DistributedExecutionError("unsupported remote request")
        if not self.is_authorized(msg.source_node):
            self.audit.append("CRITICAL","cluster","remote_job_rejected",subject=msg.source_node,
                              details={"reason":"node not authorized","address":address})
            raise DistributedExecutionError("source node is not authorized for execution")
        cmd=msg.payload.get("command")
        if not isinstance(cmd,list) or not cmd or not all(isinstance(x,str) and x for x in cmd):
            raise DistributedExecutionError("invalid remote command")
        # P015 owns actual process launch and P014 admission.
        from .resources import ResourceRequest
        raw=dict(msg.payload.get("resources") or {})
        try:req=ResourceRequest(**raw)
        except Exception as exc:raise DistributedExecutionError("invalid resource request") from exc
        rid="rjob-"+uuid.uuid4().hex;now=time.time()
        local=self.jobs.submit(name=f"Remote job from {msg.source_node}",owner=f"remote:{msg.source_node}",command=cmd,request=req)
        with self.db.transaction() as c:
            c.execute("INSERT INTO remote_jobs VALUES(?,?,?,?,?,?,?)",
                      (rid,msg.source_node,local.job_id,local.state,now,now,json.dumps(cmd,separators=(",",":"))))
        self.audit.append("WARNING","cluster","remote_job_accepted",subject=rid,
                          details={"source_node":msg.source_node,"local_job_id":local.job_id,"address":address})
        return self.get(rid)

    def get(self,rid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM remote_jobs WHERE remote_job_id=?",(rid,)).fetchone()
        if r is None:raise DistributedExecutionError(f"unknown remote job: {rid}")
        state=r["state"];updated=r["updated_unix"]
        if r["local_job_id"]:
            try:
                j=self.jobs.get(r["local_job_id"]);state=j.state
                if state!=r["state"]:
                    updated=time.time()
                    with self.db.transaction() as c:c.execute("UPDATE remote_jobs SET state=?,updated_unix=? WHERE remote_job_id=?",(state,updated,rid))
            except Exception:pass
        return RemoteJob(r["remote_job_id"],r["node_id"],r["local_job_id"],state,r["submitted_unix"],updated,tuple(json.loads(r["command_json"])))

    def list(self,limit=200):
        with self.db._connect() as c:ids=[r["remote_job_id"] for r in c.execute(
            "SELECT remote_job_id FROM remote_jobs ORDER BY submitted_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get(i) for i in ids)
