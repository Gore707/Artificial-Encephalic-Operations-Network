from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class DistributedCheckpointError(RuntimeError): pass

@dataclass(frozen=True)
class PartitionCheckpoint:
    partition_id:str; node_id:str; checkpoint_ref:str; sha256:str; byte_count:int; logical_step:int; simulation_time:float; time_unit:str

@dataclass(frozen=True)
class DistributedCheckpoint:
    checkpoint_id:str; created_unix:float; run_id:str; plan_id:str; plan_sha256:str; logical_step:int
    simulation_time:float; time_unit:str; partitions:tuple[PartitionCheckpoint,...]; status:str; manifest_sha256:str

class DistributedCheckpointService:
    """Atomic-manifest coordinator for already-consistent partition checkpoints.
    It never labels a partial or mismatched set as a valid distributed checkpoint.
    """
    def __init__(self,db,audit,partitioner):
        self.db=db; self.audit=audit; self.partitioner=partitioner; self._schema()
    def _schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS exa_distributed_checkpoints(
            checkpoint_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,run_id TEXT NOT NULL,plan_id TEXT NOT NULL,
            plan_sha256 TEXT NOT NULL,logical_step INTEGER NOT NULL,simulation_time REAL NOT NULL,time_unit TEXT NOT NULL,
            partitions_json TEXT NOT NULL,status TEXT NOT NULL,manifest_sha256 TEXT NOT NULL)""")
    @staticmethod
    def _sha(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    def create(self,run_id,plan_id,parts):
        run_id=str(run_id).strip()
        if not run_id: raise DistributedCheckpointError("run_id required")
        pv=self.partitioner.verify(plan_id)
        if not pv.get("all_ok",False): raise DistributedCheckpointError("partition plan verification failed")
        plan=self.partitioner.get(plan_id)
        rows=tuple(parts)
        if not rows: raise DistributedCheckpointError("partition checkpoints required")
        ids=[p.partition_id for p in rows]
        if len(ids)!=len(set(ids)): raise DistributedCheckpointError("duplicate partition checkpoint")
        expected_nodes=set(plan.assignments.values())
        supplied_nodes={p.node_id for p in rows}
        if supplied_nodes!=expected_nodes: raise DistributedCheckpointError("checkpoint node coverage does not match partition plan")
        steps={int(p.logical_step) for p in rows}; times={(float(p.simulation_time),str(p.time_unit)) for p in rows}
        if len(steps)!=1 or len(times)!=1: raise DistributedCheckpointError("partition checkpoints are not from one consistent simulation instant")
        for p in rows:
            if not p.partition_id or not p.node_id or not p.checkpoint_ref or len(p.sha256)!=64 or p.byte_count<0:
                raise DistributedCheckpointError("invalid partition checkpoint metadata")
        step=next(iter(steps)); sim_time,time_unit=next(iter(times))
        payload={"run_id":run_id,"plan_id":plan_id,"plan_sha256":plan.definition_sha256,"logical_step":step,
                 "simulation_time":sim_time,"time_unit":time_unit,
                 "partitions":[p.__dict__ for p in sorted(rows,key=lambda x:x.partition_id)]}
        manifest=self._sha(payload); cid="exackpt-"+uuid.uuid4().hex
        with self.db.transaction() as c:
            c.execute("INSERT INTO exa_distributed_checkpoints VALUES(?,?,?,?,?,?,?,?,?,?,?)",
             (cid,time.time(),run_id,plan_id,plan.definition_sha256,step,sim_time,time_unit,
              json.dumps(payload["partitions"],sort_keys=True),"CONSISTENT",manifest))
        self.audit.append("INFO","exa_execution.distributed_checkpoint","created",subject=cid,
         details={"run_id":run_id,"plan_id":plan_id,"logical_step":step,"partitions":len(rows)})
        return self.get(cid)
    def get(self,cid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM exa_distributed_checkpoints WHERE checkpoint_id=?",(cid,)).fetchone()
        if r is None: raise DistributedCheckpointError("unknown distributed checkpoint")
        parts=tuple(PartitionCheckpoint(**p) for p in json.loads(r["partitions_json"]))
        return DistributedCheckpoint(r["checkpoint_id"],r["created_unix"],r["run_id"],r["plan_id"],r["plan_sha256"],
         r["logical_step"],r["simulation_time"],r["time_unit"],parts,r["status"],r["manifest_sha256"])
    def verify(self,cid):
        q=self.get(cid); pv=self.partitioner.verify(q.plan_id); plan=self.partitioner.get(q.plan_id)
        payload={"run_id":q.run_id,"plan_id":q.plan_id,"plan_sha256":q.plan_sha256,"logical_step":q.logical_step,
                 "simulation_time":q.simulation_time,"time_unit":q.time_unit,
                 "partitions":[p.__dict__ for p in sorted(q.partitions,key=lambda x:x.partition_id)]}
        manifest_ok=self._sha(payload)==q.manifest_sha256
        plan_ok=bool(pv.get("all_ok",False)) and plan.definition_sha256==q.plan_sha256
        return {"manifest_ok":manifest_ok,"plan_ok":plan_ok,"status_ok":q.status=="CONSISTENT","all_ok":manifest_ok and plan_ok and q.status=="CONSISTENT"}
    def list(self,limit=250):
        with self.db._connect() as c:ids=[r["checkpoint_id"] for r in c.execute("SELECT checkpoint_id FROM exa_distributed_checkpoints ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get(x) for x in ids)
    def summary(self):
        with self.db._connect() as c:n=c.execute("SELECT COUNT(*) n FROM exa_distributed_checkpoints").fetchone()["n"]
        return {"checkpoints":n,"note":"A distributed checkpoint is accepted only when every participating node reports the same logical step and simulation instant. P072 coordinates metadata; partition payload durability remains owned by the referenced checkpoint/storage layer."}
