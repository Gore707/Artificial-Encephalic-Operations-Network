from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid,math

class NeuriteTracingError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")
KINDS=("AXON","DENDRITE","NEURITE","UNKNOWN")

@dataclass(frozen=True)
class TraceNode:
 node_id:str;xyz:tuple[float,float,float];radius:float|None;kind:str;confidence:float|None;provenance:str

@dataclass(frozen=True)
class TraceEdge:
 edge_id:str;source:str;target:str;confidence:float|None;provenance:str

@dataclass(frozen=True)
class NeuriteTrace:
 trace_id:str;segmentation_id:str;segment_id:str;created_unix:float;method:str;method_version:str
 nodes:tuple[TraceNode,...];edges:tuple[TraceEdge,...];source_segmentation_sha256:str;definition_sha256:str

class NeuriteTracingService:
 """Stores explicit axon/dendrite/neurite traces without universal acyclicity assumptions."""
 def __init__(self,db,audit,segmentations):
  self.db=db;self.audit=audit;self.segmentations=segmentations;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS cognitive_injection_neurite_traces(
   trace_id TEXT PRIMARY KEY,segmentation_id TEXT NOT NULL,segment_id TEXT NOT NULL,created_unix REAL NOT NULL,
   method TEXT NOT NULL,method_version TEXT NOT NULL,nodes_json TEXT NOT NULL,edges_json TEXT NOT NULL,
   source_segmentation_sha256 TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 @staticmethod
 def _confidence(v):
  if v is None:return None
  q=float(v)
  if not math.isfinite(q) or not 0<=q<=1:raise NeuriteTracingError("confidence must be within [0,1]")
  return q
 def create(self,segmentation_id,segment_id,method,method_version,nodes,edges):
  segset=self.segmentations.get(segmentation_id)
  if not self.segmentations.verify(segmentation_id)["all_ok"]:raise NeuriteTracingError("source segmentation failed integrity verification")
  if segment_id not in {s.segment_id for s in segset.segments}:raise NeuriteTracingError("segment id absent from segmentation")
  method=str(method).strip();version=str(method_version).strip()
  if not method or not version:raise NeuriteTracingError("method and version required")
  nn=[];seen=set()
  for raw in nodes:
   x=dict(raw);nid=str(x.get("node_id") or ("node-"+uuid.uuid4().hex))
   if nid in seen:raise NeuriteTracingError("duplicate node id")
   seen.add(nid)
   try:xyz=tuple(float(v) for v in x["xyz"])
   except Exception as exc:raise NeuriteTracingError("node xyz required") from exc
   if len(xyz)!=3 or any(not math.isfinite(v) for v in xyz):raise NeuriteTracingError("node xyz must contain three finite coordinates")
   radius=x.get("radius")
   if radius is not None:
    radius=float(radius)
    if not math.isfinite(radius) or radius<0:raise NeuriteTracingError("radius must be finite and nonnegative")
   kind=str(x.get("kind","UNKNOWN"))
   if kind not in KINDS:raise NeuriteTracingError("invalid neurite kind")
   prov=str(x.get("provenance","DERIVED"))
   if prov not in PROVENANCE:raise NeuriteTracingError("invalid node provenance")
   nn.append(TraceNode(nid,xyz,radius,kind,self._confidence(x.get("confidence")),prov))
  if not nn:raise NeuriteTracingError("at least one trace node required")
  ee=[];eids=set()
  for raw in edges:
   x=dict(raw);eid=str(x.get("edge_id") or ("edge-"+uuid.uuid4().hex));src=str(x.get("source",""));dst=str(x.get("target",""))
   if eid in eids:raise NeuriteTracingError("duplicate edge id")
   eids.add(eid)
   if src not in seen or dst not in seen:raise NeuriteTracingError("edge endpoint absent from trace")
   prov=str(x.get("provenance","DERIVED"))
   if prov not in PROVENANCE:raise NeuriteTracingError("invalid edge provenance")
   ee.append(TraceEdge(eid,src,dst,self._confidence(x.get("confidence")),prov))
  payload={"segmentation_id":segmentation_id,"segment_id":segment_id,"method":method,"method_version":version,
   "source_segmentation_sha256":segset.definition_sha256,
   "nodes":[{"node_id":n.node_id,"xyz":n.xyz,"radius":n.radius,"kind":n.kind,"confidence":n.confidence,"provenance":n.provenance} for n in nn],
   "edges":[{"edge_id":e.edge_id,"source":e.source,"target":e.target,"confidence":e.confidence,"provenance":e.provenance} for e in ee]}
  raw=self._canon(payload);sha=hashlib.sha256(raw.encode()).hexdigest();tid="trace-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_injection_neurite_traces VALUES(?,?,?,?,?,?,?,?,?,?)",
   (tid,segmentation_id,segment_id,now,method,version,json.dumps(payload["nodes"],sort_keys=True),json.dumps(payload["edges"],sort_keys=True),segset.definition_sha256,sha))
  self.audit.append("INFO","cognitive_injection.neurite_trace","created",subject=tid,details={"segmentation_id":segmentation_id,"segment_id":segment_id,"nodes":len(nn),"edges":len(ee),"definition_sha256":sha})
  return self.get(tid)
 def get(self,tid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_injection_neurite_traces WHERE trace_id=?",(tid,)).fetchone()
  if r is None:raise NeuriteTracingError("unknown trace")
  ns=tuple(TraceNode(x["node_id"],tuple(x["xyz"]),x["radius"],x["kind"],x["confidence"],x["provenance"]) for x in json.loads(r["nodes_json"]))
  es=tuple(TraceEdge(x["edge_id"],x["source"],x["target"],x["confidence"],x["provenance"]) for x in json.loads(r["edges_json"]))
  return NeuriteTrace(r["trace_id"],r["segmentation_id"],r["segment_id"],r["created_unix"],r["method"],r["method_version"],ns,es,r["source_segmentation_sha256"],r["definition_sha256"])
 def verify(self,tid):
  q=self.get(tid);s=self.segmentations.get(q.segmentation_id)
  payload={"segmentation_id":q.segmentation_id,"segment_id":q.segment_id,"method":q.method,"method_version":q.method_version,"source_segmentation_sha256":q.source_segmentation_sha256,
   "nodes":[{"node_id":n.node_id,"xyz":n.xyz,"radius":n.radius,"kind":n.kind,"confidence":n.confidence,"provenance":n.provenance} for n in q.nodes],
   "edges":[{"edge_id":e.edge_id,"source":e.source,"target":e.target,"confidence":e.confidence,"provenance":e.provenance} for e in q.edges]}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  source_ok=s.definition_sha256==q.source_segmentation_sha256 and self.segmentations.verify(q.segmentation_id)["all_ok"]
  return {"definition_ok":definition_ok,"source_ok":source_ok,"all_ok":definition_ok and source_ok}
 def summary(self,tid):
  q=self.get(tid);self_edges=sum(e.source==e.target for e in q.edges)
  return {"nodes":len(q.nodes),"edges":len(q.edges),"self_edges":self_edges,
   "note":"Cycles, recurrent paths, self-edges, branch points and terminal nodes are not rejected by universal graph rules; biological/model validation is contextual."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["trace_id"] for r in c.execute("SELECT trace_id FROM cognitive_injection_neurite_traces ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
