from __future__ import annotations

import tkinter as tk
from pathlib import Path
from datetime import datetime

from . import __version__
from .app_api import AeonServices, AppContext, AppDescriptor, AppRegistry
from .apps import SystemDiagnosticsApp, EventLogApp, PreflightApp, WorkspaceManagerApp, AuditDiagnosticsApp, SecurityApp, ProcessMonitorApp, HardwareInventoryApp, AcceleratorInventoryApp, ResourceManagerApp, JobSchedulerApp, VisualizationStudioApp, TelemetryStreamApp, ExperimentManagerApp, CheckpointManagerApp, IntegrityManagerApp, BackupManagerApp, RecoveryManagerApp, NodeProtocolApp, ClusterManagerApp, DistributedJobsApp, GuardianCoreApp, GuardianAnomalyApp, SafetyKernelApp, NeuralSafetyApp, IntegrationDiagnosticsApp, FailureQualificationApp, OSReleaseApp, ApotheosisDataLabApp, DatasetImporterApp, ScientificVisualizationStudioApp, NeuralDatasetExplorerApp, ExperimentLaboratoryApp, StatisticalUncertaintyAnalysisApp, ModelComparisonLaboratoryApp, ProvenanceReproducibilityStudioApp, NeuroimagingIngestionApp, VolumeReconstructionApp, NeuronSegmentationApp, NeuriteTracingApp, SynapseDetectionApp, CellClassificationApp, ConnectomeReconstructionApp, CognitiveInjectionWorkbenchApp, ANISpecificationApp, ANITopologyApp, ANISynapticStateApp, ANIDynamicStateApp, ANIReconstructionMetadataApp, ANIManagerApp, NeuronSimulationApp, SynapseEngineApp, SNNEngineApp, NeuralClockApp, NeuralPartitionApp, GPUExecutionApp, DistributedNeuralApp, NeuralSimulacrumApp, CognitiveAnomalyApp, CognitiveStateComparatorApp, ReconstructionConfidenceApp, CandidateReconstructionApp, CognitiveDivergenceApp, CognitiveGuardianApp, ComputeNodeServerApp, DistributedTransportApp, ExaGraphPartitionerApp, DistributedCheckpointApp, ExaClusterControlApp, ExaExecutionEngineApp, NeuralCacheVirtualDeviceApp, NeuralCacheBlockStoreApp, NeuralCacheRedundantStorageApp, NeuralCacheStateCheckpointApp, NeuralCacheMigrationApp, NeuralCacheApp, FailureCorruptionQualificationApp, ProcessFailureQualificationApp, DistributedFailureQualificationApp, ResourceFailureQualificationApp, NeuralDataFailureQualificationApp, FailureValidationCampaignApp, PerformanceBenchmarkApp, WorkloadOptimizerApp, ClusterPerformanceOptimizerApp, PerformanceOptimizationQualificationApp, PersistentSafetyGateApp, GenesisExecutionGateApp, SecuritySafetyQualificationIIIApp, FullSystemIntegrationRCIApp, FullSystemIntegrationRCIIApp, ApotheosisResearchStackApp
from .telemetry import HostTelemetry
from .windowing import WorkspaceWindowManager
from .workspaces import WorkspaceStore
from .state_db import StateDatabase
from .data_objects import DataObjectStore
from .provenance import ImmutableSourceStore, ProvenanceStore
from .audit import AuditTrail, Diagnostics
from .security import IdentityAccessManager
from .session import SessionManager
from .process_supervisor import ProcessSupervisor
from .hardware import HardwareDiscovery
from .accelerators import AcceleratorDiscovery
from .resources import ResourceManager
from .jobs import JobScheduler
from .visualization import VisualizationStore
from .telemetry_stream import TelemetryRingBuffer
from .experiments import ExperimentManager
from .checkpoint import CheckpointStore
from .integrity import IntegrityService
from .transactional_files import TransactionalFileStore
from .recovery import RecoveryManager
from .node_protocol import NodeRegistry
from .cluster import ClusterManager
from .distributed_jobs import DistributedJobService
from .guardian import GuardianService
from .guardian_anomaly import GuardianAnomalyDetector
from .safety_kernel import SafetyKernel, SafetyGovernor
from .neural_safety import NeuralSafetyPolicies, GenesisValidator
from .apotheosis_data_lab import ApotheosisDataLab
from .dataset_importer import DatasetImporter
from .scientific_visualization_studio import ScientificVisualizationStudio
from .neural_dataset_explorer import NeuralDatasetExplorer
from .experiment_laboratory import ExperimentLaboratory
from .statistical_uncertainty import StatisticalUncertaintyAnalysis
from .model_comparison_laboratory import ModelComparisonLaboratory
from .provenance_reproducibility import ProvenanceReproducibilityStudio
from .neuroimaging_ingestion import NeuroimagingIngestion
from .volume_reconstruction import VolumeReconstructionService
from .neuron_segmentation import NeuronSegmentationService
from .neurite_tracing import NeuriteTracingService
from .synapse_detection import SynapseDetectionService
from .cell_classification import CellClassificationService
from .connectome_reconstruction import ConnectomeReconstructionService
from .cognitive_injection_workbench import CognitiveInjectionWorkbench
from .ani_specification import ANISpecificationService
from .ani_topology import ANITopologyService
from .ani_synaptic_state import ANISynapticStateService
from .ani_dynamic_state import ANIDynamicStateService
from .ani_reconstruction_metadata import ANIReconstructionMetadataService
from .ani_manager import ANIManager
from .neuron_simulation import NeuronSimulationEngine
from .synapse_engine import SynapseEngine
from .snn_engine import SNNEngine
from .neural_clock import NeuralClockService
from .neural_partition import NeuralPartitionService
from .gpu_execution import GPUExecutionEngine
from .distributed_neural import DistributedNeuralExecution
from .neural_simulacrum import NeuralSimulacrum
from .cognitive_anomaly import CognitiveAnomalyDetector
from .cognitive_state_comparator import CognitiveStateComparator
from .reconstruction_confidence import ReconstructionConfidenceService
from .candidate_reconstruction import CandidateReconstructionService
from .cognitive_divergence import CognitiveDivergenceService
from .cognitive_guardian import CognitiveGuardian
from .compute_node_server import ComputeNodeServer
from .distributed_transport import DistributedTransportServer
from .exa_graph_partitioner import ExaNeuralGraphPartitioner
from .exa_distributed_checkpoint import DistributedCheckpointService
from .exa_cluster_control import ExaClusterControl
from .exa_execution_engine import ExaExecutionEngine
from .neural_cache_virtual_device import NeuralCacheVirtualDevice
from .neural_cache_block import NeuralCacheBlockStore
from .neural_cache_redundancy import NeuralCacheRedundantStorage
from .neural_cache_checkpoint import NeuralCacheStateCheckpointService
from .neural_cache_migration import NeuralCacheMigration
from .neural_cache import NeuralCache
from .failure_qualification import FailureCorruptionQualification
from .process_failure_qualification import ProcessFailureQualification
from .distributed_failure_qualification import DistributedFailureQualification
from .resource_failure_qualification import ResourceFailureQualification
from .neural_data_failure_qualification import NeuralDataFailureQualification
from .failure_validation_campaign import FailureValidationCampaign
from .performance_benchmark import PerformanceBenchmark
from .workload_optimizer import WorkloadOptimizer
from .cluster_performance_optimizer import ClusterPerformanceOptimizer
from .performance_optimization_qualification import PerformanceOptimizationQualification
from .persistent_safety_gate import PersistentSafetyGate
from .genesis_execution_gate import GenesisExecutionGate
from .independent_watchdog import IndependentWatchdog
from .execution_admission import ExecutionAdmission
from .integrated_execution_controller import IntegratedExecutionController
from .release_candidate_qualifier import ReleaseCandidateQualifier
from .apotheosis_research_stack import ApotheosisResearchStack

BG = "#070707"
PANEL = "#101010"
RED = "#d21f2b"
RED_DIM = "#74131a"
TEXT = "#e7e7e7"
MUTED = "#999999"
GREEN = "#35c46a"
AMBER = "#e3ad36"


def _bytes(value):
    if value is None:
        return "N/A"
    value = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if value < 1024 or unit == "TiB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return "N/A"


def _metric_color(percent):
    if percent is None:
        return MUTED
    if percent >= 90:
        return RED
    if percent >= 75:
        return AMBER
    return GREEN


class AeonDesktop:
    def __init__(self, root: Path, cfg, logger):
        self.root_path = root
        self.cfg = cfg
        self.logger = logger
        self.telemetry = HostTelemetry(root)
        self.state_db = StateDatabase(cfg.path("paths.state") / "aeon_state.sqlite3")
        ok, detail = self.state_db.integrity_check()
        if not ok:
            raise RuntimeError(f"AEON state database integrity check failed: {detail}")
        self.workspaces = WorkspaceStore(cfg.path("paths.state"), self.state_db)
        self.immutable_sources = ImmutableSourceStore(cfg.path("paths.data") / "immutable_sources")
        self.provenance = ProvenanceStore(self.state_db)
        self.data_objects = DataObjectStore(
            self.state_db, self.workspaces, self.immutable_sources, self.provenance
        )
        self.audit = AuditTrail(self.state_db)
        self.diagnostics = Diagnostics(root, cfg, self.state_db, self.audit)
        self.identity = IdentityAccessManager(self.state_db, self.audit)
        self.session = SessionManager()
        self.processes = ProcessSupervisor(cfg.path("paths.state"), self.audit)
        self.hardware = HardwareDiscovery(root)
        self.accelerators = AcceleratorDiscovery()
        self.resources = ResourceManager(
            self.hardware, self.accelerators, self.state_db, self.audit
        )
        self.jobs = JobScheduler(self.state_db, self.audit, self.resources, self.processes)
        self.visualizations = VisualizationStore(
            self.state_db, self.audit, cfg.path("paths.state")
        )
        self.telemetry_stream = TelemetryRingBuffer(capacity=100_000)
        self.experiments = ExperimentManager(self.state_db, self.audit, self.jobs)
        self.checkpoints = CheckpointStore(
            self.state_db, self.audit, cfg.path("paths.state")
        )
        self.integrity = IntegrityService(self.state_db, self.audit)
        self.transactional_files = TransactionalFileStore(
            self.state_db, self.audit, cfg.path("paths.state")
        )
        self.recovery = RecoveryManager(
            self.state_db, self.audit, self.transactional_files
        )
        self.nodes = NodeRegistry(self.state_db, self.audit)
        self.cluster = ClusterManager(self.state_db, self.audit, self.nodes)
        import hashlib
        cluster_secret = hashlib.sha256((str(root.resolve())+"|AEON-P025-LOCAL-CLUSTER").encode()).digest()
        self.distributed_jobs = DistributedJobService(self.state_db, self.audit, self.nodes, self.jobs, cluster_secret)
        self.guardian = GuardianService(self.state_db, self.audit, self.telemetry_stream)
        self.guardian_anomaly = GuardianAnomalyDetector(self.guardian, self.telemetry_stream, self.audit)
        self.safety_kernel = SafetyKernel(self.state_db, self.audit, self.jobs, self.processes)
        self.safety_governor = SafetyGovernor(self.safety_kernel, self.guardian, self.audit)
        self.neural_safety = NeuralSafetyPolicies(self.state_db, self.audit, self.safety_kernel)
        self.genesis = GenesisValidator(self.state_db, self.audit)
        self.apotheosis_data_lab = ApotheosisDataLab(self.state_db, self.audit, self.immutable_sources)
        self.dataset_importer = DatasetImporter(self.apotheosis_data_lab, self.audit)
        self.visualization_studio = ScientificVisualizationStudio(self.apotheosis_data_lab, self.audit)
        self.neural_dataset_explorer = NeuralDatasetExplorer(self.apotheosis_data_lab, self.audit)
        self.experiment_laboratory = ExperimentLaboratory(self.state_db, self.audit, self.apotheosis_data_lab)
        self.statistical_uncertainty = StatisticalUncertaintyAnalysis(self.apotheosis_data_lab, self.audit)
        self.model_comparison_laboratory = ModelComparisonLaboratory(self.apotheosis_data_lab, self.audit)
        self.provenance_reproducibility = ProvenanceReproducibilityStudio(self.state_db, self.audit, self.apotheosis_data_lab, self.experiment_laboratory)
        self.neuroimaging_ingestion = NeuroimagingIngestion(self.state_db, self.audit, self.apotheosis_data_lab)
        self.volume_reconstruction = VolumeReconstructionService(self.state_db, self.audit, self.apotheosis_data_lab, self.neuroimaging_ingestion)
        self.neuron_segmentation = NeuronSegmentationService(self.state_db, self.audit, self.volume_reconstruction)
        self.neurite_tracing = NeuriteTracingService(self.state_db, self.audit, self.neuron_segmentation)
        self.synapse_detection = SynapseDetectionService(self.state_db, self.audit, self.neurite_tracing)
        self.cell_classification = CellClassificationService(self.state_db, self.audit, self.neuron_segmentation)
        self.connectome_reconstruction = ConnectomeReconstructionService(self.state_db, self.audit, self.neuron_segmentation, self.synapse_detection, self.cell_classification)
        self.cognitive_injection_workbench = CognitiveInjectionWorkbench(self.state_db, self.audit, self.neuroimaging_ingestion, self.volume_reconstruction, self.neuron_segmentation, self.neurite_tracing, self.synapse_detection, self.cell_classification, self.connectome_reconstruction)
        self.ani_specification = ANISpecificationService(self.state_db, self.audit, self.connectome_reconstruction)
        self.ani_topology = ANITopologyService(self.state_db, self.audit, self.ani_specification, self.connectome_reconstruction)
        self.ani_synaptic_state = ANISynapticStateService(self.state_db, self.audit, self.ani_topology)
        self.ani_dynamic_state = ANIDynamicStateService(self.state_db, self.audit, self.ani_topology, self.ani_synaptic_state)
        self.ani_reconstruction_metadata = ANIReconstructionMetadataService(self.state_db, self.audit, self.ani_specification, self.ani_topology, self.ani_synaptic_state, self.ani_dynamic_state)
        self.ani_manager = ANIManager(self.state_db, self.audit, self.ani_specification, self.ani_topology, self.ani_synaptic_state, self.ani_dynamic_state, self.ani_reconstruction_metadata)
        self.neuron_simulation = NeuronSimulationEngine(self.state_db, self.audit)
        self.synapse_engine = SynapseEngine(self.state_db, self.audit)
        self.snn_engine = SNNEngine(self.state_db, self.audit, self.neuron_simulation, self.synapse_engine)
        self.neural_clock = NeuralClockService(self.state_db, self.audit)
        self.neural_partition = NeuralPartitionService(self.state_db, self.audit, self.snn_engine)
        self.gpu_execution = GPUExecutionEngine(self.state_db, self.audit)
        self.distributed_neural = DistributedNeuralExecution(self.state_db, self.audit, self.neural_partition, self.neural_clock, self.snn_engine)
        self.neural_simulacrum = NeuralSimulacrum(self.state_db, self.audit, self.snn_engine, self.neural_clock, self.neural_partition, self.gpu_execution, self.distributed_neural)
        self.cognitive_anomaly = CognitiveAnomalyDetector(self.state_db, self.audit)
        self.cognitive_state_comparator = CognitiveStateComparator(self.state_db, self.audit)
        self.reconstruction_confidence = ReconstructionConfidenceService(self.state_db, self.audit, self.ani_reconstruction_metadata)
        self.candidate_reconstruction = CandidateReconstructionService(self.state_db, self.audit, self.ani_reconstruction_metadata)
        self.cognitive_divergence = CognitiveDivergenceService(self.state_db, self.audit, self.cognitive_state_comparator)
        self.cognitive_guardian = CognitiveGuardian(self.state_db, self.audit, self.cognitive_anomaly, self.cognitive_state_comparator, self.reconstruction_confidence, self.candidate_reconstruction, self.cognitive_divergence)
        _node_secret = __import__("hashlib").sha256((str(self.root_path.resolve()) + "|AEON-P069-LOCAL").encode()).digest()
        self.compute_node_server = ComputeNodeServer("local-aeon-node", _node_secret, status_provider=lambda: {"version": "1.38.0"})
        self.distributed_transport = DistributedTransportServer("local-aeon-node", _node_secret, lambda transfer_id, payload, metadata: None)
        self.exa_graph_partitioner = ExaNeuralGraphPartitioner(self.state_db, self.audit, self.neural_partition)
        self.exa_distributed_checkpoint = DistributedCheckpointService(self.state_db, self.audit, self.exa_graph_partitioner)
        self.exa_cluster_control = ExaClusterControl(self.state_db, self.audit)
        self.exa_execution_engine = ExaExecutionEngine(self.state_db, self.audit, self.compute_node_server, self.distributed_transport, self.exa_graph_partitioner, self.exa_distributed_checkpoint, self.exa_cluster_control)
        self.neural_cache_virtual_device = NeuralCacheVirtualDevice(self.state_db, self.audit, self.cfg.path("paths.state") / "neural_cache")
        self.neural_cache_block_store = NeuralCacheBlockStore(self.state_db, self.audit, self.neural_cache_virtual_device)
        self.neural_cache_redundancy = NeuralCacheRedundantStorage(self.state_db, self.audit, self.neural_cache_virtual_device, self.neural_cache_block_store)
        self.neural_cache_state_checkpoint = NeuralCacheStateCheckpointService(self.state_db, self.audit, self.neural_cache_block_store)
        self.neural_cache_migration = NeuralCacheMigration(self.state_db, self.audit, self.neural_cache_virtual_device, self.neural_cache_block_store)
        self.neural_cache = NeuralCache(self.state_db, self.audit, self.neural_cache_virtual_device, self.neural_cache_block_store, self.neural_cache_redundancy, self.neural_cache_state_checkpoint, self.neural_cache_migration)
        self.failure_corruption_qualification = FailureCorruptionQualification(self.state_db, self.audit, self.neural_cache_block_store, self.neural_cache_redundancy)
        self.process_failure_qualification = ProcessFailureQualification(self.state_db, self.audit)
        self.distributed_failure_qualification = DistributedFailureQualification(self.state_db, self.audit)
        self.resource_failure_qualification = ResourceFailureQualification(self.state_db, self.audit)
        self.neural_data_failure_qualification = NeuralDataFailureQualification(self.state_db, self.audit)
        self.failure_validation_campaign = FailureValidationCampaign(self.state_db, self.audit, self.failure_corruption_qualification, self.process_failure_qualification, self.distributed_failure_qualification, self.resource_failure_qualification, self.neural_data_failure_qualification)
        self.performance_benchmark = PerformanceBenchmark(self.state_db, self.audit)
        self.workload_optimizer = WorkloadOptimizer(self.state_db, self.audit)
        self.cluster_performance_optimizer = ClusterPerformanceOptimizer(self.state_db, self.audit)
        self.performance_optimization_qualification = PerformanceOptimizationQualification(self.state_db, self.audit, self.performance_benchmark, self.workload_optimizer, self.cluster_performance_optimizer)
        self.persistent_safety_gate = PersistentSafetyGate(self.state_db, self.audit)
        self.genesis_execution_gate = GenesisExecutionGate(self.state_db, self.audit, self.persistent_safety_gate)
        self.independent_watchdog = IndependentWatchdog(self.state_db, self.audit, self.persistent_safety_gate)
        self.execution_admission = ExecutionAdmission(self.state_db, self.audit, self.persistent_safety_gate, self.genesis_execution_gate, self.independent_watchdog)
        self.integrated_execution_controller = IntegratedExecutionController(self.state_db, self.audit, self.execution_admission, self.persistent_safety_gate)
        self.release_candidate_qualifier = ReleaseCandidateQualifier(self.state_db, self.audit, self.persistent_safety_gate, self.genesis_execution_gate, self.independent_watchdog, self.execution_admission, self.integrated_execution_controller)
        self.apotheosis_research_stack = ApotheosisResearchStack(self.state_db, self.audit, self.release_candidate_qualifier, self.persistent_safety_gate, self.genesis_execution_gate, self.independent_watchdog, self.integrated_execution_controller)
        self.services = AeonServices(
            root=root,
            config=cfg,
            logger=logger,
            telemetry=self.telemetry,
            workspaces=self.workspaces,
            state_db=self.state_db,
            data_objects=self.data_objects,
            provenance=self.provenance,
            immutable_sources=self.immutable_sources,
            audit=self.audit,
            diagnostics=self.diagnostics,
            identity=self.identity,
            session=self.session,
            processes=self.processes,
            hardware=self.hardware,
            accelerators=self.accelerators,
            resources=self.resources,
            jobs=self.jobs,
            visualizations=self.visualizations,
            telemetry_stream=self.telemetry_stream,
            experiments=self.experiments,
            checkpoints=self.checkpoints,
            integrity=self.integrity,
            transactional_files=self.transactional_files,
            recovery=self.recovery,
            nodes=self.nodes,
            cluster=self.cluster,
            distributed_jobs=self.distributed_jobs,
            guardian=self.guardian,
            guardian_anomaly=self.guardian_anomaly,
            safety_kernel=self.safety_kernel,
            safety_governor=self.safety_governor,
            neural_safety=self.neural_safety,
            genesis=self.genesis,
            apotheosis_data_lab=self.apotheosis_data_lab,
            dataset_importer=self.dataset_importer,
            visualization_studio=self.visualization_studio,
            neural_dataset_explorer=self.neural_dataset_explorer,
            experiment_laboratory=self.experiment_laboratory,
            statistical_uncertainty=self.statistical_uncertainty,
            model_comparison_laboratory=self.model_comparison_laboratory,
            provenance_reproducibility=self.provenance_reproducibility,
            neuroimaging_ingestion=self.neuroimaging_ingestion,
            volume_reconstruction=self.volume_reconstruction,
            neuron_segmentation=self.neuron_segmentation,
            neurite_tracing=self.neurite_tracing,
            synapse_detection=self.synapse_detection,
            cell_classification=self.cell_classification,
            connectome_reconstruction=self.connectome_reconstruction,
            cognitive_injection_workbench=self.cognitive_injection_workbench,
            ani_specification=self.ani_specification,
            ani_topology=self.ani_topology,
            ani_synaptic_state=self.ani_synaptic_state,
            ani_dynamic_state=self.ani_dynamic_state,
            ani_reconstruction_metadata=self.ani_reconstruction_metadata,
            ani_manager=self.ani_manager,
            neuron_simulation=self.neuron_simulation,
            synapse_engine=self.synapse_engine,
            snn_engine=self.snn_engine,
            neural_clock=self.neural_clock,
            neural_partition=self.neural_partition,
            gpu_execution=self.gpu_execution,
            distributed_neural=self.distributed_neural,
            neural_simulacrum=self.neural_simulacrum,
            cognitive_anomaly=self.cognitive_anomaly,
            cognitive_state_comparator=self.cognitive_state_comparator,
            reconstruction_confidence=self.reconstruction_confidence,
            candidate_reconstruction=self.candidate_reconstruction,
            cognitive_divergence=self.cognitive_divergence,
            cognitive_guardian=self.cognitive_guardian,
            compute_node_server=self.compute_node_server,
            distributed_transport=self.distributed_transport,
            exa_graph_partitioner=self.exa_graph_partitioner,
            exa_distributed_checkpoint=self.exa_distributed_checkpoint,
            exa_cluster_control=self.exa_cluster_control,
            exa_execution_engine=self.exa_execution_engine,
            neural_cache_virtual_device=self.neural_cache_virtual_device,
            neural_cache_block_store=self.neural_cache_block_store,
            neural_cache_redundancy=self.neural_cache_redundancy,
            neural_cache_state_checkpoint=self.neural_cache_state_checkpoint,
            neural_cache_migration=self.neural_cache_migration,
            neural_cache=self.neural_cache,
            failure_corruption_qualification=self.failure_corruption_qualification,
            process_failure_qualification=self.process_failure_qualification,
            distributed_failure_qualification=self.distributed_failure_qualification,
            resource_failure_qualification=self.resource_failure_qualification,
            neural_data_failure_qualification=self.neural_data_failure_qualification,
            failure_validation_campaign=self.failure_validation_campaign,
            performance_benchmark=self.performance_benchmark,
            workload_optimizer=self.workload_optimizer,
            cluster_performance_optimizer=self.cluster_performance_optimizer,
            performance_optimization_qualification=self.performance_optimization_qualification,
            persistent_safety_gate=self.persistent_safety_gate,
            genesis_execution_gate=self.genesis_execution_gate,
            independent_watchdog=self.independent_watchdog,
            execution_admission=self.execution_admission,
            integrated_execution_controller=self.integrated_execution_controller,
            release_candidate_qualifier=self.release_candidate_qualifier,
            apotheosis_research_stack=self.apotheosis_research_stack
        )
        self.audit.append("INFO", "runtime", "desktop_initializing",
                          actor="AEON", details={"version": __version__})

        self.root = tk.Tk()
        self.root.title(f"AEON {__version__} — {cfg.get('aeon.project')}")
        self.root.geometry(str(cfg.get("ui.geometry", "1280x800")))
        self.root.minsize(960, 600)
        self.root.configure(bg=BG)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.registry = AppRegistry()
        self._register_builtin_apps()
        self._build_topbar()
        self._build_workspace()
        self._build_bottombar()

        self.windows = WorkspaceWindowManager(
            self.window_host, context_factory=self._context,
            panel=PANEL, accent=RED_DIM, text=TEXT, logger=logger
        )
        self.open_app("system")
        self._tick()
        self.logger.info(
            "AEON desktop initialized | version=%s | state_schema=%s",
            __version__, self.state_db.schema_version()
        )

    def _context(self):
        return AppContext(services=self.services, open_app=self.open_app)

    def _register_builtin_apps(self):
        for cls in (SystemDiagnosticsApp, WorkspaceManagerApp, PreflightApp, EventLogApp, AuditDiagnosticsApp, SecurityApp, ProcessMonitorApp, HardwareInventoryApp, AcceleratorInventoryApp, ResourceManagerApp, JobSchedulerApp, VisualizationStudioApp, TelemetryStreamApp, ExperimentManagerApp, CheckpointManagerApp, IntegrityManagerApp, BackupManagerApp, RecoveryManagerApp, NodeProtocolApp, ClusterManagerApp, DistributedJobsApp, GuardianCoreApp, GuardianAnomalyApp, SafetyKernelApp, NeuralSafetyApp, IntegrationDiagnosticsApp, FailureQualificationApp, OSReleaseApp, ApotheosisDataLabApp, DatasetImporterApp, ScientificVisualizationStudioApp, NeuralDatasetExplorerApp, ExperimentLaboratoryApp, StatisticalUncertaintyAnalysisApp, ModelComparisonLaboratoryApp, ProvenanceReproducibilityStudioApp, NeuroimagingIngestionApp, VolumeReconstructionApp, NeuronSegmentationApp, NeuriteTracingApp, SynapseDetectionApp, CellClassificationApp, ConnectomeReconstructionApp, CognitiveInjectionWorkbenchApp, ANISpecificationApp, ANITopologyApp, ANISynapticStateApp, ANIDynamicStateApp, ANIReconstructionMetadataApp, ANIManagerApp, NeuronSimulationApp, SynapseEngineApp, SNNEngineApp, NeuralClockApp, NeuralPartitionApp, GPUExecutionApp, DistributedNeuralApp, NeuralSimulacrumApp, CognitiveAnomalyApp, CognitiveStateComparatorApp, ReconstructionConfidenceApp, CandidateReconstructionApp, CognitiveDivergenceApp, CognitiveGuardianApp, ComputeNodeServerApp, DistributedTransportApp, ExaGraphPartitionerApp, DistributedCheckpointApp, ExaClusterControlApp, ExaExecutionEngineApp, NeuralCacheVirtualDeviceApp, NeuralCacheBlockStoreApp, NeuralCacheRedundantStorageApp, NeuralCacheStateCheckpointApp, NeuralCacheMigrationApp, NeuralCacheApp, FailureCorruptionQualificationApp, ProcessFailureQualificationApp, DistributedFailureQualificationApp, ResourceFailureQualificationApp, NeuralDataFailureQualificationApp, FailureValidationCampaignApp, PerformanceBenchmarkApp, WorkloadOptimizerApp, ClusterPerformanceOptimizerApp, PerformanceOptimizationQualificationApp, PersistentSafetyGateApp, GenesisExecutionGateApp, SecuritySafetyQualificationIIIApp, FullSystemIntegrationRCIApp, FullSystemIntegrationRCIIApp, ApotheosisResearchStackApp):
            self.registry.register(
                AppDescriptor(cls.app_id, cls.title, cls.version, lambda ctx, c=cls: c(ctx))
            )

    def _button(self, parent, text, command):
        return tk.Button(parent, text=text, command=command, bg=PANEL, fg=RED,
                         activebackground=RED_DIM, activeforeground=TEXT,
                         relief="flat", bd=0, padx=12, pady=7,
                         font=("Segoe UI", 9, "bold"), cursor="hand2")

    def _build_topbar(self):
        bar = tk.Frame(self.root, bg=PANEL, height=48,
                       highlightbackground=RED_DIM, highlightthickness=1)
        bar.pack(side="top", fill="x")
        tk.Label(bar, text="AEON", bg=PANEL, fg=RED,
                 font=("Segoe UI", 15, "bold")).pack(side="left", padx=(14, 18), pady=8)
        tk.Label(bar, text=self.cfg.get("aeon.project"), bg=PANEL, fg=MUTED,
                 font=("Consolas", 9)).pack(side="left")
        self._button(bar, "SYSTEM", lambda: self.open_app("system")).pack(side="right", padx=2)
        self._button(bar, "HARDWARE", lambda: self.open_app("hardware")).pack(side="right", padx=2)
        self._button(bar, "GPU", lambda: self.open_app("accelerators")).pack(side="right", padx=2)
        self._button(bar, "RESOURCES", lambda: self.open_app("resources")).pack(side="right", padx=2)
        self._button(bar, "JOBS", lambda: self.open_app("jobs")).pack(side="right", padx=2)
        self._button(bar, "PLOTS", lambda: self.open_app("visualizations")).pack(side="right", padx=2)
        self._button(bar, "STREAM", lambda: self.open_app("telemetry_stream")).pack(side="right", padx=2)
        self._button(bar, "EXPERIMENTS", lambda: self.open_app("experiments")).pack(side="right", padx=2)
        self._button(bar, "CHECKPOINTS", lambda: self.open_app("checkpoints")).pack(side="right", padx=2)
        self._button(bar, "INTEGRITY", lambda: self.open_app("integrity")).pack(side="right", padx=2)
        self._button(bar, "BACKUPS", lambda: self.open_app("backups")).pack(side="right", padx=2)
        self._button(bar, "RECOVERY", lambda: self.open_app("recovery")).pack(side="right", padx=2)
        self._button(bar, "NODES", lambda: self.open_app("nodes")).pack(side="right", padx=2)
        self._button(bar, "CLUSTER", lambda: self.open_app("cluster")).pack(side="right", padx=2)
        self._button(bar, "DIST JOBS", lambda: self.open_app("distributed_jobs")).pack(side="right", padx=2)
        self._button(bar, "GUARDIAN", lambda: self.open_app("guardian")).pack(side="right", padx=2)
        self._button(bar, "ANOMALY", lambda: self.open_app("guardian_anomaly")).pack(side="right", padx=2)
        self._button(bar, "SAFETY", lambda: self.open_app("safety")).pack(side="right", padx=2)
        self._button(bar, "NEURAL SAFE", lambda: self.open_app("neural_safety")).pack(side="right", padx=2)
        self._button(bar, "INTEGRATION", lambda: self.open_app("integration")).pack(side="right", padx=2)
        self._button(bar, "QUALIFY", lambda: self.open_app("qualification")).pack(side="right", padx=2)
        self._button(bar, "OS 1.0", lambda: self.open_app("os_release")).pack(side="right", padx=2)
        self._button(bar, "DATA LAB", lambda: self.open_app("apotheosis_data_lab")).pack(side="right", padx=2)
        self._button(bar, "IMPORT", lambda: self.open_app("dataset_importer")).pack(side="right", padx=2)
        self._button(bar, "VIZ STUDIO", lambda: self.open_app("scientific_visualization_studio")).pack(side="right", padx=2)
        self._button(bar, "NEURAL DATA", lambda: self.open_app("neural_dataset_explorer")).pack(side="right", padx=2)
        self._button(bar, "EXPERIMENT LAB", lambda: self.open_app("experiment_laboratory")).pack(side="right", padx=2)
        self._button(bar, "UNCERTAINTY", lambda: self.open_app("statistical_uncertainty")).pack(side="right", padx=2)
        self._button(bar, "MODEL COMP", lambda: self.open_app("model_comparison_laboratory")).pack(side="right", padx=2)
        self._button(bar, "REPRO", lambda: self.open_app("provenance_reproducibility")).pack(side="right", padx=2)
        self._button(bar, "NEURO IMG", lambda: self.open_app("neuroimaging_ingestion")).pack(side="right", padx=2)
        self._button(bar, "VOLUME", lambda: self.open_app("volume_reconstruction")).pack(side="right", padx=2)
        self._button(bar, "SEGMENT", lambda: self.open_app("neuron_segmentation")).pack(side="right", padx=2)
        self._button(bar, "TRACE", lambda: self.open_app("neurite_tracing")).pack(side="right", padx=2)
        self._button(bar, "SYNAPSE", lambda: self.open_app("synapse_detection")).pack(side="right", padx=2)
        self._button(bar, "CELL TYPE", lambda: self.open_app("cell_classification")).pack(side="right", padx=2)
        self._button(bar, "CONNECTOME", lambda: self.open_app("connectome_reconstruction")).pack(side="right", padx=2)
        self._button(bar, "COG INJECT", lambda: self.open_app("cognitive_injection_workbench")).pack(side="right", padx=2)
        self._button(bar, "ANI SPEC", lambda: self.open_app("ani_specification")).pack(side="right", padx=2)
        self._button(bar, "ANI TOPO", lambda: self.open_app("ani_topology")).pack(side="right", padx=2)
        self._button(bar, "ANI SYN", lambda: self.open_app("ani_synaptic_state")).pack(side="right", padx=2)
        self._button(bar, "ANI DYN", lambda: self.open_app("ani_dynamic_state")).pack(side="right", padx=2)
        self._button(bar, "ANI UNC", lambda: self.open_app("ani_reconstruction_metadata")).pack(side="right", padx=2)
        self._button(bar, "ANI", lambda: self.open_app("ani_manager")).pack(side="right", padx=2)
        self._button(bar, "NEURON", lambda: self.open_app("neuron_simulation")).pack(side="right", padx=2)
        self._button(bar, "SYN ENG", lambda: self.open_app("synapse_engine")).pack(side="right", padx=2)
        self._button(bar, "SNN", lambda: self.open_app("snn_engine")).pack(side="right", padx=2)
        self._button(bar, "CLOCK", lambda: self.open_app("neural_clock")).pack(side="right", padx=2)
        self._button(bar, "PART", lambda: self.open_app("neural_partition")).pack(side="right", padx=2)
        self._button(bar, "GPU", lambda: self.open_app("gpu_execution")).pack(side="right", padx=2)
        self._button(bar, "DIST", lambda: self.open_app("distributed_neural")).pack(side="right", padx=2)
        self._button(bar, "SIM 1.0", lambda: self.open_app("neural_simulacrum")).pack(side="right", padx=2)
        self._button(bar, "COG ANOM", lambda: self.open_app("cognitive_anomaly")).pack(side="right", padx=2)
        self._button(bar, "STATE CMP", lambda: self.open_app("cognitive_state_comparator")).pack(side="right", padx=2)
        self._button(bar, "RECON CONF", lambda: self.open_app("reconstruction_confidence")).pack(side="right", padx=2)
        self._button(bar, "CANDIDATE", lambda: self.open_app("candidate_reconstruction")).pack(side="right", padx=2)
        self._button(bar, "DIVERGE", lambda: self.open_app("cognitive_divergence")).pack(side="right", padx=2)
        self._button(bar, "COG 1.0", lambda: self.open_app("cognitive_guardian")).pack(side="right", padx=2)
        self._button(bar, "NODE SRV", lambda: self.open_app("compute_node_server")).pack(side="right", padx=2)
        self._button(bar, "XPORT", lambda: self.open_app("distributed_transport")).pack(side="right", padx=2)
        self._button(bar, "EXA PART", lambda: self.open_app("exa_graph_partitioner")).pack(side="right", padx=2)
        self._button(bar, "EXA CKPT", lambda: self.open_app("exa_distributed_checkpoint")).pack(side="right", padx=2)
        self._button(bar, "EXA CLUSTER", lambda: self.open_app("exa_cluster_control")).pack(side="right", padx=2)
        self._button(bar, "EXA 1.0", lambda: self.open_app("exa_execution_engine")).pack(side="right", padx=2)
        self._button(bar, "NCACHE", lambda: self.open_app("neural_cache_virtual_device")).pack(side="right", padx=2)
        self._button(bar, "NC BLOCK", lambda: self.open_app("neural_cache_block_store")).pack(side="right", padx=2)
        self._button(bar, "NC REDUND", lambda: self.open_app("neural_cache_redundancy")).pack(side="right", padx=2)
        self._button(bar, "NC CKPT", lambda: self.open_app("neural_cache_state_checkpoint")).pack(side="right", padx=2)
        self._button(bar, "NC MOVE", lambda: self.open_app("neural_cache_migration")).pack(side="right", padx=2)
        self._button(bar, "NC 1.0", lambda: self.open_app("neural_cache")).pack(side="right", padx=2)
        self._button(bar, "FAIL I", lambda: self.open_app("failure_corruption_qualification")).pack(side="right", padx=2)
        self._button(bar, "FAIL II", lambda: self.open_app("process_failure_qualification")).pack(side="right", padx=2)
        self._button(bar, "FAIL III", lambda: self.open_app("distributed_failure_qualification")).pack(side="right", padx=2)
        self._button(bar, "FAIL IV", lambda: self.open_app("resource_failure_qualification")).pack(side="right", padx=2)
        self._button(bar, "FAIL V", lambda: self.open_app("neural_data_failure_qualification")).pack(side="right", padx=2)
        self._button(bar, "FAIL VI", lambda: self.open_app("failure_validation_campaign")).pack(side="right", padx=2)
        self._button(bar, "PERF I", lambda: self.open_app("performance_benchmark")).pack(side="right", padx=2)
        self._button(bar, "PERF II", lambda: self.open_app("workload_optimizer")).pack(side="right", padx=2)
        self._button(bar, "PERF III", lambda: self.open_app("cluster_performance_optimizer")).pack(side="right", padx=2)
        self._button(bar, "PERF IV", lambda: self.open_app("performance_optimization_qualification")).pack(side="right", padx=2)
        self._button(bar, "SAFE I", lambda: self.open_app("persistent_safety_gate")).pack(side="right", padx=2)
        self._button(bar, "SAFE II", lambda: self.open_app("genesis_execution_gate")).pack(side="right", padx=2)
        self._button(bar, "SAFE III", lambda: self.open_app("security_safety_qualification_iii")).pack(side="right", padx=2)
        self._button(bar, "RC I", lambda: self.open_app("full_system_integration_rc_i")).pack(side="right", padx=2)
        self._button(bar, "RC II", lambda: self.open_app("full_system_integration_rc_ii")).pack(side="right", padx=2)
        self._button(bar, "APOTHEOSIS 1.0", lambda: self.open_app("apotheosis_research_stack")).pack(side="right", padx=2)
        self._button(bar, "PROCESSES", lambda: self.open_app("processes")).pack(side="right", padx=2)
        self._button(bar, "SECURITY", lambda: self.open_app("security")).pack(side="right", padx=2)
        self._button(bar, "AUDIT", lambda: self.open_app("audit")).pack(side="right", padx=2)
        self._button(bar, "WORKSPACES", lambda: self.open_app("workspaces")).pack(side="right", padx=2)
        self._button(bar, "PREFLIGHT", lambda: self.open_app("preflight")).pack(side="right", padx=2)
        self._button(bar, "LOG", lambda: self.open_app("event_log")).pack(side="right", padx=2)

    def _build_workspace(self):
        self.workspace = tk.Frame(self.root, bg=BG)
        self.workspace.pack(fill="both", expand=True, padx=18, pady=18)
        header = tk.Frame(self.workspace, bg=BG)
        header.pack(fill="x")
        tk.Label(header, text="AEON WORKSPACE", bg=BG, fg=TEXT,
                 font=("Segoe UI", 20, "bold")).pack(side="left")
        self.active_label = tk.Label(header, text="", bg=BG, fg=MUTED, font=("Consolas", 9))
        self.active_label.pack(side="right", pady=8)
        self.workspace_label = tk.Label(header, text="", bg=BG, fg=RED, font=("Consolas", 9, "bold"))
        self.workspace_label.pack(side="right", padx=18, pady=8)
        self.window_host = tk.Frame(self.workspace, bg=BG)
        self.window_host.pack(fill="both", expand=True, pady=(14, 0))

    def _build_bottombar(self):
        bar = tk.Frame(self.root, bg=PANEL, height=34,
                       highlightbackground=RED_DIM, highlightthickness=1)
        bar.pack(side="bottom", fill="x")
        self.cpu_label = tk.Label(bar, bg=PANEL, fg=MUTED, font=("Consolas", 9))
        self.cpu_label.pack(side="left", padx=12, pady=7)
        self.ram_label = tk.Label(bar, bg=PANEL, fg=MUTED, font=("Consolas", 9))
        self.ram_label.pack(side="left", padx=12)
        self.disk_label = tk.Label(bar, bg=PANEL, fg=MUTED, font=("Consolas", 9))
        self.disk_label.pack(side="left", padx=12)
        self.window_label = tk.Label(bar, bg=PANEL, fg=MUTED, font=("Consolas", 9))
        self.window_label.pack(side="left", padx=12)
        self.clock_label = tk.Label(bar, bg=PANEL, fg=MUTED, font=("Consolas", 9))
        self.clock_label.pack(side="right", padx=12)

    def open_app(self, app_id):
        descriptor = self.registry.get(app_id)
        self.windows.open(descriptor)
        self.active_label.config(text=f"ACTIVE: {descriptor.title.upper()}")
        self.window_label.config(text=f"APPS {len(self.windows.open_ids())}")

    def _tick(self):
        snap = self.telemetry.snapshot()
        cpu = snap.cpu_percent
        self.cpu_label.config(text=f"CPU {'N/A' if cpu is None else f'{cpu:.1f}%'}",
                              fg=_metric_color(cpu))
        if snap.ram_total_bytes:
            ram_pct = 100 * snap.ram_used_bytes / snap.ram_total_bytes
            self.ram_label.config(text=f"RAM {ram_pct:.1f}% {_bytes(snap.ram_used_bytes)}",
                                  fg=_metric_color(ram_pct))
        else:
            self.ram_label.config(text="RAM N/A", fg=MUTED)
        disk_pct = 100 * snap.disk_used_bytes / snap.disk_total_bytes
        self.disk_label.config(text=f"DISK {disk_pct:.1f}%", fg=_metric_color(disk_pct))
        self.window_label.config(text=f"APPS {len(self.windows.open_ids())}")
        active_app = self.windows.active_app_id
        self.active_label.config(
            text=f"ACTIVE: {self.registry.get(active_app).title.upper()}" if active_app else "ACTIVE: NONE"
        )
        active_ws = self.workspaces.active()
        self.workspace_label.config(
            text=f"WORKSPACE: {active_ws.name.upper()}" if active_ws else "WORKSPACE: NONE"
        )
        self.clock_label.config(text=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self.root.after(int(self.cfg.get("ui.telemetry_interval_ms", 1000)), self._tick)

    def close(self):
        self.cluster.stop()
        self.jobs.shutdown()
        self.processes.shutdown()
        self.audit.append("INFO", "runtime", "desktop_shutdown", actor="AEON")
        self.logger.info("AEON desktop shutdown requested")
        self.windows.close_all()
        self.root.destroy()

    def run(self):
        self.root.mainloop()
