from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,os,shutil,time,uuid

class CheckpointError(RuntimeError):pass

@dataclass(frozen=True)
class Checkpoint:
    checkpoint_id:str;owner_type:str;owner_id:str;state_label:str
    created_unix:float;payload_path:str;sha256:str;size_bytes:int
    consistency:str;metadata:dict

class CheckpointStore:
    """Atomic immutable checkpoint payload store.

    P019 can guarantee byte-consistent snapshots only for state presented to it
    as a closed bytes object or stable source file. Live simulation backends
    must later provide their own quiesce/COW/double-buffer consistency barrier.
    """
    CONSISTENCY={"BYTE_ATOMIC","BACKEND_CONSISTENT"}

    def __init__(self,db,audit,state_dir:Path):
        self.db=db;self.audit=audit
        self.root=Path(state_dir)/"checkpoints";self.root.mkdir(parents=True,exist_ok=True)
        self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS checkpoints(
             checkpoint_id TEXT PRIMARY KEY,owner_type TEXT NOT NULL,owner_id TEXT NOT NULL,
             state_label TEXT NOT NULL,created_unix REAL NOT NULL,payload_path TEXT NOT NULL,
             sha256 TEXT NOT NULL,size_bytes INTEGER NOT NULL,consistency TEXT NOT NULL,
             metadata_json TEXT NOT NULL)""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_checkpoint_owner ON checkpoints(owner_type,owner_id,created_unix)")

    def create_bytes(self,owner_type,owner_id,state_label,payload:bytes,metadata=None,consistency="BYTE_ATOMIC"):
        if not isinstance(payload,(bytes,bytearray,memoryview)):raise CheckpointError("payload must be bytes-like")
        return self._commit(owner_type,owner_id,state_label,bytes(payload),metadata,consistency)

    def create_file(self,owner_type,owner_id,state_label,source:Path,metadata=None,consistency="BYTE_ATOMIC"):
        source=Path(source)
        if not source.is_file():raise CheckpointError(f"checkpoint source is not a file: {source}")
        # Read a stable closed-file image. A changing live file cannot be
        # promoted to BACKEND_CONSISTENT without an explicit backend barrier.
        before=source.stat()
        data=source.read_bytes()
        after=source.stat()
        if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
            raise CheckpointError("source changed while checkpoint was being captured")
        return self._commit(owner_type,owner_id,state_label,data,metadata,consistency)

    def _commit(self,owner_type,owner_id,state_label,data,metadata,consistency):
        owner_type=owner_type.strip();owner_id=owner_id.strip();state_label=state_label.strip()
        if not owner_type or not owner_id or not state_label:raise CheckpointError("owner type/id and state label are required")
        if consistency not in self.CONSISTENCY:raise CheckpointError("unsupported consistency class")
        metadata=dict(metadata or {})
        digest=hashlib.sha256(data).hexdigest();cid="chk-"+uuid.uuid4().hex
        folder=self.root/digest[:2]/digest[2:4];folder.mkdir(parents=True,exist_ok=True)
        final=folder/f"{cid}.bin";tmp=folder/f".{cid}.{os.getpid()}.tmp"
        with tmp.open("wb") as h:
            h.write(data);h.flush();os.fsync(h.fileno())
        os.replace(tmp,final)
        try:final.chmod(0o444)
        except OSError:pass
        now=time.time()
        with self.db.transaction() as c:
            c.execute("INSERT INTO checkpoints VALUES(?,?,?,?,?,?,?,?,?,?)",
              (cid,owner_type,owner_id,state_label,now,str(final),digest,len(data),consistency,
               json.dumps(metadata,sort_keys=True,separators=(",",":"))))
        self.audit.append("INFO","checkpoint","created",subject=cid,
          details={"owner_type":owner_type,"owner_id":owner_id,"sha256":digest,
                   "size_bytes":len(data),"consistency":consistency})
        return self.get(cid)

    def get(self,cid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM checkpoints WHERE checkpoint_id=?",(cid,)).fetchone()
        if r is None:raise CheckpointError(f"Unknown checkpoint: {cid}")
        return Checkpoint(r["checkpoint_id"],r["owner_type"],r["owner_id"],r["state_label"],r["created_unix"],
          r["payload_path"],r["sha256"],r["size_bytes"],r["consistency"],json.loads(r["metadata_json"]))

    def list(self,owner_type=None,owner_id=None,limit=200):
        sql="SELECT checkpoint_id FROM checkpoints";args=[];where=[]
        if owner_type is not None:where.append("owner_type=?");args.append(owner_type)
        if owner_id is not None:where.append("owner_id=?");args.append(owner_id)
        if where:sql+=" WHERE "+" AND ".join(where)
        sql+=" ORDER BY created_unix DESC LIMIT ?";args.append(int(limit))
        with self.db._connect() as c:ids=[r["checkpoint_id"] for r in c.execute(sql,args).fetchall()]
        return tuple(self.get(i) for i in ids)

    def verify(self,cid):
        cp=self.get(cid);p=Path(cp.payload_path)
        if not p.is_file():return False,"payload missing"
        h=hashlib.sha256();size=0
        with p.open("rb") as f:
            for block in iter(lambda:f.read(1024*1024),b""):
                h.update(block);size+=len(block)
        if size!=cp.size_bytes:return False,"size mismatch"
        if h.hexdigest()!=cp.sha256:return False,"sha256 mismatch"
        return True,"ok"

    def restore_copy(self,cid,destination:Path):
        cp=self.get(cid);ok,msg=self.verify(cid)
        if not ok:raise CheckpointError(f"checkpoint integrity failure: {msg}")
        dst=Path(destination);dst.parent.mkdir(parents=True,exist_ok=True)
        tmp=dst.with_name(dst.name+f".{cid}.tmp")
        shutil.copyfile(cp.payload_path,tmp)
        with tmp.open("rb") as h:os.fsync(h.fileno())
        os.replace(tmp,dst)
        self.audit.append("INFO","checkpoint","restored_copy",subject=cid,details={"destination":str(dst)})
        return dst
