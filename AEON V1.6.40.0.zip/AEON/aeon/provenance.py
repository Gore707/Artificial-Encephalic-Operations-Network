from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib
import json
import os
import shutil
import time
import uuid

PROVENANCE_CLASSES = (
    "MEASURED",
    "DERIVED",
    "INFERRED",
    "AI-RECONSTRUCTED",
    "UNKNOWN",
)


class ProvenanceError(RuntimeError):
    pass


@dataclass(frozen=True)
class ProvenanceRecord:
    record_id: str
    object_id: str
    classification: str
    parent_object_id: str | None
    operation: str
    agent: str
    confidence: float | None
    evidence: dict[str, Any]
    created_unix: float


class ImmutableSourceStore:
    """Content-addressed immutable source storage for AEON.

    Files are copied into AEON-controlled storage under their SHA-256 digest.
    Existing content is verified before reuse. Stored files are marked read-only;
    integrity is enforced cryptographically rather than relying on permissions.
    """

    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def fingerprint(path: Path, chunk_size: int = 1024 * 1024) -> tuple[str, int]:
        h = hashlib.sha256()
        size = 0
        with Path(path).open("rb") as stream:
            while True:
                block = stream.read(chunk_size)
                if not block:
                    break
                h.update(block)
                size += len(block)
        return h.hexdigest(), size

    def path_for(self, digest: str) -> Path:
        if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest.lower()):
            raise ProvenanceError("Invalid SHA-256 digest")
        return self.root / digest[:2] / digest[2:4] / digest.lower()

    def ingest(self, source: Path) -> tuple[Path, str, int]:
        source = Path(source).expanduser().resolve()
        if not source.is_file():
            raise ProvenanceError(f"Source file does not exist: {source}")
        digest, size = self.fingerprint(source)
        target = self.path_for(digest)
        target.parent.mkdir(parents=True, exist_ok=True)

        if target.exists():
            existing_digest, existing_size = self.fingerprint(target)
            if existing_digest != digest or existing_size != size:
                raise ProvenanceError("Immutable store collision/integrity failure")
            return target, digest, size

        tmp = target.with_name(target.name + ".tmp-" + uuid.uuid4().hex)
        try:
            with source.open("rb") as src, tmp.open("xb") as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)
                dst.flush()
                os.fsync(dst.fileno())
            copied_digest, copied_size = self.fingerprint(tmp)
            if copied_digest != digest or copied_size != size:
                raise ProvenanceError("Source changed or copy verification failed during ingest")
            os.replace(tmp, target)
            try:
                target.chmod(0o444)
            except OSError:
                pass
        finally:
            if tmp.exists():
                tmp.unlink(missing_ok=True)
        return target, digest, size

    def verify(self, digest: str) -> tuple[bool, str]:
        target = self.path_for(digest)
        if not target.is_file():
            return False, "Immutable source blob is missing"
        actual, _ = self.fingerprint(target)
        if actual != digest.lower():
            return False, "Immutable source blob failed SHA-256 verification"
        return True, "Immutable source blob verified"


class ProvenanceStore:
    def __init__(self, state_db):
        self.db = state_db
        self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS provenance_records (
                    record_id TEXT PRIMARY KEY,
                    object_id TEXT NOT NULL,
                    classification TEXT NOT NULL,
                    parent_object_id TEXT,
                    operation TEXT NOT NULL,
                    agent TEXT NOT NULL,
                    confidence REAL,
                    evidence_json TEXT NOT NULL,
                    created_unix REAL NOT NULL,
                    FOREIGN KEY(object_id) REFERENCES data_objects(object_id)
                        ON DELETE CASCADE,
                    FOREIGN KEY(parent_object_id) REFERENCES data_objects(object_id)
                        ON DELETE RESTRICT
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_provenance_object
                ON provenance_records(object_id, created_unix)
            """)

    def record(
        self,
        object_id: str,
        classification: str,
        *,
        operation: str,
        agent: str,
        parent_object_id: str | None = None,
        confidence: float | None = None,
        evidence: dict[str, Any] | None = None,
    ) -> ProvenanceRecord:
        classification = classification.strip().upper()
        if classification not in PROVENANCE_CLASSES:
            raise ProvenanceError(f"Invalid provenance classification: {classification}")
        operation = operation.strip()
        agent = agent.strip()
        if not operation or not agent:
            raise ProvenanceError("operation and agent are required")
        if confidence is not None and not (0.0 <= confidence <= 1.0):
            raise ProvenanceError("confidence must be between 0 and 1")

        encoded = json.dumps(dict(evidence or {}), separators=(",", ":"), ensure_ascii=False)
        record_id = "prov-" + uuid.uuid4().hex
        created = time.time()

        with self.db.transaction() as conn:
            if conn.execute("SELECT 1 FROM data_objects WHERE object_id=?", (object_id,)).fetchone() is None:
                raise ProvenanceError(f"Unknown data object: {object_id}")
            if parent_object_id and conn.execute(
                "SELECT 1 FROM data_objects WHERE object_id=?", (parent_object_id,)
            ).fetchone() is None:
                raise ProvenanceError(f"Unknown parent data object: {parent_object_id}")
            conn.execute("""
                INSERT INTO provenance_records(
                    record_id, object_id, classification, parent_object_id,
                    operation, agent, confidence, evidence_json, created_unix
                ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                record_id, object_id, classification, parent_object_id,
                operation, agent, confidence, encoded, created
            ))
        return self.get(record_id)

    def get(self, record_id: str) -> ProvenanceRecord:
        with self.db._connect() as conn:
            row = conn.execute(
                "SELECT * FROM provenance_records WHERE record_id=?", (record_id,)
            ).fetchone()
        if row is None:
            raise ProvenanceError(f"Unknown provenance record: {record_id}")
        return self._row(row)

    def history(self, object_id: str) -> tuple[ProvenanceRecord, ...]:
        with self.db._connect() as conn:
            rows = conn.execute("""
                SELECT * FROM provenance_records
                WHERE object_id=? ORDER BY created_unix, record_id
            """, (object_id,)).fetchall()
        return tuple(self._row(row) for row in rows)

    def _row(self, row) -> ProvenanceRecord:
        return ProvenanceRecord(
            record_id=row["record_id"],
            object_id=row["object_id"],
            classification=row["classification"],
            parent_object_id=row["parent_object_id"],
            operation=row["operation"],
            agent=row["agent"],
            confidence=row["confidence"],
            evidence=json.loads(row["evidence_json"]),
            created_unix=float(row["created_unix"]),
        )
