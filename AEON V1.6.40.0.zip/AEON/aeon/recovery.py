from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,os,shutil,time,uuid

class RecoveryError(RuntimeError):pass

@dataclass(frozen=True)
class RecoveryEvent:
    recovery_id:str;backup_id:str;target_path:str;pre_recovery_backup_id:str|None
    restored_sha256:str;created_unix:float;status:str

class RecoveryManager:
    """Verified rollback coordinator.

    Recovery never trusts a backup merely because it exists. The selected
    backup is verified first, the current target is preserved through P021,
    replacement is atomic, and the restored bytes are verified again.
    """
    def __init__(self,db,audit,transactional_files):
        self.db=db;self.audit=audit;self.files=transactional_files;self._ensure_schema()

    def _ensure_schema(self):
        with self.db.transaction() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS recovery_events(
             recovery_id TEXT PRIMARY KEY,backup_id TEXT NOT NULL,target_path TEXT NOT NULL,
             pre_recovery_backup_id TEXT,restored_sha256 TEXT NOT NULL,
             created_unix REAL NOT NULL,status TEXT NOT NULL)""")

    def rollback(self,backup_id,expected_current_sha256=None):
        backup=self.files.get(backup_id)
        ok,msg=self.files.verify_backup(backup_id)
        if not ok:
            self.audit.append("CRITICAL","recovery","backup_rejected",subject=backup_id,
                              details={"reason":msg})
            raise RecoveryError(f"backup failed integrity verification: {msg}")
        src=Path(backup.backup_path);target=Path(backup.target_path)
        data=src.read_bytes()
        if hashlib.sha256(data).hexdigest()!=backup.sha256:
            raise RecoveryError("backup changed during recovery read")
        rid="rec-"+uuid.uuid4().hex
        self.audit.append("WARNING","recovery","rollback_started",subject=rid,
                          details={"backup_id":backup_id,"target":str(target)})
        try:
            prior=self.files.write_bytes(target,data,expected_current_sha256)
            restored=self._hash(target)
            if restored!=backup.sha256:
                raise RecoveryError("post-rollback verification failed")
            now=time.time()
            with self.db.transaction() as c:
                c.execute("INSERT INTO recovery_events VALUES(?,?,?,?,?,?,?)",
                          (rid,backup_id,str(target),prior.backup_id if prior else None,
                           restored,now,"SUCCEEDED"))
            self.audit.append("INFO","recovery","rollback_succeeded",subject=rid,
                              details={"backup_id":backup_id,
                                       "pre_recovery_backup_id":prior.backup_id if prior else None,
                                       "restored_sha256":restored})
            return self.get(rid)
        except Exception as exc:
            self.audit.append("CRITICAL","recovery","rollback_failed",subject=rid,
                              details={"backup_id":backup_id,"error":str(exc)})
            raise

    def get(self,rid):
        with self.db._connect() as c:r=c.execute("SELECT * FROM recovery_events WHERE recovery_id=?",(rid,)).fetchone()
        if r is None:raise RecoveryError(f"Unknown recovery event: {rid}")
        return RecoveryEvent(r["recovery_id"],r["backup_id"],r["target_path"],r["pre_recovery_backup_id"],
                             r["restored_sha256"],r["created_unix"],r["status"])

    def list(self,limit=200):
        with self.db._connect() as c:
            ids=[r["recovery_id"] for r in c.execute(
                "SELECT recovery_id FROM recovery_events ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
        return tuple(self.get(i) for i in ids)

    @staticmethod
    def _hash(path):
        h=hashlib.sha256()
        with Path(path).open("rb") as f:
            for block in iter(lambda:f.read(1024*1024),b""):h.update(block)
        return h.hexdigest()
