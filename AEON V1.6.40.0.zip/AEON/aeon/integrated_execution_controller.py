from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class IntegratedExecutionError(RuntimeError):pass

@dataclass(frozen=True)
class IntegratedRun:
 run_id:str;created_unix:float;subject_id:str;certificate_id:str;admission_id:str;status:str;evidence_sha256:str

class IntegratedExecutionController:
 """P094 release-candidate execution front door.
 New integrated neural execution must pass P093 admission before a run record can enter ADMITTED state.
 This controller intentionally does not claim every legacy API has been removed or made private.
 """
 def __init__(self,db,audit,admission,safety_gate):
  self.db=db;self.audit=audit;self.admission=admission;self.safety_gate=safety_gate;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p094_integrated_runs(
   run_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,subject_id TEXT NOT NULL,certificate_id TEXT NOT NULL,
   admission_id TEXT NOT NULL,status TEXT NOT NULL,evidence_sha256 TEXT NOT NULL)""")
 def admit(self,subject_id,subject_bytes,certificate_id):
  decision=self.admission.admit(subject_id,subject_bytes,certificate_id)
  payload={"subject_id":str(subject_id),"certificate_id":str(certificate_id),"admission_id":decision.admission_id,"status":"ADMITTED"}
  sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest();rid="p094-"+uuid.uuid4().hex
  with self.db.transaction() as c:c.execute("INSERT INTO p094_integrated_runs VALUES(?,?,?,?,?,?,?)",(rid,time.time(),str(subject_id),str(certificate_id),decision.admission_id,"ADMITTED",sha))
  self.audit.append("INFO","integration.p094","run_admitted",subject=rid,details=payload);return self.get(rid)
 def require_runnable(self,run_id):
  r=self.get(run_id)
  if r.status!="ADMITTED":raise IntegratedExecutionError("run is not admitted")
  self.safety_gate.require_clear("NEW_WORK","GENESIS_EXECUTION","WATCHDOG")
  payload={"subject_id":r.subject_id,"certificate_id":r.certificate_id,"admission_id":r.admission_id,"status":r.status}
  sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
  if sha!=r.evidence_sha256:raise IntegratedExecutionError("integrated run evidence integrity failure")
  return True
 def transition(self,run_id,status):
  target=str(status).upper()
  if target not in {"RUNNING","CHECKPOINTED","COMPLETED","HALTED"}:raise IntegratedExecutionError("invalid integrated run transition")
  if target=="RUNNING":self.require_runnable(run_id)
  with self.db.transaction() as c:
   r=c.execute("SELECT * FROM p094_integrated_runs WHERE run_id=?",(run_id,)).fetchone()
   if r is None:raise IntegratedExecutionError("unknown integrated run")
   payload={"subject_id":r["subject_id"],"certificate_id":r["certificate_id"],"admission_id":r["admission_id"],"status":target}
   sha=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
   c.execute("UPDATE p094_integrated_runs SET status=?,evidence_sha256=? WHERE run_id=?",(target,sha,run_id))
  self.audit.append("INFO","integration.p094","run_transition",subject=run_id,details={"status":target});return self.get(run_id)
 def get(self,run_id):
  with self.db._connect() as c:r=c.execute("SELECT * FROM p094_integrated_runs WHERE run_id=?",(run_id,)).fetchone()
  if r is None:raise IntegratedExecutionError("unknown integrated run")
  return IntegratedRun(r["run_id"],r["created_unix"],r["subject_id"],r["certificate_id"],r["admission_id"],r["status"],r["evidence_sha256"])
 def readiness(self):
  return {"phase":"FULL-SYSTEM INTEGRATION / RC I","front_door":"P094 IntegratedExecutionController",
   "enforced":["P093 deterministic execution admission","P092 exact-state Genesis certificate","P091 persistent safety gates","watchdog gate re-check before RUNNING","integrity-bound run lifecycle"],
   "remaining":["legacy execution API audit/wiring","release-candidate end-to-end qualification","remaining known foundation debt not directly closed by P091-P094"],
   "claim":"P094 establishes the integrated guarded execution path; it does not claim all historical/legacy execution paths are yet impossible to call directly."}
