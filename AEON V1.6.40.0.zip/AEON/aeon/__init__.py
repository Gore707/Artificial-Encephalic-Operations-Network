"""AEON — Artificial Encephalic Operations Network."""
__version__ = "1.64.0"
