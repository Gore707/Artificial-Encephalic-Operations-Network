from __future__ import annotations
from dataclasses import dataclass
import json,math,time,uuid,statistics

class CognitiveAnomalyError(RuntimeError):pass

@dataclass(frozen=True)
class CognitiveObservation:
 observation_id:str;created_unix:float;stream_id:str;metric:str;value:float;unit:str
 provenance:str;confidence:float;source_ref:str

@dataclass(frozen=True)
class CognitiveAnomaly:
 anomaly_id:str;created_unix:float;stream_id:str;metric:str;severity:str;method:str
 score:float;confidence:float;observation_id:str;details:dict

class CognitiveAnomalyDetector:
 """Non-mutating cognitive/neural anomaly analytics. Detection is evidence, not permission to rewrite state."""
 PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")
 SEVERITY=("ADVISORY","WARNING","CRITICAL")
 def __init__(self,db,audit):
  self.db=db;self.audit=audit;self._schema()
 def _schema(self):
  with self.db.transaction() as c:
   c.execute("""CREATE TABLE IF NOT EXISTS cognitive_observations(
    observation_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,stream_id TEXT NOT NULL,metric TEXT NOT NULL,value REAL NOT NULL,
    unit TEXT NOT NULL,provenance TEXT NOT NULL,confidence REAL NOT NULL,source_ref TEXT NOT NULL)""")
   c.execute("""CREATE TABLE IF NOT EXISTS cognitive_anomalies(
    anomaly_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,stream_id TEXT NOT NULL,metric TEXT NOT NULL,severity TEXT NOT NULL,
    method TEXT NOT NULL,score REAL NOT NULL,confidence REAL NOT NULL,observation_id TEXT NOT NULL,details_json TEXT NOT NULL,
    UNIQUE(observation_id,method))""")
 def observe(self,stream_id,metric,value,unit,provenance,confidence,source_ref):
  stream_id=str(stream_id).strip();metric=str(metric).strip();unit=str(unit).strip();prov=str(provenance).upper();source_ref=str(source_ref).strip()
  v=float(value);conf=float(confidence)
  if not stream_id or not metric or not unit or not source_ref:raise CognitiveAnomalyError("stream, metric, unit and source_ref required")
  if prov not in self.PROVENANCE:raise CognitiveAnomalyError("invalid provenance")
  if not math.isfinite(v) or not math.isfinite(conf) or not 0<=conf<=1:raise CognitiveAnomalyError("invalid numeric observation")
  oid="cogobs-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_observations VALUES(?,?,?,?,?,?,?,?,?)",(oid,now,stream_id,metric,v,unit,prov,conf,source_ref))
  return self.get_observation(oid)
 def get_observation(self,oid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_observations WHERE observation_id=?",(oid,)).fetchone()
  if r is None:raise CognitiveAnomalyError("unknown observation")
  return CognitiveObservation(r["observation_id"],r["created_unix"],r["stream_id"],r["metric"],r["value"],r["unit"],r["provenance"],r["confidence"],r["source_ref"])
 def _history(self,o,limit):
  with self.db._connect() as c:
   rows=c.execute("""SELECT value FROM cognitive_observations WHERE stream_id=? AND metric=? AND unit=? AND observation_id<>?
    ORDER BY created_unix DESC LIMIT ?""",(o.stream_id,o.metric,o.unit,o.observation_id,int(limit))).fetchall()
  return [float(r["value"]) for r in reversed(rows)]
 def detect_robust_z(self,observation_id,window=32,minimum_history=5,warning_z=3.5,critical_z=6.0):
  o=self.get_observation(observation_id);window=int(window);minimum_history=int(minimum_history)
  if window<minimum_history or minimum_history<3:raise CognitiveAnomalyError("invalid history configuration")
  wz=float(warning_z);cz=float(critical_z)
  if not 0<wz<cz:raise CognitiveAnomalyError("thresholds must satisfy 0 < warning < critical")
  hist=self._history(o,window)
  if len(hist)<minimum_history:return None
  med=statistics.median(hist);dev=[abs(x-med) for x in hist];mad=statistics.median(dev)
  if mad==0:
   score=0.0 if o.value==med else float("inf")
  else:score=abs(0.6744897501960817*(o.value-med)/mad)
  if score<wz:return None
  sev="CRITICAL" if score>=cz else "WARNING"
  confidence=min(o.confidence, min(1.0,len(hist)/max(window,1)))
  details={"history_count":len(hist),"median":med,"mad":mad,"warning_z":wz,"critical_z":cz,"provenance":o.provenance,"source_ref":o.source_ref}
  with self.db.transaction() as c:
   existing=c.execute("SELECT anomaly_id FROM cognitive_anomalies WHERE observation_id=? AND method=?",(o.observation_id,"ROBUST_Z_MAD")).fetchone()
   if existing:return self.get_anomaly(existing["anomaly_id"])
   aid="coganom-"+uuid.uuid4().hex;c.execute("INSERT INTO cognitive_anomalies VALUES(?,?,?,?,?,?,?,?,?,?)",
    (aid,time.time(),o.stream_id,o.metric,sev,"ROBUST_Z_MAD",score,confidence,o.observation_id,json.dumps(details,sort_keys=True)))
  self.audit.append(sev,"cognitive_guardian.anomaly","detected",subject=aid,details={"metric":o.metric,"score":score,"provenance":o.provenance})
  return self.get_anomaly(aid)
 def get_anomaly(self,aid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_anomalies WHERE anomaly_id=?",(aid,)).fetchone()
  if r is None:raise CognitiveAnomalyError("unknown anomaly")
  return CognitiveAnomaly(r["anomaly_id"],r["created_unix"],r["stream_id"],r["metric"],r["severity"],r["method"],r["score"],r["confidence"],r["observation_id"],json.loads(r["details_json"]))
 def list_anomalies(self,limit=250):
  with self.db._connect() as c:ids=[r["anomaly_id"] for r in c.execute("SELECT anomaly_id FROM cognitive_anomalies ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get_anomaly(x) for x in ids)
 def summary(self):
  with self.db._connect() as c:
   obs=c.execute("SELECT COUNT(*) n FROM cognitive_observations").fetchone()["n"];anom=c.execute("SELECT COUNT(*) n FROM cognitive_anomalies").fetchone()["n"]
  return {"observations":obs,"anomalies":anom,"method":"ROBUST_Z_MAD",
   "note":"Anomalies are analytical findings with provenance/confidence. They do not authorize automatic modification of cognitive state."}
