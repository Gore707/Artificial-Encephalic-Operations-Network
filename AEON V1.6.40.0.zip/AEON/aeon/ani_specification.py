from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class ANISpecificationError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")
ANI_SCHEMA="AEON-ANI"
ANI_SCHEMA_VERSION="1.0"
STATE_DOMAINS=("TOPOLOGY","SYNAPTIC","DYNAMIC","CELLULAR","MOLECULAR","GLIAL","GENE_EXPRESSION","EPIGENETIC","OTHER")

@dataclass(frozen=True)
class ANIField:
 field_id:str;domain:str;name:str;unit:str;value_type:str;required:bool;provenance:str;confidence:float|None;source_ref:str|None;description:str

@dataclass(frozen=True)
class ANISpecification:
 ani_spec_id:str;created_unix:float;name:str;schema_name:str;schema_version:str;source_connectome_id:str|None
 fields:tuple[ANIField,...];unmeasured_domains:tuple[str,...];assumptions:tuple[str,...];source_hashes:tuple[tuple[str,str],...];definition_sha256:str

class ANISpecificationService:
 """Versioned ANI schema manifest; specification is not an executable neural state."""
 def __init__(self,db,audit,connectomes):
  self.db=db;self.audit=audit;self.connectomes=connectomes;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS ani_specifications(
   ani_spec_id TEXT PRIMARY KEY,created_unix REAL NOT NULL,name TEXT NOT NULL,schema_name TEXT NOT NULL,
   schema_version TEXT NOT NULL,source_connectome_id TEXT,fields_json TEXT NOT NULL,unmeasured_domains_json TEXT NOT NULL,
   assumptions_json TEXT NOT NULL,source_hashes_json TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def create(self,name,fields,source_connectome_id=None,unmeasured_domains=(),assumptions=()):
  name=str(name).strip()
  if not name:raise ANISpecificationError("ANI specification name required")
  bindings={}
  if source_connectome_id is not None:
   c=self.connectomes.get(str(source_connectome_id))
   if not self.connectomes.verify(str(source_connectome_id))["all_ok"]:raise ANISpecificationError("source connectome integrity failed")
   bindings["CONNECTOME:"+str(source_connectome_id)]=c.definition_sha256
  out=[];seen=set()
  for raw in fields:
   x=dict(raw);fid=str(x.get("field_id") or ("field-"+uuid.uuid4().hex))
   if fid in seen:raise ANISpecificationError("duplicate ANI field id")
   seen.add(fid);domain=str(x.get("domain","OTHER"))
   if domain not in STATE_DOMAINS:raise ANISpecificationError("invalid ANI state domain")
   prov=str(x.get("provenance","UNKNOWN"))
   if prov not in PROVENANCE:raise ANISpecificationError("invalid provenance")
   conf=x.get("confidence")
   if conf is not None:
    conf=float(conf)
    if not 0<=conf<=1:raise ANISpecificationError("confidence must be within [0,1]")
   nm=str(x.get("name","")).strip();vt=str(x.get("value_type","")).strip()
   if not nm or not vt:raise ANISpecificationError("field name and value_type required")
   out.append(ANIField(fid,domain,nm,str(x.get("unit","")),vt,bool(x.get("required",False)),prov,conf,
                       str(x["source_ref"]) if x.get("source_ref") is not None else None,str(x.get("description",""))))
  if not out:raise ANISpecificationError("at least one ANI field required")
  unknown=tuple(str(x) for x in unmeasured_domains)
  if any(x not in STATE_DOMAINS for x in unknown):raise ANISpecificationError("invalid unmeasured domain")
  payload={"name":name,"schema_name":ANI_SCHEMA,"schema_version":ANI_SCHEMA_VERSION,
   "source_connectome_id":str(source_connectome_id) if source_connectome_id is not None else None,
   "fields":[f.__dict__ for f in out],"unmeasured_domains":unknown,"assumptions":tuple(str(x) for x in assumptions),
   "source_hashes":tuple(sorted(bindings.items()))}
  sha=hashlib.sha256(self._canon(payload).encode()).hexdigest();sid="ani-spec-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO ani_specifications VALUES(?,?,?,?,?,?,?,?,?,?,?)",
   (sid,now,name,ANI_SCHEMA,ANI_SCHEMA_VERSION,payload["source_connectome_id"],json.dumps(payload["fields"],sort_keys=True),
    json.dumps(unknown),json.dumps(payload["assumptions"]),json.dumps(payload["source_hashes"]),sha))
  self.audit.append("INFO","ani.specification","created",subject=sid,details={"fields":len(out),"schema_version":ANI_SCHEMA_VERSION,"definition_sha256":sha})
  return self.get(sid)
 def get(self,sid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM ani_specifications WHERE ani_spec_id=?",(sid,)).fetchone()
  if r is None:raise ANISpecificationError("unknown ANI specification")
  return ANISpecification(r["ani_spec_id"],r["created_unix"],r["name"],r["schema_name"],r["schema_version"],r["source_connectome_id"],
   tuple(ANIField(**x) for x in json.loads(r["fields_json"])),tuple(json.loads(r["unmeasured_domains_json"])),
   tuple(json.loads(r["assumptions_json"])),tuple(tuple(x) for x in json.loads(r["source_hashes_json"])),r["definition_sha256"])
 def verify(self,sid):
  q=self.get(sid);source_ok=True
  for key,sha in q.source_hashes:
   try:
    if key.startswith("CONNECTOME:"):
     rid=key.split(":",1)[1];obj=self.connectomes.get(rid);source_ok &= obj.definition_sha256==sha and self.connectomes.verify(rid)["all_ok"]
   except Exception:source_ok=False
  payload={"name":q.name,"schema_name":q.schema_name,"schema_version":q.schema_version,"source_connectome_id":q.source_connectome_id,
   "fields":[f.__dict__ for f in q.fields],"unmeasured_domains":q.unmeasured_domains,"assumptions":q.assumptions,"source_hashes":q.source_hashes}
  definition_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.definition_sha256
  return {"definition_ok":definition_ok,"source_ok":bool(source_ok),"all_ok":definition_ok and bool(source_ok)}
 def completeness(self,sid):
  q=self.get(sid);domains={f.domain for f in q.fields}
  return {"represented_domains":tuple(sorted(domains)),"explicitly_unmeasured":q.unmeasured_domains,
   "required_unknown_fields":tuple(f.field_id for f in q.fields if f.required and f.provenance=="UNKNOWN"),
   "information_sufficiency":"UNDETERMINED",
   "note":"ANI schema coverage is not proof that captured fields constitute Minimum Sufficient Cognitive State."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["ani_spec_id"] for r in c.execute("SELECT ani_spec_id FROM ani_specifications ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
