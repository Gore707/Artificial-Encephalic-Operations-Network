from __future__ import annotations
from dataclasses import dataclass
import time

class WatchdogInterlockError(RuntimeError):pass

@dataclass(frozen=True)
class WatchdogState:
 worker_id:str;last_heartbeat_unix:float;timeout_seconds:float;healthy:bool

class IndependentWatchdog:
 """P093 deterministic heartbeat/deadlock interlock.
 Heartbeats are independent records; timeout evaluation places a persistent safety hold.
 """
 def __init__(self,db,audit,safety_gate):
  self.db=db;self.audit=audit;self.safety_gate=safety_gate;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS p093_watchdog_heartbeats(
   worker_id TEXT PRIMARY KEY,last_heartbeat_unix REAL NOT NULL,timeout_seconds REAL NOT NULL)""")
 def register(self,worker_id,timeout_seconds=10.0,now=None):
  w=str(worker_id).strip();t=float(timeout_seconds)
  if not w or t<=0:raise WatchdogInterlockError("worker and positive timeout required")
  ts=time.time() if now is None else float(now)
  with self.db.transaction() as c:c.execute("""INSERT INTO p093_watchdog_heartbeats VALUES(?,?,?)
   ON CONFLICT(worker_id) DO UPDATE SET last_heartbeat_unix=excluded.last_heartbeat_unix,timeout_seconds=excluded.timeout_seconds""",(w,ts,t))
  return self.state(w,ts)
 def heartbeat(self,worker_id,now=None):
  w=str(worker_id).strip();ts=time.time() if now is None else float(now)
  with self.db.transaction() as c:
   r=c.execute("SELECT timeout_seconds FROM p093_watchdog_heartbeats WHERE worker_id=?",(w,)).fetchone()
   if r is None:raise WatchdogInterlockError("worker not registered")
   c.execute("UPDATE p093_watchdog_heartbeats SET last_heartbeat_unix=? WHERE worker_id=?",(ts,w))
  return self.state(w,ts)
 def state(self,worker_id,now=None):
  w=str(worker_id).strip();ts=time.time() if now is None else float(now)
  with self.db._connect() as c:r=c.execute("SELECT * FROM p093_watchdog_heartbeats WHERE worker_id=?",(w,)).fetchone()
  if r is None:raise WatchdogInterlockError("worker not registered")
  return WatchdogState(w,r["last_heartbeat_unix"],r["timeout_seconds"],ts-r["last_heartbeat_unix"]<=r["timeout_seconds"])
 def evaluate(self,now=None):
  ts=time.time() if now is None else float(now);stale=[]
  with self.db._connect() as c:rows=c.execute("SELECT * FROM p093_watchdog_heartbeats").fetchall()
  for r in rows:
   if ts-r["last_heartbeat_unix"]>r["timeout_seconds"]:stale.append(r["worker_id"])
  if stale:self.safety_gate.hold("WATCHDOG","stale heartbeat: "+",".join(sorted(stale)),"SAFETY_KERNEL")
  self.audit.append("WARNING" if stale else "INFO","safety.p093","watchdog_evaluate",details={"stale_workers":sorted(stale)})
  return {"healthy":not stale,"stale_workers":sorted(stale),"evaluated_unix":ts}
