from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid

class ANIManagerError(RuntimeError):pass

@dataclass(frozen=True)
class ANIImage:
 ani_id:str;name:str;created_unix:float;ani_spec_id:str;topology_id:str;synaptic_state_id:str|None
 dynamic_state_id:str|None;reconstruction_metadata_id:str|None;source_hashes:tuple[tuple[str,str],...]
 manifest_sha256:str;status:str

class ANIManager:
 """Assembles immutable-by-reference ANI manifests from verified components."""
 def __init__(self,db,audit,specs,topologies,synaptic,dynamic,metadata):
  self.db=db;self.audit=audit;self.specs=specs;self.topologies=topologies;self.synaptic=synaptic;self.dynamic=dynamic;self.metadata=metadata;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS ani_images(
   ani_id TEXT PRIMARY KEY,name TEXT NOT NULL,created_unix REAL NOT NULL,ani_spec_id TEXT NOT NULL,topology_id TEXT NOT NULL,
   synaptic_state_id TEXT,dynamic_state_id TEXT,reconstruction_metadata_id TEXT,source_hashes_json TEXT NOT NULL,
   manifest_sha256 TEXT NOT NULL,status TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 def create(self,name,ani_spec_id,topology_id,synaptic_state_id=None,dynamic_state_id=None,reconstruction_metadata_id=None):
  name=str(name).strip()
  if not name:raise ANIManagerError("ANI name required")
  sp=self.specs.get(ani_spec_id);tp=self.topologies.get(topology_id)
  if not self.specs.verify(ani_spec_id)["all_ok"] or not self.topologies.verify(topology_id)["all_ok"]:raise ANIManagerError("ANI source integrity failed")
  if tp.ani_spec_id!=ani_spec_id:raise ANIManagerError("topology belongs to another ANI specification")
  bindings={"ANI_SPEC:"+ani_spec_id:sp.definition_sha256,"TOPOLOGY:"+topology_id:tp.definition_sha256}
  if synaptic_state_id is not None:
   sy=self.synaptic.get(str(synaptic_state_id))
   if sy.topology_id!=topology_id or not self.synaptic.verify(str(synaptic_state_id))["all_ok"]:raise ANIManagerError("synaptic state binding failed")
   bindings["SYNAPTIC:"+str(synaptic_state_id)]=sy.definition_sha256
  if dynamic_state_id is not None:
   dy=self.dynamic.get(str(dynamic_state_id))
   if dy.topology_id!=topology_id or not self.dynamic.verify(str(dynamic_state_id))["all_ok"]:raise ANIManagerError("dynamic state binding failed")
   if synaptic_state_id is not None and dy.synaptic_state_id not in (None,str(synaptic_state_id)):raise ANIManagerError("dynamic/synaptic binding mismatch")
   bindings["DYNAMIC:"+str(dynamic_state_id)]=dy.definition_sha256
  if reconstruction_metadata_id is not None:
   md=self.metadata.get(str(reconstruction_metadata_id))
   if md.ani_spec_id!=ani_spec_id or not self.metadata.verify(str(reconstruction_metadata_id))["all_ok"]:raise ANIManagerError("reconstruction metadata binding failed")
   if md.topology_id not in (None,topology_id):raise ANIManagerError("metadata/topology binding mismatch")
   bindings["METADATA:"+str(reconstruction_metadata_id)]=md.definition_sha256
  payload={"name":name,"ani_spec_id":ani_spec_id,"topology_id":topology_id,
   "synaptic_state_id":str(synaptic_state_id) if synaptic_state_id is not None else None,
   "dynamic_state_id":str(dynamic_state_id) if dynamic_state_id is not None else None,
   "reconstruction_metadata_id":str(reconstruction_metadata_id) if reconstruction_metadata_id is not None else None,
   "source_hashes":tuple(sorted(bindings.items()))}
  sha=hashlib.sha256(self._canon(payload).encode()).hexdigest();aid="ani-"+uuid.uuid4().hex;now=time.time()
  # CREATED means assembled and integrity-bound, not executable or Genesis-qualified.
  with self.db.transaction() as c:c.execute("INSERT INTO ani_images VALUES(?,?,?,?,?,?,?,?,?,?,?)",
   (aid,name,now,ani_spec_id,topology_id,payload["synaptic_state_id"],payload["dynamic_state_id"],
    payload["reconstruction_metadata_id"],json.dumps(payload["source_hashes"]),sha,"CREATED"))
  self.audit.append("INFO","ani.manager","created",subject=aid,details={"manifest_sha256":sha,"status":"CREATED"})
  return self.get(aid)
 def get(self,aid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM ani_images WHERE ani_id=?",(aid,)).fetchone()
  if r is None:raise ANIManagerError("unknown ANI")
  return ANIImage(r["ani_id"],r["name"],r["created_unix"],r["ani_spec_id"],r["topology_id"],r["synaptic_state_id"],
   r["dynamic_state_id"],r["reconstruction_metadata_id"],tuple(tuple(x) for x in json.loads(r["source_hashes_json"])),
   r["manifest_sha256"],r["status"])
 def verify(self,aid):
  q=self.get(aid);services={"ANI_SPEC":self.specs,"TOPOLOGY":self.topologies,"SYNAPTIC":self.synaptic,"DYNAMIC":self.dynamic,"METADATA":self.metadata};source_ok=True
  for key,sha in q.source_hashes:
   try:
    typ,rid=key.split(":",1);svc=services[typ];obj=svc.get(rid);source_ok &= obj.definition_sha256==sha and svc.verify(rid)["all_ok"]
   except Exception:source_ok=False
  payload={"name":q.name,"ani_spec_id":q.ani_spec_id,"topology_id":q.topology_id,"synaptic_state_id":q.synaptic_state_id,
   "dynamic_state_id":q.dynamic_state_id,"reconstruction_metadata_id":q.reconstruction_metadata_id,"source_hashes":q.source_hashes}
  manifest_ok=hashlib.sha256(self._canon(payload).encode()).hexdigest()==q.manifest_sha256
  return {"manifest_ok":manifest_ok,"source_ok":bool(source_ok),"all_ok":manifest_ok and bool(source_ok)}
 def readiness(self,aid):
  q=self.get(aid);sp=self.specs.completeness(q.ani_spec_id);integrity=self.verify(aid)
  return {"integrity":integrity,"has_synaptic_state":q.synaptic_state_id is not None,"has_dynamic_state":q.dynamic_state_id is not None,
   "has_reconstruction_metadata":q.reconstruction_metadata_id is not None,"required_unknown_fields":sp["required_unknown_fields"],
   "information_sufficiency":"UNDETERMINED","genesis_status":"NOT_VALIDATED",
   "executable":False,
   "note":"ANI assembly does not authorize execution. A future executable state must pass model-aware Genesis validation before tick 0."}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["ani_id"] for r in c.execute("SELECT ani_id FROM ani_images ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
