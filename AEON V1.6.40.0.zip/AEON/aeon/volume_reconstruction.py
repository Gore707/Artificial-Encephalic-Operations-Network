from __future__ import annotations
from dataclasses import dataclass
import hashlib,json,time,uuid,math

class VolumeReconstructionError(RuntimeError):pass
PROVENANCE=("MEASURED","DERIVED","INFERRED","AI-RECONSTRUCTED","UNKNOWN")

@dataclass(frozen=True)
class VolumeReconstruction:
 volume_id:str;imaging_id:str;dataset_id:str;created_unix:float;shape:tuple[int,int,int]
 voxel_size:dict;coordinate_frame:str;transform_chain:tuple[dict,...]
 uncertainty:dict;known_losses:tuple[str,...];provenance:str;source_sha256:str;definition_sha256:str

class VolumeReconstructionService:
 """Persistent volume reconstruction definitions with explicit transforms/losses.
 This patch defines and validates reconstruction geometry; it does not fabricate voxels.
 """
 def __init__(self,db,audit,data_lab,neuroimaging):
  self.db=db;self.audit=audit;self.data_lab=data_lab;self.neuroimaging=neuroimaging;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS cognitive_injection_volumes(
   volume_id TEXT PRIMARY KEY,imaging_id TEXT NOT NULL,dataset_id TEXT NOT NULL,created_unix REAL NOT NULL,
   shape_json TEXT NOT NULL,voxel_size_json TEXT NOT NULL,coordinate_frame TEXT NOT NULL,
   transform_chain_json TEXT NOT NULL,uncertainty_json TEXT NOT NULL,known_losses_json TEXT NOT NULL,
   provenance TEXT NOT NULL,source_sha256 TEXT NOT NULL,definition_sha256 TEXT NOT NULL)""")
 @staticmethod
 def _canon(x):return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)
 @staticmethod
 def _shape(v):
  try:q=tuple(int(x) for x in v)
  except Exception as exc:raise VolumeReconstructionError("shape must contain three integers") from exc
  if len(q)!=3 or any(x<=0 for x in q):raise VolumeReconstructionError("shape must be three positive integers")
  return q
 def define(self,imaging_id,shape,voxel_size,coordinate_frame,transform_chain=(),uncertainty=None,known_losses=(),provenance="DERIVED"):
  if provenance not in PROVENANCE:raise VolumeReconstructionError("invalid provenance")
  img=self.neuroimaging.get(imaging_id);verify=self.neuroimaging.verify(imaging_id)
  if not verify["all_ok"]:raise VolumeReconstructionError("source imaging record failed integrity verification")
  qshape=self._shape(shape);vox=dict(voxel_size or {})
  if not vox:raise VolumeReconstructionError("voxel size metadata required")
  for k,v in vox.items():
   if isinstance(v,(int,float)) and (not math.isfinite(float(v)) or float(v)<=0):raise VolumeReconstructionError("voxel dimensions must be positive finite values")
  frame=str(coordinate_frame).strip()
  if not frame:raise VolumeReconstructionError("coordinate frame required")
  chain=tuple(dict(x) for x in transform_chain);loss=tuple(str(x) for x in known_losses);unc=dict(uncertainty or {})
  payload={"imaging_id":imaging_id,"dataset_id":img.dataset_id,"shape":qshape,"voxel_size":vox,"coordinate_frame":frame,
   "transform_chain":chain,"uncertainty":unc,"known_losses":loss,"provenance":provenance,"source_sha256":img.source_sha256}
  try:raw=self._canon(payload)
  except (TypeError,ValueError) as exc:raise VolumeReconstructionError("volume definition must be JSON-serializable") from exc
  sha=hashlib.sha256(raw.encode("utf-8")).hexdigest();vid="vol-"+uuid.uuid4().hex;now=time.time()
  with self.db.transaction() as c:c.execute("INSERT INTO cognitive_injection_volumes VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
   (vid,imaging_id,img.dataset_id,now,json.dumps(qshape),json.dumps(vox,sort_keys=True),frame,json.dumps(chain,sort_keys=True),
    json.dumps(unc,sort_keys=True),json.dumps(loss),provenance,img.source_sha256,sha))
  self.audit.append("INFO","cognitive_injection.volume","defined",subject=vid,
   details={"imaging_id":imaging_id,"dataset_id":img.dataset_id,"shape":qshape,"provenance":provenance,"definition_sha256":sha})
  return self.get(vid)
 def get(self,vid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM cognitive_injection_volumes WHERE volume_id=?",(vid,)).fetchone()
  if r is None:raise VolumeReconstructionError("unknown volume")
  return VolumeReconstruction(r["volume_id"],r["imaging_id"],r["dataset_id"],r["created_unix"],tuple(json.loads(r["shape_json"])),
   json.loads(r["voxel_size_json"]),r["coordinate_frame"],tuple(json.loads(r["transform_chain_json"])),
   json.loads(r["uncertainty_json"]),tuple(json.loads(r["known_losses_json"])),r["provenance"],r["source_sha256"],r["definition_sha256"])
 def verify(self,vid):
  q=self.get(vid);img=self.neuroimaging.get(q.imaging_id)
  payload={"imaging_id":q.imaging_id,"dataset_id":q.dataset_id,"shape":q.shape,"voxel_size":q.voxel_size,
   "coordinate_frame":q.coordinate_frame,"transform_chain":q.transform_chain,"uncertainty":q.uncertainty,
   "known_losses":q.known_losses,"provenance":q.provenance,"source_sha256":q.source_sha256}
  definition_ok=hashlib.sha256(self._canon(payload).encode("utf-8")).hexdigest()==q.definition_sha256
  source_ok=img.dataset_id==q.dataset_id and img.source_sha256==q.source_sha256 and self.neuroimaging.verify(q.imaging_id)["all_ok"]
  return {"definition_ok":definition_ok,"source_ok":source_ok,"all_ok":definition_ok and source_ok}
 def list(self,limit=250):
  with self.db._connect() as c:ids=[r["volume_id"] for r in c.execute("SELECT volume_id FROM cognitive_injection_volumes ORDER BY created_unix DESC LIMIT ?",(int(limit),)).fetchall()]
  return tuple(self.get(x) for x in ids)
