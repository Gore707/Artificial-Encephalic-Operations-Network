from __future__ import annotations

from dataclasses import dataclass
import tkinter as tk

from .app_api import AeonApplication, AppContext, AppDescriptor


@dataclass
class WindowRecord:
    descriptor: AppDescriptor
    application: AeonApplication
    frame: tk.Frame
    body: tk.Frame


class WorkspaceWindowManager:
    def __init__(self, host: tk.Widget, *, context_factory, panel: str, accent: str,
                 text: str, logger):
        self.host = host
        self.context_factory = context_factory
        self.panel = panel
        self.accent = accent
        self.text = text
        self.logger = logger
        self._windows: dict[str, WindowRecord] = {}
        self._active: str | None = None

    @property
    def active_app_id(self):
        return self._active

    def open(self, descriptor: AppDescriptor) -> WindowRecord:
        app_id = descriptor.app_id
        if app_id in self._windows:
            self.focus(app_id)
            return self._windows[app_id]

        context = self.context_factory()
        application = descriptor.factory(context)
        if not isinstance(application, AeonApplication):
            raise TypeError(f"{app_id} factory did not return AeonApplication")

        frame = tk.Frame(self.host, bg=self.panel, highlightbackground=self.accent,
                         highlightthickness=1)
        titlebar = tk.Frame(frame, bg=self.panel, height=34)
        titlebar.pack(fill="x")
        tk.Label(titlebar, text=descriptor.title.upper(), bg=self.panel, fg=self.text,
                 font=("Segoe UI", 10, "bold")).pack(side="left", padx=10, pady=7)
        tk.Label(titlebar, text=f"v{descriptor.version}", bg=self.panel, fg=self.accent,
                 font=("Consolas", 8)).pack(side="left", padx=4)
        tk.Button(titlebar, text="×", command=lambda: self.close(app_id),
                  bg=self.panel, fg=self.accent, activebackground=self.accent,
                  activeforeground=self.text, relief="flat", bd=0,
                  font=("Segoe UI", 12, "bold"), cursor="hand2").pack(side="right", padx=6)

        body = tk.Frame(frame, bg=self.panel)
        body.pack(fill="both", expand=True)
        application.build(body)

        record = WindowRecord(descriptor, application, frame, body)
        self._windows[app_id] = record
        self.logger.info("Application opened | app=%s | version=%s", app_id, descriptor.version)
        self.focus(app_id)
        return record

    def focus(self, app_id: str) -> None:
        record = self._windows.get(app_id)
        if record is None:
            return
        for other in self._windows.values():
            other.frame.pack_forget()
        record.frame.pack(fill="both", expand=True)
        self._active = app_id
        record.application.on_focus()
        self.logger.info("Application focused | app=%s", app_id)

    def close(self, app_id: str) -> None:
        record = self._windows.pop(app_id, None)
        if record is None:
            return
        try:
            record.application.on_close()
        finally:
            record.frame.destroy()
        self.logger.info("Application closed | app=%s", app_id)
        self._active = None
        if self._windows:
            self.focus(next(reversed(self._windows)))

    def close_all(self) -> None:
        for app_id in tuple(self._windows):
            self.close(app_id)

    def open_ids(self) -> tuple[str, ...]:
        return tuple(self._windows)
