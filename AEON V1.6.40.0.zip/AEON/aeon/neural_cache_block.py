from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,os,struct,time,uuid,zlib

class NeuralCacheBlockError(RuntimeError):pass

@dataclass(frozen=True)
class NeuralCacheBlock:
 block_id:str;device_id:str;created_unix:float;kind:str;payload_bytes:int;stored_bytes:int;sha256:str;crc32:str;path:str;metadata:dict

class NeuralCacheBlockStore:
 """P076 integrity-protected block representation.
 CRC32 is detection only; SHA-256 provides stronger integrity checking. No corrective ECC claim.
 """
 MAGIC=b"AEONNCB1";VERSION=1
 def __init__(self,db,audit,devices):
  self.db=db;self.audit=audit;self.devices=devices;self._schema()
 def _schema(self):
  with self.db.transaction() as c:c.execute("""CREATE TABLE IF NOT EXISTS neural_cache_blocks(
   block_id TEXT PRIMARY KEY,device_id TEXT NOT NULL,created_unix REAL NOT NULL,kind TEXT NOT NULL,payload_bytes INTEGER NOT NULL,
   stored_bytes INTEGER NOT NULL,sha256 TEXT NOT NULL,crc32 TEXT NOT NULL,path TEXT NOT NULL,metadata_json TEXT NOT NULL)""")
 @staticmethod
 def _crc(data):return f"{zlib.crc32(data)&0xffffffff:08x}"
 def write(self,device_id,payload,kind="NEURAL_STATE",metadata=None):
  d=self.devices.get(device_id)
  if d.status!="ONLINE":raise NeuralCacheBlockError("Neural Cache device is not writable")
  data=bytes(payload);meta=dict(metadata or {});json.dumps(meta)
  header={"version":self.VERSION,"kind":str(kind),"payload_bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"crc32":self._crc(data),"metadata":meta}
  hraw=json.dumps(header,sort_keys=True,separators=(",",":")).encode()
  if len(hraw)>1024*1024:raise NeuralCacheBlockError("block header too large")
  raw=self.MAGIC+struct.pack("!I",len(hraw))+hraw+data
  self.devices.reserve(device_id,len(raw))
  bid="ncblock-"+uuid.uuid4().hex;path=Path(d.root_path)/(bid+".ncb");tmp=path.with_suffix(".tmp")
  try:
   with open(tmp,"xb") as f:
    f.write(raw);f.flush();os.fsync(f.fileno())
   os.replace(tmp,path)
   with self.db.transaction() as c:c.execute("INSERT INTO neural_cache_blocks VALUES(?,?,?,?,?,?,?,?,?,?)",
    (bid,device_id,time.time(),str(kind),len(data),len(raw),header["sha256"],header["crc32"],str(path),json.dumps(meta,sort_keys=True)))
  except Exception:
   try:tmp.unlink(missing_ok=True);path.unlink(missing_ok=True)
   finally:self.devices.release(device_id,len(raw))
   raise
  self.audit.append("INFO","neural_cache.block_store","block_written",subject=bid,details={"device_id":device_id,"payload_bytes":len(data),"kind":str(kind)})
  return self.get(bid)
 def get(self,bid):
  with self.db._connect() as c:r=c.execute("SELECT * FROM neural_cache_blocks WHERE block_id=?",(bid,)).fetchone()
  if r is None:raise NeuralCacheBlockError("unknown Neural Cache block")
  return NeuralCacheBlock(r["block_id"],r["device_id"],r["created_unix"],r["kind"],r["payload_bytes"],r["stored_bytes"],r["sha256"],r["crc32"],r["path"],json.loads(r["metadata_json"]))
 def _decode(self,b):
  raw=Path(b.path).read_bytes()
  if raw[:len(self.MAGIC)]!=self.MAGIC:raise NeuralCacheBlockError("invalid block magic")
  pos=len(self.MAGIC)
  if len(raw)<pos+4:raise NeuralCacheBlockError("truncated block")
  n=struct.unpack("!I",raw[pos:pos+4])[0];pos+=4
  if n<=0 or n>1024*1024 or len(raw)<pos+n:raise NeuralCacheBlockError("invalid block header")
  h=json.loads(raw[pos:pos+n]);data=raw[pos+n:]
  return h,data,len(raw)
 def verify(self,bid):
  b=self.get(bid)
  try:h,data,total=self._decode(b)
  except Exception as e:return {"format_ok":False,"sha256_ok":False,"crc32_ok":False,"size_ok":False,"metadata_ok":False,"all_ok":False,"error":str(e)}
  sha=hashlib.sha256(data).hexdigest();crc=self._crc(data)
  fmt=h.get("version")==self.VERSION and h.get("kind")==b.kind
  size=len(data)==b.payload_bytes==h.get("payload_bytes") and total==b.stored_bytes
  metadata=h.get("metadata")==b.metadata
  return {"format_ok":fmt,"sha256_ok":sha==b.sha256==h.get("sha256"),"crc32_ok":crc==b.crc32==h.get("crc32"),"size_ok":size,"metadata_ok":metadata,
   "all_ok":fmt and sha==b.sha256==h.get("sha256") and crc==b.crc32==h.get("crc32") and size and metadata}
 def read(self,bid):
  v=self.verify(bid)
  if not v["all_ok"]:raise NeuralCacheBlockError("block integrity verification failed")
  return self._decode(self.get(bid))[1]
 def list_blocks(self,device_id=None):
  with self.db._connect() as c:
   if device_id:rows=c.execute("SELECT block_id FROM neural_cache_blocks WHERE device_id=? ORDER BY created_unix",(device_id,)).fetchall()
   else:rows=c.execute("SELECT block_id FROM neural_cache_blocks ORDER BY created_unix").fetchall()
  return tuple(self.get(r["block_id"]) for r in rows)
 def summary(self):
  bs=self.list_blocks();return {"blocks":len(bs),"payload_bytes":sum(b.payload_bytes for b in bs),"stored_bytes":sum(b.stored_bytes for b in bs),
   "integrity":"SHA-256 + CRC32 detection; corrective ECC is not claimed by P076."}
