@echo off
setlocal
cd /d "%~dp0\.."
where py >nul 2>nul || (
  echo Python launcher "py" not found.
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
call ".venv\Scripts\python.exe" -m pip install --upgrade pip
call ".venv\Scripts\python.exe" -m pip install -e ".[dev]"
call ".venv\Scripts\python.exe" -m pytest
