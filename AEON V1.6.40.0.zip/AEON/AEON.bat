@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PYTHON_EXE="
if exist ".venv\Scripts\python.exe" set "PYTHON_EXE=.venv\Scripts\python.exe"
if not defined PYTHON_EXE (
    where py >nul 2>nul && set "PYTHON_EXE=py -3"
)
if not defined PYTHON_EXE (
    where python >nul 2>nul && set "PYTHON_EXE=python"
)
if not defined PYTHON_EXE (
    echo [AEON] Python 3 was not found.
    echo Install Python 3.11 or newer and run AEON.bat again.
    pause
    exit /b 1
)

%PYTHON_EXE% -m aeon.bootstrap %*
set "AEON_EXIT=%ERRORLEVEL%"
if not "%AEON_EXIT%"=="0" (
    echo.
    echo [AEON] Launch failed with exit code %AEON_EXIT%.
    echo Review runtime\logs\aeon.log for details.
    pause
)
exit /b %AEON_EXIT%
